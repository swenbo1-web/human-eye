"""Offline proof, timing, and managed-memory comparison for the frozen recheck."""

from argparse import ArgumentParser
from collections import Counter, defaultdict
from copy import deepcopy
from functools import lru_cache
from hashlib import sha256
import json
from pathlib import Path
from statistics import median
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OLD = HERE.parent / "formal_cost_001" / "formal"
sys.path.insert(0, str(ROOT))

from artifacts.integration.formal_cost_001 import resources
from artifacts.integration.formal_cost_001.latency import MODEL_MEMBERS, PUBLIC_MEMBERS


SEEDS = (20261105, 79463, 310519)
ROLES = ("B", "I")
ORDINALS = range(24)
PAIRS = range(36)
WARM = 5
ARM_KEYS = {(ordinal, pair, role) for ordinal in ORDINALS for pair in PAIRS for role in ROLES}
PAIR_KEYS = {(ordinal, pair) for ordinal in ORDINALS for pair in PAIRS}
BOUNDARIES = {
    "before": ("t0", "t1"), "action": ("t1", "t2"), "feedback": ("t2", "t3"),
    "next": ("t3", "t4"), "continuous_total": ("t0", "t4"),
}
STAMPS = ("t0", "t1", "t2", "t3", "t_next_observed", "t4")
METRICS = dict.fromkeys(resources.MANAGED_HOT_POINTS, 262_144) | {"window_peak": 1_048_576}
PROCESS_FLAGS = ("verified_process", "runtime_matches", "stable_sources", "stable_inputs")
OLD_MANIFEST_SHA = "093a0df0ea941eb7cc6bd1206490627ca8196e0951fff18e6601fb513816e8c7"
OLD_INDEX_SHA = "05d93ebe31677cef58a1d722e8833abbfd3a9a60ec46c34f09bccf8ed493c91a"


def _wire(data):
    return json.dumps(data, sort_keys=True, ensure_ascii=False, allow_nan=False, separators=(",", ":"))


def _read(path, errors):
    try:
        data = json.loads(path.read_bytes())
        if not isinstance(data, dict):
            raise ValueError("expected a JSON object")
        return data
    except (OSError, ValueError) as exc:
        errors.append(f"{path}: {exc}")
        return {}


def _lines(path, errors):
    rows = []
    try:
        with path.open(encoding="utf-8") as stream:
            for line_number, line in enumerate(stream, 1):
                try:
                    row = json.loads(line)
                    if not isinstance(row, dict):
                        raise ValueError("expected a JSON object")
                    rows.append(row)
                except ValueError as exc:
                    errors.append(f"{path}:{line_number}: {exc}")
    except OSError as exc:
        errors.append(f"{path}: {exc}")
    return rows


def _indexed(rows, columns, expected, label, errors):
    index = {}
    field_types = tuple(map(type, next(iter(expected)))) if expected else None
    for row in rows:
        try:
            key = tuple(row[name] for name in columns)
            if field_types is not None and tuple(map(type, key)) != field_types:
                errors.append(f"{label}: unexpected key field types {key}")
            elif key in index:
                errors.append(f"{label}: repeated key {key}")
            else:
                index[key] = row
        except (KeyError, TypeError) as exc:
            errors.append(f"{label}: invalid key: {exc}")
    if expected is not None and set(index) != expected:
        errors.append(f"{label}: missing={sorted(expected - index.keys())}, unexpected="
                      f"{sorted(index.keys() - expected, key=str)}")
    return index


@lru_cache(maxsize=None)
def _identity(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": sha256(data).hexdigest()}


class Historical:
    """Check every old file used as a comparator against its immutable receipt."""

    def __init__(self, directory, errors):
        self.directory = directory
        self.errors = errors
        self.index = _read(directory / "artifact-identity.json", errors).get("files", {})
        self.checked = set()
        try:
            if _identity(directory / "artifact-identity.json")["sha256"] != OLD_INDEX_SHA:
                errors.append("Historical artifact identity SHA differs from the frozen receipt")
        except OSError as exc:
            errors.append(str(exc))

    def verify(self, path):
        key = path.relative_to(self.directory).as_posix()
        if key in self.checked:
            return
        self.checked.add(key)
        try:
            if _identity(path) != self.index.get(key):
                self.errors.append(f"Historical identity mismatch: {key}")
        except OSError as exc:
            self.errors.append(f"Historical file unavailable: {key}: {exc}")


def _status(values):
    values = tuple(values)
    if "FAIL" in values:
        return "FAIL"
    return "PASS" if values and set(values) == {"PASS"} else "UNVERIFIED"


def _process(directory, errors):
    process = _read(directory / "process.json", errors)
    if process.get("exit_code") != 0 or any(process.get(key) is not True for key in PROCESS_FLAGS):
        errors.append(f"{directory.name}: unverified process receipt")


@lru_cache(maxsize=None)
def _model(path):
    members = {}
    digest = sha256()
    with np.load(path, allow_pickle=False) as payload:
        if set(payload.files) != MODEL_MEMBERS or len(payload.files) != len(MODEL_MEMBERS):
            raise ValueError("NPZ model members are incomplete or repeated")
        for name in sorted(payload.files):
            array = payload[name]
            member = {"dtype": array.dtype.str, "shape": list(array.shape),
                      "sha256": sha256(array.tobytes(order="C")).hexdigest()}
            digest.update(_wire((name, member)).encode("utf-8"))
            members[name] = member
    return {"sha256": digest.hexdigest(), "members": members}


def _sha_field(value):
    if not isinstance(value, str) or len(value) != 64 or any(char not in "0123456789abcdef" for char in value):
        raise ValueError("invalid SHA-256 field")
    return value


def _proof_signature(row, directory, historical=None):
    role = row["role"]
    public = {}
    checks = row["checks"]
    if (set(row["public"]) != PUBLIC_MEMBERS or not isinstance(checks, dict) or not checks
            or any(type(value) is not bool for value in checks.values())):
        raise ValueError("public proof members or binding checks are incomplete")
    for name, receipt in row["public"].items():
        path = directory / "proof_store" / role / "public" / f"{_sha_field(receipt['sha256'])}.bin"
        actual = _identity(path)
        if receipt != {**actual, "file": path.relative_to(directory).as_posix()}:
            raise ValueError(f"public blob receipt mismatch: {name}")
        if historical is not None:
            historical.verify(path)
        public[name] = actual
    path = directory / "proof_store" / role / "model" / f"{_sha_field(row['model']['sha256'])}.npz"
    model = _model(path)
    if row["model"] != {**model, "file": path.relative_to(directory).as_posix()}:
        raise ValueError("NPZ model receipt mismatch")
    if historical is not None:
        historical.verify(path)
    return {"public": public, "model": model, "next": _wire(row["next"]),
            "checks": row["checks"], "pristine_active_state": row["pristine_active_state"]}


def _proofs(old, new, cases, historical):
    errors, failures = [], []
    signatures = {}
    for side, directory in (("old", old), ("new", new)):
        path = directory / "proofs.jsonl"
        if side == "old":
            historical.verify(path)
        rows = _indexed(_lines(path, errors), ("ordinal", "pair", "role"),
                        ARM_KEYS, str(path), errors)
        for key in sorted(ARM_KEYS & rows.keys()):
            ordinal, pair, _ = key
            row = rows[key]
            try:
                if row["case_id"] != cases[ordinal] or row["warmup"] is not (pair < WARM):
                    raise ValueError("case ID or warmup flag differs from the registered row")
                signatures[side, key] = _proof_signature(row, directory, historical if side == "old" else None)
            except (KeyError, TypeError, OSError, ValueError) as exc:
                errors.append(f"{side} proof {key}: {exc}")
    matched_arms = 0
    for key in sorted(ARM_KEYS):
        left, right = (signatures.get((side, key)) for side in ("old", "new"))
        if left is None or right is None:
            continue
        fields = [name for name in left if left[name] != right[name]]
        failed_checks = sorted(name for name, valid in right["checks"].items() if valid is not True)
        if fields or failed_checks:
            failures.append({"key": key, "different_from_old": fields, "failed_checks": failed_checks})
        else:
            matched_arms += 1
    matched_pairs = 0
    path = new / "pairs.jsonl"
    pair_rows = _indexed(_lines(path, errors), ("ordinal", "pair"), PAIR_KEYS, str(path), errors)
    for ordinal, pair in sorted(PAIR_KEYS):
        b, i = (signatures.get(("new", (ordinal, pair, role))) for role in ROLES)
        row = pair_rows.get((ordinal, pair))
        if not row or b is None or i is None:
            continue
        different = [name for name in b if b[name] != i[name]]
        equivalent = not different and bool(b["pristine_active_state"]) and all(b["checks"].values())
        if row.get("equivalent") is not equivalent:
            errors.append(f"Pair ({ordinal}, {pair}) has an inconsistent saved equivalence flag")
        if row.get("case_id") != cases[ordinal] or row.get("warmup") is not (pair < WARM):
            errors.append(f"Pair ({ordinal}, {pair}) has inconsistent saved case metadata")
        if equivalent:
            matched_pairs += 1
        else:
            failures.append({"key": (ordinal, pair), "different_between_new_roles": different})
    status = "FAIL" if failures else "UNVERIFIED" if errors else "PASS"
    return {"status": status, "expected_arms": len(ARM_KEYS), "exact_old_matches": matched_arms,
            "expected_pairs": len(PAIR_KEYS), "matched_new_pairs": matched_pairs,
            "failure_count": len(failures), "failures": failures, "errors": errors}


def _latency(seed, process_index, cases, old, new, historical, expected_manifest):
    job = new / f"latency-{seed}"
    directory = job / "result"
    historical_directory = old / job.name / "result"
    errors = []
    _process(job, errors)
    saved = _read(directory / "summary.json", errors)
    if saved.get("manifest_sha256") != expected_manifest or saved.get("seed") != seed:
        errors.append("Latency summary does not bind the original workload and assigned seed")
    history_gc = historical_directory / "gc.json"
    historical.verify(history_gc)
    original_gc = _read(history_gc, errors)
    gc = _read(directory / "gc.json", errors)
    if (gc.get("initial", {}).get("enabled") is not True
            or gc.get("initial", {}).get("thresholds") != original_gc.get("initial", {}).get("thresholds")
            or not isinstance(gc.get("events"), list)):
        errors.append("Latency GC state or event record is unverified")
    _read(directory / "clock.json", errors)
    _read(directory / "time_anchors.json", errors)
    path = directory / "intervals.jsonl"
    raw_rows = _lines(path, errors)
    indexed = _indexed(raw_rows, ("ordinal", "pair", "role"), ARM_KEYS, str(path), errors)
    schedule = [(ordinal, pair, role) for ordinal in ORDINALS for pair in PAIRS
                for role in (ROLES if (process_index + ordinal + pair) % 2 == 0 else ROLES[::-1])]
    if list(indexed) != schedule:
        errors.append("Interval rows differ from the registered execution order")
    measured = defaultdict(list)
    prior = {}
    physical = {}
    for key in schedule:
        if key not in indexed:
            continue
        ordinal, pair, role = key
        row = indexed[key]
        try:
            clocks = row["counter_ns"]
            stamps = [clocks[name] for name in STAMPS]
            execution = ROLES if (process_index + ordinal + pair) % 2 == 0 else ROLES[::-1]
            creation = ROLES if (process_index + ordinal) % 2 == 0 else ROLES[::-1]
            if any(type(value) is not int for value in stamps) or stamps != sorted(stamps):
                raise ValueError("invalid absolute timestamps")
            if (row["case_id"] != cases[ordinal] or row["warmup"] is not (pair < WARM)
                    or tuple(row["execution_roles"]) != execution or row["execution_index"] != execution.index(role)
                    or tuple(row["creation_roles"]) != creation or row["creation_index"] != creation.index(role)):
                raise ValueError("registered case or order metadata mismatch")
            if row["physical_instance"] != physical.setdefault((ordinal, role), row["physical_instance"]):
                raise ValueError("physical lane changed within the case")
            gap = clocks["t0"] - prior[ordinal] if ordinal in prior else None
            if row["prior_arm_t4_to_t0_ns"] != gap or (gap is not None and gap < 0):
                raise ValueError("inter-arm absolute timestamps mismatch")
            prior[ordinal] = clocks["t4"]
            values = {name: clocks[end] - clocks[start] for name, (start, end) in BOUNDARIES.items()}
            values["next_observe"] = clocks["t_next_observed"] - clocks["t3"]
            values["next_predict"] = clocks["t4"] - clocks["t_next_observed"]
            if values != row["ns"]:
                raise ValueError("saved intervals differ from independent absolute-counter subtraction")
            if pair >= WARM:
                for name in BOUNDARIES:
                    measured[name, ordinal, role].append(values[name])
        except (KeyError, TypeError, ValueError) as exc:
            errors.append(f"Interval {key}: {exc}")
    if any(physical.get((ordinal, "B")) == physical.get((ordinal, "I")) for ordinal in ORDINALS):
        errors.append("Physical B/I lane independence is unverified")
    timings = {}
    for name in BOUNDARIES:
        p95 = {}
        for role in ROLES:
            by_case = [measured[name, ordinal, role] for ordinal in ORDINALS]
            if all(len(values) == 31 for values in by_case):
                p95[role] = float(np.quantile([median(values) for values in by_case], .95, method="linear"))
        ratio = p95["I"] / p95["B"] if p95.keys() == set(ROLES) and p95["B"] > 0 else None
        numeric = "UNVERIFIED" if ratio is None else "PASS" if ratio <= 1.05 else "FAIL"
        original = saved.get("segments", {}).get(name, {})
        if p95 and (p95 != original.get("p95_ns") or ratio != original.get("I_over_B")
                    or numeric != original.get("gate")):
            errors.append(f"{name}: recomputed summary differs from the retained summary")
        timings[name] = {"p95_ns": p95, "I_over_B": ratio, "numeric_status": numeric}
    for metric in timings.values():
        metric["status"] = "UNVERIFIED" if errors else metric["numeric_status"]
    proof = _proofs(historical_directory, directory, cases, historical)
    return {"status": _status([proof["status"], *(row["status"] for row in timings.values())]),
            "observed_arm_rows": len(raw_rows), "interval_errors": errors, "segments": timings, "proof": proof}


def _instrument(job, errors):
    directory = job / "result"
    path = directory / "instrument.json"
    # The new validation records are separate from the frozen measurement schema.
    if not path.is_file() and (job / path.name).is_file():
        directory, path = job, job / path.name
    instrument = _read(path, errors)
    gc = instrument.get("gc", {})
    camera = instrument.get("camera", {})
    events = _lines(directory / "gc_events.jsonl", errors)
    cameras = _lines(directory / "camera_bindings.jsonl", errors)
    if (instrument.get("valid") is not True or gc.get("enabled_before") is not True
            or gc.get("enabled_after") is not True or not gc.get("threshold_before")
            or gc.get("threshold_before") != gc.get("threshold_after") or gc.get("overflow") != 0
            or gc.get("callback_errors") != 0 or gc.get("recorded") != len(events)
            or gc.get("capacity") != 32_768 or len(events) > gc["capacity"]
            or gc.get("buffer_preallocated_before_tracing") is not True
            or instrument.get("snapshot_calls") != 0 or instrument.get("active_collect_calls") != 0):
        errors.append(f"{job.name}: invalid GC recorder or configuration")
    if (camera.get("valid") is not True or camera.get("expected_records") != 96
            or camera.get("recorded") != len(cameras) or len(cameras) != 96
            or camera.get("overflow") != 0 or camera.get("binding_errors") != 0):
        errors.append(f"{job.name}: incomplete or invalid camera binding audit")
    try:
        previous = -1
        event_start = None
        for event in events:
            stamp = event["qpc_ns"]
            phase = event["phase_id"]
            if (type(stamp) is not int or stamp < previous or event["ordinal"] not in range(-1, 24)
                    or event["generation"] not in (0, 1, 2)
                    or type(phase) is not int or phase < 0 or gc["phase_names"][phase] != event["phase"]
                    or any(type(event[key]) is not int or event[key] < 0 for key in ("collected", "uncollectable"))):
                raise ValueError("malformed fixed-buffer event")
            previous = stamp
            pair_key = (event["generation"], event["ordinal"], phase)
            if event["event"] == "start" and event_start is None:
                event_start = pair_key
            elif event["event"] == "stop" and event_start == pair_key:
                event_start = None
            else:
                raise ValueError("unpaired GC event")
        if event_start is not None:
            raise ValueError("unclosed GC collection")
    except (IndexError, KeyError, TypeError, ValueError) as exc:
        errors.append(f"{job.name}: {exc}")
    expected = {(ordinal, phase, camera_id) for ordinal in ORDINALS
                for phase in (6, 7) for camera_id in (0, 1)}
    indexed = _indexed(cameras, ("ordinal", "phase_id", "camera_index"), expected,
                       f"{job.name}: cameras", errors)
    for ordinal in ORDINALS:
        for phase, name in ((6, "normal_close"), (7, "reopen_exception")):
            pair = [indexed.get((ordinal, phase, camera_id), {}) for camera_id in (0, 1)]
            for row in pair:
                bindings = row.get("bindings", {})
                if (row.get("phase") != name or row.get("object_type") != "_bpy_types.Object"
                        or row.get("data_type") != "bpy.types.Camera" or row.get("object_kind") != "CAMERA"
                        or row.get("camera_kind") != "ORTHO" or row.get("release_verified") is not True
                        or "native_allocation_bytes" not in row or row["native_allocation_bytes"] is not None
                        or not isinstance(bindings, dict) or len(bindings) != 8
                        or any(valid is not True for valid in bindings.values())
                        or any(type(row.get(key)) is not int or row[key] <= 0 for key in
                               ("renderer_python_identity", "object_pointer", "data_pointer"))):
                    errors.append(f"{job.name}: invalid camera binding for {(ordinal, phase, row.get('camera_index'))}")
            b, i = pair
            if (b.get("renderer_python_identity") != i.get("renderer_python_identity")
                    or b.get("object_pointer") == i.get("object_pointer")
                    or b.get("data_pointer") == i.get("data_pointer")):
                errors.append(f"{job.name}: camera pair is not distinct within the renderer at {(ordinal, phase)}")
    return {"gc": gc, "camera": camera}


def _expected_census(ownership):
    """The authorized camera classification moves only the observed opaque type."""
    expected = deepcopy(ownership)
    unknown = expected["uncovered_types"]
    tag = "_bpy_types.Object"
    if tag in unknown.get("renderer", ()):
        unknown["renderer"].remove(tag)
        if not unknown["renderer"]:
            del unknown["renderer"]
        opaque = expected["native_opaque_types"]
        opaque["renderer"] = sorted(set(opaque.get("renderer", ())) | {tag})
    return expected


def _managed_arm(seed, role, cases, old, new, historical, expected_manifest):
    name = f"managed-{seed}-{role}"
    job = new / name
    directory = job / "result"
    historical_dir = old / name / "result"
    errors = []
    _process(job, errors)
    instrumentation = _instrument(job, errors)
    summary = _read(directory / "summary.json", errors)
    if (summary.get("manifest_sha256") != expected_manifest or summary.get("seed") != seed
            or summary.get("role") != role or summary.get("instrument") != "managed"):
        errors.append(f"{name}: worker summary binding mismatch")
    history, current = {}, {}
    points, history_points = {}, {}
    for location, dst, checkpoints in ((historical_dir, history, history_points), (directory, current, points)):
        raw, checkpoint_file = location / "cases.jsonl", location / "checkpoints.jsonl"
        if location == historical_dir:
            historical.verify(raw)
            historical.verify(checkpoint_file)
        dst.update(_indexed(_lines(raw, errors), ("ordinal",), {(i,) for i in ORDINALS}, str(raw), errors))
        checkpoints.update(_indexed(_lines(checkpoint_file, errors), ("case", "point"), None,
                                    str(checkpoint_file), errors))
    if points.keys() != history_points.keys():
        errors.append(f"{name}: checkpoint coverage differs from original")
    census_mismatches = []
    for key in points.keys() & history_points.keys():
        try:
            expected = _expected_census(history_points[key]["ownership"])
            if _wire(expected) != _wire(points[key].get("ownership")):
                census_mismatches.append(key)
        except (AttributeError, KeyError, TypeError, ValueError) as exc:
            errors.append(f"{name}: malformed census {key}: {exc}")
    if census_mismatches:
        errors.append(f"{name}: census differs beyond the opaque camera classification")
    rows, failures = {}, []
    for ordinal, case in enumerate(cases):
        original, observed = history.get((ordinal,)), current.get((ordinal,))
        if not original or not observed:
            continue
        row_errors = []
        if any(observed.get(key) != original.get(key) for key in ("case", "ordinal", "family", "role", "instrument")):
            row_errors.append("case identity differs from original")
        if observed.get("case") != case or observed.get("role") != role or observed.get("error"):
            row_errors.append("worker case binding or execution error")
        proof = {}
        for phase, field in (("hot", "hot_proof"), ("reopen", "reopened_proof")):
            left, right = (original, observed) if phase == "hot" else (
                original.get("lifecycle", {}), observed.get("lifecycle", {}))
            a, b = left.get(field), right.get(field)
            if not a or not b:
                proof[phase] = "UNVERIFIED"
            elif not b.get("checks") or any(valid is not True for valid in b["checks"].values()) or _wire(a) != _wire(b):
                proof[phase] = "FAIL"
                failures.append({"ordinal": ordinal, "case": case, "phase": phase,
                                 "different_fields": sorted(key for key in a.keys() | b.keys()
                                                            if _wire(a.get(key)) != _wire(b.get(key)))})
            else:
                proof[phase] = "PASS"
        old_life, new_life = (row.get("lifecycle", {}) for row in (original, observed))
        lifecycle_keys = ("close", "closed_public", "fresh_reopen", "reopened_ticket_owner_is_distinct",
                          "reopened_close", "reopened_close_trigger")
        if any(key not in new_life for key in lifecycle_keys) or not observed.get("logical_gpu"):
            lifecycle = "UNVERIFIED"
        elif (any(_wire(old_life.get(key)) != _wire(new_life[key]) for key in lifecycle_keys)
              or _wire(original.get("logical_gpu")) != _wire(observed["logical_gpu"])):
            lifecycle = "FAIL"
        else:
            lifecycle = "PASS"
        metadata = observed.get("managed", {})
        raw, coverage = {}, {}
        for point in resources.MANAGED_HOT_POINTS:
            checkpoint = points.get((case, point), {})
            raw[point] = checkpoint.get("current_bytes")
            coverage[point] = bool(checkpoint.get("ownership") is not None
                                   and not checkpoint["ownership"].get("uncovered_types")
                                   and metadata.get("ownership_covered", {}).get(point) is True)
            if type(raw[point]) is not int or raw[point] != metadata.get("current_bytes", {}).get(point):
                row_errors.append(f"{point}: raw and case-summary current disagree")
        raw["window_peak"] = points.get((case, "hot_outputs_held"), {}).get("peak_since_latest_reset_bytes")
        if type(raw["window_peak"]) is not int or raw["window_peak"] != metadata.get("window_peak_bytes"):
            row_errors.append("raw t4 window peak and case summary disagree")
        rows[ordinal] = {"case": case, "proof": proof, "lifecycle": lifecycle,
                         "current_ownership_covered": coverage, "raw_bytes": raw, "errors": row_errors}
    return {"role": role, "instrumentation": instrumentation, "errors": errors,
            "census_points_checked": len(points.keys() & history_points.keys()),
            "census_mismatches": sorted(census_mismatches, key=str),
            "rows": rows, "proof_differences": failures}


def _managed(seed, cases, old, new, historical, expected_manifest):
    arms = {role: _managed_arm(seed, role, cases, old, new, historical, expected_manifest) for role in ROLES}
    frozen = resources.compare(*(new / f"managed-{seed}-{role}" / "result" for role in ROLES), "managed")
    comparisons = []
    for ordinal, case in enumerate(cases):
        left, right = (arms[role]["rows"].get(ordinal, {}) for role in ROLES)
        saved = frozen["cases"][ordinal]
        proof = _status([saved["public_and_model_equivalence"],
                         *(row.get("proof", {}).get(phase, "UNVERIFIED")
                           for row in (left, right) for phase in ("hot", "reopen"))])
        lifecycle = _status([saved["logical_gpu_and_lifecycle"],
                             *(row.get("lifecycle", "UNVERIFIED") for row in (left, right))])
        instruments_valid = not any(arms[role]["errors"] for role in ROLES)
        metrics = {}
        for point, limit in METRICS.items():
            b, i = (row.get("raw_bytes", {}).get(point) for row in (left, right))
            delta = i - b if type(b) is int and type(i) is int else None
            numeric = "UNVERIFIED" if delta is None else "PASS" if delta <= limit else "FAIL"
            valid = (proof == "PASS" and instruments_valid and left and right
                     and not left["errors"] and not right["errors"]
                     and saved["metric_deltas"].get(point, {}).get("I_minus_B_bytes") == delta
                     and (point == "window_peak" or all(row["current_ownership_covered"].get(point)
                                                        for row in (left, right))))
            metrics[point] = {"B_bytes": b, "I_bytes": i, "I_minus_B_bytes": delta, "limit_bytes": limit,
                              "numeric_status": numeric, "status": numeric if valid else "UNVERIFIED"}
        comparisons.append({"seed": seed, "ordinal": ordinal, "case": case, "public_model_next": proof,
                            "logical_gpu_lifecycle": lifecycle, "metrics": metrics})
    totals = {point: _metric_summary(comparisons, point) for point in METRICS}
    proof_totals = {phase: dict(Counter(row["proof"].get(phase, "UNVERIFIED")
                                        for arm in arms.values() for row in arm["rows"].values()))
                    for phase in ("hot", "reopen")}
    lifecycle_totals = dict(Counter(row["logical_gpu_lifecycle"] for row in comparisons))
    return {"status": _status([*(row["status"] for row in totals.values()),
                               *(row[name] for row in comparisons for name in ("public_model_next", "logical_gpu_lifecycle"))]),
            "metrics": totals, "proof_status_counts": proof_totals, "lifecycle_status_counts": lifecycle_totals,
            "comparisons": comparisons, "arms": arms,
            "frozen_comparator_input_errors": frozen["input_errors"]}


def _metric_summary(rows, point):
    values = [(row["seed"], row["case"], row["metrics"][point]) for row in rows]
    worst = max((item for item in values if item[2]["I_minus_B_bytes"] is not None),
                key=lambda item: item[2]["I_minus_B_bytes"], default=(None, None, {}))
    return {"status": _status(value["status"] for _, _, value in values),
            "gate_counts": dict(Counter(value["status"] for _, _, value in values)),
            "numeric_counts": dict(Counter(value["numeric_status"] for _, _, value in values)),
            "worst_seed": worst[0], "worst_case": worst[1],
            "maximum_I_minus_B_bytes": worst[2].get("I_minus_B_bytes")}


def _write(path, data):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(data, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")


def run(old, new, out):
    old, new, out = (Path(path).resolve() for path in (old, new, out))
    errors = []
    historical = Historical(old, errors)
    historical.verify(old / "manifest.json")
    old_manifest = _read(old / "manifest.json", errors)
    new_manifest = _read(new / "manifest.json", errors)
    cases = [row["case_id"] for row in old_manifest["formal_plans"]]
    if len(cases) != 24 or len(set(cases)) != 24:
        raise ValueError("Original manifest must bind 24 distinct cases")
    if new_manifest.get("formal_manifest_sha256") != OLD_MANIFEST_SHA:
        errors.append("New manifest does not bind the original formal workload SHA")
    out.mkdir(parents=True, exist_ok=False)
    latency, managed = {}, {}
    all_managed = []
    for index, seed in enumerate(SEEDS):
        tim = _latency(seed, index, cases, old, new, historical, OLD_MANIFEST_SHA)
        mem = _managed(seed, cases, old, new, historical, OLD_MANIFEST_SHA)
        all_managed.extend(mem["comparisons"])
        for label, results, group in (("latency", tim, latency), ("managed", mem, managed)):
            path = out / f"{label}-{seed}.json"
            _write(path, results)
            group[str(seed)] = {key: results[key] for key in
                                (("status", "segments") if label == "latency" else
                                 ("status", "metrics", "proof_status_counts", "lifecycle_status_counts"))}
            group[str(seed)]["details"] = path.name
        latency[str(seed)]["proof"] = {key: tim["proof"][key] for key in (
            "status", "expected_arms", "exact_old_matches", "expected_pairs", "matched_new_pairs", "failure_count")}
    totals = {point: _metric_summary(all_managed, point) for point in METRICS}
    gates = {"latency": _status(row["status"] for row in latency.values()),
             "managed": _status(row["status"] for row in managed.values()),
             "historical_and_manifest_identity": "UNVERIFIED" if errors else "PASS"}
    summary = {"scope": "fixed repair recheck only", "status": _status(gates.values()),
               "gates": gates, "latency": latency, "managed": managed, "managed_totals": totals,
               "historical_files_verified": len(historical.checked), "identity_errors": errors,
               "original_managed_exceedances_retained": 33, "original_qualification_remeasured": False}
    _write(out / "summary.json", summary)
    lines = ["# 建树生命周期修复复核", "", f"复核结果 **{summary['status']}**。", "",
             "| 种子 | 五段时延及公开证据 | 托管 current、peak 与生命周期 |",
             "| --- | --- | --- |"]
    for seed in map(str, SEEDS):
        lines.append(f"| {seed} | [{latency[seed]['status']}]({latency[seed]['details']}) | "
                     f"[{managed[seed]['status']}]({managed[seed]['details']}) |")
    lines.extend(("", "数值超门和证据待验分别记录。原正式轮 33 个托管常驻超门点保留。"
                  "本轮只复核登记的同场景时延和托管内存。", "", "[机器汇总](summary.json)", ""))
    (out / "README.md").write_text("\n".join(lines), encoding="utf-8", newline="\n")
    print(json.dumps({"status": summary["status"], "gates": gates, "output": str(out)}, ensure_ascii=False))
    return summary


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--old-dir", type=Path, default=OLD)
    parser.add_argument("--new-dir", type=Path, default=HERE)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    run(args.old_dir, args.new_dir, args.out or args.new_dir / "analysis")
