# 建树生命周期修复复核

复核结果 **PASS**。

| 种子 | 五段时延及公开证据 | 托管 current、peak 与生命周期 |
| --- | --- | --- |
| 20261105 | [PASS](latency-20261105.json) | [PASS](managed-20261105.json) |
| 79463 | [PASS](latency-79463.json) | [PASS](managed-79463.json) |
| 310519 | [PASS](latency-310519.json) | [PASS](managed-310519.json) |

数值超门和证据待验分别记录。原正式轮 33 个托管常驻超门点保留。本轮只复核登记的同场景时延和托管内存。

[机器汇总](summary.json)
