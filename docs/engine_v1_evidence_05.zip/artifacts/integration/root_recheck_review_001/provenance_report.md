# managed_current_recheck_001 来源与仪器独立审查

结论：当前交付的来源绑定、九进程固定范围、串行时序和 managed 仪器修订均符合事前协议。没有发现需要新增原生实验的来源或仪器阻塞。本结论不代替主干对时延、资源数值和公开输出的独立验收，原 33 个失败点也不改判。

只进行了 CPU 离线核验、Git 对象只读检查和隔离的分类器正负例；没有 Blender/GPU、新性能测试、生产或作者原件修改。`provenance_probe.py/.json` 保存本次可复核过程和结果；`provenance_probe_attempts.json` 记录首次离线审查假设错误及修正，未隐藏失败尝试。

## 文件、来源与真实版本

| 项目 | 本次独立核验 |
| --- | --- |
| artifact-identity.json | SHA `904733375f92791733f8bd35db334fafa06d2b8dcd496f244a52a42a72653a8a`；16,109 项 SHA/大小全部匹配，文件集合无缺失或额外文件（身份文件自身除外） |
| manifest.json | SHA `13386228b34b8f5da1a054dfece6ac1275ab983c985280bb095af4c6ae114255` |
| sources.zip | SHA `7b169c3165493c0e6f2d7ce6d0e25e21b1251db600bb1bff68dee85e0f60d4a8`；599 个唯一成员逐项等于 source_superset |
| 事前协议 | MANAGED_CURRENT_RECHECK_PROTOCOL.md SHA `d65d29910acffa38da701a339e96ae042146408ccb0b103ed46fbb76c7a7de00`；现文件、登记和 ZIP 一致 |
| 原 formal 来源 | 595 项中仅 fast_bvh_clearance.py 改变，其余 594 项全部相同 |
| 唯一生产差异 | split 正常执行后增加 `del split`；原文本删除该行后逐字节相同，精确 diff 与登记及 production.diff 一致 |

原核 SHA 为 `ffc494bf309bb9010854d88007edb54533c9fa9d7fad68905fe0d75663692aeb`，本轮候选为 `76b25ff24cbde8433bcf700f8b45e3dfe8fefa8737425ef992ff7d1f3b8bebc1`。原 formal manifest/identity 仍是 `093a0df0…` / `05d93ebe…`，登记输入未改写旧身份。

必须区分 Git HEAD 与实际运行源：登记 HEAD `02afecc861efa62089191bc34c844a510dfa8039` 的已提交 BC blob **仍为旧 ffc494**；其余 16 个生产文件与运行快照相同。登记 ZIP 和九个进程的实际导入回执则已经全部是工作区的 **76b25** 候选。随后提交 `4372bfc97b9c61177dcc3b0bbca7b885457950a1` 的全部 17 个生产文件与登记 ZIP 完全相同，当前工作区生产字节也相同。

因此执行一致性的依据是冻结源 ZIP、launch 的 manifest 身份、前后 source checks 和实际 imports，不是“两个 commit blob 相等”。本审查第一次离线探针错误地要求两 commit 都等于候选，因 02afecc 的旧 blob 触发 AssertionError；后续只修正这项历史比较语义，保留其失败定位和所有其它断言，没有调整交付数据或重跑原生过程。

## 九进程顺序、输入与环境

实际归档恰好有九套 launch/process/runtime，顺序等于登记：三个 latency 按 seed 20261105、79463、310519；随后六个 managed 同 seed 顺序且每 seed B 后 I。所有 QPC 区间严格串行、不重叠，batch 锚点包住全体。

| job | 实际 UTC，2026-11-06 | imports / inputs |
| --- | --- | ---: |
| latency-20261105 | 04:55:03.469680–04:57:25.287890 | 26 / 161 |
| latency-79463 | 04:57:29.172311–04:59:45.729970 | 26 / 161 |
| latency-310519 | 04:59:49.541267–05:02:02.710986 | 26 / 161 |
| managed-20261105-B | 05:02:06.261846–05:02:34.335906 | 30 / 161 |
| managed-20261105-I | 05:02:37.962959–05:03:05.737756 | 30 / 161 |
| managed-79463-B | 05:03:07.917257–05:03:31.829886 | 30 / 161 |
| managed-79463-I | 05:03:33.992201–05:03:58.309147 | 30 / 161 |
| managed-310519-B | 05:04:01.829242–05:04:27.102707 | 30 / 161 |
| managed-310519-I | 05:04:29.296515–05:04:53.596325 | 30 / 161 |

逐项重算全部登记输入 SHA；launch 与 manifest job 完全相同；实际 imports 与该批 source ZIP 一致，九次实际 BC 导入均为 76b25。process 与 batch 退出码均为 0，记录的源/输入稳定性为 true，未见导入差异。历史 stable_sources/stable_inputs 是运行器的前后检查收据；本次读档没有重新观察过去的执行或每一次文件打开。

原生指纹逐字段等于 formal 的 native_expected：Blender 5.2.3 LTS、原 exe/Python exe/DLL 身份、Python 3.13.13、NumPy 2.3.4、NVIDIA RTX 3060、OpenGL/驱动报告 610.88。实际有效环境等于 launch；相对于原相应 job，只有有意更换的独立 pycache 路径。三个 latency 没有导入新 managed_worker，继续使用冻结的原 latency.py；六个 managed 均实际导入了新 managed_worker。

登记、独占创建输出目录和单个串行执行循环，以及完整九套回执，支持“本归档固定批次一次执行”。没有 OS/DXGI、旧 CF、F180 或其它额外 job 归档；这不升级为对机器外部所有未归档活动的取证结论。

`compare.py` 的 SHA 为 `572c9f7792461eaac6491bfe35cdd3c2f283d00dd5adafd593d85b8cc354da28`。它是原生批次后单独索引的离线比较器，不在冻结 599 源集合中，也未出现在任何 worker imports。本报告没有以该比较器摘要代替来源或原始仪器核验。

## 仪器差异确实限于授权范围

本审查从归档原 `resource_instruments.py:backing_census` 和新 managed_worker 的实际替换常量重新生成候选函数及 unified diff，结果与 manifest 的 census_diff、六个实际 census.patch 和完整 managed-instrumentation.diff 逐字节相同。没有重新改写旧仪器文件。

唯一 census 语义变化是在原 opaque 分支增加 `_renderer_camera` 条件，必须同时满足：根名为 renderer、确切 `_bpy_types.Object` 类型、`isinstance(value, bpy.types.Object)`、CAMERA 对象、root.cameras 恰为两个、该对象是二者之一。没有对所有 `_bpy_types` 对象或所有未知 native 类型一概放行。

为验证负例，本审查从冻结 AST 隔离编译原/候选 census 和谓词，使用纯 Python 的测试类型，不导入 Blender。原分类器把两模拟真实相机列为 uncovered，候选只将该合法对移入 opaque，NumPy/bytes 计数不变。以下五类仍然 uncovered：其它根下的 Object；renderer 中不属于 cameras tuple 的 Object；同模块同名但不是指定 Object 类实例；MESH Object；其它未知类型。故其它 unknown 的 UNVERIFIED 路径保留。

其余 wrapper 仅设置 GC 静态阶段后调用原函数，和在原 `_instrument_close` 前记录相机整数绑定。原 `_case_work`、`_managed_hot`、`_current_point`、`_proof_summary`、owner_roots、outputs 删除、reference replacement、close/reopen/异常路径均来自未变的旧源；没有新增冷起点扣除、改变 current/peak 数字、替换阶段读数或保留 snapshot/referrer 对象。原 t4 先读 current/peak，再进入原 census；相机绑定位于正常三 hot 点之后的 pre-close，reopen 也在原 pre-close 点记录。

这些 wrapper、分类判断和记录仍可能产生仪器开销，属于协议明确列出的验证侧差异；不能将新测量说成旧仪器条件原样重跑，更不能因此取消原正式失败。

## GC 原始事件和约束

六个 managed 统一在原 resources.run 启动 tracing 前建立数值缓冲：GC 32,768×7 int64，相机 96×8 int64，六个 int64 计数器，底层总容量 1,841,200 B（不含 Python 容器头）。循环内只写固定单元；GC 回调没有 append 字典或写日志，最终 JSON 在原运行结束、回调移除后输出。

源码 AST 未发现 collect、disable、set_threshold、take_snapshot、get_referrers/get_referents 调用；原依赖代码身份未变。六个 instrument 回执均显示 GC 前后启用、threshold `(2000,10,10)` 不变，无溢出或回调异常；不能只据此声称零 GC/零扰动。

本次逐条核对 gc_events 的 QPC 单调性、generation、ordinal、静态 phase 名/编号、runtime 范围和 start/stop 配对：

| 每个 seed 的角色 | 原始事件 | 完整集合 | generation 0 / 1 |
| --- | ---: | ---: | ---: |
| B（共三进程） | 各 20 | 各 10 | 各 9 / 1 |
| I（共三进程） | 各 18 | 各 9 | 各 8 / 1 |

无未配对事件或缓冲错误。事件阶段由 wrapper 更新，是阶段标签；没有据标签推导某个对象的释放量或把 GC 差异改写成性能收益。

## 实际相机 Object/Data 与释放归属

六个 managed 共保存 **576 条** 原生相机绑定记录，精确覆盖每例 24×两个 close 阶段×两个相机×六进程，无重复或遗漏。每对都属于同一 renderer，Object pointer 两个不同、Camera data pointer 两个不同且非零。所有运行时检查满足真实 `_bpy_types.Object`、bpy.types.Object 实例、bpy.types.Camera data、CAMERA/ORTHO、bpy.data 注册指针匹配，以及对应 lane renderer 的持有关系。

576 个 release_verified 分别与本例 cases.jsonl 的 `close` / `reopened_close.camera_objects_and_data_removed` 相同且为 true。原 `_instrument_close` 先保存两个 Object/Data 名称并核对存在，close 后核对对象和 data 均已移除；原 offscreen/CPU/model/bridge 所有权检查仍在原位置执行。新数字缓冲不保存相机 Python 对象或 lane 引用，局部 camera/data/registered_object 引用在 camera_bindings 返回后结束。

边界是：新证据为 **pre-close 原生指针/类型绑定 + 原有 name/data 清理检查**；release_verified 是从原 cases 清理结果关联而来，不是新增一次独立的 post-close 指针读取。该组合足以支持协议要求的实际相机归属和原释放证据，不应宣传为额外独立释放实验。所有 native_allocation_bytes 仍为 null，未将未知大小填零，也没有加算至 traced current。

## 接收建议

来源、范围与仪器门可接受。资源原始数值/公开证明和时延预算由相应主干审查合并判定；本报告不替代它们，也不以摘要 PASS 推导整机 PASS。新代码证据覆盖本批三个 latency 与六个 managed，旧 CF/OS/F 等只按旧源码和原实测范围承接，不能伪称已在 76b25 重测。

原 33 个 current 超门点及旧批次状态保持历史事实。建议归档本报告、probe/JSON 与首次离线假设失败记录；无需追加原生测试或再开启算法优化循环。
