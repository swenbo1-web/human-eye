# 生命周期有限复核：资源及公开状态独立审查

**结论：本批资源与生命周期门通过，支持接受当前一行 `del split` 的有限修复。** 未发现剩余资源、公开状态或接线语义阻塞，也没有需要再次优化算法的证据。整机决定仍由主端结合独立来源/仪器审查和三进程时延审查作出。本次新通过不修改旧正式批次的 33 个 current 失败，不证明全部旧差值只有闭包循环这一根因。

本审查只做 CPU 离线读取与重算，没有启动 Blender/GPU、功能测试、性能或训练，没有修改作者证据、生产、git 或 docs。`resource_probe.py` 不导入生产模块、作者 `compare.py` 或 `resources.compare`；输出 `resource_probe.json`，最终 errors=0。读取的 1,768 个不同文件均核验其所属交付身份表，旧身份表另绑定原冻结 SHA `05d93ebe31677cef58a1d722e8833abbfd3a9a60ec46c34f09bccf8ed493c91a`。

## 原固定门的独立数值结果

| 对应量 | 数量 | I−B 最小值 | I−B 最大值 | 原预算 | 超限 |
|---|---:|---:|---:|---:|---:|
| hot_outputs_held current | 72 | −101,155 B | −2,867 B | 262,144 B | 0 |
| hot_outputs_released current | 72 | −103,194 B | −2,020 B | 262,144 B | 0 |
| hot_reference_replaced current | 72 | −102,626 B | −952 B | 262,144 B | 0 |
| 完整 t0→t4 window peak | 72 | −129,086 B | −18,645 B | 1,048,576 B | 0 |

held 与 peak 的最大项为 seed310519 / I-open-tip-0；released 与 reference 的最大项为 seed20261105 / I-open-tip-0。216 个 current 对应点和 72 个 peak 窗口分别判定，未用负差抵消正差，没有扣冷起点、扣验证者开销或把增量峰换成完整峰。

逐案例验证 `cases.jsonl` 中三个 current 值等于对应原始 checkpoint；window_peak 等于 t4 held checkpoint 的 `peak_since_latest_reset_bytes`。另核对 `peak_above_start = full_window_peak − current_before_reset`，该增量只保留为诊断，未参与完整峰门。JSON 保留每个 B/I 原值、差值与门限，而非只存 PASS。

旧批次重新读取原始 current，仍有 **33 个超限点，最大 +488,751 B**。未从新批次推算、改写或消除旧失败。

## 轨迹、输入和保留点完整性

六进程均为原三 seed × B/I，每进程 24 例；案例 ID、ordinal、family、role、instrument 和顺序逐行与原档匹配。新登记引用原 workload manifest，执行设置仍是 5 warm、1 hot（pair5），正常关闭与重开 pair36/37。原 `resources.py`、`resource_instruments.py`、`common.py` 在两份冻结 sources.zip 中字节相同；没有换一套资源执行函数。

每进程严格保留 **338 条 checkpoint：2 个全局冷点 + 24×14 个案例点**。六进程共 2,028 条；B/I 有 1,014 个对应点，点名和顺序均完整：冷加载前后、建 lane/参考/session/basis、正常三热点、close 外部 bytes 持有/释放、重开前/就绪/输出持有/释放。144 条热链的 QPC t0/t1/t2/t3/next-observed/t4 单调，案例之间顺序无重叠。

其余点单列，不事后新增热门。对应 current 的最大 I−B：closed bytes held/released 均 −1,170 B，cold before reopen −1,498 B，reopened lane ready −3,299 B，reopened outputs held −5,369 B，reopened released −7,242 B。全局首次冷点差为 0，reference ready 最大 +243 B；这些冷值不从热值中相减。

## owner/backing 与 opaque 原生引用

2,028 条 census 全部独立重算去重 NumPy、公开 bytes、共享根组合、各 root backing 数量和字节合计。**全部新旧 census 完全相同，唯一允许的差别是 renderer 的 `_bpy_types.Object` 从 uncovered 移至 native opaque。** B/I 的全部 1,014 对完整 ownership 对象也相同，没有新增数组副本、缺失根或共享归属变动。

正常会话有 10 个明确根：bridge、indexes、readback、model、reference、renderer、current、basis、validation_reset_weights、caller_outputs。全局加载后单列 immutable_deployment_parameters，当前每进程为 13 个 backing / 266,648 B。归因字节没有重复加到 tracemalloc current/peak。

576 个 renderer 保留点均只有声明的 Object、GPUOffScreen、GPUShader opaque 引用，所有新 census 的 uncovered_types 为空。相机实际类型/身份及 GC 仪器的独立审查由 camera reviewer 完成：严格分类谓词仅接受该 renderer 的两个真实 CAMERA Object；异根、非成员、同名假类型及其他未知类仍未覆盖。相机 576 条 pre-close 绑定覆盖每例 normal close 和 reopen exception，各有两个不同 Object/Data，释放字段逐项绑定原生命周期检查。没有为原生 allocation 伪填 0。

归属闭合的范围是协议列明的 owner/backing 和显式 opaque 原生资源；这不是把所有 Python 报表、宿主场景、驱动 allocator 的字节逐对象完整列账。全进程 traced current 原值仍如实通过门。close 后 owner backing 为零也不代表全进程 RSS、显存或宿主输入引用为零。

## close/reopen、公开持有和异常范围

144 个新 arm-case 的完整 lifecycle 对象及 logical_gpu 对象与原档逐字段相同；72 对 B/I 也相同。每例 normal close 和 reopened close 各 6 项实际检查全部成立：一次 offscreen.free、相机 Object/Data 移除、renderer CPU buffer 清空、模型数组清空、bridge/index/current 清空、session reference/renderer 清空。

normal close 时调用者保留的 6 个 immutable bytes buffer 数量/总长度与 retained receipts 完全一致；PNG 和 AO 保持原绑定且 close 前后不变。释放外部 payload 后 owned bytes/NumPy 为零。重开时 current/renderer/bridge 为新初态、模型 writes 回到 240，下一票据 owner 与旧会话不同；重开反馈后的活动状态仍按原输入更新。

异常轨迹仍是**完整服务链之后的 untimed caller abort，经过 lane finally 关闭**。它证明该冻结异常释放责任，不泛化为全部原生分配失败、split 中断或所有异常阶段。最后 `reopened_released` 的空 root 没有被用来代替 native close 检查，也没有被解释成进程零占用。

## hot/reopen AO、PNG、模型与 next

对 144 个 arm-case 的 hot 和 reopen 两阶段，**288 份新旧完整 proof 摘要逐字段精确相同**；不删字段，不做新的 ID 归一。公开六项 bytes 长度/hash、十项绑定检查、active_model digest、next digest 均一致。72 对 B/I 的两阶段公开状态也相同。

进一步从旧/新 latency 保存的相同 pair5 证明中，读取实际 AO/PNG bytes 和 NPZ，交叉绑定 managed hot receipts：

- 共 1,728 次实际公开 blob 读取核验（144 arm-case × 旧/新 × 6 项）；新旧完整字节相同。
- 共 288 次实际 NPZ 加载，核对每项 dtype/shape/原始 bytes、保存摘要和 managed 摘要。每份包含完整当前活跃 10 项数组；V writes=242，A writes=240 或 241，keys/values/known 长度严格等于 writes。新旧数组逐字节相同。
- actual next JSON 的全部字段重算摘要，与 managed hot 相同；包括 command/predictor/prediction、动作 features/meters、view features、before/after/next audits、候选顺序/方向/射线及绑定。
- 对 reopened next，仅按原 manifest 将两个明确字段 observation_id/action_id 置为 pair37 的固定值，其余字段不动，即精确得到 reopened 摘要。reopen 的 PNG 与上述实际 blob 完全相同，活动模型摘要也相同。

证据层级需准确表述：managed 原格式保存的是实际执行所得的 proof receipts/断言，**没有独立 managed blob/NPZ store**。本审查直接读到的实际 bytes/数组来自相同输入的 latency store，并通过强摘要交叉绑定；reopened AO 则直接核对新旧对应 managed receipts。未声称主干重新读取当时 managed 进程的内存或重新执行原生几何/渲染。该边界沿用冻结协议，没有因此新增测试或字段豁免。

## 测量边界与整体框架风险

原 `_managed_hot` 在 t0 前读取 current 并 reset_peak，t4 回调先读取 current/peak，再创建输出封装、做 census/证明/报告；三热 current、参考替换和释放顺序未变。原 owner_roots、proof 局部变量生命周期、del warm/outputs/payloads/check_release 等清理原样保留。相机绑定新增操作在三个热读数之后的 close 前，不偷移热段工作。

camera reviewer 的独立源码/事件核验确认：六 managed GC 均正常开启，阈值保持 2000/10/10；B 各 20、I 各 18 事件完整配对，无 buffer 溢出/回调异常；无 collect/snapshot/referrer 扫描/disable/set_threshold。数字 GC/相机缓冲在 tracing 前预分配，两臂使用同样仪器；没有按命中 GC 删除样本或借仪器扣 baseline。

唯一生产改动仍是成功建树后删除递归闭包。原独立弱引用和数值证明已经覆盖它的生命周期机制与算法不变，本次正常链/关闭/重开公开状态及资源门给出新原生证据。该变更没有引入防御链或修改已验收算法，当前没有理由让新实施聊天再次优化 BC。

剩余风险在已冻结承诺范围内：24 例与三 seed 不证明所有场景性能；opaque native 不是显存实测字节；旧 OS sampled maximum 和旧 CF 成本没有在新 hash 重测；caller abort 不覆盖全部异常；全局 GC/allocator 时刻不能静态证明完全不变。这些限制既有且已在协议披露，不构成本批任意扩测的理由。同场景时延由另一独立审查判定，若其与来源审查也通过，可由主端关闭本次有限修复验收；不需再开算法优化循环。

本批结果足以证明新版本在本轮固定资源门及公开状态上没有退化，**不足以把原 33 个失败统一归因于某次 GC 或单一闭包，更不能改写旧批次结论**。
