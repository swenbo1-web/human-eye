"""Independent CPU provenance and bounded-instrument audit; never runs native code."""
from collections import Counter, defaultdict
from collections.abc import Mapping
from dataclasses import fields, is_dataclass
from datetime import datetime, timezone
from enum import Enum
from hashlib import sha256
from pathlib import Path
from types import BuiltinMethodType, FunctionType, MethodType
from zipfile import ZipFile
import ast
import difflib
import io
import json
import subprocess
import tarfile
import numpy as np

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'artifacts/integration/managed_current_recheck_001'
OLD=ROOT/'artifacts/integration/formal_cost_001/formal'
OUT=Path(__file__).with_suffix('.json')
BC='human_eye_fast/fast_bvh_clearance.py'
CANDIDATE='76b25ff24cbde8433bcf700f8b45e3dfe8fefa8737425ef992ff7d1f3b8bebc1'
CACHE={}
def read(p):return json.loads(p.read_bytes())
def rows(p):return [json.loads(line) for line in p.read_text(encoding='utf-8').splitlines()]
def ident(p):
    p=p.resolve()
    if p not in CACHE:
        data=p.read_bytes();CACHE[p]={'bytes':len(data),'sha256':sha256(data).hexdigest()}
    return CACHE[p]
def utc(ns):return datetime.fromtimestamp(ns/1e9,timezone.utc).isoformat()
def literal_assignments(tree):
    result={}
    for n in tree.body:
        if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
            try:result[n.targets[0].id]=ast.literal_eval(n.value)
            except (ValueError,TypeError):pass
    return result

def main():
    index=read(BASE/'artifact-identity.json');m=read(BASE/'manifest.json');old=read(OLD/'manifest.json')
    assert index['file_count']==len(index['files'])==16109
    for n,v in index['files'].items():assert ident(BASE/n)==v,n
    assert {p.relative_to(BASE).as_posix() for p in BASE.rglob('*') if p.is_file()}==set(index['files'])|{'artifact-identity.json'}
    with ZipFile(BASE/'sources.zip') as z:
        assert len(z.namelist())==len(set(z.namelist()))==599
        sources={n:z.read(n) for n in z.namelist()}
    assert {n:sha256(b).hexdigest() for n,b in sources.items()}==m['source_superset']
    changed={n:{'old':h,'new':m['source_superset'].get(n)} for n,h in old['source_superset'].items() if m['source_superset'].get(n)!=h}
    assert set(changed)=={BC} and changed[BC]['new']==CANDIDATE
    with ZipFile(OLD/'sources.zip') as z:bc_before=z.read(BC)
    before=bc_before.decode().splitlines(keepends=True);after=sources[BC].decode().splitlines(keepends=True)
    marker=[i for i,l in enumerate(after) if l.strip()=='del split'];assert len(marker)==1
    i=marker[0];assert after[i-1].strip()=='split(0, count, depth)' and before==after[:i]+after[i+1:]
    production_diff=''.join(difflib.unified_diff(before,after,fromfile='formal/'+BC,tofile='recheck/'+BC))
    assert production_diff==m['production_change']['diff']==(BASE/'production.diff').read_bytes().decode()
    assert ident(OLD/'manifest.json')['sha256']==m['formal_manifest_sha256']=='093a0df0ea941eb7cc6bd1206490627ca8196e0951fff18e6601fb513816e8c7'
    assert ident(OLD/'artifact-identity.json')['sha256']==m['formal_artifact_index_sha256']=='05d93ebe31677cef58a1d722e8833abbfd3a9a60ec46c34f09bccf8ed493c91a'
    assert ident(Path(m['protocol']['path']))=={k:m['protocol'][k] for k in ('sha256','bytes')}
    jobs=[f'latency-{s}' for s in (20261105,79463,310519)]+[f'managed-{s}-{r}' for s in (20261105,79463,310519) for r in ('B','I')]
    assert [j['job_id'] for j in m['jobs']]==jobs
    assert sorted(p.parent.name for p in BASE.glob('*/launch.json'))==sorted(jobs)
    assert m['execution']['latency']==old['latency'] and m['execution']['seed_order']==[20261105,79463,310519]
    assert {k:v for k,v in m['execution']['managed'].items() if k in old['resource']}==old['resource']
    assert m['execution']['managed']['role_order_per_seed']==['B','I']
    assert m['execution']['managed']['current_limit_bytes']==262144 and m['execution']['managed']['peak_limit_bytes']==1048576
    assert m['execution']['original_current_over_limit_points_retained']==33
    run_receipts=[];gc_info=[];camera_info=[]
    worker_name='artifacts/integration/managed_current_recheck_001/managed_worker.py'
    worker=sources[worker_name].decode();tree=ast.parse(worker);const=literal_assignments(tree)
    for job in m['jobs']:
        n=job['job_id'];d=BASE/n;launch=read(d/'launch.json');proc=read(d/'process.json');runtime=read(d/'runtime.json')
        assert {k:v for k,v in launch.items() if k!='manifest'}==job
        assert {k:launch['manifest'][k] for k in ('sha256','bytes')}==ident(BASE/'manifest.json')
        assert '--background' in job['argv'] and '--factory-startup' in job['argv'] and job['argv'][-1]==n
        for p,h in job['input_files'].items():assert ident(ROOT/p)['sha256']==h,p
        imports=read(d/'project-imports.json')['paths']
        assert len(imports)==proc['observed_project_imports']
        assert all(m['source_superset'].get(p)==h for p,h in imports.items())
        assert imports[BC]==CANDIDATE
        assert 'artifacts/integration/managed_current_recheck_001/compare.py' not in imports
        assert proc['exit_code']==0 and all(proc[k] for k in ('stable_sources','stable_inputs','runtime_matches','candidate_bc_observed','verified_process'))
        assert not proc['import_discrepancies']
        assert runtime['environment']==job['environment_effective']
        assert runtime['blender_executable']==m['runtime_registration']['blender_executable']
        assert all(runtime[k]==v for k,v in m['runtime_registration']['native_expected'].items())
        prior=next(j for j in old['jobs'] if j['job_id']==n)
        env=dict(prior['environment_effective']);env['PYTHONPYCACHEPREFIX']=job['environment_effective']['PYTHONPYCACHEPREFIX']
        assert env==job['environment_effective']
        clock=runtime['clock'];a=clock['start']['monotonic_before_ns'];b=clock['end']['monotonic_after_ns']
        run_receipts.append({'job':n,'input_count':len(job['input_files']),'actual_import_count':len(imports),
                             'start_qpc_ns':a,'end_qpc_ns':b,'start_utc':utc(clock['start']['utc_ns']),
                             'end_utc':utc(clock['end']['utc_ns']),'pid':runtime['pid'],'process':proc})
        if job['kind']=='latency':
            assert worker_name not in imports
            continue
        assert worker_name in imports
        inst=read(d/'result/instrument.json');g=inst['gc'];c=inst['camera']
        assert inst['valid'] and inst['original_run_completed'] and inst['snapshot_calls']==inst['active_collect_calls']==0
        assert g['enabled_before'] and g['enabled_after'] and g['threshold_before']==g['threshold_after']==[2000,10,10]
        assert g['overflow']==g['callback_errors']==0 and g['first_error_type'] is None and g['buffer_preallocated_before_tracing']
        assert g['capacity']==32768 and g['phase_names']==list(const['PHASES'])
        events=rows(d/'result/gc_events.jsonl');assert len(events)==g['recorded']
        active={};pairs=[]
        for row in events:
            assert a<row['qpc_ns']<b and row['phase']==g['phase_names'][row['phase_id']] and -1<=row['ordinal']<24
            assert row['generation'] in (0,1,2) and row['collected']>=0 and row['uncollectable']>=0
            if row['event']=='start':assert row['generation'] not in active;active[row['generation']]=row
            else:
                assert row['event']=='stop';start=active.pop(row['generation']);assert start['qpc_ns']<row['qpc_ns']
                pairs.append({'start':start,'stop':row,'elapsed_ns':row['qpc_ns']-start['qpc_ns']})
        assert not active and all(x['qpc_ns']<y['qpc_ns'] for x,y in zip(events,events[1:]))
        gc_info.append({'job':n,'events':len(events),'collections':len(pairs),'generation_counts':dict(Counter(p['start']['generation'] for p in pairs)),
                        'threshold':[2000,10,10],'overflow':0,'callback_errors':0,'collections_raw':pairs})
        assert c['valid'] and c['expected_records']==c['recorded']==96 and c['overflow']==c['binding_errors']==0 and c['first_error_type'] is None and c['native_allocation_bytes'] is None
        cams=rows(d/'result/camera_bindings.jsonl');assert len(cams)==96
        assert {(r['ordinal'],r['phase_id'],r['camera_index']) for r in cams}=={(o,p,i) for o in range(24) for p in (6,7) for i in (0,1)}
        case_data={r['ordinal']:r for r in rows(d/'result/cases.jsonl')};assert len(case_data)==24
        groups=defaultdict(list)
        for r in cams:
            assert all(r['bindings'].values()) and r['object_type']=='_bpy_types.Object' and r['data_type']=='bpy.types.Camera'
            assert r['object_kind']=='CAMERA' and r['camera_kind']=='ORTHO' and r['native_allocation_bytes'] is None
            phase='close' if r['phase_id']==6 else 'reopened_close'
            assert r['release_verified']==case_data[r['ordinal']]['lifecycle'][phase]['camera_objects_and_data_removed']==True
            assert r['phase']==('normal_close' if r['phase_id']==6 else 'reopen_exception')
            assert r['object_pointer'] and r['data_pointer'] and r['renderer_python_identity']
            groups[r['ordinal'],r['phase_id']].append(r)
        for pair in groups.values():
            x,y=pair;assert x['renderer_python_identity']==y['renderer_python_identity'] and x['object_pointer']!=y['object_pointer'] and x['data_pointer']!=y['data_pointer']
        camera_info.append({'job':n,'records':96,'groups':len(groups),'all_actual_binding_flags_true':True,
                            'same_renderer_distinct_Object_and_Data_per_pair':True,'release_flags_match_original_close_checks':True,
                            'limit':'Pre-close raw pointer binding; post-close removal is original name/data audit, not a new independently recorded post-close pointer read'})
    assert all(a['end_qpc_ns']<b['start_qpc_ns'] for a,b in zip(run_receipts,run_receipts[1:]))
    batch=read(BASE/'batch-processes.json');start=read(BASE/'batch-started.json')
    assert batch['all_processes_verified'] and batch['processes']==[r['process'] for r in run_receipts]
    assert start['start']['monotonic_after_ns']<run_receipts[0]['start_qpc_ns'] and run_receipts[-1]['end_qpc_ns']<batch['end']['monotonic_before_ns']
    # Reconstruct the precise source transformation without importing the new worker.
    original_file=sources['artifacts/integration/formal_cost_001/resource_instruments.py'].decode()
    original_tree=ast.parse(original_file)
    census=next(n for n in original_tree.body if isinstance(n,ast.FunctionDef) and n.name=='backing_census')
    original='\n'.join(original_file.splitlines()[census.lineno-1:census.end_lineno])+'\n'
    branch=const['CENSUS_BRANCH'];replacement=const['CENSUS_REPLACEMENT']
    assert original.count(branch)==1
    candidate=original.replace(branch,replacement,1)
    cdiff=''.join(difflib.unified_diff(original.splitlines(keepends=True),candidate.splitlines(keepends=True),fromfile='frozen resource_instruments.py:backing_census',tofile='recheck managed_worker.py:backing_census'))
    assert cdiff==m['instrumentation']['census_diff']
    full_diff=cdiff+'\n'+''.join(difflib.unified_diff([],worker.splitlines(keepends=True),fromfile='/dev/null',tofile=worker_name))
    assert sha256(full_diff.encode()).hexdigest()==m['instrumentation']['diff_sha256']
    assert (BASE/'managed-instrumentation.diff').read_bytes()==full_diff.encode()
    for j in jobs[3:]:assert (BASE/j/'result/census.patch').read_text()==cdiff
    forbidden=[]
    for node in ast.walk(tree):
        if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute):
            if node.func.attr in ('collect','set_threshold','take_snapshot','get_referrers','get_referents','disable'):forbidden.append(ast.unparse(node.func))
    assert not forbidden
    callback=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='on_gc')
    assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ('append','write','dump','dumps','take_snapshot') for n in ast.walk(callback))
    # Execute only isolated pure-Python census functions and fake test objects, no Blender imports.
    ns={'np':np,'Mapping':Mapping,'fields':fields,'is_dataclass':is_dataclass,'Enum':Enum,
        'MethodType':MethodType,'FunctionType':FunctionType,'BuiltinMethodType':BuiltinMethodType,'CAMERA_COUNT':2}
    owner=next(n for n in original_tree.body if isinstance(n,ast.FunctionDef) and n.name=='_array_owner')
    predicate=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='_renderer_camera')
    bpy_object=type('Object',(),{'__module__':'_bpy_types'})
    ns['object_type']=bpy_object
    exec(compile(ast.Module(body=[owner,predicate],type_ignores=[]),'isolated frozen helpers','exec'),ns)
    exec(compile(original,'original census','exec'),ns);old_census=ns['backing_census']
    exec(compile(candidate,'candidate census','exec'),ns);new_census=ns['backing_census']
    renderer_type=type('Renderer',(),{'__module__':'human_eye_fast.audit_fixture'})
    cameras=[bpy_object(),bpy_object()]
    for c in cameras:c.type='CAMERA'
    renderer=renderer_type();renderer.cameras=tuple(cameras)
    roots={'renderer':renderer};o=old_census(roots);c=new_census(roots)
    assert o['uncovered_types']=={'renderer':['_bpy_types.Object']} and c['uncovered_types']=={}
    assert c['native_opaque_types']=={'renderer':['_bpy_types.Object']}
    assert o['deduplicated_numpy']==c['deduplicated_numpy'] and o['deduplicated_public_bytes_roots']==c['deduplicated_public_bytes_roots']
    negative={}
    for name,test in [('other_root',{'not_renderer':renderer}),('unlisted_Object',{'renderer':cameras[0]})]:
        # For unlisted Object use a recognized root carrying a nonmember Object.
        if name=='unlisted_Object':
            test_renderer=renderer_type();test_renderer.cameras=tuple(cameras);extra=bpy_object();extra.type='CAMERA';test_renderer.extra=extra;test={'renderer':test_renderer}
        result=new_census(test);assert result['uncovered_types'];negative[name]=result['uncovered_types']
    foreign=type('Object',(),{'__module__':'_bpy_types'})();foreign.type='CAMERA'
    renderer2=renderer_type();renderer2.cameras=(foreign,cameras[0]);negative['not_bpy_Object_isinstance']=new_census({'renderer':renderer2})['uncovered_types'];assert negative['not_bpy_Object_isinstance']
    alien=type('Unknown',(),{'__module__':'unrecognized_native'})();negative['other_unknown']=new_census({'unknown':alien})['uncovered_types'];assert negative['other_unknown']
    cameras[0].type='MESH';negative['non_camera_Object']=new_census(roots)['uncovered_types'];assert negative['non_camera_Object'];cameras[0].type='CAMERA'
    # Registration HEAD is not a claim that its BC blob already contained the working-tree repair.
    production={n:b for n,b in sources.items() if n.startswith('human_eye_fast/')}
    git_sources={}
    for ref in ('02afecc','4372bfc'):
        commit=subprocess.check_output(['git','rev-parse',ref],cwd=ROOT,text=True).strip()
        data=subprocess.check_output(['git','archive','--format=tar',ref,'human_eye_fast'],cwd=ROOT)
        with tarfile.open(fileobj=io.BytesIO(data)) as tar:
            archived={n:tar.extractfile(n).read() for n in production}
        differing=[n for n in production if archived[n]!=production[n]]
        if ref=='02afecc':
            assert differing==[BC] and archived[BC]==bc_before
        else:
            assert not differing
        git_sources[commit]={'production_files':len(archived),'different_from_run_snapshot':differing,
                             'all_equal_to_run_snapshot':not differing,'BC_sha256':sha256(archived[BC]).hexdigest()}
    assert m['git_head_at_registration'] in git_sources
    assert all((ROOT/n).read_bytes()==b for n,b in production.items())
    result={'all_checks_pass':True,'scope':'CPU archive/receipt verification and isolated census classification tests; no Blender/GPU/process rerun',
            'artifact_identity':ident(BASE/'artifact-identity.json'),'artifact_count':16109,'manifest':ident(BASE/'manifest.json'),
            'sources_zip':ident(BASE/'sources.zip'),'source_members':599,'protocol':m['protocol'],
            'changes_from_original_595':changed,'production_diff':production_diff,'git_production_bytes':git_sources,
            'HEAD_interpretation':'02afecc committed BC remains old; registration source ZIP and all actual imports contain the uncommitted 76b25 working-tree repair; 4372bfc commits that exact repaired production byte set',
            'run_receipts':run_receipts,'gc_instrumentation':gc_info,'camera_bindings':camera_info,
            'census_diff_reconstructed_exactly':True,'full_managed_diff_reconstructed_exactly':True,
            'forbidden_calls_in_new_managed_worker':forbidden,'classifier_positive_test':c,'classifier_negative_tests':negative,
            'offline_compare_sha256':ident(BASE/'compare.py'),'offline_comparator_excluded_from_workers':True,
            'run_count_scope':'Exactly nine archived launch/process directories and serial registration; cannot rule out unrecorded activity outside this evidence tree',
            'original_33_failures_reclassified':False}
    OUT.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('run_receipts','gc_instrumentation','camera_bindings','classifier_positive_test')},indent=2))

if __name__=='__main__':main()
