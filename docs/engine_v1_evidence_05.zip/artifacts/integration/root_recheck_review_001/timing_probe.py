"""Independent offline latency, actual bytes, state and old-formal comparison."""
from collections import Counter, defaultdict
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
from statistics import median
from zipfile import ZipFile
import numpy as np

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'artifacts/integration/managed_current_recheck_001'
OLD=ROOT/'artifacts/integration/formal_cost_001/formal'
OUT=Path(__file__).with_suffix('.json')
SEEDS=(20261105,79463,310519)
SEGMENTS={'before':('t0','t1'),'action':('t1','t2'),'feedback':('t2','t3'),'next':('t3','t4'),
          'continuous_total':('t0','t4'),'next_observe':('t3','t_next_observed'),'next_predict':('t_next_observed','t4')}
GATES=tuple(SEGMENTS)[:5]
PUBLIC={'before.ao.json','transition.ao.json','next.ao.json','before.png','after.png','next.png'}
MODELS={f'{p}_{n}' for p in ('v','a') for n in ('keys','values','known','weights','writes')}
CHECKS={'action_ticket_matches_arm','after_actual_label','after_independently_scored_binding','before_actual_label',
        'before_attachment_reused','before_independently_scored_binding','model_writes','next_independently_scored_binding',
        'next_plan_binding','same_active_state_across_repeats','same_frame'}

def read(p):return json.loads(p.read_bytes())
def lines(p):return [json.loads(line) for line in p.read_bytes().splitlines()]
def digest(b):return sha256(b).hexdigest()
def canonical(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode()
def p95(a):return float(np.quantile(a,.95,method='linear'))
def equal_array(a,b):return a.dtype==b.dtype and a.shape==b.shape and a.tobytes()==b.tobytes()
def design(query,deployment,prefix):
    x=np.array(query,dtype=np.float64,copy=True)
    if prefix=='v':x[...,2:]=np.log1p(x[...,2:])
    x=(x-deployment[prefix+'_mean'])/deployment[prefix+'_scale']
    parts=[x]
    if deployment[prefix+'_quadratic']:
        n=x.shape[-1]
        parts.append(np.stack([x[...,i]*x[...,j] for i in range(n) for j in range(i,n)],axis=-1))
    parts.append(np.ones((*x.shape[:-1],1)))
    return np.concatenate(parts,axis=-1)

public_cache={};model_cache={};json_cache={};learning_errors=[];next_prediction_errors=[]
def public(folder,member):
    p=folder/member['file'];assert p.is_relative_to(folder)
    if p not in public_cache:public_cache[p]=p.read_bytes()
    b=public_cache[p]
    assert len(b)==member['bytes'] and digest(b)==member['sha256']
    return b

def model(folder,record,deployment):
    path=folder/record['file']
    assert set(record['members'])==MODELS
    assert digest(b''.join(canonical((name,record['members'][name])) for name in sorted(MODELS)))==record['sha256']
    if path not in model_cache:
        with np.load(path,allow_pickle=False) as z:arrays={k:z[k] for k in z.files}
        assert set(arrays)==MODELS
        for name,array in arrays.items():
            meta=record['members'][name]
            assert array.dtype.str==meta['dtype'] and list(array.shape)==meta['shape'] and digest(array.tobytes())==meta['sha256']
        for prefix in ('v','a'):
            for field in ('keys','values','known'):
                assert equal_array(arrays[f'{prefix}_{field}'][:240],deployment[f'{prefix}_{field}'])
        assert int(arrays['v_writes'])==len(arrays['v_keys'])==242
        assert int(arrays['a_writes'])==len(arrays['a_keys']) in (240,241)
        vw=deployment['v_weights'].copy()
        for slot in (240,241):
            known=arrays['v_known'][slot];assert np.count_nonzero(known)==1
            index=int(np.flatnonzero(known)[0]);label,rays=arrays['v_values'][slot,index]
            assert label in (0,1) and rays>=0 and int(rays)==rays
            d=design(arrays['v_keys'][slot,index],deployment,'v')
            error=np.exp(-np.logaddexp(0.,-(d@vw)))-label
            rate=.05/(1+d@d);vw[:-1]*=1-rate*deployment['v_lambda'];vw-=rate*error*d
        np.testing.assert_allclose(vw,arrays['v_weights'],rtol=2e-14,atol=2e-15)
        aw=deployment['a_weights'].copy()
        if int(arrays['a_writes'])==241:
            assert arrays['a_known'][240,0]
            d=design(arrays['a_keys'][240],deployment,'a')
            error=d@aw-arrays['a_values'][240,0];rate=.05/(1+d@d)
            aw[:-1]*=1-rate*deployment['a_lambda'];aw-=rate*error*d
        np.testing.assert_allclose(aw,arrays['a_weights'],rtol=2e-14,atol=2e-15)
        learning_errors.append({'file':str(path.relative_to(ROOT)),'V_max_abs':float(np.max(np.abs(vw-arrays['v_weights']))),
                                'A_max_abs':float(np.max(np.abs(aw-arrays['a_weights'])))})
        model_cache[path]=arrays
    arrays=model_cache[path]
    for name,array in arrays.items():
        meta=record['members'][name]
        assert (array.dtype.str,list(array.shape),digest(array.tobytes()))==(meta['dtype'],meta['shape'],meta['sha256'])
    return arrays

manifest=read(BASE/'manifest.json');original=read(OLD/'manifest.json')
assert digest((OLD/'manifest.json').read_bytes())==manifest['formal_manifest_sha256']
assert original['limits']['integration_latency_ratio']==1.05
with ZipFile(BASE/'sources.zip') as fresh,ZipFile(OLD/'sources.zip') as old:
    source_checks={}
    for name in ('artifacts/integration/formal_cost_001/common.py','artifacts/integration/formal_cost_001/latency.py',
                 'human_eye_fast/cerebellar_flash.py','verification/integration_reference.py'):
        assert fresh.read(name)==old.read(name)
        assert digest(fresh.read(name))==manifest['source_superset'][name]
        source_checks[name]=digest(fresh.read(name))

reports=[];all_ranges=[]
for process,seed in enumerate(SEEDS):
    folder=BASE/f'latency-{seed}/result';old_folder=OLD/f'latency-{seed}/result'
    config=original['seeds'][process];assert config['seed']==seed
    with np.load(ROOT/config['deployment'],allow_pickle=False) as z:deployment={k:z[k] for k in z.files}
    pristine={'v_weights':deployment['v_weights'],'a_weights':deployment['a_weights']}
    for prefix in ('v','a'):
        pristine[prefix+'_writes']=np.array(240,dtype='<i8')
        for field in ('keys','values','known'):pristine[prefix+'_'+field]=deployment[prefix+'_'+field]
    h=sha256()
    for name,array in pristine.items():
        h.update(json.dumps((name,array.dtype.str,array.shape),separators=(',',':')).encode());h.update(array.tobytes())
    pristine_hash=h.hexdigest()
    rows=lines(folder/'intervals.jsonl');proofs=lines(folder/'proofs.jsonl');pairs=lines(folder/'pairs.jsonl')
    old_proofs=lines(old_folder/'proofs.jsonl')
    expected_keys=[(c,p,r) for c in range(24) for p in range(36) for r in (('B','I') if (process+c+p)%2==0 else ('I','B'))]
    assert [(r['ordinal'],r['pair'],r['role']) for r in rows]==expected_keys
    assert [(r['ordinal'],r['pair'],r['role']) for r in proofs]==expected_keys
    assert [(r['ordinal'],r['pair'],r['role']) for r in old_proofs]==expected_keys
    assert len(rows)==len(proofs)==len(old_proofs)==1728 and len(pairs)==864
    assert [(r['ordinal'],r['pair']) for r in pairs]==[(c,p) for c in range(24) for p in range(36)]
    keys=dict(zip(expected_keys,rows));pk=dict(zip(expected_keys,proofs));ok=dict(zip(expected_keys,old_proofs))
    measured=defaultdict(list);physical={};prior_global=None;prior_by_case={};families={}
    repeat_state={};negative_updates=Counter();array_comparisons=0;public_comparisons=0
    for row,proof,old_proof in zip(rows,proofs,old_proofs,strict=True):
        c,p,role=row['ordinal'],row['pair'],row['role'];key=(c,p,role)
        plan=original['formal_plans'][c];case=plan['case_id'];ids=original['iterations'][p]
        feedback=config['integration_feedback'][case]
        assert row['case_id']==proof['case_id']==old_proof['case_id']==case
        assert row['warmup']==proof['warmup']==(p<5)
        assert proof['physical_instance']==row['physical_instance']
        create=['B','I'] if (process+c)%2==0 else ['I','B'];execute=['B','I'] if (process+c+p)%2==0 else ['I','B']
        assert row['creation_roles']==create and row['creation_index']==create.index(role)
        assert row['execution_roles']==execute and row['execution_index']==execute.index(role)
        assert physical.setdefault((c,role),row['physical_instance'])==row['physical_instance']
        assert families.setdefault(c,row['family'])==row['family']
        stamps=row['counter_ns'];ordered=[stamps[k] for k in ('t0','t1','t2','t3','t_next_observed','t4')]
        assert all(a<b for a,b in zip(ordered,ordered[1:]))
        assert prior_global is None or prior_global<=stamps['t0'];prior_global=stamps['t4']
        previous=prior_by_case.get(c)
        assert row['prior_arm_t4_to_t0_ns']==(None if previous is None else stamps['t0']-previous)
        prior_by_case[c]=stamps['t4'];assert row['reset_ns']>0
        assert set(row['ns'])==set(SEGMENTS)
        for segment,(a,b) in SEGMENTS.items():
            value=stamps[b]-stamps[a];assert value==row['ns'][segment]
            if p>=5:measured[c,role,segment].append(value)
        assert row['ns']['continuous_total']==sum(row['ns'][s] for s in ('before','action','feedback','next'))
        assert row['ns']['next']==row['ns']['next_observe']+row['ns']['next_predict']
        assert set(proof['checks'])==set(old_proof['checks'])==CHECKS
        assert all(type(v) is bool and v for v in proof['checks'].values())
        assert proof['pristine_active_state']==old_proof['pristine_active_state']==pristine_hash
        assert canonical(proof['next'])==canonical(old_proof['next'])
        assert set(proof['public'])==set(old_proof['public'])==PUBLIC
        public_bytes={}
        for name in PUBLIC:
            new=public(folder,proof['public'][name]);historical=public(old_folder,old_proof['public'][name])
            assert new==historical;public_comparisons+=1;public_bytes[name]=new
        arrays=model(folder,proof['model'],deployment);old_arrays=model(old_folder,old_proof['model'],deployment)
        assert all(equal_array(arrays[name],old_arrays[name]) for name in MODELS);array_comparisons+=len(MODELS)
        state=proof['model']['sha256'];assert repeat_state.setdefault((c,role),state)==state
        follow=proof['next'];assert follow['observation_id']==ids['next'] and follow['action_id']==ids['next_action']
        assert follow['predictor']==plan['arms']['deployment']['predictor']
        next_command=plan['next_command_prediction_only']['command']
        wanted_command={'delta_world_m':next_command['delta_world_m']} if next_command['kind']=='translate' else {'key_name':next_command['key_name'],'value':next_command['target_value']}
        assert canonical(follow['command'])==canonical(wanted_command)
        before=json.loads(public_bytes['before.ao.json']);joint=json.loads(public_bytes['transition.ao.json']);following=json.loads(public_bytes['next.ao.json'])
        assert before[0:2]==joint[0:2]==following[0:2]==['he-ao/1','m']
        assert len(before[3])==len(following[3])==1 and len(joint[3])==2
        assert joint[3][0]==before[3][0]
        assert joint[4][0:3]==[ids['action'],ids['before'],ids['after']]
        assert joint[4][9]==joint[4][8]-joint[4][7]
        observations={'before':before[3][0],'after':joint[3][1],'next':following[3][0]}
        for offset,phase in enumerate(('before','after','next')):
            obs=observations[phase];a=follow['view_audits'][phase];f=feedback[phase]
            assert obs[0]==ids[phase] and obs[1]==f['frame_id'] and obs[5][0]==ids[phase]+'.png'
            assert digest(public_bytes[phase+'.png'])==f['png_sha256']
            assert a['canonical_index']==f['canonical_index'] and a['direction']==f['direction'] and a['order']==f['order']
            assert a['total_rays']==f['total_rays'] and a['native_stop']==f['native_stop']
            selected=next(probe for probe in a['probes'] if probe['direction']==a['direction'])
            assert selected['ray_count']==f['selected_rays']
            if offset<2:
                slot=240+offset;index=a['canonical_index']
                assert np.flatnonzero(arrays['v_known'][slot]).tolist()==[index]
                assert arrays['v_values'][slot,index].tolist()==[float(f['safe']),f['selected_rays']]
                assert f['safe']==bool(f['pixel_success'] and f['native_stop'])
                if not f['safe']:negative_updates[case+'/'+phase]+=1
        assert int(arrays['a_writes'])==240+(follow['predictor']=='L')
        vscore=design(follow['view_features'],deployment,'v')@arrays['v_weights']
        assert sorted(range(16),key=lambda k:(-vscore[k],k))==follow['view_audits']['next']['order']
        if follow['predictor']=='L':
            features=np.asarray(follow['action_features']);wanted=follow['action_meters']*(features[1]+design(features,deployment,'a')@arrays['a_weights'])
            error=abs(wanted-follow['predicted_delta_m']);next_prediction_errors.append(float(error))
            assert np.isclose(wanted,follow['predicted_delta_m'],rtol=2e-14,atol=1e-16)
        else:assert follow['action_features'] is None and follow['action_meters'] is None
    assert len(set(physical.values()))==48
    assert sorted(Counter(families.values()).values())==[4]*6
    for c in range(24):
        for p in range(36):
            b,i=pk[c,p,'B'],pk[c,p,'I'];pair=pairs[c*36+p]
            assert pair['case_id']==keys[c,p,'B']['case_id'] and pair['warmup']==(p<5)
            assert pair['equivalent'] and pair['all_binding_and_repeat_checks_valid'] and pair['next_fields_exact'] and pair['post_feedback_active_model_exact'] and pair['pristine_active_state_exact']
            assert pair['different_public_members']==[] and pair['failed_checks']=={'B':[],'I':[]}
            assert canonical(b['next'])==canonical(i['next']) and b['pristine_active_state']==i['pristine_active_state']
            for name in PUBLIC:assert public(folder,b['public'][name])==public(folder,i['public'][name])
            ba=model(folder,b['model'],deployment);ia=model(folder,i['model'],deployment)
            assert all(equal_array(ba[name],ia[name]) for name in MODELS)
    for left,right in zip(proofs,rows[1:]):
        prior=keys[left['ordinal'],left['pair'],left['role']]['counter_ns']['t4']
        assert prior+left['t4_to_proof_serialization_ns']<=right['counter_ns']['t0']
    summary=read(folder/'summary.json');assert summary['ratio_limit']==1.05 and summary['manifest_sha256']==manifest['formal_manifest_sha256']
    assert summary['warm_pairs_per_case']==5 and summary['measured_pairs_per_case']==31 and not summary['timing_gate_uses_pooled_data']
    segments={}
    for segment in SEGMENTS:
        assert all(len(measured[c,r,segment])==31 for c in range(24) for r in ('B','I'))
        med={r:[float(median(measured[c,r,segment])) for c in range(24)] for r in ('B','I')}
        absolute={r:p95(v) for r,v in med.items()};ratio=absolute['I']/absolute['B']
        assert summary['segments'][segment]['p95_ns']==absolute and summary['segments'][segment]['I_over_B']==ratio
        local=[med['I'][c]/med['B'][c] for c in range(24)];worst=max(range(24),key=local.__getitem__)
        byfamily={}
        for family in sorted(set(families.values())):
            cs=[c for c in range(24) if families[c]==family];pvals={r:p95([med[r][c] for c in cs]) for r in ('B','I')}
            rr=pvals['I']/pvals['B'];assert summary['segments'][segment]['by_family'][family]['p95_ns']==pvals
            assert summary['segments'][segment]['by_family'][family]['I_over_B']==rr
            byfamily[family]={'p95_ns':pvals,'I_over_B':rr}
        for c in range(24):
            item=summary['segments'][segment]['by_case'][keys[c,5,'B']['case_id']]
            assert item['I_over_B_medians']==local[c]
            for role in ('B','I'):
                values=measured[c,role,segment]
                assert item['arms'][role]=={'count':31,'median_ns':med[role][c],'p95_ns':p95(values),'minimum_ns':min(values),'maximum_ns':max(values)}
        gate=ratio<=1.05 if segment in GATES else None
        if segment in GATES:assert gate and summary['segments'][segment]['gate']=='PASS'
        else:assert summary['segments'][segment]['gate']=='DESCRIPTIVE_ONLY'
        slow=max((r for r in rows if not r['warmup']),key=lambda r:r['ns'][segment])
        segments[segment]={'p95_ns':absolute,'I_over_B':ratio,'passed':gate,'case_medians_ns':med,
            'case_ratios_I_over_B':local,'by_family':byfamily,'worst_case':keys[worst,5,'B']['case_id'],'worst_case_ratio':local[worst],
            'cases_above_1_05':[keys[c,5,'B']['case_id'] for c,x in enumerate(local) if x>1.05],
            'slowest_measured_row':{k:slow[k] for k in ('case_id','pair','role')},'slowest_measured_ns':slow['ns'][segment]}
    gc=read(folder/'gc.json');old_gc=read(old_folder/'gc.json')
    assert gc['initial']['enabled'] and gc['initial']['thresholds']==old_gc['initial']['thresholds']
    events=gc['events'];assert [e['qpc_ns'] for e in events]==sorted(e['qpc_ns'] for e in events)
    pending={};spans=[]
    for event in events:
        gen=event['generation']
        if event['event']=='start':assert gen not in pending;pending[gen]=event['qpc_ns']
        else:
            start=pending.pop(gen);assert event['duration_ns']==event['qpc_ns']-start
            spans.append((start,event['qpc_ns'],gen))
    assert not pending
    overlaps={role:{} for role in ('B','I')};overlapping_rows=[]
    for role in overlaps:
        for segment,(a,b) in SEGMENTS.items():
            values=[]
            for row in rows:
                if row['role']!=role or row['warmup']:continue
                delta=sum(max(0,min(row['counter_ns'][b],stop)-max(row['counter_ns'][a],start)) for start,stop,_ in spans)
                values.append(delta)
                if delta and segment=='continuous_total':overlapping_rows.append({'case_id':row['case_id'],'pair':row['pair'],'role':role,'overlap_ns':delta,'total_ns':row['ns']['continuous_total']})
            entry={'measured_rows_with_overlap':sum(x>0 for x in values),'maximum_overlap_ns':max(values)}
            overlaps[role][segment]=entry
            if segment!='next':assert summary['gc_measured_overlap'][role][segment]==entry
    anchors=read(folder/'time_anchors.json');clock=read(folder/'clock.json')
    assert clock['perf_counter']['monotonic'] and not clock['perf_counter']['adjustable'] and len(clock['empty_ns'])==1000
    assert anchors['start']==clock['start'] and anchors['start']['qpc_after_ns']<rows[0]['counter_ns']['t0']
    assert rows[-1]['counter_ns']['t4']<anchors['end']['qpc_before_ns']
    assert len({(r['ordinal'],r['pair'],r['role']) for r in rows if r['warmup']})==240
    all_ranges.append((anchors['start']['qpc_before_ns'],anchors['end']['qpc_after_ns']))
    reports.append({'seed':seed,'rows':1728,'pairs':864,'warm_pairs':120,'measured_pairs':744,'physical_lanes':48,
        'all_pair_and_old_formal_actual_public_bytes_exact':True,'old_formal_public_comparisons':public_comparisons,
        'all_pair_and_old_formal_model_arrays_bitwise_exact':True,'old_formal_array_comparisons':array_comparisons,
        'all_pair_and_old_formal_next_fields_exact':True,'negative_feedback_updates_by_case':dict(negative_updates),
        'segments':segments,'gc':{'thresholds':gc['initial']['thresholds'],'events':len(events),'collections':len(spans),
        'by_generation':dict(Counter(gen for _,_,gen in spans)),'measured_overlap':overlaps,'overlap_rows_retained':overlapping_rows},
        'clock':{'resolution_seconds':clock['perf_counter']['resolution'],'empty_call_median_ns':median(clock['empty_ns']),
                 'start_utc':datetime.fromtimestamp(anchors['start']['utc_unix_ns']/1e9,timezone.utc).isoformat(),
                 'end_utc':datetime.fromtimestamp(anchors['end']['utc_unix_ns']/1e9,timezone.utc).isoformat()}})
assert all(a[1]<b[0] for a,b in zip(all_ranges,all_ranges[1:]))
result={'decision':'ACCEPT_RECHECK_LATENCY_AND_OBSERVED_FUNCTIONAL_EQUIVALENCE','scope':'Independent CPU recomputation; no native run or author compare.py execution',
    'source_unchanged_timing_semantics':source_checks,'seeds':reports,'total_rows':5184,'total_pairs':2592,'measured_pairs':2232,
    'all_fifteen_preregistered_gates_passed':all(s['segments'][g]['passed'] for s in reports for g in GATES),
    'public_files_read_and_verified':len(public_cache),'active_npz_files_read_and_verified':len(model_cache),
    'new_public_files':sum(p.is_relative_to(BASE) for p in public_cache),'new_model_files':sum(p.is_relative_to(BASE) for p in model_cache),
    'old_formal_public_content_comparisons':sum(r['old_formal_public_comparisons'] for r in reports),
    'old_formal_active_array_bitwise_comparisons':sum(r['old_formal_array_comparisons'] for r in reports),
    'independent_learning_reconstruction_max_abs':{head:max(r[head+'_max_abs'] for r in learning_errors) for head in ('V','A')},
    'independent_next_L_prediction_max_abs':max(next_prediction_errors,default=0),
    'arithmetic_check_tolerance_only':{'update_rtol':2e-14,'update_atol':2e-15,'next_prediction_rtol':2e-14,'next_prediction_atol':1e-16},
    'arithmetic_tolerance_does_not_relax_bitwise_pair_or_old_formal_comparisons':True,
    'no_slow_or_gc_row_excluded':True,'new_qualification_exemptions':False,
    'limits':['Collection p95 gates do not assert every case or every repeat is non-regressing.',
              'Independent learning arithmetic uses saved actual feature rows; it is not a new independent geometry/feature-extraction oracle.',
              'G next geometry prediction is checked exactly against B and old formal proof, not independently recomputed from unavailable full host geometry.',
              'This review does not adjudicate resource gates or replace original failed evidence.']}
OUT.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in result.items() if k!='seeds'},indent=2))
for r in reports:print(r['seed'],{g:r['segments'][g]['I_over_B'] for g in GATES},'GC',r['gc']['collections'],len(r['gc']['overlap_rows_retained']))
