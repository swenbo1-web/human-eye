"""Read-only source comparison for the accepted functional engine and repair."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess


ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).with_suffix('.json')
BASE = '79f8bcc'
BC = 'human_eye_fast/fast_bvh_clearance.py'
manifest = json.loads((ROOT / 'artifacts/integration/managed_current_recheck_001/manifest.json').read_text())
records = {}
changed = []
for path in sorted((ROOT / 'human_eye_fast').glob('*.py')):
    name = path.relative_to(ROOT).as_posix()
    current = path.read_bytes()
    previous = subprocess.check_output(['git', 'show', f'{BASE}:{name}'], cwd=ROOT)
    digest = hashlib.sha256(current).hexdigest()
    assert digest == manifest['source_superset'][name], name
    records[name] = {'sha256': digest, 'bytes': len(current), 'same_as_functional_base': current == previous}
    if current != previous:
        changed.append(name)
        old_bc, new_bc = previous, current
    tree = ast.parse(current, filename=name)
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            modules = [item.name for item in node.names]
        elif isinstance(node, ast.ImportFrom):
            modules = [node.module or '']
        else:
            continue
        assert all(not module.startswith(('verification', 'artifacts')) for module in modules), name
assert len(records) == 17
assert changed == [BC]
assert new_bc == old_bc.replace(b'            split(0, count, depth)\r\n',
                               b'            split(0, count, depth)\r\n            del split\r\n', 1)
old_tree = ast.parse(old_bc)
new_tree = ast.parse(new_bc)
deleted = []
for node in ast.walk(new_tree):
    for field, value in ast.iter_fields(node):
        if isinstance(value, list):
            matches = [item for item in value if isinstance(item, ast.Delete)
                       and len(item.targets) == 1 and isinstance(item.targets[0], ast.Name)
                       and item.targets[0].id == 'split']
            if matches:
                deleted.extend(matches)
                setattr(node, field, [item for item in value if item not in matches])
assert len(deleted) == 1
assert ast.dump(old_tree) == ast.dump(new_tree)
result = {
    'scope': 'Source/AST evidence only; no new native run, numerical test or performance claim',
    'functional_base_commit': BASE,
    'production_file_count': len(records),
    'unchanged_production_files': len(records) - len(changed),
    'changed_files': changed,
    'only_AST_change': 'Delete split immediately after successful recursive construction',
    'no_verification_or_artifacts_imports': True,
    'registered_production_sources_match': True,
    'source_files': records,
    'all_checks_pass': True,
}
OUT.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in result.items() if k != 'source_files'}))
