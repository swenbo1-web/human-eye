"""Independent offline resource/semantic recomputation; imports no project code."""
from collections import Counter
from copy import deepcopy
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import zipfile

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
NEW = ROOT / "artifacts/integration/managed_current_recheck_001"
OLD = ROOT / "artifacts/integration/formal_cost_001/formal"
SEEDS = (20261105, 79463, 310519)
HOT = ("hot_outputs_held", "hot_outputs_released", "hot_reference_replaced")
POINTS = ("cold_before_lane", "cold_reference_ready", "cold_session_ready", "cold_basis_ready",
          "cold_lane_ready", *HOT, "closed_public_bytes_held", "closed_public_bytes_released",
          "cold_before_reopen", "cold_reopened_lane_ready", "reopened_outputs_held", "reopened_released")
ROOTS = {"bridge", "indexes", "readback", "model", "reference", "renderer", "current", "basis",
         "validation_reset_weights", "caller_outputs"}
PUBLIC = {"before.ao.json", "transition.ao.json", "next.ao.json", "before.png", "after.png", "next.png"}
ACTIVE_ORDER = ("v_weights", "a_weights", "v_writes", "v_keys", "v_values", "v_known",
                "a_writes", "a_keys", "a_values", "a_known")
ERRORS, COUNTS, READS = [], Counter(), {}
INDEXES = {root: json.loads((root / "artifact-identity.json").read_bytes())["files"] for root in (OLD, NEW)}


def check(condition, reason):
    if not condition:
        ERRORS.append(reason)


def identity(data):
    return {"bytes": len(data), "sha256": sha256(data).hexdigest()}


def read(root, relative):
    data = (root / relative).read_bytes()
    actual = identity(data)
    check(actual == INDEXES[root].get(relative), f"identity: {root.name}/{relative}")
    READS[(root / relative).relative_to(ROOT).as_posix()] = actual
    return data


def doc(root, relative):
    return json.loads(read(root, relative))


def lines(root, relative):
    return [json.loads(line) for line in read(root, relative).splitlines()]


def wire(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False, separators=(",", ":")).encode()


def normal_census(old):
    expected = deepcopy(old)
    missing = expected["uncovered_types"]
    if "_bpy_types.Object" in missing.get("renderer", []):
        missing["renderer"].remove("_bpy_types.Object")
        if not missing["renderer"]:
            del missing["renderer"]
        native = expected["native_opaque_types"].setdefault("renderer", [])
        native.append("_bpy_types.Object")
        native.sort()
    return expected


def census(row, label):
    owner = row["ownership"]
    groups = owner["attribution_groups"]
    check(not owner["uncovered_types"], label + ": uncovered type")
    for kind, category, count_key, bytes_key in (
        ("numpy", "deduplicated_numpy", "unique_backings", "backing_bytes"),
        ("bytes", "deduplicated_public_bytes_roots", "unique_buffers", "bytes"),
    ):
        selected = [g for g in groups if g["kind"] == kind]
        check(owner[category][count_key] == sum(g["unique_backings"] for g in selected), label + ": backing count")
        check(owner[category][bytes_key] == sum(g["bytes"] for g in selected), label + ": backing sum")
    for name, data in owner["per_root_numpy"].items():
        selected = [g for g in groups if g["kind"] == "numpy" and name in g["roots"]]
        check(data["unique_backings"] == sum(g["unique_backings"] for g in selected), label + ": root count " + name)
        check(data["backing_bytes"] == sum(g["bytes"] for g in selected), label + ": root bytes " + name)
    allowed_roots = {"immutable_deployment_parameters"} if row["point"] == "cold_after_workload_load" else ROOTS
    check(all(set(g["roots"]) <= allowed_roots for g in groups), label + ": unexpected root")
    if row["point"] == "cold_after_workload_load":
        check(set(owner["per_root_numpy"]) == allowed_roots, label + ": immutable deployment root")
    COUNTS["censuses_internally_recomputed"] += 1
    point = row["point"]
    if point in (*HOT, "reopened_outputs_held", "cold_lane_ready", "closed_public_bytes_held", "closed_public_bytes_released", "cold_reopened_lane_ready"):
        check(set(owner["per_root_numpy"]) == ROOTS, label + ": missing owner root")
    if point in (*HOT, "reopened_outputs_held"):
        check(owner["native_opaque_types"] == {"renderer": ["_bpy_types.Object", "builtins.GPUOffScreen", "builtins.GPUShader"]}, label + ": opaque owner")
        COUNTS["renderer_opaque_censuses"] += 1
    if point in ("closed_public_bytes_held", "closed_public_bytes_released", "reopened_released"):
        check(owner["deduplicated_numpy"] == {"unique_backings": 0, "backing_bytes": 0}, label + ": owned arrays retained after close")
        check(not owner["native_opaque_types"], label + ": owned native reference after close")
        if point != "closed_public_bytes_held":
            check(owner["deduplicated_public_bytes_roots"] == {"unique_buffers": 0, "bytes": 0}, label + ": public roots after release")


def proof_check(proof, label):
    check(set(proof) == {"checks", "public", "active_model_sha256", "next_sha256"}, label + ": proof fields")
    check(set(proof["public"]) == PUBLIC, label + ": public fields")
    check(len(proof["checks"]) == 10 and all(value is True for value in proof["checks"].values()), label + ": binding checks")
    check(all(len(proof[key]) == 64 for key in ("active_model_sha256", "next_sha256")), label + ": digest")


def model_read(root, directory, row):
    raw = read(root, directory + "/" + row["model"]["file"])
    with np.load(BytesIO(raw), allow_pickle=False) as archive:
        arrays = {name: archive[name] for name in archive.files}
    check(set(arrays) == set(ACTIVE_ORDER), "NPZ active members")
    named, member_hash = {}, sha256()
    for name in sorted(arrays):
        array = arrays[name]
        member = {"dtype": array.dtype.str, "shape": list(array.shape), "sha256": sha256(array.tobytes()).hexdigest()}
        named[name] = member
        member_hash.update(wire((name, member)))
    check(named == row["model"]["members"] and member_hash.hexdigest() == row["model"]["sha256"], "NPZ saved receipt")
    sequential = sha256()
    for name in ACTIVE_ORDER:
        array = arrays[name]
        sequential.update(json.dumps((name, array.dtype.str, array.shape), separators=(",", ":")).encode())
        sequential.update(array.tobytes())
    COUNTS["actual_npz_loaded"] += 1
    return arrays, sequential.hexdigest()


def stats(rows, key):
    worst = max(rows, key=lambda row: row[key])
    return {"count": len(rows), "min": min(row[key] for row in rows), "max": worst[key],
            "max_seed": worst["seed"], "max_case": worst["case"],
            "over_limit": sum(row[key] > row["limit"] for row in rows)}


def main():
    old_manifest = doc(OLD, "manifest.json")
    new_manifest = doc(NEW, "manifest.json")
    old_index_sha = sha256((OLD / "artifact-identity.json").read_bytes()).hexdigest()
    check(old_index_sha == new_manifest["formal_artifact_index_sha256"] == "05d93ebe31677cef58a1d722e8833abbfd3a9a60ec46c34f09bccf8ed493c91a", "immutable historical file index binding")
    check(identity((OLD / "manifest.json").read_bytes())["sha256"] == new_manifest["formal_manifest_sha256"], "formal manifest binding")
    check(new_manifest["execution"]["managed"] | {} == old_manifest["resource"] | {
        "role_order_per_seed": ["B", "I"], "current_limit_bytes": 262144, "peak_limit_bytes": 1048576}, "managed execution registration")
    case_ids = [row["case_id"] for row in old_manifest["formal_plans"]]
    check(len(case_ids) == len(set(case_ids)) == 24, "case list")
    source_comparisons = {}
    with zipfile.ZipFile(BytesIO(read(OLD, "sources.zip"))) as old_zip, zipfile.ZipFile(BytesIO(read(NEW, "sources.zip"))) as new_zip:
        for name in ("resources.py", "resource_instruments.py", "common.py"):
            key = "artifacts/integration/formal_cost_001/" + name
            a, b = old_zip.read(key), new_zip.read(key)
            check(a == b, "unchanged base resource source: " + name)
            source_comparisons[key] = {"unchanged": a == b, **identity(b)}
    rows_by_seed, checkpoints_by_seed = {}, {}
    current, peaks, checkpoint_deltas, history_deltas = [], [], [], []
    lifecycle_rows, proof_rows, workers = [], [], []
    for seed_index, seed in enumerate(SEEDS):
        cases, checkpoints = {}, {}
        for role in ("B", "I"):
            prefix = f"managed-{seed}-{role}/result/"
            summary = doc(NEW, prefix + "summary.json")
            expected_summary = {"seed": seed, "role": role, "instrument": "managed", "process_index": seed_index,
                                "cases": 24, "warm_chains_per_case": 5, "measured_chains_per_case": 1,
                                "measured_pair": 5, "untimed_resource_lifecycle_pairs": [36, 37],
                                "managed_hot_points": list(HOT), "manifest_sha256": new_manifest["formal_manifest_sha256"]}
            check(all(summary[k] == v for k, v in expected_summary.items()), prefix + "summary input/order")
            old_cases, new_cases = lines(OLD, prefix + "cases.jsonl"), lines(NEW, prefix + "cases.jsonl")
            old_points, new_points = lines(OLD, prefix + "checkpoints.jsonl"), lines(NEW, prefix + "checkpoints.jsonl")
            expected_keys = [(None, "cold_before_workload_load"), (None, "cold_after_workload_load")]
            expected_keys += [(case_id, point) for case_id in case_ids for point in POINTS]
            check([(r["case"], r["point"]) for r in new_points] == expected_keys, prefix + "exact checkpoint sequence")
            check([(r["case"], r["point"]) for r in old_points] == expected_keys, prefix + "old checkpoint sequence")
            check([r["case"] for r in new_cases] == case_ids and [r["ordinal"] for r in new_cases] == list(range(24)), prefix + "exact case sequence")
            cases[role] = new_cases
            checkpoints[role] = {(r["case"], r["point"]): r for r in new_points}
            for old_row, row in zip(old_points, new_points, strict=True):
                label = f"{seed}/{role}/{row['case']}/{row['point']}"
                census(row, label)
                check(normal_census(old_row["ownership"]) == row["ownership"], label + ": census changed beyond exact opaque classification")
                COUNTS["censuses_exact_to_old_except_authorized_camera_classification"] += 1
            last_t4 = 0
            for ordinal, (old_row, row) in enumerate(zip(old_cases, new_cases, strict=True)):
                case_id = case_ids[ordinal]
                label = f"{seed}/{role}/{case_id}"
                check(all(row[k] == old_row[k] for k in ("case", "ordinal", "family", "role", "instrument")), label + ": case binding")
                stamps = [row["stamps_qpc_ns"][key] for key in ("t0", "t1", "t2", "t3", "t_next_observed", "t4")]
                check(stamps == sorted(stamps) and last_t4 < stamps[0], label + ": sequential complete hot QPC")
                last_t4 = stamps[-1]
                for phase, a, b in (("hot", old_row["hot_proof"], row["hot_proof"]),
                                    ("reopen", old_row["lifecycle"]["reopened_proof"], row["lifecycle"]["reopened_proof"])):
                    proof_check(b, label + "/" + phase)
                    exact = wire(a) == wire(b)
                    check(exact, label + ": exact historical " + phase + " proof")
                    proof_rows.append({"seed": seed, "role": role, "case": case_id, "phase": phase, "exact_to_original_without_normalization": exact})
                life = row["lifecycle"]
                check(wire(life) == wire(old_row["lifecycle"]), label + ": complete original lifecycle equality")
                check(all(value is True for value in life["close"].values()) and len(life["close"]) == 6, label + ": close release")
                check(all(value is True for value in life["reopened_close"].values()) and len(life["reopened_close"]) == 6, label + ": exception release")
                check(life["fresh_reopen"] is True and life["reopened_ticket_owner_is_distinct"] is True, label + ": new session owner")
                check(life["reopened_close_trigger"] == "untimed caller exception through lane finally", label + ": exception scope")
                check(life["closed_public"]["public_bytes_valid"] is True and life["closed_public"]["unchanged_across_close"] is True, label + ": public bytes after close")
                cp = checkpoints[role]
                held = cp[case_id, "closed_public_bytes_held"]["ownership"]["deduplicated_public_bytes_roots"]
                check(held == {"unique_buffers": 6, "bytes": sum(x["bytes"] for x in life["closed_public"]["retained"].values())}, label + ": retained bytes backing")
                gpu = row["logical_gpu"]
                check(gpu == old_row["logical_gpu"] and gpu["renderers"] == 1 and len(gpu["cameras"]) == 2 and len(gpu["offscreen"]) == 1 and len(gpu["batches"]) == 6, label + ": logical GPU")
                lifecycle_rows.append({"seed": seed, "role": role, "case": case_id, "old_lifecycle_exact": life == old_row["lifecycle"], "old_logical_gpu_exact": gpu == old_row["logical_gpu"]})
                managed = row["managed"]
                check(managed["window_peak_bytes"] == cp[case_id, HOT[0]]["peak_since_latest_reset_bytes"], label + ": t4 full peak")
                check(managed["peak_above_start_bytes"] == managed["window_peak_bytes"] - managed["current_before_reset_bytes"], label + ": increment separately recorded")
                for point in HOT:
                    check(managed["current_bytes"][point] == cp[case_id, point]["current_bytes"], label + ": current raw correspondence")
                    check(managed["ownership_covered"][point] is True, label + ": known owner gate")
                check(not row.get("error"), label + ": worker error")
            workers.append({"seed": seed, "role": role, "cases": len(new_cases), "checkpoints": len(new_points), "pid": summary["pid"], "exact_case_and_point_sequence": True})
        rows_by_seed[seed], checkpoints_by_seed[seed] = cases, checkpoints
        for key, b in checkpoints["B"].items():
            i = checkpoints["I"][key]
            check(b["ownership"] == i["ownership"], f"{seed}/{key}: B/I full ownership equality")
            checkpoint_deltas.append({"seed": seed, "case": key[0], "point": key[1], "B_current": b["current_bytes"], "I_current": i["current_bytes"], "delta": i["current_bytes"]-b["current_bytes"]})
        for ordinal, (b, i) in enumerate(zip(cases["B"], cases["I"], strict=True)):
            check(b["hot_proof"] == i["hot_proof"] and b["lifecycle"] == i["lifecycle"] and b["logical_gpu"] == i["logical_gpu"], f"{seed}/{ordinal}: B/I semantic/lifecycle equality")
            for point in HOT:
                bv, iv = (checkpoints[role][(b["case"], point)]["current_bytes"] for role in ("B", "I"))
                current.append({"seed": seed, "case": b["case"], "ordinal": ordinal, "point": point, "B": bv, "I": iv, "delta": iv-bv, "limit": 262144})
            bv, iv = b["managed"]["window_peak_bytes"], i["managed"]["window_peak_bytes"]
            peaks.append({"seed": seed, "case": b["case"], "ordinal": ordinal, "B": bv, "I": iv, "delta": iv-bv, "limit": 1048576})
        old_b = lines(OLD, f"managed-{seed}-B/result/cases.jsonl")
        old_i = lines(OLD, f"managed-{seed}-I/result/cases.jsonl")
        for b, i in zip(old_b, old_i, strict=True):
            for point in HOT:
                history_deltas.append(i["managed"]["current_bytes"][point] - b["managed"]["current_bytes"][point])

    # Cross-link actual saved hot-pair AO/PNG/NPZ/next from both latency generations
    # to managed proof receipts. Reopen receipts are compared exactly to old raw
    # receipts above; no nonexistent managed NPZ/blob store is claimed.
    crosslinks = []
    for seed in SEEDS:
        directory = f"latency-{seed}/result"
        selected = {}
        for root in (OLD, NEW):
            proof_rows_all = lines(root, directory + "/proofs.jsonl")
            selected[root] = {(r["ordinal"], r["role"]): r for r in proof_rows_all if r["pair"] == 5}
            check(len(selected[root]) == 48, f"{root.name}/{seed}: all actual hot pair proof rows")
        for ordinal, case_id in enumerate(case_ids):
            for role in ("B", "I"):
                originals = {}
                for root in (OLD, NEW):
                    row = selected[root][ordinal, role]
                    managed = (rows_by_seed[seed][role][ordinal] if root == NEW else
                               json.loads((OLD / f"managed-{seed}-{role}/result/cases.jsonl").read_bytes().splitlines()[ordinal]))
                    public_data = {}
                    for name, receipt in row["public"].items():
                        raw = read(root, directory + "/" + receipt["file"])
                        check(identity(raw) == {k: receipt[k] for k in ("bytes", "sha256")}, "actual public blob receipt")
                        check(identity(raw) == managed["hot_proof"]["public"][name], "actual public blob/managed hot receipt")
                        public_data[name] = raw
                        COUNTS["actual_public_blob_receipts_checked"] += 1
                    arrays, active_digest = model_read(root, directory, row)
                    check(active_digest == managed["hot_proof"]["active_model_sha256"], "actual NPZ/managed hot active state")
                    check(active_digest == managed["lifecycle"]["reopened_proof"]["active_model_sha256"], "actual NPZ/managed reopened active state")
                    check(sha256(wire(row["next"])).hexdigest() == managed["hot_proof"]["next_sha256"], "actual next/managed hot")
                    reopened_next = deepcopy(row["next"])
                    reopened_next["observation_id"] = old_manifest["iterations"][37]["next"]
                    reopened_next["action_id"] = old_manifest["iterations"][37]["next_action"]
                    check(sha256(wire(reopened_next)).hexdigest() == managed["lifecycle"]["reopened_proof"]["next_sha256"], "reopened next differs beyond frozen pair-37 IDs")
                    for name in ("before.png", "after.png", "next.png"):
                        check(identity(public_data[name]) == managed["lifecycle"]["reopened_proof"]["public"][name], "reopened PNG bytes link")
                    learned = old_manifest["formal_plans"][ordinal]["arms"]["deployment"]["predictor"] == "L"
                    check(int(arrays["v_writes"]) == 242 and int(arrays["a_writes"]) == 240 + learned, "active writes")
                    for prefix in ("a", "v"):
                        check(all(len(arrays[prefix + "_" + name]) == int(arrays[prefix + "_writes"]) for name in ("keys", "values", "known")), "complete active prefix")
                    originals[root] = (public_data, arrays, row["next"])
                a, b = originals[OLD], originals[NEW]
                exact = a[0] == b[0] and a[2] == b[2] and all(a[1][name].dtype == b[1][name].dtype and a[1][name].shape == b[1][name].shape and a[1][name].tobytes() == b[1][name].tobytes() for name in ACTIVE_ORDER)
                check(exact, f"{seed}/{case_id}/{role}: actual old/new hot bytes/state/next")
                crosslinks.append({"seed": seed, "case": case_id, "role": role, "actual_old_new_hot_exact": exact, "reopen_next_only_pair37_ids": True})
    check(len(current) == 216 and len(peaks) == 72, "fixed gate coverage")
    check(sum(value > 262144 for value in history_deltas) == 33, "historical 33 failures retained")
    check(not any(row["delta"] > row["limit"] for row in current + peaks), "numeric managed budget")
    summaries = {point: stats([row for row in current if row["point"] == point], "delta") for point in HOT}
    summaries["full_window_peak"] = stats(peaks, "delta")
    result = {
        "scope": "Independent CPU offline recomputation. No author compare.py/resources.compare or production code executed; no Blender/GPU/testing/performance run.",
        "errors": ERRORS, "all_checks_pass": not ERRORS,
        "counts": dict(COUNTS), "workers": workers,
        "gate_summary": summaries, "current_216": current, "full_window_peak_72": peaks,
        "all_checkpoint_pairs_1014": checkpoint_deltas,
        "historical_proof_comparisons_288": proof_rows,
        "lifecycle_comparisons_144": lifecycle_rows,
        "actual_hot_blob_npz_next_crosslinks_144": crosslinks,
        "unchanged_base_resource_sources": source_comparisons,
        "original_current_failures_retained": sum(value > 262144 for value in history_deltas),
        "original_current_max_delta": max(history_deltas),
        "verified_file_receipts": READS,
        "historical_identity_index_sha256": old_index_sha,
        "new_identity_index_sha256": sha256((NEW / "artifact-identity.json").read_bytes()).hexdigest(),
        "limits": ["Managed records retain proof digests/assertions, not standalone managed AO/NPZ stores; actual hot bytes/state are independently cross-linked to saved pair-5 latency stores.",
                   "Reopen AO receipts are exact to historical corresponding receipts; actual original/new managed native execution was not rerun offline.",
                   "Owned backing zeros after close do not mean whole-process/native allocator memory is zero.",
                   "CallerAbort lifecycle is untimed after a complete chain; it does not cover every possible native allocation failure.",
                   "New pass does not prove every original 33 failure had the closure cycle as its sole cause."]}
    (Path(__file__).with_suffix(".json")).write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"errors": len(ERRORS), "first_errors": ERRORS[:10], "gates": summaries, "counts": dict(COUNTS), "verified_files": len(READS)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
