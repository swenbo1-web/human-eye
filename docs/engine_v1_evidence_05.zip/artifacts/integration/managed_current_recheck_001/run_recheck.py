"""Register and run the fixed post-lifecycle-repair verification batch once."""

from argparse import ArgumentParser
import difflib
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback
from zipfile import ZIP_DEFLATED, ZipFile


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
FORMAL = HERE.parent / "formal_cost_001" / "formal"
FORMAL_MANIFEST = FORMAL / "manifest.json"
FORMAL_SHA = "093a0df0ea941eb7cc6bd1206490627ca8196e0951fff18e6601fb513816e8c7"
FORMAL_INDEX_SHA = "05d93ebe31677cef58a1d722e8833abbfd3a9a60ec46c34f09bccf8ed493c91a"
PROTOCOL = ROOT / "docs/MANAGED_CURRENT_RECHECK_PROTOCOL.md"
REVIEW = ROOT / "docs/SURFACE_INDEX_LIFECYCLE_REVIEW.md"
BC = "human_eye_fast/fast_bvh_clearance.py"
OLD_BC_SHA = "ffc494bf309bb9010854d88007edb54533c9fa9d7fad68905fe0d75663692aeb"
FIXED_BC_SHA = "76b25ff24cbde8433bcf700f8b45e3dfe8fefa8737425ef992ff7d1f3b8bebc1"
SEEDS = (20261105, 79463, 310519)
ROLES = ("B", "I")
sys.path.insert(0, str(ROOT))

from artifacts.integration.method_diagnostic_001.runtime_identity import (
    clock_anchor, effective_environment, identity, native_fingerprint, write_json,
)


def _read(path):
    return json.loads(path.read_bytes())


def _relative(path):
    return path.resolve().relative_to(ROOT).as_posix()


def _digest(payload):
    return sha256(payload).hexdigest()


def _verify_inputs(files):
    for name, expected in files.items():
        if identity(ROOT / name)["sha256"] != expected:
            raise RuntimeError(f"Frozen input changed: {name}")


def _sources(previous):
    original = previous["source_superset"]
    assert original[BC] == OLD_BC_SHA
    files = {}
    for name, original_sha in original.items():
        data = (ROOT / name).read_bytes()
        expected = FIXED_BC_SHA if name == BC else original_sha
        if _digest(data) != expected:
            raise RuntimeError(f"Unexpected source difference: {name}")
        files[name] = data
    for path in [PROTOCOL, REVIEW, HERE / "run_recheck.py", HERE / "managed_worker.py"]:
        files[_relative(path)] = path.read_bytes()
    return files


def _bc_diff(candidate):
    with ZipFile(FORMAL / "sources.zip") as archive:
        original = archive.read(BC)
    assert _digest(original) == OLD_BC_SHA and _digest(candidate) == FIXED_BC_SHA
    before, after = original.decode("utf-8").splitlines(keepends=True), candidate.decode("utf-8").splitlines(keepends=True)
    marker = next(i for i, line in enumerate(after) if line.strip() == "del split")
    assert after[marker-1].strip() == "split(0, count, depth)"
    assert before == after[:marker] + after[marker+1:]
    return "".join(difflib.unified_diff(before, after, fromfile=f"formal/{BC}", tofile=f"recheck/{BC}"))


def _job_names():
    yield from (f"latency-{seed}" for seed in SEEDS)
    for seed in SEEDS:
        yield from (f"managed-{seed}-{role}" for role in ROLES)


def _jobs(formal, path, runtime):
    original = {row["job_id"]: row for row in formal["jobs"]}
    shared = {_relative(FORMAL_MANIFEST): FORMAL_SHA,
              _relative(FORMAL / "artifact-identity.json"): FORMAL_INDEX_SHA,
              _relative(PROTOCOL): identity(PROTOCOL)["sha256"],
              _relative(REVIEW): identity(REVIEW)["sha256"]}
    for name in _job_names():
        old = original[name]
        out = HERE / name
        if out.exists():
            raise FileExistsError(out)
        overrides = {**old["environment_overrides"],
                     "PYTHONPYCACHEPREFIX": str(out / "isolated-pycache")}
        expected_env = {**old["environment_effective"], "PYTHONPYCACHEPREFIX": overrides["PYTHONPYCACHEPREFIX"]}
        env = effective_environment({**os.environ, **overrides})
        if env != expected_env:
            raise RuntimeError(f"Effective environment differs from the frozen prior job: {name}")
        inputs = {**old["input_files"], **shared}
        _verify_inputs(inputs)
        argv = [runtime["blender_executable"]["path"], "--background", "--factory-startup", "--disable-autoexec",
                "--threads", "1", "--python-exit-code", "1", "--python", str(Path(__file__).resolve()),
                "--", "--worker", str(path), name]
        yield {"job_id": name, "kind": old["kind"], "seed": old["seed"], "process_index": old["process_index"],
               "role": old["role"], "argv": argv, "input_files": inputs,
               "environment_overrides": overrides, "environment_effective": env}


def register():
    from artifacts.integration.managed_current_recheck_001.managed_worker import instrumentation_config

    assert identity(FORMAL_MANIFEST)["sha256"] == FORMAL_SHA
    formal = _read(FORMAL_MANIFEST)
    runtime = dict(formal["runtime_registration"])
    assert identity(runtime["blender_executable"]["path"]) == runtime["blender_executable"]
    runtime["launcher_python"] = identity(sys.executable)
    runtime["launcher_python_version"] = sys.version
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    sources = _sources(formal)
    production_diff = _bc_diff(sources[BC])
    path = HERE / "manifest.json"
    jobs = list(_jobs(formal, path, runtime))
    settings = instrumentation_config()
    managed_path = _relative(HERE / "managed_worker.py")
    managed_diff = settings["census_diff"] + "\n" + "".join(difflib.unified_diff(
        [], sources[managed_path].decode("utf-8").splitlines(keepends=True),
        fromfile="/dev/null", tofile=managed_path,
    ))
    manifest = {
        "scope": "single post-repair batch: three same-scene latency plus six managed-resource processes",
        "git_head_at_registration": head, "formal_manifest": _relative(FORMAL_MANIFEST),
        "formal_manifest_sha256": FORMAL_SHA, "formal_artifact_index_sha256": FORMAL_INDEX_SHA,
        "protocol": identity(PROTOCOL), "runtime_registration": runtime,
        "source_superset": {name: _digest(data) for name, data in sources.items()},
        "production_change": {"path": BC, "original_sha256": OLD_BC_SHA, "recheck_sha256": FIXED_BC_SHA,
                              "diff": production_diff},
        "instrumentation": {**settings, "diff_path": "managed-instrumentation.diff",
                            "diff_sha256": _digest(managed_diff.encode("utf-8"))},
        "offline_comparison": {"scope": "read-only analysis runs after all registered workers",
                               "rule": "original raw numerical gates and matching public/model/next proof, "
                                       "as defined by the preregistered protocol",
                               "note": "Offline report source is indexed separately and is never imported by workers."},
        "execution": {"seed_order": SEEDS, "latency": formal["latency"],
                      "managed": {**formal["resource"], "role_order_per_seed": ROLES,
                                  "current_limit_bytes": 262_144, "peak_limit_bytes": 1_048_576},
                      "original_current_over_limit_points_retained": 33},
        "jobs": jobs,
    }
    with ZipFile(HERE / "sources.zip", "x", compression=ZIP_DEFLATED) as archive:
        for name, payload in sources.items():
            archive.writestr(name, payload)
    with (HERE / "production.diff").open("x", encoding="utf-8", newline="") as stream:
        stream.write(production_diff)
    with (HERE / "managed-instrumentation.diff").open("x", encoding="utf-8", newline="") as stream:
        stream.write(managed_diff)
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(manifest, stream, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write("\n")
    print(f"Registered {len(jobs)} serial processes: {identity(path)['sha256']}", flush=True)
    return path


def _observed():
    paths = {Path(raw).resolve() for module in tuple(sys.modules.values())
             if (raw := getattr(module, "__file__", None))}
    paths.add(Path(__file__).resolve())
    return {_relative(path): identity(path)["sha256"] for path in sorted(paths)
            if path.is_relative_to(ROOT) and path.is_file()}


def _worker(manifest_path, job_id):
    manifest = _read(manifest_path)
    job = next(row for row in manifest["jobs"] if row["job_id"] == job_id)
    out = HERE / job_id
    sys.dont_write_bytecode = True
    sys.pycache_prefix = os.environ["PYTHONPYCACHEPREFIX"]
    anchor = clock_anchor()
    workload = ROOT / manifest["formal_manifest"]
    try:
        if job["kind"] == "latency":
            from artifacts.integration.formal_cost_001.latency import run

            run(workload, out / "result", job["process_index"])
        else:
            from artifacts.integration.managed_current_recheck_001.managed_worker import run

            run(workload, out / "result", job["process_index"], job["role"])
    finally:
        write_json(out / "project-imports.json", {"scope": "observed project imports at worker exit", "paths": _observed()})
        try:
            write_json(out / "runtime.json", native_fingerprint(anchor))
        except Exception:
            (out / "runtime-error.txt").write_text(traceback.format_exc(), encoding="utf-8")


def _sources_match(manifest):
    try:
        return all(identity(ROOT / name)["sha256"] == sha for name, sha in manifest["source_superset"].items())
    except OSError:
        return False


def _execute_job(job, manifest_path, manifest, registered):
    if identity(manifest_path) != registered or not _sources_match(manifest):
        raise RuntimeError("Recheck registration or source changed before job launch")
    _verify_inputs(job["input_files"])
    env = {**os.environ, **job["environment_overrides"]}
    if effective_environment(env) != job["environment_effective"]:
        raise RuntimeError("Recheck environment changed after registration")
    name = job["job_id"]
    out = HERE / name
    out.mkdir()
    write_json(out / "launch.json", {**job, "manifest": registered})
    print(f"Starting {name}", flush=True)
    with (out / "worker.log").open("wb") as stream:
        proc = subprocess.run(job["argv"], cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT,
                              check=False)
    runtime_path, imports_path = out / "runtime.json", out / "project-imports.json"
    runtime = _read(runtime_path) if runtime_path.is_file() else {}
    imports = _read(imports_path)["paths"] if imports_path.is_file() else {}
    mismatches = [name for name, sha in imports.items() if manifest["source_superset"].get(name) != sha]
    try:
        _verify_inputs(job["input_files"])
        inputs_stable = identity(manifest_path) == registered
    except (RuntimeError, OSError):
        inputs_stable = False
    expected_runtime = manifest["runtime_registration"]["native_expected"]
    result = {"job_id": name, "exit_code": proc.returncode, "stable_sources": _sources_match(manifest),
              "stable_inputs": inputs_stable, "observed_project_imports": len(imports),
              "import_discrepancies": mismatches, "candidate_bc_observed": imports.get(BC) == FIXED_BC_SHA,
              "runtime_matches": bool(runtime and runtime["environment"] == job["environment_effective"]
                                      and runtime.get("blender_executable") == manifest["runtime_registration"]["blender_executable"]
                                      and all(runtime.get(key) == value for key, value in expected_runtime.items()))}
    result["verified_process"] = bool(result["exit_code"] == 0 and result["stable_sources"]
                                      and inputs_stable and result["candidate_bc_observed"]
                                      and not mismatches and result["runtime_matches"])
    write_json(out / "process.json", result)
    print(json.dumps(result), flush=True)
    return result


def execute(manifest_path):
    manifest = _read(manifest_path)
    assert [job["job_id"] for job in manifest["jobs"]] == list(_job_names())
    registered = identity(manifest_path)
    with (HERE / "batch-started.json").open("x", encoding="utf-8") as stream:
        json.dump({"manifest": registered, "start": clock_anchor()}, stream)
    results = [_execute_job(job, manifest_path, manifest, registered) for job in manifest["jobs"]]
    verified = all(result["verified_process"] for result in results)
    write_json(HERE / "batch-processes.json", {"all_processes_verified": verified, "processes": results,
                                              "end": clock_anchor()})
    return 0 if verified else 1


def main():
    if "--worker" in sys.argv:
        start = sys.argv.index("--worker")
        _worker(Path(sys.argv[start + 1]), sys.argv[start + 2])
        return 0
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=("register", "execute"))
    args = parser.parse_args()
    if args.operation == "register":
        register()
        return 0
    return execute(HERE / "manifest.json")


if __name__ == "__main__":
    status = main()
    if status:
        raise SystemExit(status)
