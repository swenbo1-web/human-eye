"""Run one managed-resource role with the two preregistered instrumentation changes."""

from array import array
from contextlib import contextmanager
from difflib import unified_diff
import gc
from inspect import getsource
import json
from pathlib import Path
from time import perf_counter_ns
import tracemalloc

from artifacts.integration.formal_cost_001 import resource_instruments, resources


GC_CAPACITY = 32_768
GC_COLUMNS = 7
CASE_COUNT = 24
CAMERA_COUNT = 2
CAMERA_COLUMNS = 8
CAMERA_RECORDS = CASE_COUNT * CAMERA_COUNT * 2
PHASES = (
    "before_first_case",
    "setup_and_warmup",
    "hot_chain",
    "held_census_and_reporting",
    "hot_proof",
    "released_census_and_reference_reset",
    "reference_replaced_and_normal_lifecycle",
    "reopen_lifecycle",
    "case_reporting",
)
CHECKPOINT_PHASE = {
    "hot_outputs_held": 3,
    "hot_outputs_released": 5,
    "hot_reference_replaced": 6,
    "cold_before_reopen": 7,
}
CENSUS_BRANCH = '            elif (type(value).__module__.split(".", 1)[0] in ("bpy", "bpy_types", "_bpy", "gpu", "mathutils")'
CENSUS_REPLACEMENT = (
    '            elif (_renderer_camera(root_name, root, value)\n'
    '                  or type(value).__module__.split(".", 1)[0] in ("bpy", "bpy_types", "_bpy", "gpu", "mathutils")'
)


def _census_sources():
    original = getsource(resource_instruments.backing_census)
    if original.count(CENSUS_BRANCH) != 1:
        raise RuntimeError("Frozen backing census does not contain the expected classification branch")
    return original, original.replace(CENSUS_BRANCH, CENSUS_REPLACEMENT, 1)


def census_diff():
    original, candidate = _census_sources()
    return "".join(unified_diff(original.splitlines(keepends=True), candidate.splitlines(keepends=True),
                                fromfile="frozen resource_instruments.py:backing_census",
                                tofile="recheck managed_worker.py:backing_census"))


def instrumentation_config():
    return {
        "camera_opaque_rule": "Only _bpy_types.Object instances of bpy.types.Object, CAMERA, "
                              "and identity members of the renderer root's camera tuple",
        "camera_binding_point": "Existing pre-close instrumentation after all normal hot readings",
        "camera_binding_records": CAMERA_RECORDS,
        "camera_binding_storage": {"columns": CAMERA_COLUMNS, "type": "signed 64-bit array"},
        "gc_buffer": {"capacity": GC_CAPACITY, "columns": GC_COLUMNS, "type": "signed 64-bit array",
                      "phases": dict(enumerate(PHASES))},
        "gc_threshold_changed": False,
        "active_collect_calls": 0,
        "snapshot_calls": 0,
        "original_tracemalloc_start_and_t4_reads": True,
        "census_diff": census_diff(),
    }


def _corrected_census(object_type):
    _, candidate = _census_sources()

    def _renderer_camera(root_name, root, value):
        cls = type(value)
        return (root_name == "renderer" and cls.__module__ == "_bpy_types"
                and cls.__qualname__ == "Object" and isinstance(value, object_type)
                and value.type == "CAMERA" and len(root.cameras) == CAMERA_COUNT
                and (value is root.cameras[0] or value is root.cameras[1]))

    namespace = dict(vars(resource_instruments))
    namespace["_renderer_camera"] = _renderer_camera
    exec(compile(candidate, f"{__file__}:backing_census", "exec"), namespace)
    return namespace["backing_census"]


class _Recorder:
    def __init__(self, bpy):
        self.bpy = bpy
        self.object_type = bpy.types.Object
        self.camera_type = bpy.types.Camera
        self.gc_rows = array("q", [0]) * (GC_CAPACITY * GC_COLUMNS)
        self.camera_rows = array("q", [0]) * (CAMERA_RECORDS * CAMERA_COLUMNS)
        if self.gc_rows.itemsize != 8 or self.camera_rows.itemsize != 8:
            raise RuntimeError("Instrumentation requires signed 64-bit numeric storage")
        self.counters = array("q", [0]) * 6
        self.ordinal = -1
        self.phase = 0
        self.first_callback_error = None
        self.first_binding_error = None

    def on_gc(self, event, info):
        try:
            qpc = perf_counter_ns()
            row = self.counters[0]
            if row >= GC_CAPACITY:
                self.counters[1] += 1
                return
            if event not in ("start", "stop"):
                raise ValueError("Unexpected GC callback event")
            start = row * GC_COLUMNS
            self.gc_rows[start] = self.ordinal
            self.gc_rows[start + 1] = self.phase
            self.gc_rows[start + 2] = qpc
            self.gc_rows[start + 3] = int(event == "stop")
            self.gc_rows[start + 4] = info["generation"]
            self.gc_rows[start + 5] = info.get("collected", 0)
            self.gc_rows[start + 6] = info.get("uncollectable", 0)
            self.counters[0] += 1
        except Exception as error:
            self.counters[2] += 1
            if self.first_callback_error is None:
                self.first_callback_error = type(error).__name__

    def camera_bindings(self, lane):
        try:
            renderer = lane.renderer
            if len(renderer.cameras) != CAMERA_COUNT:
                raise ValueError("Expected the original renderer camera pair")
            if lane.role == "I":
                owned = lane._session._renderer is renderer
            else:
                owned = lane._b_renderer is renderer and lane._b_control._renderer is renderer
            for camera_index, camera in enumerate(renderer.cameras):
                row = self.counters[3]
                if row >= CAMERA_RECORDS:
                    self.counters[4] += 1
                    return
                data = camera.data
                object_pointer = camera.as_pointer()
                data_pointer = data.as_pointer()
                registered_object = self.bpy.data.objects.get(camera.name)
                registered_data = self.bpy.data.cameras.get(data.name)
                flags = (
                    int(owned)
                    | int(type(camera).__module__ == "_bpy_types" and type(camera).__qualname__ == "Object") << 1
                    | int(isinstance(camera, self.object_type)) << 2
                    | int(isinstance(data, self.camera_type)) << 3
                    | int(camera.type == "CAMERA") << 4
                    | int(data.type == "ORTHO") << 5
                    | int(registered_object is not None and registered_object.as_pointer() == object_pointer) << 6
                    | int(registered_data is not None and registered_data.as_pointer() == data_pointer) << 7
                )
                start = row * CAMERA_COLUMNS
                self.camera_rows[start] = self.ordinal
                self.camera_rows[start + 1] = self.phase
                self.camera_rows[start + 2] = camera_index
                self.camera_rows[start + 3] = renderer.as_pointer() if hasattr(renderer, "as_pointer") else id(renderer)
                self.camera_rows[start + 4] = object_pointer
                self.camera_rows[start + 5] = data_pointer
                self.camera_rows[start + 6] = flags
                self.camera_rows[start + 7] = int(type(data).__module__ == "bpy.types"
                                                  and type(data).__qualname__ == "Camera")
                self.counters[3] += 1
        except Exception as error:
            self.counters[5] += 1
            if self.first_binding_error is None:
                self.first_binding_error = type(error).__name__


@contextmanager
def _verification_hooks(recorder, corrected_census):
    original_case = resources._case_work
    original_hot = resources._managed_hot
    original_point = resources._current_point
    original_proof = resources._proof_summary
    original_close = resources._instrument_close
    original_census = resources.backing_census

    def case_work(case, role, instrument, result, checkpoints, samples_stream, dxgi, adapter_error, config):
        recorder.ordinal = case.ordinal
        recorder.phase = 1
        try:
            return original_case(case, role, instrument, result, checkpoints, samples_stream,
                                 dxgi, adapter_error, config)
        finally:
            recorder.phase = 8

    def managed_hot(lane, result, checkpoints):
        recorder.phase = 2
        return original_hot(lane, result, checkpoints)

    def current_point(stream, case_id, name, roots, reading=None):
        phase = CHECKPOINT_PHASE.get(name)
        if phase is not None:
            recorder.phase = phase
        return original_point(stream, case_id, name, roots, reading)

    def proof_summary(lane, outputs):
        if recorder.phase == 3:
            recorder.phase = 4
        return original_proof(lane, outputs)

    def instrument_close(lane):
        recorder.camera_bindings(lane)
        return original_close(lane)

    resources._case_work = case_work
    resources._managed_hot = managed_hot
    resources._current_point = current_point
    resources._proof_summary = proof_summary
    resources._instrument_close = instrument_close
    resources.backing_census = corrected_census
    try:
        yield
    finally:
        resources._case_work = original_case
        resources._managed_hot = original_hot
        resources._current_point = original_point
        resources._proof_summary = original_proof
        resources._instrument_close = original_close
        resources.backing_census = original_census


def _save_gc(out_dir, recorder):
    with (out_dir / "gc_events.jsonl").open("x", encoding="utf-8", newline="\n") as stream:
        for index in range(recorder.counters[0]):
            start = index * GC_COLUMNS
            ordinal, phase, qpc, event, generation, collected, uncollectable = (
                recorder.gc_rows[start:start + GC_COLUMNS]
            )
            resources._write(stream, {"ordinal": ordinal, "phase_id": phase, "phase": PHASES[phase],
                                      "qpc_ns": qpc, "event": "stop" if event else "start",
                                      "generation": generation, "collected": collected,
                                      "uncollectable": uncollectable})


def _save_cameras(out_dir, recorder):
    release_by_case = {}
    path = out_dir / "cases.jsonl"
    if path.exists():
        with path.open(encoding="utf-8") as stream:
            for line in stream:
                row = json.loads(line)
                lifecycle = row.get("lifecycle", {})
                release_by_case[row["ordinal"]] = {
                    phase: lifecycle.get(key, {}).get("camera_objects_and_data_removed", False)
                    for phase, key in ((6, "close"), (7, "reopened_close"))
                }
    expected = {(ordinal, phase, camera) for ordinal in range(CASE_COUNT)
                for phase in (6, 7) for camera in range(CAMERA_COUNT)}
    seen = set()
    groups = {}
    valid = True
    with (out_dir / "camera_bindings.jsonl").open("x", encoding="utf-8", newline="\n") as stream:
        for index in range(recorder.counters[3]):
            start = index * CAMERA_COLUMNS
            ordinal, phase, camera_index, renderer_id, obj, data, flags, camera_class = (
                recorder.camera_rows[start:start + CAMERA_COLUMNS]
            )
            key = ordinal, phase, camera_index
            release_verified = release_by_case.get(ordinal, {}).get(phase, False)
            bindings = {name: bool(flags & (1 << bit)) for bit, name in enumerate((
                "owned_by_lane_renderer", "exact_bpy_object_type", "is_bpy_types_object",
                "is_bpy_types_camera_data", "is_camera_object", "is_orthographic_data",
                "registered_object_pointer_matches", "registered_data_pointer_matches",
            ))}
            resources._write(stream, {
                "ordinal": ordinal, "phase": "normal_close" if phase == 6 else "reopen_exception",
                "phase_id": phase, "camera_index": camera_index, "renderer_python_identity": renderer_id,
                "object_pointer": obj, "data_pointer": data,
                "object_type": "_bpy_types.Object" if bindings["exact_bpy_object_type"] else None,
                "data_type": "bpy.types.Camera" if camera_class else None,
                "object_kind": "CAMERA" if bindings["is_camera_object"] else None,
                "camera_kind": "ORTHO" if bindings["is_orthographic_data"] else None,
                "bindings": bindings, "release_verified": release_verified, "native_allocation_bytes": None,
            })
            valid &= (key in expected and key not in seen and bool(renderer_id and obj and data)
                      and flags == 255 and bool(camera_class) and release_verified)
            seen.add(key)
            groups.setdefault((ordinal, phase), []).append((renderer_id, obj, data))
    valid &= seen == expected
    for rows in groups.values():
        valid &= (len(rows) == CAMERA_COUNT and rows[0][0] == rows[1][0]
                  and rows[0][1] != rows[1][1] and rows[0][2] != rows[1][2])
    return bool(valid)


def run(original_manifest_path, out_dir, process_index, role):
    import bpy

    if not bpy.app.background or role not in ("B", "I") or process_index not in range(3):
        raise ValueError("Expected a preregistered background managed process")
    if tracemalloc.is_tracing():
        raise RuntimeError("Expected original tracing to start inside the frozen worker")
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=False)
    enabled_before = gc.isenabled()
    threshold_before = gc.get_threshold()
    if not enabled_before:
        raise RuntimeError("Managed recheck requires GC enabled at the original threshold")
    recorder = _Recorder(bpy)
    corrected_census = _corrected_census(recorder.object_type)
    (out_dir / "census.patch").write_text(census_diff(), encoding="utf-8", newline="\n")
    callback = recorder.on_gc
    original_complete = False
    gc.callbacks.append(callback)
    try:
        with _verification_hooks(recorder, corrected_census):
            result = resources.run(original_manifest_path, out_dir, process_index, role, "managed")
        original_complete = True
    finally:
        gc.callbacks.remove(callback)
        enabled_after = gc.isenabled()
        threshold_after = gc.get_threshold()
        _save_gc(out_dir, recorder)
        cameras_valid = (_save_cameras(out_dir, recorder)
                         and recorder.counters[4] == recorder.counters[5] == 0)
        gc_valid = (enabled_before and enabled_after and threshold_before == threshold_after
                    and recorder.counters[1] == recorder.counters[2] == 0)
        valid = original_complete and cameras_valid and gc_valid and not tracemalloc.is_tracing()
        report = {
            "scope": "verification-only changes around the frozen managed workload",
            "valid": valid, "original_run_completed": original_complete,
            "gc": {"enabled_before": enabled_before, "enabled_after": enabled_after,
                   "threshold_before": threshold_before, "threshold_after": threshold_after,
                   "capacity": GC_CAPACITY, "recorded": recorder.counters[0],
                   "overflow": recorder.counters[1], "callback_errors": recorder.counters[2],
                   "first_error_type": recorder.first_callback_error, "phase_names": PHASES,
                   "buffer_preallocated_before_tracing": True},
            "camera": {"expected_records": CAMERA_RECORDS, "recorded": recorder.counters[3],
                       "overflow": recorder.counters[4], "binding_errors": recorder.counters[5],
                       "first_error_type": recorder.first_binding_error, "valid": cameras_valid,
                       "native_allocation_bytes": None},
            "snapshot_calls": 0, "active_collect_calls": 0,
        }
        with (out_dir / "instrument.json").open("x", encoding="utf-8", newline="\n") as stream:
            json.dump(report, stream, ensure_ascii=False, allow_nan=False, indent=2)
            stream.write("\n")
    if not valid:
        raise RuntimeError("Managed verification instrumentation incomplete; retain original worker evidence")
    return result
