"""Availability only: inspect managed and process/adapter readings in separate workers."""

from argparse import ArgumentParser
from contextlib import ExitStack
from ctypes import (
    POINTER, Structure, WinDLL, WINFUNCTYPE, byref, c_int32, c_size_t, c_uint32, c_uint64,
    c_void_p, c_wchar, cast, get_last_error, sizeof,
)
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import subprocess
import sys
import tracemalloc
from uuid import UUID


ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np


def process_memory():
    class Counters(Structure):
        _fields_ = [("cb", c_uint32), ("PageFaultCount", c_uint32)] + [
            (name, c_size_t) for name in ("PeakWorkingSetSize", "WorkingSetSize",
                "QuotaPeakPagedPoolUsage", "QuotaPagedPoolUsage", "QuotaPeakNonPagedPoolUsage",
                "QuotaNonPagedPoolUsage", "PagefileUsage", "PeakPagefileUsage", "PrivateUsage")
        ]

    dll = WinDLL("kernel32", use_last_error=True)
    dll.GetCurrentProcess.restype = c_void_p
    get_memory = dll.K32GetProcessMemoryInfo
    get_memory.argtypes = (c_void_p, POINTER(Counters), c_uint32)
    get_memory.restype = c_int32
    counters = Counters()
    counters.cb = sizeof(counters)
    if not get_memory(dll.GetCurrentProcess(), byref(counters), counters.cb):
        raise OSError(f"K32GetProcessMemoryInfo failed: {get_last_error()}")
    return {"working_set_bytes": counters.WorkingSetSize,
            "process_peak_working_set_bytes": counters.PeakWorkingSetSize,
            "private_commit_bytes": counters.PrivateUsage}


class Guid(Structure):
    _fields_ = [("bytes", c_uint32 * 4)]

    @classmethod
    def parse(cls, text):
        return cls.from_buffer_copy(UUID(text).bytes_le)


class AdapterDesc(Structure):
    _fields_ = [("description", c_wchar * 128), ("vendor", c_uint32), ("device", c_uint32),
                ("subsystem", c_uint32), ("revision", c_uint32), ("dedicated_video", c_size_t),
                ("dedicated_system", c_size_t), ("shared_system", c_size_t),
                ("luid_low", c_uint32), ("luid_high", c_int32), ("flags", c_uint32)]


class VideoInfo(Structure):
    _fields_ = [(name, c_uint64) for name in ("budget", "current_usage",
                                             "available_for_reservation", "current_reservation")]


def _method(interface, slot, result, *args):
    vtable = cast(interface, POINTER(POINTER(c_void_p)))[0]
    return WINFUNCTYPE(result, c_void_p, *args)(vtable[slot])


def _check(result, operation):
    if result < 0:
        raise OSError(f"{operation} failed: 0x{result & 0xffffffff:08x}")


def _release(interface):
    _method(interface, 2, c_uint32)(interface)


class DxgiProcessUsage:
    def __init__(self, stack, description_match):
        dll = WinDLL("dxgi", use_last_error=True)
        create = dll.CreateDXGIFactory1
        create.argtypes = (POINTER(Guid), POINTER(c_void_p))
        create.restype = c_int32
        factory = c_void_p()
        factory_guid = Guid.parse("770aae78-f26f-4dba-a829-253c83d1b387")
        _check(create(byref(factory_guid), byref(factory)), "CreateDXGIFactory1")
        stack.callback(_release, factory)
        enumerate_adapter = _method(factory, 12, c_int32, c_uint32, POINTER(c_void_p))
        self.adapters = []
        self.adapter = None
        index = 0
        while True:
            adapter = c_void_p()
            result = enumerate_adapter(factory, index, byref(adapter))
            if result & 0xffffffff == 0x887a0002:
                break
            _check(result, "EnumAdapters1")
            stack.callback(_release, adapter)
            description = AdapterDesc()
            _check(_method(adapter, 10, c_int32, POINTER(AdapterDesc))(
                adapter, byref(description)), "GetDesc1")
            info = {"name": description.description, "vendor": description.vendor,
                    "device": description.device, "luid": [description.luid_high, description.luid_low]}
            self.adapters.append(info)
            if description_match.casefold() in description.description.casefold() and not description.flags & 2:
                if self.adapter is not None:
                    raise ValueError("Ambiguous DXGI adapter identity")
                self.adapter = c_void_p()
                adapter_guid = Guid.parse("645967a4-1392-4310-a798-8053ce3e93fd")
                _check(_method(adapter, 0, c_int32, POINTER(Guid), POINTER(c_void_p))(
                    adapter, byref(adapter_guid), byref(self.adapter)), "QueryInterface IDXGIAdapter3")
                stack.callback(_release, self.adapter)
                self.identity = info
            index += 1
        if self.adapter is None:
            raise ValueError(f"Adapter {description_match!r} not found: {self.adapters}")
        self.query = _method(self.adapter, 14, c_int32, c_uint32, c_uint32, POINTER(VideoInfo))

    def sample(self):
        result = {}
        for group, name in enumerate(("local", "nonlocal")):
            info = VideoInfo()
            _check(self.query(self.adapter, 0, group, byref(info)), "QueryVideoMemoryInfo")
            result[name] = {key: getattr(info, key) for key, _ in info._fields_}
        return result


def numpy_backings(*roots):
    """Enumerate owned backing buffers through declared Python state roots."""
    seen, owners = set(), {}

    def visit(obj):
        identity = id(obj)
        if identity in seen:
            return
        seen.add(identity)
        if isinstance(obj, np.ndarray):
            owner = obj
            while isinstance(owner, (np.ndarray, memoryview)):
                underlying = owner.base if isinstance(owner, np.ndarray) else owner.obj
                if underlying is None:
                    break
                owner = underlying
            owners[id(owner)] = memoryview(owner).nbytes
        elif isinstance(obj, dict):
            for value in obj.values():
                visit(value)
        elif isinstance(obj, (list, tuple)):
            for value in obj:
                visit(value)
        elif type(obj).__module__.startswith(("human_eye_fast.", "verification.integration_reference")):
            if hasattr(obj, "__dict__"):
                visit(vars(obj))
            for name in getattr(type(obj), "__slots__", ()):
                if hasattr(obj, name):
                    visit(getattr(obj, name))
    visit(roots)
    return {"unique_buffers": len(owners), "bytes": sum(owners.values())}


def run(manifest, mode):
    import bpy
    import gpu
    from human_eye_fast.control import Goal
    from human_eye_fast.raycast_saccade_gpu import VGRenderer
    from verification.cf_training import load_frozen
    from verification.integration_fixtures import build_fixture, fixture_manifest
    from verification.integration_reference import SharedCaptureControl
    from verification.test_integration_preflight import _materialize

    assert bpy.app.background
    registration = json.loads(manifest.read_bytes())
    config = registration["method_probe"]["resource"]
    entry = registration["deployments"][config["deployment_process_index"]]
    model_path = ROOT / entry["sealed_path"]
    model_data = model_path.read_bytes()
    assert sha256(model_data).hexdigest() == entry["sealed_sha256"]
    spec = fixture_manifest()[0]
    assert spec.case_id == config["case_id"]
    case = build_fixture(spec)
    samples = []
    with ExitStack() as stack:
        dxgi = None
        unavailable = None
        if mode == "os":
            try:
                dxgi = DxgiProcessUsage(stack, "GeForce RTX 3060")
            except (OSError, ValueError) as error:
                unavailable = str(error)
        else:
            tracemalloc.start()
        def sample(phase, *roots):
            row = {"phase": phase}
            if mode == "managed":
                current, peak = tracemalloc.get_traced_memory()
                row.update(traced_current_bytes=current, traced_peak_bytes=peak,
                           numpy_owned=numpy_backings(*roots))
            else:
                row["process"] = process_memory()
                if dxgi is not None:
                    try:
                        row["gpu"] = dxgi.sample()
                    except OSError as error:
                        row["gpu_error"] = str(error)
            samples.append(row)

        with _materialize(case) as (scene, objects):
            goal = Goal(*case.target_ids, case.goal_distance_m, case.goal_tolerance_m)
            sample("cold_start")
            control = SharedCaptureControl(scene, objects, goal, model=load_frozen(BytesIO(model_data)).session())
            with bpy.context.temp_override(scene=scene, view_layer=scene.view_layers[0]):
                renderer = VGRenderer()
                try:
                    sample("after_init", control, renderer)
                    measured = control.observe("memory")
                    mesh = {key: control.bridge.get(key) for key in case.target_ids}
                    prepared = renderer.prepare(mesh)
                    sample("prepared", control, renderer, prepared)
                    rendered = renderer.observe(
                        prepared, measured.surface, target_ids=case.target_ids,
                        frame_id=measured.frame_id, scale_length=scene.unit_settings.scale_length,
                    )
                    sample("observed", control, renderer, prepared)
                    png_bytes = len(rendered.png)
                    del prepared
                finally:
                    renderer.close()
            control.close()
            del mesh
            sample("close", control, renderer)
        if mode == "managed":
            tracemalloc.stop()
        diagnostics = None
        if mode == "os":
            try:
                proc = subprocess.run(("nvidia-smi", "--query-gpu=name,driver_version,driver_model.current",
                                       "--format=csv,noheader"), capture_output=True, text=True, check=False)
                diagnostics = {"exit_code": proc.returncode, "stdout": proc.stdout, "stderr": proc.stderr}
            except OSError as error:
                diagnostics = {"error": str(error)}
        identity = dxgi.identity if dxgi is not None else None
        adapter_ok = identity is not None and "GeForce RTX 3060" in gpu.platform.renderer_get()
    return {
        "scope": "instrumentation availability only; one B component draw, no I or comparison",
        "case": spec.case_id, "mode": mode, "manifest_sha256": sha256(manifest.read_bytes()).hexdigest(),
        "blender": bpy.app.version_string, "backend": gpu.platform.backend_type_get(),
        "renderer": gpu.platform.renderer_get(), "png_bytes": png_bytes,
        "actual_deployment_read": {"path": entry["sealed_path"], "sha256": entry["sealed_sha256"]},
        "dxgi_adapter": identity, "renderer_adapter_match": adapter_ok,
        "dxgi_unavailable_reason": unavailable, "nvidia_smi_availability": diagnostics,
        "samples": samples,
    }


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--instrument", choices=("managed", "os"), required=True)
    args = parser.parse_args(sys.argv[sys.argv.index("--") + 1:])
    assert args.manifest.is_file() and not args.out.exists()
    result = run(args.manifest, args.instrument)
    args.out.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
