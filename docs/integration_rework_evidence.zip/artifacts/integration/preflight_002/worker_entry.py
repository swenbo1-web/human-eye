"""Load a registered entry script and retain the local import identity on exit."""

import os
from pathlib import Path
import runpy
import sys


entry = Path(os.environ["HE_INTEGRATION_ENTRY"])
receipt = Path(__file__).resolve().parent / "closure" / "sitecustomize.py"
sys.dont_write_bytecode = True
sys.pycache_prefix = os.environ["PYTHONPYCACHEPREFIX"]
sys.argv[0] = str(entry)
try:
    runpy.run_path(str(entry), run_name="__main__")
finally:
    runpy.run_path(str(receipt))["record"]("entry")
