"""Preregistered B/B measurement-method probe. No production I or formal scores."""

from argparse import ArgumentParser
from contextlib import ExitStack
from hashlib import sha256
import json
from pathlib import Path
import sys
import time


ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np


def _digest(data):
    return sha256(data).hexdigest()


def _load(path):
    return json.loads(path.read_bytes())


def _write(path, value):
    path.write_text(json.dumps(value, allow_nan=False, indent=2) + "\n", encoding="utf-8")


def _append(path, value):
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(value, allow_nan=False, separators=(",", ":")) + "\n")


def _project_imports():
    result = {}
    for name, module in sys.modules.items():
        source = getattr(module, "__file__", None)
        if source and Path(source).is_file():
            path = Path(source).resolve()
            if path.is_relative_to(ROOT):
                result[name] = {"path": path.relative_to(ROOT).as_posix(),
                                "sha256": _digest(path.read_bytes())}
    return result


def _state(model):
    return model.view_head.weights.copy(), model.action_head.weights.copy(), (
        model.views.writes, model.actions.writes)


def _restore(model, initial):
    view, action, counts = initial
    np.copyto(model.view_head.weights, view)
    np.copyto(model.action_head.weights, action)
    model.views.writes, model.actions.writes = counts


def _verify_frame(frame, expected, selection, failure_dir):
    receipt = frame.view
    assert receipt is not None and receipt.consumed
    assert frame.readback.frame_id == expected["frame_id"]
    assert list(frame.readback.target_ids) == expected["target_ids"]
    assert receipt.index == expected["canonical_index"]
    assert receipt.rays == expected["selected_probe_rays"]
    assert receipt.native_stop == expected["native_stop"]
    assert selection["direction"] == expected["selected_direction"]
    png = frame.attachments[receipt.attachment_key]
    actual = _digest(png)
    if actual != expected["png_sha256"]:
        (failure_dir / f"mismatch-{receipt.observation_id}.png").write_bytes(png)
        _write(failure_dir / f"mismatch-{receipt.observation_id}.json", {
            "expected": expected, "actual_sha256": actual,
            "actual_witness": frame.fact.image.rendered.metadata["witness"],
        })
        raise AssertionError(f"{receipt.observation_id} PNG identity differs: {actual}")


def _changes(phase):
    from human_eye_fast.blender_resident_bridge import MeshChange
    from verification.integration_reference import CaptureChange
    result = {}
    for key, flags in phase["changes"].items():
        mask = MeshChange.NONE
        for flag in flags:
            mask |= MeshChange[flag]
        result[key] = CaptureChange(mask)
    return result


def _archive_feedback(bb):
    root = ROOT / bb["archived_feedback_root"]
    records = {}
    reads = []
    for case, rows in bb["archived_feedback"].items():
        records[case] = []
        for row in rows:
            record = root / row["archive_record"]
            image = root / case / row["attachment_key"]
            for path, expected in ((record, row["archive_record_sha256"]),
                                   (image, row["png_sha256"])):
                data = path.read_bytes()
                assert _digest(data) == expected
                reads.append({"path": path.relative_to(ROOT).as_posix(), "sha256": expected})
            evidence = _load(record)
            assert evidence["score"]["passed"] == row["strict_verdict"]
            assert evidence["score"]["safe"] == row["safe"]
            records[case].append(row)
    return records, reads


def _run_case(case, plan, bb, frozen, feedback, raw_path, out):
    import bpy
    from human_eye_fast.control import Goal
    from human_eye_fast.raycast_saccade_gpu import VGRenderer
    from verification.integration_reference import (
        SharedCaptureControl, ViewFeedback, action_feedback, execute, observe, predict,
        reference_from_capture, relative_basis_from_rna, view_feedback,
    )
    from verification.test_integration_preflight import _command, _materialize

    timers = time.perf_counter_ns
    phases = [plan[key] for key in ("reference_capture", "before", "after_readback_and_publication", "next")]
    ref_changes, before_changes, after_changes, next_changes = map(_changes, phases)
    mode = case.mode
    action_arm = plan["arms"]["deployment"]["predictor"]
    case_ordinal = case.spec.ordinal
    with ExitStack() as stack:
        lanes = []
        for lane in bb["lane_labels"]:
            scene, objects = stack.enter_context(_materialize(case))
            moving = objects[case.target_ids[0]]
            with bpy.context.temp_override(scene=scene, view_layer=scene.view_layers[0]):
                renderer = VGRenderer()
            model = frozen.session()
            goal = Goal(*case.target_ids, case.goal_distance_m, case.goal_tolerance_m)
            control = SharedCaptureControl(scene, objects, goal,
                                           generations=phases[0]["topology_generations"],
                                           renderer=renderer, model=model)
            def close_in_context(control=control):
                with control.scene_context():
                    control.close()
            stack.callback(close_in_context)
            initial = _state(model)
            assert max(initial[-1]) <= model.views.capacity - 2
            reference = reference_from_capture(control, control.observe("reference", changes=ref_changes))
            basis = None
            if case.command.kind == "set_shape_key":
                block = moving.data.shape_keys.key_blocks[case.command.key_name]
                q = float(block.value)
                basis = relative_basis_from_rna(moving, case.command.key_name)
                def reset(block=block, q=q):
                    block.value = q
            else:
                assert moving.rotation_mode == "XYZ"
                # Restore the authored float32 channels exactly. Assigning a
                # derived matrix makes Blender decompose rotation/scale again.
                location = tuple(moving.location)
                rotation = tuple(moving.rotation_euler)
                scale = tuple(moving.scale)
                def reset(moving=moving, location=location, rotation=rotation, scale=scale):
                    moving.location = location
                    moving.rotation_euler = rotation
                    moving.scale = scale
            lanes.append((control, renderer, model, initial, reference, reset, basis))

        commands = (_command(case.command), _command(case.followup_command))
        observed_ids = bb["observation_id_templates"]
        action_ids = bb["action_id_templates"]
        results = []
        for pair in (*bb["warm_pair_indices"], *bb["measured_pair_indices"]):
            order = [0, 1] if (case_ordinal + pair) % 2 == 0 else [1, 0]
            timings = {}
            for lane in order:
                control, renderer, model, initial, reference, reset, basis = lanes[lane]
                reset()
                _restore(model, initial)
                names = {key: fmt.format(pair=pair, lane=lane) for key, fmt in observed_ids.items()}
                ids = {key: fmt.format(pair=pair, lane=lane) for key, fmt in action_ids.items()}
                # Offline lookup and feedback transport construction stay outside.
                # Actual ticket checks and consumption are in the feedback interval.
                feedback_values = tuple(ViewFeedback(names[name], f"{names[name]}.png",
                                                     row["canonical_index"], row["strict_verdict"])
                                        for name, row in zip(("before", "after"), feedback, strict=True))

                t0 = timers()
                before = observe(control, renderer, reference, names["before"], mode=mode,
                                 view_arm="L", model=model, changes=before_changes)
                t1 = timers()
                plan_now = predict(control, before, commands[0], ids["act"], action_arm=action_arm,
                                   model=model, basis=basis)
                result = execute(control, renderer, reference, before, plan_now, names["after"],
                                 mode=mode, view_arm="L", model=model, changes=after_changes)
                t2 = timers()
                view_feedback(control, model, before.view, feedback_values[0])
                view_feedback(control, model, result.after.view, feedback_values[1])
                if result.action_ticket is not None:
                    action_feedback(control, model, result.action_ticket)
                t3 = timers()
                following = observe(control, renderer, reference, names["next"], mode=mode,
                                    view_arm="L", model=model, changes=next_changes)
                next_plan = predict(control, following, commands[1], ids["next-act"],
                                    action_arm=action_arm, model=model, basis=basis)
                t4 = timers()

                row = {"before": t1-t0, "action": t2-t1, "feedback": t3-t2, "next": t4-t3,
                       "continuous_total": t4-t0}
                timings[str(lane)] = row
                _append(raw_path, {"case": case.spec.case_id, "pair": pair, "lane": lane,
                                   "warmup": pair in bb["warm_pair_indices"], "order": order,
                                   "ns": row})
                for frame, expected in zip((before, result.after), feedback, strict=True):
                    _verify_frame(frame, expected, frame.fact.image.rendered.metadata["selection"], out)
                assert model.views.writes == initial[-1][0] + 2
                assert model.actions.writes == initial[-1][1] + int(action_arm == "L")
                assert next_plan.action.before_observation_id == names["next"]
                assert result.outcome.before.frame_id == result.outcome.after.frame_id
                assert model.views.values[initial[-1][0] + 1, result.after.view.index, 0] == feedback[1]["safe"]
                # Let both lanes release equivalent caller-owned return objects outside measurement.
                del before, result, following, next_plan, plan_now
            results.append({"pair": pair, "order": order, "lanes_ns": timings,
                            "warmup": pair in bb["warm_pair_indices"]})
            if pair == bb["measured_pair_indices"][-1]:
                _write(out / f"{case.spec.case_id}.json", results)
    return results


def run(args):
    import bpy
    import gpu
    from verification.cf_training import load_frozen
    from verification.integration_fixtures import build_fixture, fixture_manifest

    assert bpy.app.background and not args.out.exists()
    args.out.mkdir(parents=True)
    manifest = _load(args.manifest)
    bb = manifest["method_probe"]["bb"]
    feedback, reads = _archive_feedback(bb)
    deployments = manifest["deployments"]
    selected_deployment = deployments[bb["deployment_process_index"]]
    snapshot = ROOT / selected_deployment["sealed_path"]
    model_data = snapshot.read_bytes()
    assert _digest(model_data) == selected_deployment["sealed_sha256"]
    reads.append({"path": snapshot.relative_to(ROOT).as_posix(), "sha256": _digest(model_data)})
    from io import BytesIO
    frozen = load_frozen(BytesIO(model_data))
    empty = []
    for _ in range(1000):
        start = time.perf_counter_ns()
        end = time.perf_counter_ns()
        empty.append(end-start)
    _write(args.out / "clock.json", {"clock": vars(time.get_clock_info("perf_counter")), "empty_ns": empty})
    specs = {spec.case_id: spec for spec in fixture_manifest()}
    plans = {row["case_id"]: row for row in manifest["formal_plans"]}
    raw = args.out / "intervals.jsonl"
    cases = {key: _run_case(build_fixture(specs[key]), plans[key], bb, frozen, feedback[key],
                            raw, args.out) for key in bb["case_ids"]}
    segments = {}
    for segment in bb["segments"]:
        case_medians = {}
        for key, rows in cases.items():
            case_medians[key] = [
                float(np.median([row["lanes_ns"][str(lane)][segment] for row in rows if not row["warmup"]]))
                for lane in bb["lane_labels"]
            ]
        p95 = np.quantile(list(case_medians.values()), .95, axis=0, method="linear").tolist()
        ratios = [p95[0] / p95[1], p95[1] / p95[0]]
        segments[segment] = {"case_medians_ns": case_medians, "lane_p95_ns": p95, "ratios": ratios,
                             "within_5_percent": max(ratios) <= 1.05}
    _write(args.out / "summary.json", {
        "scope": "measurement method only; one serial B/B process; no production I",
        "manifest_sha256": _digest(args.manifest.read_bytes()), "actual_data_reads": reads,
        "blender": bpy.app.version_string, "gpu": gpu.platform.renderer_get(),
        "passed_method_check": all(value["within_5_percent"] for value in segments.values()),
        "segments": segments, "project_imports": _project_imports(),
    })


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    run(parser.parse_args(sys.argv[sys.argv.index("--") + 1:]))
