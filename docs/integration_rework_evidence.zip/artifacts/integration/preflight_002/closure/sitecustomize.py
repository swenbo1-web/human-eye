"""Record local project modules when a Python/Pillow worker exits."""

import atexit
from hashlib import sha256
import json
import os
from pathlib import Path
import sys


def record(role):
    root = Path(os.environ["HE_INTEGRATION_PROJECT_ROOT"])
    output = Path(os.environ["HE_INTEGRATION_IMPORT_RECEIPTS"])
    modules = {}
    for name, module in tuple(sys.modules.items()):
        raw = getattr(module, "__file__", None)
        if raw:
            path = Path(raw).resolve()
            if path.is_relative_to(root) and path.is_file():
                modules[name] = {"path": path.relative_to(root).as_posix(),
                                 "sha256": sha256(path.read_bytes()).hexdigest()}
    entry = Path(sys.argv[0]).resolve()
    if entry.is_file() and entry.is_relative_to(root):
        modules["__executed_entry__"] = {"path": entry.relative_to(root).as_posix(),
                                         "sha256": sha256(entry.read_bytes()).hexdigest()}
    target = output / f"{role}-{os.getpid()}.json"
    target.write_text(json.dumps({"pid": os.getpid(), "argv": sys.argv, "modules": modules},
                                 indent=2) + "\n", encoding="utf-8")


if os.environ.get("HE_INTEGRATION_IMPORT_RECEIPTS"):
    atexit.register(record, "python")
