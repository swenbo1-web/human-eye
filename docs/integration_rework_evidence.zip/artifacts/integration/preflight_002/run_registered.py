"""Launch registered bounded probes, archiving exact source bytes and inputs first."""

from argparse import ArgumentParser
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile, ZIP_DEFLATED


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
DEFAULT_PY = Path(r"D:\human eye\venv\Scripts\python.exe")
DEFAULT_BLENDER = Path(r"C:\Program Files\Blender Foundation\Blender 5.2\blender.exe")
THREADS = {"OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1",
           "BLIS_NUM_THREADS": "1", "VECLIB_MAXIMUM_THREADS": "1",
           "NUMEXPR_NUM_THREADS": "1", "PYTHONDONTWRITEBYTECODE": "1"}


def _digest(data):
    return sha256(data).hexdigest()


def _json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, allow_nan=False, indent=2) + "\n",
                    encoding="utf-8")


def _sources():
    paths = [*ROOT.glob("human_eye_fast/**/*.py"), *ROOT.glob("verification/**/*.py"),
             *HERE.glob("*.py"), *HERE.glob("closure/*.py"),
             *ROOT.glob("docs/ENGINE_INTEGRATION*.md")]
    return {path.relative_to(ROOT).as_posix(): path.read_bytes() for path in sorted(set(paths))}


def _relative(path):
    return Path(path).resolve().relative_to(ROOT).as_posix()


def _launch(args, manifest_path, manifest, phase):
    folder = args.run_dir / phase
    folder.mkdir(parents=True, exist_ok=False)
    receipts = folder / "imports"
    receipts.mkdir()
    worker = HERE / "worker_entry.py"
    registered = [manifest_path]
    deployed = manifest["deployments"][0]
    snapshot = ROOT / deployed["sealed_path"]
    payload = folder / "result"
    native = phase != "stub"
    if phase in ("stub", "legacy", "rework"):
        script = ROOT / "verification" / "test_integration_preflight.py"
        tail = ["--phase", phase, "--out", payload]
        if native:
            registered.append(snapshot)
            tail += ["--snapshot", snapshot, "--pillow-python", args.python]
    else:
        registered.append(snapshot)
        if phase == "bb":
            script = HERE / "bb_probe.py"
            feedback_root = ROOT / manifest["method_probe"]["bb"]["archived_feedback_root"]
            for case_id, feedback in manifest["method_probe"]["bb"]["archived_feedback"].items():
                for row in feedback:
                    registered.extend((feedback_root / row["archive_record"],
                                       feedback_root / case_id / row["attachment_key"]))
            tail = ["--manifest", manifest_path, "--out", payload]
        else:
            script = HERE / "resource_probe.py"
            tail = ["--manifest", manifest_path, "--out", folder / "result.json", "--instrument", phase]
    env = {
        **THREADS, "HE_INTEGRATION_PROJECT_ROOT": str(ROOT), "HE_INTEGRATION_ENTRY": str(script),
        "HE_INTEGRATION_IMPORT_RECEIPTS": str(receipts), "PYTHONPATH": str(HERE / "closure"),
        "PYTHONPYCACHEPREFIX": str(folder / "isolated-pycache"),
    }
    if native:
        cmd = [args.blender, "--background", "--factory-startup", "--disable-autoexec", "--threads", "1",
               "--python-exit-code", "1", "--python", worker, "--", *tail]
    else:
        cmd = [args.python, "-B", worker, *tail]
    cmd = list(map(os.fspath, cmd))
    sources = _sources()
    identity = {key: _digest(data) for key, data in sources.items()}
    assert identity["verification/integration_fixtures.py"] == manifest["generator_sha256"]
    inputs = {_relative(path): _digest(path.read_bytes()) for path in registered}
    if native:
        assert inputs[_relative(snapshot)] == deployed["sealed_sha256"]
    with ZipFile(folder / "sources.zip", "w", compression=ZIP_DEFLATED) as archive:
        for key, data in sources.items():
            archive.writestr(key, data)
    _json(folder / "launch.json", {"argv": cmd, "entry": _relative(script), "env": env,
                                   "source_superset": identity, "input_files": inputs})
    print(f"registered probe {phase}", flush=True)
    with (folder / "worker.log").open("wb") as log:
        process = subprocess.run(cmd, cwd=ROOT, env={**os.environ, **env}, stdout=log,
                                 stderr=subprocess.STDOUT, check=False)
    stable_sources = identity == {key: _digest(data) for key, data in _sources().items()}
    stable_inputs = inputs == {name: _digest((ROOT / name).read_bytes()) for name in inputs}
    imports = sorted(receipts.glob("*.json"))
    loaded = {}
    import_identity_errors = []
    for receipt in imports:
        data = json.loads(receipt.read_bytes())
        for item in data["modules"].values():
            if identity.get(item["path"]) != item["sha256"]:
                import_identity_errors.append(item)
            loaded[item["path"]] = item["sha256"]
    _json(folder / "process.json", {"exit_code": process.returncode, "stable_sources": stable_sources,
                                    "stable_inputs": stable_inputs, "observed_modules": loaded,
                                    "import_identity_errors": import_identity_errors,
                                    "worker_receipts": [path.name for path in imports]})
    return process.returncode == 0 and stable_sources and stable_inputs and bool(imports) and not import_identity_errors


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--phase", choices=("stub", "rework", "legacy", "bb", "managed", "os"),
                        nargs="+", required=True)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--python", type=Path, default=DEFAULT_PY)
    parser.add_argument("--blender", type=Path, default=DEFAULT_BLENDER)
    args = parser.parse_args()
    args.run_dir = args.run_dir.resolve()
    if not args.run_dir.is_relative_to(HERE):
        raise ValueError("Use a new run directory under preflight_002")
    path = HERE / "manifest.json"
    manifest = json.loads(path.read_bytes())
    results = [_launch(args, path, manifest, phase) for phase in args.phase]
    sys.exit(0 if all(results) else 1)


if __name__ == "__main__":
    main()
