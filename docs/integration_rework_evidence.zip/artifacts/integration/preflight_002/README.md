# 统一引擎接线预检复审证据

本轮交付验证侧 B、状态及失败边界、24 个正式主例的逐阶段清单和计量方法探针。B/B 的下一查询段为 **1.0768**，超过 1.05，方法资格未通过。协议冻结交主干复审。 [API 草案](../../../docs/ENGINE_INTEGRATION_API_DRAFT.md) · [协议草案](../../../docs/ENGINE_INTEGRATION_PROTOCOL_DRAFT.md)

[预登记清单](manifest.json) 的 SHA-256 为 `62e2d7ad5a2e26088b95bece1e7f0908e00444775dee4d6e92d9e33f7f59a4ab`，各过程均绑定这一版本。每个阶段目录中的 `launch.json` 保存实际 argv、环境和输入摘要，`sources.zip` 保存当时的项目源码字节，`imports/` 保存已观测的项目/venv 模块身份，`process.json` 保存退出码与稳定性核对。记录范围为归档项目源码、观测加载模块和逐阶段登记输入。便携及原生功能探针在源码中固定步骤并绑定清单，B/B 直接读取清单的计量规格及标签来源。 [交付摘要及文件 SHA-256](source-identity.json)

| 证据 | 实测结果 |
| --- | --- |
| [六个便携故障控制](run_001/stub/result/summary.json) | 过期计划拒绝且宿主未写入。目标或控制量回读失败时已有写入而无 Outcome。实测后上下文、渲染、AO 失败保留 −0.25 m 的 Outcome。 |
| [两个原生控制](run_002/rework/result/summary.json) | 随动屏上下文换代、单位变化和禁图，非 Basis relative key、重备 basis、替换参考和票据拒绝均通过断言。 |
| [旧功能对照](run_001/legacy/result/summary.json) · [独立公开重放](public-replay.json) | 原七例通过功能断言。旧新各 15 AO、14 PNG 和 schema 共 30 文件逐字节一致，8 份视觉评分也逐字节一致。随动屏后图唯一完整视觉失败仍为 `directions`，标签为 false。 |
| [B/B 汇总](run_002/bb/result/summary.json) · [计时原始行](run_002/bb/result/intervals.jsonl) · [时钟](run_002/bb/result/clock.json) | 3 例各 5 对预热及 31 对计量，实际票据校验、消费和模型更新进计时，PNG 身份核对在计时外。下一查询 p95 为 21.576970/23.234300 ms，是唯一超过 1.05 的段。 |
| [托管读数](run_001/managed/result.json) · [Win32/DXGI 读数](run_001/os/result.json) | 两个独立后台 Blender 进程各做一例一次绘制。托管探针热段峰值 7,262,572 B，关闭后 owner 数为零。绘制后工作集 283,009,024 B，DXGI LOCAL/NON_LOCAL 当前用量为 11,866,112/12,652,544 B，驱动用量读数在该进程关闭会话后仍相同。 |

[首个原生控制尝试](run_001/rework/worker.log) 的初始掩码断言把枚举组合写成 11，修正为符号组合后实测为 13。[首个 B/B 尝试](run_001/bb/worker.log) 在首条预热的 PNG 对账退出，修正平移复位为原始 Blender 通道后用原清单运行。首个 B/B 的一条预热记录不进统计。正式计量区间、样本、标签、次序和门槛沿用原清单。

仍待验的控制包括参考跟随、物理同尺度的单位重编码、目标三角行重排、零距打开及零距 SECTION 无图、部署格式等价、完整双会话交错学习与释放后重开。票据控制实测了过期计划、跨会话、重复和关闭后的拒绝。同一 owner 下故意错配的附件、观察 ID 或方向仍待单独注入，TD 故障也待单独注入。生产会话、正式 I/CF 性能、正式资源峰值及增量均待后续阶段。

计量方法若需继续确认，建议先固定一次覆盖三个封存 seed 与全部 24 例的 B/B，按原阶段及 5% 门保留所有过程，另按物理臂、AB/BA 及案例披露差异。保留本次失败，新增验证方案及资源峰值采样口径由主干事前审定。
