"""Re-read the two public package trees and compare archived strict visual scores."""

from hashlib import sha256
import json
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT))

from verification import ao_public_consumer as consumer


def identity(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": sha256(data).hexdigest()}


def read_tree(root):
    reader = consumer.Reader()
    schema = reader.json(root / "schema.json", "public schema")
    packages = {}
    errors = {}
    for path in sorted(root.glob("*/*.ao.json")):
        relative = path.relative_to(root).as_posix()
        try:
            packages[relative] = consumer.normalize(
                schema, reader.json(path, "public AO package"), path, reader)
        except (consumer.PublicDataError, OSError, ValueError) as error:
            errors[relative] = str(error)
    transitions = {}
    for name, item in packages.items():
        if Path(name).name != "transition.ao.json":
            continue
        folder = Path(name).parent
        before = packages[f"{folder.as_posix()}/before.ao.json"]["observations"][0]
        next_observation = packages[f"{folder.as_posix()}/next.ao.json"]["observations"][0]
        old, new = item["observations"]
        transitions[folder.as_posix()] = {
            "before_preserved": before == old,
            "observation_ids": [old["observation_id"], new["observation_id"],
                                next_observation["observation_id"]],
            "frame_ids": [old["frame_id"], new["frame_id"], next_observation["frame_id"]],
            "measured_delta_m": item["outcome"]["measured_delta_m"],
        }
    return {"files": list(reader.files.values()), "AO_packages": len(packages),
            "unique_referenced_PNGs": len(reader.images), "errors": errors,
            "transitions": transitions}


def public_inventory(root, replay):
    return {
        Path(row["path"]).relative_to(root).as_posix(): row["sha256"]
        for row in replay["files"]
    }


def read_visual_scores(root, public):
    result = {}
    for path in sorted(root.glob("*/*.visual.json")):
        raw = path.read_bytes()
        visual = json.loads(raw)
        relative = path.relative_to(root).as_posix()
        png = relative.removesuffix(".visual.json") + ".png"
        evidence, score = visual["evidence"], visual["score"]
        result[relative] = {
            "identity": {"path": str(path), "bytes": len(raw), "sha256": sha256(raw).hexdigest()},
            "score": score,
            "failed_checks": sorted(key for key, value in score["checks"].items() if not value),
            "png_identity_matches_public_read": score["png_sha256"] == public.get(png),
            "canonical_index": evidence["candidate"],
            "selected_probe_rays": evidence["selected_rays"],
        }
    return result


def actual_modules():
    paths = {}
    for name, module in tuple(sys.modules.items()):
        filename = getattr(module, "__file__", None)
        if filename and Path(filename).is_file():
            paths.setdefault(Path(filename).resolve(), []).append(name)
    return [
        {**identity(path), "module_names": sorted(paths[path])}
        for path in sorted(paths, key=str)
    ]


def main():
    historical = HERE.parent / "preflight_001" / "native_002"
    legacy = HERE / "run_001" / "legacy" / "result"
    roots = {"historical": historical, "legacy": legacy}
    public = {key: read_tree(root) for key, root in roots.items()}
    inventories = {key: public_inventory(root, public[key]) for key, root in roots.items()}
    old_files, new_files = inventories.values()
    differences = [
        name for name in sorted(set(old_files) | set(new_files))
        if old_files.get(name) != new_files.get(name)
    ]
    visuals = {key: read_visual_scores(root, inventories[key]) for key, root in roots.items()}
    old_visual, new_visual = visuals.values()
    visual_differences = [
        name for name in sorted(set(old_visual) | set(new_visual))
        if name not in old_visual or name not in new_visual
        or old_visual[name]["score"] != new_visual[name]["score"]
    ]
    visual_file_differences = [
        name for name in sorted(set(old_visual) | set(new_visual))
        if name not in old_visual or name not in new_visual
        or old_visual[name]["identity"]["sha256"] != new_visual[name]["identity"]["sha256"]
    ]
    negative = "I-carried-screen-0/after.visual.json"
    passed = (
        not differences and not visual_differences and len(old_files) == 30
        and all(row["AO_packages"] == 15 and row["unique_referenced_PNGs"] == 14
                and not row["errors"] and len(row["transitions"]) == 4
                and all(value["before_preserved"] for value in row["transitions"].values())
                for row in public.values())
        and all(len(rows) == 8 and all(row["png_identity_matches_public_read"] for row in rows.values())
                and {name for name, row in rows.items() if not row["score"]["passed"]} == {negative}
                and rows[negative]["failed_checks"] == ["directions"]
                and rows[negative]["score"]["pixel_success"] is False
                and rows[negative]["score"]["safe"] is False
                for rows in visuals.values())
    )
    report = {
        "passed": passed,
        "method": "original public AO consumer normalize/Reader; separate recorded strict-score comparison",
        "scope": "No new Blender, training, rays, or visual scoring. Public consumption does not imply visual pass.",
        "python": {"version": sys.version, "executable": identity(sys.executable)},
        "replay_script": identity(__file__),
        "public_consumer": identity(consumer.__file__),
        "loaded_module_files": actual_modules(),
        "public_read": public,
        "public_byte_differences": differences,
        "visual_score_differences": visual_differences,
        "visual_evidence_byte_differences": visual_file_differences,
        "strict_visual_records": visuals,
    }
    output = HERE / "public-replay.json"
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + "\n",
                      encoding="utf-8")
    print(f"{'PASS' if passed else 'DIFFERENCE'} {output} sha256={identity(output)['sha256']}")
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
