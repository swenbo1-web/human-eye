"""Read-only CPU verification of preflight_002 identity and public replay archives."""
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import sys
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "artifacts/integration/preflight_002"
OUT = Path(__file__).with_suffix(".json")
sys.path.insert(0, str(ROOT))


def digest(data):
    return sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main():
    identity = read(BASE / "source-identity.json")
    manifest_raw = (BASE / "manifest.json").read_bytes()
    manifest = json.loads(manifest_raw)
    errors = []
    artifact_inventory = identity["artifact_files_relative_to_this_directory"]
    for relative, expected in artifact_inventory.items():
        path = BASE / relative
        data = path.read_bytes()
        if len(data) != expected["bytes"] or digest(data) != expected["sha256"]:
            errors.append({"artifact_changed": relative})
    all_actual = {p.relative_to(BASE).as_posix() for p in BASE.rglob("*") if p.is_file()}
    unlisted_all = sorted(all_actual - set(artifact_inventory) - {"source-identity.json"})
    # The parent independently reran stub/rework after the author's handoff.
    # Preserve that inventory separately; do not call its files missing author evidence.
    parent_added = [name for name in unlisted_all if name.startswith("root_replay_001/")]
    unlisted = [name for name in unlisted_all if name not in parent_added]
    for relative, expected in identity["working_source"].items():
        data = (ROOT / relative).read_bytes()
        if len(data) != expected["bytes"] or digest(data) != expected["sha256"]:
            errors.append({"handoff_source_changed": relative})
    assert digest(manifest_raw) == identity["manifest_sha256"]
    from verification.integration_fixtures import manifest_document
    rebuilt = (json.dumps(manifest_document(feedback_root=Path(manifest["method_probe"]["bb"]["archived_feedback_root"])),
                          ensure_ascii=False, allow_nan=False, indent=2) + "\n").encode("utf-8")
    assert rebuilt == manifest_raw
    runs, prior_sources = [], None
    for launch_path in sorted(BASE.glob("run_*/*/launch.json")):
        folder = launch_path.parent
        relative = folder.relative_to(BASE).as_posix()
        launch, process = read(launch_path), read(folder / "process.json")
        with ZipFile(folder / "sources.zip") as archive:
            assert len(archive.namelist()) == len(set(archive.namelist()))
            archived_hashes = {name: digest(archive.read(name)) for name in archive.namelist()}
        assert archived_hashes == launch["source_superset"]
        assert archived_hashes["verification/integration_fixtures.py"] == manifest["generator_sha256"]
        for name, expected in launch["input_files"].items():
            assert digest((ROOT / name).read_bytes()) == expected, (relative, name)
        assert launch["input_files"]["artifacts/integration/preflight_002/manifest.json"] == digest(manifest_raw)
        module_files, receipts = {}, []
        for path in sorted((folder / "imports").glob("*.json")):
            receipt = read(path)
            for name, info in receipt["modules"].items():
                assert archived_hashes[info["path"]] == info["sha256"], (relative, name, info)
                module_files[info["path"]] = info["sha256"]
            receipts.append({"name": path.name, "pid": receipt["pid"], "argv": receipt["argv"],
                             "module_count": len(receipt["modules"])})
        assert module_files == process["observed_modules"]
        assert [r["name"] for r in receipts] == process["worker_receipts"]
        assert process["import_identity_errors"] == []
        assert process["stable_sources"] and process["stable_inputs"]
        assert launch["entry"] in archived_hashes
        assert launch["entry"] in module_files
        summary = identity["process_checks"][relative]
        assert summary["exit_code"] == process["exit_code"]
        assert summary["archived_source_files"] == len(archived_hashes)
        assert summary["registered_inputs"] == len(launch["input_files"])
        assert summary["receipt_files"] == len(receipts)
        assert summary["observed_import_files"] == len(module_files)
        changed = sorted(name for name, expected in archived_hashes.items()
                         if not (ROOT / name).is_file() or digest((ROOT / name).read_bytes()) != expected)
        runs.append({"run": relative, "exit_code": process["exit_code"],
                     "source_files": len(archived_hashes), "input_files": len(launch["input_files"]),
                     "observed_project_files": len(module_files), "receipts": receipts,
                     "launch_to_final_source_changes": changed,
                     "manifest_bound": True, "zip_inputs_receipts_consistent": True})
    assert len(runs) == 8
    assert [(r["run"], r["exit_code"]) for r in runs if r["exit_code"]] == [
        ("run_001/bb", 1), ("run_001/rework", 1)]

    replay_module = load(BASE / "public_replay.py", "root_provenance_public_replay")
    original = ROOT / "artifacts/integration/preflight_001/native_002"
    legacy = BASE / "run_001/legacy/result"
    public_results = {}
    inventories, visuals = {}, {}
    recorded_replay = read(BASE / "public-replay.json")
    for key, tree in (("historical", original), ("legacy", legacy)):
        actual = replay_module.read_tree(tree)  # Calls the public consumer; writes no archive.
        assert actual == recorded_replay["public_read"][key]
        inventories[key] = replay_module.public_inventory(tree, actual)
        visuals[key] = replay_module.read_visual_scores(tree, inventories[key])
        assert visuals[key] == recorded_replay["strict_visual_records"][key]
        assert actual["errors"] == {}
        assert actual["AO_packages"] == 15 and actual["unique_referenced_PNGs"] == 14
        assert len(inventories[key]) == 30
        assert all(t["before_preserved"] for t in actual["transitions"].values())
        public_results[key] = {"packages": actual["AO_packages"], "PNGs": actual["unique_referenced_PNGs"],
                               "files": len(inventories[key]), "transitions": actual["transitions"]}
    assert inventories["historical"] == inventories["legacy"]
    for name in visuals["historical"]:
        old, new = visuals["historical"][name], visuals["legacy"][name]
        assert old["score"] == new["score"]
        assert old["identity"]["sha256"] == new["identity"]["sha256"]
    negative = "I-carried-screen-0/after.visual.json"
    for key, rows in visuals.items():
        assert [name for name, row in rows.items() if not row["score"]["passed"]] == [negative]
        assert rows[negative]["failed_checks"] == ["directions"]
        assert rows[negative]["score"]["pixel_success"] is False
        assert rows[negative]["score"]["safe"] is False
    replay_identity_checks = {}
    for key in ("replay_script", "public_consumer"):
        item = recorded_replay[key]
        assert digest(Path(item["path"]).read_bytes()) == item["sha256"]
        replay_identity_checks[key] = True
    all_loaded = recorded_replay["loaded_module_files"]
    changed_loaded = []
    for item in all_loaded:
        path = Path(item["path"])
        if not path.is_file() or digest(path.read_bytes()) != item["sha256"]:
            changed_loaded.append(item["path"])
    result = {"passed_archive_consistency": not errors and not unlisted,
              "scope": "No Blender/GPU/native rerun. Public consumer reread and archive hash verification only.",
              "errors": errors, "unlisted_artifacts": unlisted,
              "later_parent_artifacts_outside_author_identity": parent_added,
              "manifest_sha256": digest(manifest_raw), "manifest_rebuilt_byte_identical": True,
              "verified_artifact_files": len(artifact_inventory), "runs": runs,
              "public_replay": public_results,
              "public_and_visual_bytes_unchanged": True,
              "known_direction_failure_preserved": negative,
              "replay_code_identities_match": replay_identity_checks,
              "replay_loaded_files_checked": len(all_loaded), "changed_replay_loaded_files": changed_loaded,
              "limits": ["Import receipts contain project files present in sys.modules at exit, not all venv/Blender runtime modules.",
                         "Receipt hashes read disk bytes at exit; launch/end stability is observed, not a file-open audit.",
                         "launch.env records overrides, not every inherited environment variable.",
                         "Blender/Python executable content hashes are not in the per-launch input lists."]}
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    print(json.dumps({k:v for k,v in result.items() if k not in ("runs","public_replay","limits")}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
