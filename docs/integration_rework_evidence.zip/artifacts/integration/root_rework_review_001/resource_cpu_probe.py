"""Exercise only the archived Python NumPy backing walker; never call OS/GPU/Blender."""
import ast
from hashlib import sha256
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT / "artifacts/integration/preflight_002/resource_probe.py"
OUT = Path(__file__).with_suffix(".json")


def main():
    raw = SOURCE.read_bytes()
    tree = ast.parse(raw)
    node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "numpy_backings")
    isolated = ast.Module(body=[node], type_ignores=[])
    namespace = {"np": np}
    exec(compile(isolated, str(SOURCE), "exec"), namespace)
    count = namespace["numpy_backings"]
    base = np.arange(128, dtype=np.float64)
    ordinary = count(base, base[::2], base.reshape(16, 8), base.view())
    assert ordinary == {"unique_buffers": 1, "bytes": base.nbytes}
    storage = bytearray(2048)
    a = np.frombuffer(storage, dtype=np.uint8)
    b = np.frombuffer(memoryview(storage)[16:], dtype=np.uint8)
    external = count(a, b)
    assert external == {"unique_buffers": 1, "bytes": len(storage)}
    memoryview_only = count(memoryview(base))
    assert memoryview_only == {"unique_buffers": 0, "bytes": 0}
    holder = type("ForeignOutput", (), {})()
    holder.features = base
    foreign = count(holder)
    assert foreign == {"unique_buffers": 0, "bytes": 0}
    strides = np.lib.stride_tricks.as_strided(base, shape=(32,), strides=(8,))
    try:
        strided = count(strides)
    except TypeError as exc:
        strided = {"error_type": type(exc).__name__, "message": str(exc)}
    # Demonstrates the release claim's root scope: another live holder survives.
    owner = type("OwnedState", (), {"__module__": "human_eye_fast.review_probe"})()
    owner.array = base
    held_by_caller = owner.array
    before = count(owner)
    owner.array = None
    declared_roots_after_close = count(owner)
    including_caller = count(owner, held_by_caller)
    assert declared_roots_after_close["bytes"] == 0 and including_caller["bytes"] == base.nbytes
    result = {
        "scope": "CPU synthetic coverage of exactly the archived numpy_backings function; no native resources",
        "source_sha256": sha256(raw).hexdigest(),
        "ordinary_array_views": ordinary, "shared_bytearray_via_memoryview": external,
        "memoryview_only_root_omitted": memoryview_only, "foreign_holder_omitted": foreign,
        "stride_tricks_base": strided,
        "release_scope": {"before": before, "only_declared_closed_roots": declared_roots_after_close,
                          "including_live_caller": including_caller},
        "interpretation": "Standard ndarray/base/memoryview chains deduplicate correctly; explicit root/type coverage remains necessary."
    }
    OUT.write_text(json.dumps(result, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
