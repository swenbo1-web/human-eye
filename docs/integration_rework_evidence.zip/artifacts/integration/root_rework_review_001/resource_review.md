# preflight_002 资源测法独立审查

结论：两个资源进程确实提供了可读的托管、NumPy backing、Win32 工作集和 DXGI 本进程显存分点数据；**尚未验证任何 I−B 资源上限、完整热闭环峰值或释放后重开**。代码与 raw 的 availability-only 范围一致。按主干本轮决定，API/状态可单独冻结并推进生产功能接线；成本及资源协议仍未冻结，正式 I 资源计量继续禁止。本轮只固定测法修正方向，不能把缺测计为通过。

审查只读取归档并执行 CPU backing 计数覆盖探针。本目录 `resource_cpu_probe.py/.json` 提取并执行作者原 `numpy_backings` 函数；未调用 resource_probe.run、Win32、DXGI 或 Blender。作者 resource_probe 源码摘要为 `8ac509d2e17a6ce4d300b1c62872ce429054a728d063002b72eb060d57d3184b`。

## NumPy backing 去重及托管峰值

作者沿 ndarray.base / memoryview.obj 追到实际 Python owner，以 owner 身份去重。CPU 实验确认：一个 1024 B ndarray 的切片、reshape 和 view 合计仍为 1 buffer/1024 B；两个共享 2048 B bytearray、其中一个通过 memoryview 建立的 ndarray，仍为 1 buffer/2048 B。这比相加 ndarray.nbytes 正确，现有 NumPy 常规持有图可以沿用。

该函数是有边界的 root 遍历，不是全进程分配清单。它只递归 dict values、list/tuple 和指定项目模块的对象；直接 memoryview root 及其它模块输出包装对象会被忽略，stride_tricks 的 DummyArray base 则触发 TypeError。以上均已在 CPU 探针复现。未发现本次 draw 必然使用这些额外形式，故不把合成边界误报为现有字节数造假；正式测量应登记实际 root 与类型覆盖，特别是公开输出、票据、临时前快照和未来生产 Session，不能依靠当前模块名前缀默默漏算。

正式输出应列 owner 标识、字节、来自哪些 root 和共享关系。当前函数只返回总数/总字节，尚不能核对 protocol 所称“按归属”记录。调用者仍持有的 AO/PNG bytes、票据 Python 对象由 tracemalloc 计费，NumPy owner 统计只作归因，二者不得相加后再次计费。

`resource_probe.py` 在读取部署字节、创建 fixture 之后启动 tracemalloc，随后执行 _materialize、加载模型、创建 control/renderer、capture/prepare/一次 observe；**没有任何 reset_peak 调用**。所以 `7,262,572 B` 是 start 以来的累计追踪峰，不是经过隔离的热段峰。prepared 时已经达到该数值，observed/close 沿用同一累计最大值。README 的“热段峰值”应改称“本次追踪区间累计峰”。Python 的 reset_peak 只重置峰值为当前已追踪大小，不清除已有分配；适合在初始化完成后建立明确热段边界。[Python tracemalloc 文档](https://docs.python.org/3/library/tracemalloc.html#tracemalloc.reset_peak)

当前 sample 在读取 current/peak 后执行 backing 遍历及追加字典；这些审计分配可能计入后续累计峰。正式热段不要在段内构造逐 owner 清单，先用轻量 get_traced_memory 读出热段结束值，再做归属审计，并在下一段前重置峰。启动追踪前已经分配的 fixture/model_data/import 常驻也应明确归为未包含或由冷点/OS 读数另列。

## RSS 与 DXGI 归因

Win32 Counter 结构和当前进程句柄用法与字段定义吻合。WorkingSetSize 是本进程当前工作集，PrivateUsage 是私有提交，PeakWorkingSetSize 是进程峰值字段；不能将 private commit 当 RSS，亦不能把进程启动以来峰值的差当某一热段峰值。[Microsoft PROCESS_MEMORY_COUNTERS_EX](https://learn.microsoft.com/en-us/windows/win32/api/psapi/ns-psapi-process_memory_counters_ex)

DXGI 通过 IDXGIAdapter3 的 QueryVideoMemoryInfo 读取指定 adapter、node 0、LOCAL/NON_LOCAL 两组 CurrentUsage，是调用进程当前用量；Budget 是 OS 给的预算，非实际占用，CurrentReservation 也非实际占用。本代码读字段和 HRESULT 检查符合该语义。node 0 适用于这里声明的单 GPU；正式运行仍需记录 node，而不只把 0 隐含在代码中。[Microsoft QueryVideoMemoryInfo](https://learn.microsoft.com/en-us/windows/win32/api/dxgi1_4/nf-dxgi1_4-idxgiadapter3-queryvideomemoryinfo) · [字段定义](https://learn.microsoft.com/en-us/windows/win32/api/dxgi1_4/ns-dxgi1_4-dxgi_query_video_memory_info)

raw 绑定 RTX 3060、LUID `[0,83164]`、OpenGL、WDDM driver 610.88。代码要求名称匹配仅有一个非软件适配器，再以 Blender renderer 名称复核；足以支持本次单卡 availability，正式运行应完整保存适配器枚举及固定 LUID/node，防止名称相同的多卡歧义。不要用预算或 nvidia-smi 的整卡值替换进程 CurrentUsage。若改为外部采样器，直接在外部进程调用此 DXGI 方法会测到外部进程自身；要在目标进程内采样，或使用可按 PID/LUID 归因的其它已核实机制。

两种 raw 都只有 cold_start、after_init、prepared、observed、close 五个点，且没有采样时间戳、2 ms 周期或最大间隔。OS observed 为 RSS `283,009,024 B`，LOCAL `11,866,112 B`、NON_LOCAL `12,652,544 B`；它们是真实分点读数，不是热窗峰值。两组 GPU 不能只选更小的一组比较门槛，也不能将它们和 RSS 相加，因为 NON_LOCAL 与系统内存存在不同计量归属。

## close 的真实证明范围

close 后 NumPy owner=0 只证明传入 `numpy_backings(control, renderer)` 的声明根没有可达 ndarray owner。CPU 探针用另一调用者继续持有 array 的例子，复现了“声明根计数为零、实际仍有活 backing”同时成立。因此不应称为全进程所有资源已经释放。

本次 root 不含仍活着的 rendered/其 PNG，且没有建立 TD 参考、完整学习票据及联合 before/after 发布。control.close 代码清空 bridge/index/reference/model 持有；renderer.close 释放 offscreen 并删除相机、清空几个 NumPy 压缩缓冲，但本探针局部变量仍持有 renderer，renderer.shader/hud_shader 也仍是字段。作者没有记录 RNA 相机资源数量、GPU 对象生命周期、弱引用或释放后重开重复曲线。

close 的 LOCAL/NON_LOCAL 数值与 observed 相同是应该保存的现象。可能存在驱动保留，也存在尚未释放的 Python/GPU 对象范围；本证据不能把全部差额归因给驱动缓存，更不能据此证明泄漏或无泄漏。正式 close 验收应分别检查 API 拥有的引用和原生对象已释放、调用者保留输出仍可读、清除调用者输出后的托管状态、重开后是否持续增长。不要要求 GPU 计费瞬时回零来替代对象所有权核查。

## 后续正式测法候选及有限待验项

以下供后续事前选定，不代表本轮已经批准正式资源协议。数值门继续使用原建议，不扩大阈值：

1. B/I 每 seed 分别新进程、同设备和 24 例顺序；分别采集导入后冷点、模型、参考建立/替换、完整热闭环输出仍持有、反馈消费且输出释放、close、reopen。拓扑重建及异常释放分列，不和正常热闭环平均。
2. 托管实验在创建会话/模型前启动追踪。初始化和预热结束、t0 前 reset_peak；连续覆盖 before→execute/after→feedback→next，t4 后立即取 current/peak。在记录外做 owner census，登记实际模型、bridge/index、参考、前快照、渲染器及调用者输出/票据 roots。常驻比较定义建议为每 seed 所有对应热态点 `max(I_current−B_current)` ≤262,144 B；峰值比较建议为对应热窗 peak 的最大 I−B ≤1,048,576 B。是否采用逐点最大而非其它汇总应由主干在新数据产生前固定。
3. OS/驱动实验独立于 tracemalloc 和正式延迟计时。先固定同窗 RSS、LOCAL、NON_LOCAL 的比较对象；建议 GPU 门比较 `LOCAL+NON_LOCAL` 同时刻之和的 I−B，同时分列两组，8,388,608 B 上限不变。RSS 单独比较，不与 GPU 相加。若选择各组分别 ≤8 MiB，则属于另一个口径，必须明确事前登记，不能测完择优。
4. 对峰值做一次有边界的采样资格探针：目标进程内、单调时间戳、每次读数开始/结束时间、实际间隔分布/最大间隔、阶段标记和固定热窗。Python 线程可能被 GIL/宿主长调用推迟，标称 2 ms 不构成覆盖证明。主干要事前选择“实际定期采样峰”或需要 PID/LUID 可归因的更强峰值机制。周期采样只支持采样峰声明；未观测到的更短峰不能算作满足真实瞬时峰上限。
5. 给释放检查补上确定的 owned roots、相机/原生句柄生命周期和 close→reopen 固定重复序列；先保留输出测试 bytes 可读，再清除输出检查常驻变化。这是验证层证据，不给生产引擎增加扫描、重试或防御链。

当前两个 availability 结果均不得填入 I−B 常驻/峰值通过栏。它们不要求重复启动 BC/VG 等模块优化，也不能代替当前另外尚未通过的 B/B 延迟计量资格。

## 下一次仅一个 B 方法探针的最小工作单

建议使用原清单的 `I-open-tip-0`、deployment process index 0，在**一个新的 B 进程**中执行事前固定的一条完整链；只验证采样可达性和显式 ownership，不计量 I，不比较 B/I，不输出正式延迟或资源收益。代码、输入、运行时身份及根清单在启动前归档，固定一次运行，失败保留，不因未达期望更换样本。

- 构建模型、参考及 B 后列出 reference/model/bridge/index/renderer 和调用者输出、票据的实际根；共享 buffer 在全根集合去重，记录 owner 与来源路径。检查前 moving 快照和输出持有责任，没有模型训练任务或新增优化。
- 在唯一完整 before→execute/after→feedback→next 链前 reset_peak，链后先读 current/peak 再整理审计字典。仅报告此固定链的追踪峰及真实保留状态；不使用之前累计的 7,262,572 B。
- 同一 B 进程内采 Win32/DXGI，记录 PID、adapter LUID、node、单调计时分辨率及每次查询起止时间。保存全时序和最大实际间隔，明确分别为分点 current 与采样值。该方法探针允许测量工具相互影响，不能转用其值宣布正式资源收益。
- close 时分别核查 B 所拥有的桥、模型、参考、GPU/offscreen/相机责任；调用者 AO/PNG bytes 仍持有且应可读。之后清除外部输出/票据，再列根；不把外部保留量算作 B 未释放，也不把单一空根推成全进程零资源。
- 结束后由主干根据最大采样间隔及适配器归因决定后续采用明确的 sampled peak，还是另行登记 ETW 方案。若周期无法覆盖短峰，本次仍只认证 current 可读，不宣称瞬时峰门通过。

该最小工作单只检验资源方法，生产接线可独立推进；正式 I 资源计量继续等待资源协议单独冻结。
