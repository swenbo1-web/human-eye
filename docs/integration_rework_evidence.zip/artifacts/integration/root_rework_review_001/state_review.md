# preflight_002 状态契约独立复审

2026-11-06；integration_state_review。仅审查状态、API、最小控制接缝及已有证据，不审定正式性能。未运行 Blender/GPU，未改生产或交付文件。本轮新增仅为本目录 state_probe.py、state_probe.json 和本文。

## 结论

**状态/API 接口可以冻结，用于一次有界的阶段二生产接线。未发现仍阻止正确接线的状态错误。** 上轮列出的 context generation、禁图、NONE、执行失败真实 Outcome、票据生命周期及 basis 缓存边界均已补齐。没有理由为这些项目再开启一次架构/算法优化或要求重跑全部预检。

这一结论不等于生产入口已经交付，也不等于正式性能协议已通过。B/B 下一查询段 1.0768 的计量资格问题由主干另行裁定，不能被本报告的状态通过结论覆盖。

## 上轮问题逐项核对

| 项目 | 本次实现及已有证据 | 判断 |
| --- | --- | --- |
| per-object masks/generation | CaptureChange(mask,generation)；构造复制代号；目标固定拓扑/外观；context TOPOLOGY 要求新代号并在成功 capture 后更新；AO 按每对象代号。run_002/rework/masks 实测 6/7/8/9→6/7/10/9，after masks 为5/5/4/0，换代为0/0/2/0，单位改变为8/8/8/8，同阶段同 bridge/graph。 | 已补齐。 |
| 最小 seam / 真实 Outcome | 同 graph 中先目标 capture/BC，再实际 control_after，物化 Outcome 后才 context；prepare/not_written、setter/unknown、target_readback/written 无 Outcome；之后 context/TD/render/AO 均携真实 Outcome。无重试或第二次目标 capture。 | 顺序正确，可以冻结；生产保留同序。 |
| plan/current 失效 | owner、consumed、同一个 readback 身份和 observation ID 联合绑定。执行开始消耗计划，controller 撤销 current；after 发布失败也清空 current；新 observe/replace/close 撤销旧计划。 | 已补齐。过期计划拒绝不写入；失败不能重用旧计划。 |
| 禁图 / NONE / 无动作 | _render 在 mode=None 立即返回 disabled；空面、零距 SECTION 独立返回无图状态；公开预测使用大写 NONE；NoAction 明确 NO_SURFACE/GOAL_REACHED。原生 UnavailableRenderer 控制证明禁图没有 prepare/render，真实 NONE 平移得到实测 delta。 | 上轮 B 具体错误已修复。 |
| basis 生命周期 | RelativeShapeBasis 保存 moving/key/relative_key 身份和只读 BU 差分；缓存定义固定、改变 authored 定义显式重备，当前单位/A 每次用于世界变换。native nonbasis-key 读取实际 Relative，q .25→.625，修改 key 后显式重备并核对世界 basis。 | 公式及生命周期已明确；不用 hash/扫描。 |
| 迟到/重复/close 票据 | V/A owner+消费标志，票据无会话回指；V 比较观察/附件/方向绑定；A 只读真实 Outcome。文档明确活跃会话内跨 next/reference replacement 可迟到，close 失效，复制合同外。native tickets 在替换 reference 后实际写入2V+1A；foreign/duplicate/closed 拒绝。 | 已补齐，无需未决表。 |
| before 所有权 | execute 写入前仅复制前 moving 世界坐标，摘要/三角/像素按既有固定拓扑和所有权复用；输出 AO/PNG bytes 保留。 | 实现正确；本轮独立可变借用缓冲 probe 进一步验证联合包前事实未变。 |

## 证据核对

读取了 run_001/stub 原始 summary、测试源及 run_002/rework masks/tickets 原始记录和公开 AO。run_002/rework 的 process.json 为 exit_code=0、stable_sources=true、stable_inputs=true、import_identity_errors=[]；执行中的 integration_reference.py SHA256 与本次所读文件一致：95fff56d1b6f31600bf2904caf83e3f8a6f9c66a929ed5f317be1a72e5941dd9。

run_001/stub 是**便携假宿主**，不能称作 Blender 原生故障注入：

- stale-plan：零写入，无 Outcome。
- target-readback、control-after：实际 stub setter 一次到 x=.25，返回 written，无 Outcome。
- after-context、post-render、post-ao：同一写入一次，实际 BC 计算 delta=-.25 m，错误携 Outcome。事件顺序证明 context 在 control_after 读取之后。

run_002/rework 才是原生 Blender 证据：逐对象掩码与换代、真实单位改变、禁图/NONE、非 Basis key、参考替换与迟到反馈、外来/重复/关闭票据拒绝。这里 scale 从1改为.5使物理世界缩半，**不冒充物理不变的单位重编码控制**；后者仍已正确列在阶段二待验。

首轮原生 masks 失败及日志被保留；11→符号组合13是断言期望写错后的明确修复，当前成功证据实测13。没有据失败删掉场景或放宽数值/图像门。

## 本轮独立 CPU 检查

`state_probe.py` 使用验证侧 fake host 以及现行真实 BC/TD/CF/AO 代码，输出 state_probe.json，所有断言通过。它不是 Blender/GPU 证据，也不是性能数据。

1. 构造会就地改写旧 world buffer 的 BorrowingBridge，确认执行确实改变 before.fact 借用坐标，但联合 AO 的 before 与原公开观察完全相同，原 AO bytes 不变；没有 renderer 仍可完整禁图发布。
2. 实际生成 L action 特征和 A receipt，替换参考后更新一次；重复反馈拒绝且无第二次更新，已消费特征释放。
3. 分别在 context、TD、render、AO 注入失败。每例只有一次 setter，delta=-.25 m 的同一个真实 Outcome 保留；current 无效、plan 已消费；错误附带的 A 票据可从该 Outcome 真值更新一次。此前没有专门注入的 TD 边界在本轮补成 CPU 证据，不宣称其原生注入已完成。
4. synthetic V receipt 在同 owner 下分别错配 observation、附件、方向，均在消费/更新前拒绝；正确绑定随后成功更新一次。这里只验证绑定入口，不声称新的真实 V 质量样本。

另运行 `python -m unittest verification.test_integration_preflight.IntegrationDesignPreflight -v`，当前3项全部通过，其中包含原来的6个便携故障分支。

## 最小剩余工作：属于阶段二实施/验收，不是新阻塞

- 把已冻结的顺序接入 production control 的可选 seam；未传参数的独立旧 controller 保留原行为，包括其直接空面执行，而统一 session 执行其 NO_SURFACE 政策。B 当前有意模拟统一政策，不能把 B 的整个 execute 覆盖原样当作旧 controller 默认分支。
- 生产对外返回不可变 bytes 与轻量绑定，不把 B 验证内部的 borrowed ObservedFrame.fact 当成公共 mesh API；lazy VG、每会话私有部署模型及 close 由新入口实现。
- 已登记的参考跟随、物理不变单位重编码、目标换代重排、零距打开/SECTION、部署加载等价、完整双会话交错及释放重开，继续作为阶段二功能门。未跑不等于当前接口有缺陷，不需要因此再做一次预检优化循环。
- 正式计量资格和资源峰值定义由另一路复审及主干决定，保持与本报告的状态/API 冻结结论分开。

建议：状态侧批准冻结并进入生产接线；不再退回做泛化状态机、容错层或已验收内核优化。
