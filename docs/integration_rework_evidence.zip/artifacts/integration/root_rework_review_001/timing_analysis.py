"""Offline audit only: no Blender/GPU imports, reruns, or threshold changes."""
from collections import Counter
from difflib import unified_diff
from hashlib import sha256
import csv
import json
from pathlib import Path
import sys
from zipfile import ZipFile
import numpy as np

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
BASE = ROOT / 'artifacts/integration/preflight_002'
OUT = Path(__file__).parent
RESULT = BASE / 'run_002/bb/result'
raw = [json.loads(line) for line in (RESULT/'intervals.jsonl').read_text().splitlines()]
manifest = json.loads((BASE/'manifest.json').read_bytes())
bb = manifest['method_probe']['bb']
summary = json.loads((RESULT/'summary.json').read_bytes())
segments = bb['segments']
for row in raw:
    assert sum(row['ns'][x] for x in segments[:-1]) == row['ns']['continuous_total']
    assert row['warmup'] == (row['pair'] in bb['warm_pair_indices'])
    row['position'] = row['order'].index(row['lane'])
assert len(raw) == 216
measured = [r for r in raw if not r['warmup']]
assert len(measured) == 186

def desc(values):
    a=np.asarray(values,float)
    return {'n':len(a),'min':float(a.min()),'p25':float(np.quantile(a,.25)),
            'median':float(np.median(a)),'p75':float(np.quantile(a,.75)),
            'p95':float(np.quantile(a,.95)),'max':float(a.max()),'mean':float(a.mean())}

out={'input_hashes':{str(p.relative_to(ROOT)).replace('\\','/'):sha256(p.read_bytes()).hexdigest()
                     for p in (BASE/'manifest.json',BASE/'bb_probe.py',RESULT/'summary.json',RESULT/'intervals.jsonl',RESULT/'clock.json')},
     'counts':{'all_rows':len(raw),'measured_rows':len(measured),'measured_pairs':len(measured)//2},
     'cases':{},'recomputed_segments':{},'archive_changes':{},'source_identity_checks':{}}
for case in bb['case_ids']:
    data=[r for r in measured if r['case']==case]
    pairs={p:{r['lane']:r for r in data if r['pair']==p} for p in bb['measured_pair_indices']}
    assert all(len(v)==2 and v[0]['order']==v[1]['order'] for v in pairs.values())
    archive=json.loads((RESULT/f'{case}.json').read_bytes())
    for r in raw:
        if r['case']==case:
            match=next(a for a in archive if a['pair']==r['pair'])
            assert r['ns']==match['lanes_ns'][str(r['lane'])]
    case_result={'ordering_counts':dict(Counter(f"lane{r['lane']}_position{r['position']}" for r in data)), 'segments':{}}
    for s in segments:
        lanes={str(l):desc([r['ns'][s]/1e6 for r in data if r['lane']==l]) for l in (0,1)}
        delta=np.array([(v[1]['ns'][s]-v[0]['ns'][s])/1e6 for v in pairs.values()])
        ratio=np.array([v[1]['ns'][s]/v[0]['ns'][s] for v in pairs.values()])
        grouped={f'lane{l}_{pos}':desc([r['ns'][s]/1e6 for r in data if r['lane']==l and r['position']==pos]) for l in (0,1) for pos in (0,1)}
        trend={f'p{lo}-{hi}_lane{l}':desc([r['ns'][s]/1e6 for r in data if r['lane']==l and lo<=r['pair']<=hi]) for lo,hi in ((5,14),(15,24),(25,35)) for l in (0,1)}
        warm={str(l):[r['ns'][s]/1e6 for r in raw if r['case']==case and r['warmup'] and r['lane']==l] for l in (0,1)}
        # 15 adjacent two-pair blocks (5+6 ...33+34); pair35 is retained separately.
        blocks=[]
        for p in range(5,35,2):
            assert pairs[p][0]['order'] != pairs[p+1][0]['order']
            means=[(pairs[p][l]['ns'][s]+pairs[p+1][l]['ns'][s])/2 for l in (0,1)]
            blocks.append({'pairs':[p,p+1],'lane1_minus_0_ms':(means[1]-means[0])/1e6,'lane1_over_0':means[1]/means[0]})
        # Descriptive OLS only: log(lane1/lane0) = intercept + order + repeat + order*repeat.
        t=np.array(list(pairs),float); t-=t.mean()
        order=np.array([1 if v[1]['position']==1 else -1 for v in pairs.values()])
        X=np.column_stack([np.ones(31),order,t,order*t]); y=np.log(ratio)
        coeff=np.linalg.lstsq(X,y,rcond=None)[0]
        slope=[]
        for l in (0,1):
            vals=np.array([pairs[p][l]['ns'][s]/1e6 for p in pairs])
            slope.append(float(np.polyfit(t,vals,1)[0]))
        case_result['segments'][s]={'lanes_ms':lanes,'median_lane1_over_0':lanes['1']['median']/lanes['0']['median'],
            'paired_delta_ms':desc(delta),'paired_ratio':desc(ratio),'lane1_slower_pairs':int((delta>0).sum()),
            'by_lane_position_ms':grouped,'temporal_thirds_ms':trend,'warmup_ms':warm,
            'balanced_blocks':blocks,'balanced_block_ratio':desc([b['lane1_over_0'] for b in blocks]),
            'unmatched_final_pair':{'pair':35,'lane1_over_0':ratio[-1]},
            'descriptive_log_ratio_ols':dict(zip(('lane_intercept','second_position_effect','repeat_slope','position_repeat_interaction'),coeff.tolist())),
            'raw_slope_ms_per_repeat_by_lane':slope}
    out['cases'][case]=case_result

for s in segments:
    medians={case:[np.median([r['ns'][s] for r in measured if r['case']==case and r['lane']==l]) for l in (0,1)] for case in bb['case_ids']}
    p95=np.quantile(list(medians.values()),.95,axis=0,method='linear')
    assert medians==summary['segments'][s]['case_medians_ns']
    assert np.array_equal(p95,summary['segments'][s]['lane_p95_ns'])
    out['recomputed_segments'][s]={'case_medians_ns':medians,'lane_p95_ns':p95.tolist(),
        'max_bidirectional_ratio':float(max(p95)/min(p95)),'within_5_percent':bool(max(p95)/min(p95)<=1.05)}
clock=json.loads((RESULT/'clock.json').read_bytes())
out['clock']={'spec':clock['clock'],'empty_ns':desc(clock['empty_ns'])}
from verification.cf_training import load_frozen
frozen=load_frozen(ROOT/'artifacts/cf/formal_001/20261105/seal/frozen.npz')
models=(frozen.session(),frozen.session())
out['model_load_only']={'initial_counts':[models[0].views.writes,models[0].actions.writes],
    'capacities':[models[0].views.capacity,models[0].actions.capacity],
    'head_weight_shapes':[list(models[0].view_head.weights.shape),list(models[0].action_head.weights.shape)],
    'private_equal_state':{}}
for name in ('view_head.weights','action_head.weights','views.keys','views.values','views.known','actions.keys','actions.values','actions.known'):
    owner,field=name.split('.')
    arrays=[getattr(getattr(m,owner),field) for m in models]
    if owner in ('views','actions'):
        arrays=[a[:getattr(m,owner).writes] for a,m in zip(arrays,models)]
    out['model_load_only']['private_equal_state'][name]={
        'equal_bytes':arrays[0].tobytes()==arrays[1].tobytes(),
        'shares_memory':bool(np.shares_memory(*arrays)),
        'active_bytes':arrays[0].nbytes}
for m in models:m.close()
with ZipFile(BASE/'run_001/bb/sources.zip') as first, ZipFile(BASE/'run_002/bb/sources.zip') as second:
    for name in sorted(set(first.namelist())|set(second.namelist())):
        if name.endswith('/'):
            continue
        a=first.read(name) if name in first.namelist() else b''
        b=second.read(name) if name in second.namelist() else b''
        if a != b:
            out['archive_changes'][name]={'before_sha256':sha256(a).hexdigest(),'after_sha256':sha256(b).hexdigest()}
            if name.endswith('.py'):
                out['archive_changes'][name]['diff']=''.join(unified_diff(a.decode('utf-8-sig').splitlines(True),b.decode('utf-8-sig').splitlines(True),fromfile='run_001',tofile='run_002'))
    for name in second.namelist():
        current=ROOT/name
        if current.is_file() and name in ('artifacts/integration/preflight_002/bb_probe.py','verification/integration_reference.py','human_eye_fast/cerebellar_flash.py'):
            out['source_identity_checks'][name]=sha256(second.read(name)).hexdigest()==sha256(current.read_bytes()).hexdigest()
with (OUT/'timing_rows.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=['case','pair','lane','position','warmup',*segments]);w.writeheader()
    for r in raw:w.writerow({k:r[k] for k in ('case','pair','lane','position','warmup')}|{s:r['ns'][s] for s in segments})
(OUT/'timing_analysis.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n',encoding='utf-8')
print('COUNTS',out['counts'])
print('CLOCK',out['clock'])
print('ARCHIVE_CHANGED',list(out['archive_changes']))
print('P95', {s:v['max_bidirectional_ratio'] for s,v in out['recomputed_segments'].items()})
for c,d in out['cases'].items():
    print('\nCASE',c,d['ordering_counts'])
    for s,x in d['segments'].items():
        print(s,'medians_ms',[x['lanes_ms'][str(l)]['median'] for l in (0,1)],'ratio',round(x['median_lane1_over_0'],6),
              'paired_delta',round(x['paired_delta_ms']['median'],6),'lane1_slower',x['lane1_slower_pairs'],
              'order_medians', {k:round(v['median'],6) for k,v in x['by_lane_position_ms'].items()},
              'third_medians',{k:round(v['median'],6) for k,v in x['temporal_thirds_ms'].items()},
              'ABBA_median_ratio',round(x['balanced_block_ratio']['median'],6))
