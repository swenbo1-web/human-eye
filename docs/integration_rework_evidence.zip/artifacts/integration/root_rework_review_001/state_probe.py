"""Independent CPU state checks, using a synthetic host only."""

from contextlib import nullcontext
from hashlib import sha256
import json
from pathlib import Path
import sys
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from human_eye_fast.cerebellar_flash import CerebellarFlash, LinearHead
from human_eye_fast.control import Goal, Translate
from human_eye_fast.fast_affordance_out import public_schema
from verification import integration_reference as ref
from verification.test_fast_affordance_out import decode_public
from verification.test_integration_preflight import _StubBridge, _StubObject


class BorrowingBridge(_StubBridge):
    """Make existing world buffers change in place, as the real RB does."""

    def capture(self, key, obj, graph, scale, changes=0):
        previous = self.meshes.get(key)
        current = super().capture(key, obj, graph, scale, changes)
        if previous is not None:
            previous.world_m[:] = current.world_m
            previous.world_from_local[:] = current.world_from_local
            self.meshes[key] = previous
            return previous
        return current


def create(case="success", *, borrowing=False):
    events = []
    objects = {key: _StubObject(key, x, events)
               for key, x in (("moving", 0.), ("reference", 2.), ("context", 4.))}
    scene = SimpleNamespace(frame_current=17, view_layers=[object()],
                            unit_settings=SimpleNamespace(scale_length=1.))
    graph = object()
    bpy = SimpleNamespace(context=SimpleNamespace(
        temp_override=lambda **_: nullcontext(), evaluated_depsgraph_get=lambda: graph))
    model = CerebellarFlash(
        LinearHead(np.zeros(5), np.ones(5), np.zeros(6), quadratic=False,
                   regularization=0., view=True),
        LinearHead(np.zeros(23), np.ones(23), np.zeros(24), quadratic=False,
                   regularization=0., view=False), retrieval_scale=np.ones((16, 5)), capacity=8,
    )
    with patch.dict(sys.modules, {"bpy": bpy}):
        control = ref.SharedCaptureControl(scene, objects, Goal("moving", "reference", 0., 0.),
                                           model=model, generations={"moving": 6, "reference": 7,
                                                                     "context": 8})
    control.bridge = (BorrowingBridge if borrowing else _StubBridge)(case, events)
    reference = ref.reference_from_capture(control, control.observe("reference"))
    before = ref.observe(control, None, reference, "before", mode=None, view_arm="F", model=model)
    return control, reference, before, model, events


def main():
    records = {"evidence_kind": "CPU synthetic host; not Blender or GPU evidence"}
    control, reference, before, model, events = create(borrowing=True)
    try:
        original_bytes = before.ao_bytes
        before_positions = before.fact.deformation.position_vertices_m.copy()
        plan = ref.predict(control, before, Translate((.25, 0., 0.)), "act", action_arm="L",
                           model=model)
        result = ref.execute(control, None, reference, before, plan, "after", mode=None,
                             view_arm="F", model=model)
        assert not np.array_equal(before.fact.deformation.position_vertices_m, before_positions)
        old = decode_public(original_bytes, public_schema())["observations"][0]
        combined = decode_public(result.ao_bytes, public_schema())["observations"][0]
        assert combined == old and before.ao_bytes == original_bytes
        assert result.after.image_status == "disabled" and not result.attachments
        records["before_ownership"] = {
            "borrowed_positions_really_mutated": True,
            "joint_before_equals_original_public_observation": True,
            "original_bytes_unchanged": True,
            "no_renderer_needed": True,
        }
        replacement = ref.WorldReference(17, 6, control.bridge.get("moving").world_m)
        control.replace_reference(replacement)
        ticket = result.action_ticket
        ref.action_feedback(control, model, ticket)
        assert model.actions.writes == 1 and ticket.consumed and ticket.features is None
        try:
            ref.action_feedback(control, model, ticket)
        except ValueError:
            assert model.actions.writes == 1
        else:
            raise AssertionError("Duplicate A receipt accepted")
        records["delayed_a_after_reference_replacement"] = {
            "one_actual_update": True, "duplicate_rejected_without_update": True,
            "features_released_by_ticket": True,
        }
    finally:
        control.close()

    failures = []
    for case in ("after-context", "post-td", "post-render", "post-ao"):
        control, reference, before, model, events = create(case)
        try:
            plan = ref.predict(control, before, Translate((.25, 0., 0.)), "act",
                               action_arm="L", model=model)
            names = {"post-td": "compute_cross_frame_deformation_tensor",
                     "post-render": "_render", "post-ao": "encode"}
            injection = (patch.object(ref, names[case], side_effect=RuntimeError(case))
                         if case in names else nullcontext())
            with injection:
                try:
                    ref.execute(control, None, reference, before, plan, "after", mode=None,
                                view_arm="F", model=model)
                except ref.ActionStageError as error:
                    assert error.write_status == "written" and error.outcome.measured_delta_m == -.25
                    assert error.action_ticket.outcome is error.outcome
                    assert control._latest is None and plan.consumed and plan.features is None
                    ref.action_feedback(control, model, error.action_ticket)
                    assert model.actions.writes == 1
                    failures.append({"case": case, "stage": error.stage,
                                     "delta_m": error.outcome.measured_delta_m,
                                     "actual_writes": sum(event[0] == "write" for event in events),
                                     "current_invalid": control._latest is None,
                                     "valid_a_update": model.actions.writes})
                else:
                    raise AssertionError("Expected injected failure")
            assert sum(event[0] == "write" for event in events) == 1
        finally:
            control.close()
    records["post_measurement_failures"] = failures

    control, reference, before, model, events = create()
    try:
        # Synthetic receipt tests only the lightweight binding gate, not V quality.
        receipt = ref.ViewReceipt("before", "L", 2, 7, True, np.zeros((16, 5)),
                                  "before.png", control._owner)
        wrong = [ref.ViewFeedback("other", "before.png", 2, True),
                 ref.ViewFeedback("before", "other.png", 2, True),
                 ref.ViewFeedback("before", "before.png", 3, True)]
        for feedback in wrong:
            try:
                ref.view_feedback(control, model, receipt, feedback)
            except ValueError:
                assert not receipt.consumed and model.views.writes == 0
            else:
                raise AssertionError("Wrong binding accepted")
        ref.view_feedback(control, model, receipt, ref.ViewFeedback("before", "before.png", 2, True))
        assert receipt.consumed and receipt.features is None and model.views.writes == 1
        records["synthetic_same_owner_v_binding"] = {
            "wrong_observation_attachment_direction_rejected": True,
            "rejection_did_not_consume_or_update": True,
            "correct_binding_updates_once": True,
        }
    finally:
        control.close()

    records["source_sha256"] = {name: sha256((ROOT / name).read_bytes()).hexdigest() for name in (
        "verification/integration_reference.py", "verification/test_integration_preflight.py",
        "docs/ENGINE_INTEGRATION_API_DRAFT.md", "docs/ENGINE_INTEGRATION_PROTOCOL_DRAFT.md")}
    Path(__file__).with_suffix(".json").write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(records, indent=2))


if __name__ == "__main__":
    main()
