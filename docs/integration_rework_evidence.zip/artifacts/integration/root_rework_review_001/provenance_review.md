# preflight_002 来源及公开重放独立复核

作者交付的来源链一致性通过；不把探针的功能退出成功解读为资源门或性能资格通过。复核脚本为本目录 `provenance_probe.py`，结果为 `provenance_probe.json`。仅执行 CPU 读档、散列校验、清单生成和公开消费者重读，没有启动 Blender、GPU、训练或性能重测，也没有改作者交付。

## 已独立核对

- `source-identity.json` 列出的 138 个归档文件，当前字节数与 SHA-256 全部吻合；其 5 个 working_source 文件亦吻合。
- manifest 使用当前已封存摘要的生成器和原反馈目录重新生成，**逐字节一致**。摘要为 `62e2d7ad5a2e26088b95bece1e7f0908e00444775dee4d6e92d9e33f7f59a4ab`。8 次作者启动全部绑定此清单；读取的原部署/历史 PNG/评分输入摘要亦全部吻合。
- 每次启动的 `sources.zip` 都包含 571 个无重复路径源码条目。每个 ZIP 条目的实际字节摘要，逐项等于对应 launch 的 source_superset。
- 全部 import receipt 的项目路径/散列都在该次 ZIP 中；合并结果逐项等于 process.observed_modules。回执文件列表和数目、输入数、退出码与最终 identity 汇总一致，没有 import_identity_error。所有已归档进程结束时稳定性检查记录为 true。
- 预检第一次 rework 与 bb 的退出码均为 1，失败源码、日志、输入与回执仍保留。其它 6 次退出为 0。不能把 run_002 成功写成初次就成功。
- CPU 重新调用原公开 AO 消费者，旧/重放两树各读 15 AO、14 个被引用 PNG 和 schema，30 个公开文件逐字节一致。四条 transition 的旧 before 均保持不变。8 份视觉 evidence 文件与严格 score 也逐字节一致。
- 唯一负例仍为 `I-carried-screen-0/after.visual.json`，失败项仍只有 `directions`，`pixel_success=false` 且 `safe=false`。没有因接线返工放宽已定位的相机方向门。
- `public-replay.json` 记录的重放脚本/消费者源码和 200 个实际加载文件，当前散列全部吻合。公开重放是公开数据可读性与记录一致性的证据；没有新做像素评分或原生几何 oracle。

| 作者启动 | 退出码 | ZIP 源码 | 输入 | 观测项目文件 |
| --- | ---: | ---: | ---: | ---: |
| run_001/stub | 0 | 571 | 1 | 17 |
| run_001/rework | 1 | 571 | 2 | 23 |
| run_001/legacy | 0 | 571 | 2 | 25 |
| run_001/bb | 1 | 571 | 14 | 21 |
| run_001/managed | 0 | 571 | 2 | 21 |
| run_001/os | 0 | 571 | 2 | 21 |
| run_002/rework | 0 | 571 | 2 | 25 |
| run_002/bb | 0 | 571 | 14 | 21 |

主干随后新增的 `root_replay_001/` 不属于作者原 138 文件。探针将其单独列出，没有将这些新增文件误报为作者归档遗漏，也没有将其结果混入作者统计。

## 源码版本边界和来源声明的限度

run_001 启动版本与最终交付的差别集中于 bb_probe、test_integration_preflight 及两份 API/协议文档；run_002 与最终版本只差两份文档。各次运行按自己的 ZIP 复原，不能统一以最终工作树代替失败时版本。生产 VG 的既有方向缺陷没有在本轮源码中被改掉。

当前回执 `closure/sitecustomize.py` 只记录进程退出时仍在 `sys.modules` 中、且位于项目 root 内的文件；并非全部 venv、Blender 内嵌 Python、动态库或瞬时导入的完整闭包。README 中“项目/venv 模块身份”的措辞超过该原生回执的实现范围，虽独立 public replay 另有其自身 200 个加载文件记录，不能倒推覆盖所有 Blender worker。

回执在退出时读取磁盘字节，配合启动/退出源码稳定性核对和禁写 pyc/隔离缓存，足以支持这里的普通项目来源追溯；它不是文件打开事件审计，不能声称观测了每次 import 的确切读取时刻。launch.env 只保存主动覆盖的环境项，实际执行还继承 os.environ；每个 launch 的 input_files 也没有包含 Blender/Python 二进制摘要。版本字符串和 Blender build hash 可以从日志获得，但与二进制内容摘要不是同一证据。

## 冻结建议

现有作者证据可作为此次返工的可信来源基线，不必因此重跑已通过的 CPU/原生功能。正式新进程开始前，给运行身份记录补一个小的运行时指纹：Blender 与 Pillow Python 可执行文件 SHA-256、实际 Python/NumPy/Pillow 版本及路径、GPU/backend/driver、决定设备和线程的实际环境值。保留当前项目 ZIP、输入和子进程回执机制；文案明确“项目源码及已观测导入身份”，避免承诺完整运行时闭包。

这属于下一轮正式启动的事前记录补齐，不可回填后宣称此前未记录的信息已在当时实采。资源可执行测法和缺测状态另见 `resource_review.md`；B/B 资格失败应继续由原计量门处置，来源一致性通过不能豁免它。
