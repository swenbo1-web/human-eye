# CF-S 预检证据

建议当前使用精确 TD Top-6。现有 AO 第 13 题在完整 TD 后消费有序六行，没有预 TD 发布点。条件预取实验的消费入口、基线和门槛见 [验收草案](../../../docs/CF_S_ACCEPTANCE_DRAFT.md)。草案建议在真实消费者提出提前准备需求后再冻结实验。

- `ao-case13-replay.json` 记录已验收 AO 归档第 13 题的独立公开消费者重放。两个状态各恢复 70 面归约中的原面 0–5、六项指标和第 8 帧米制世界质心。记录含输入身份及公开事实。
- `train-and-analytic.json` 记录四个预定训练样本的 598 个原面、独立 QR/SVD 比较、单指标直接选择和两个桶的可达上限。解析反例中复合 Top-6 为原面 3–8，而伸长、面积、法向、位移的单项第一分别为 0、3、1、2。解析控制还验证了同一稀疏输入可对应三个不同的目标桶，两桶预算不能覆盖所有可能。
- `manifest-*.json` 含 1,080 个主规格和 18 个诊断规格。每 seed 分别为 240/60/60 组训练、验证和结构族留出，另有 6 个诊断规格、3 个诊断组。留出和诊断只枚举规格。
- `unit.log` 为 10 项便携预检。源和产物身份见 `source-identity.json`。本次未启动 Blender、训练、选模或正式性能测量。

## 复跑

在仓库根目录运行，输出目录建议另建。

```powershell
$cfPy = 'D:\human eye\venv\Scripts\python.exe'
$cfOut = 'artifacts/cf/s_preflight_replay'
New-Item -ItemType Directory -Path $cfOut | Out-Null
foreach ($cfSplit in @('train','validation','evaluation','diagnostic')) {
    & $cfPy -B verification/cf_salience_fixtures.py --split $cfSplit --output "$cfOut/manifest-$cfSplit.json"
}
& $cfPy -B -m unittest verification.test_cf_salience_preflight -v
& $cfPy -B -c 'import json; from verification.test_cf_salience_preflight import preflight_report; print(json.dumps(preflight_report(), allow_nan=False, indent=2))'
```

AO 回放使用 `verification.ao_public_consumer.consume(schema, task, raw, package_path, reader)`。取 `artifacts/ao/refinement_supplement_001/process-1/method-R/schema.json`，再分别取其 `state-0`、`state-1` 的 `tasks.json` 第 13 题及 `13.c.json`。按原任务核对 `reduced_face_count=70`、`top_face_ids=[0,1,2,3,4,5]`、实际输出原面顺序、`position_frame=8`。每行位移为 `1/64 m`，原面 `i` 的质心在状态 `j` 为 `[i+1/8+1/64+j/8, 1/8-j/4, j/2]`。reader 可断言没有图像读取请求。
