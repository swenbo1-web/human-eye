"""Independent replay of the existing AO case-13 consumer contract."""
from hashlib import sha256
import json
import math
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from verification.ao_public_consumer import consume
from human_eye_fast.tensor_deform import compute_cross_frame_deformation_tensor

OUT = Path(__file__).with_name('consumer_probe.json')
reads = []


def read(path):
    data = path.read_bytes()
    reads.append({'path': path.relative_to(ROOT).as_posix(), 'sha256': sha256(data).hexdigest(),
                  'bytes': len(data)})
    return json.loads(data)


def no_media(path):
    raise AssertionError(f'Unexpected external/media read: {path}')


def main():
    folder = ROOT / 'artifacts/ao/refinement_supplement_001/process-1/method-R'
    schema = read(folder / 'schema.json')
    original = read(ROOT / 'artifacts/cf/s_preflight_001/ao-case13-replay.json')
    states = []
    expected_score = (1 / 64) / math.hypot(9 + 3 / 8, 6 + 3 / 8)
    for state in (0, 1):
        tasks = read(folder / f'state-{state}/tasks.json')
        task = next(row for row in tasks if row['id'] == '13')
        assert set(task) == {'id', 'question'}
        packet_path = folder / f'state-{state}/13.c.json'
        result = consume(schema, task, read(packet_path), packet_path, no_media)
        answer = result['answer']
        d = answer['deformation']
        assert result['public_consistency_passed'] is True
        assert d['reduced_face_count'] == 70
        assert d['top_face_ids'] == list(range(6))
        assert [row['original_face_id'] for row in d['faces']] == list(range(6))
        assert d['reference_frame'] == 7 and d['sample_frames'] == [8] and d['position_frame'] == 8
        assert d['object_id'] == 'O13-A'
        assert d['position_kind'] == 'face_centroid'
        assert d['peak_occurrence_frame']['available'] is False
        for i, row in enumerate(d['faces']):
            expected = {'max_principal_stretch': 1., 'min_principal_stretch': 1.,
                        'max_area_strain': 0., 'max_normal_angle_deg': 0.,
                        'max_centroid_displacement': 1 / 64, 'score': expected_score}
            for name, value in expected.items():
                assert math.isclose(row[name], value, rel_tol=1e-14, abs_tol=1e-14), (state, i, name)
            assert row['position_m'] == [i + 1 / 8 + 1 / 64 + state / 8,
                                         1 / 8 - state / 4, state / 2]
        assert answer == original['states'][state]

        # Independently re-create the specified analytic geometry, without the
        # fixture generator or private grading truth. All 70 faces translate.
        origins = np.array([(i, j, 0.) for j in range(7) for i in range(10)])
        old = (origins[:, None] + np.array([[0., 0., 0.], [.375, 0., 0.], [0., .375, 0.]])).reshape(-1, 3)
        old += [state / 8, -state / 4, state / 2]
        new = old + [1 / 64, 0., 0.]
        faces = np.arange(len(old)).reshape(-1, 3)
        metrics = compute_cross_frame_deformation_tensor((new,), faces, reference_vertices=old, top_k=6)
        assert metrics['witness_triangle_ids'].tolist() == list(range(6))
        for name, value in expected.items():
            np.testing.assert_allclose(metrics[name], value, rtol=1e-14, atol=1e-14)
        states.append({'state': state, 'question': task['question'], 'answer': answer,
                       'all_70_face_analytic_metrics_pass': True,
                       'no_early_deadline_or_prefetch_field_in_task': True})
    source_paths = ('verification/ao_public_consumer.py', 'verification/ao_fixtures.py',
                    'human_eye_fast/fast_affordance_out.py', 'human_eye_fast/tensor_deform.py')
    sources = {p: sha256((ROOT / p).read_bytes()).hexdigest() for p in source_paths}
    report = {'status': 'PASS', 'states': states, 'actual_data_reads': reads, 'source_sha256': sources,
              'limit': 'Proves the existing AO case-13 contract and these two archive states. '
                       'It is not a proof about all possible future consumers, visual salience, '
                       'per-metric extrema outside transmitted rows, or prefetch latency.'}
    OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('PASS: two AO-13 archives; 140 all-face analytic metric rows; no media reads')


if __name__ == '__main__':
    main()
