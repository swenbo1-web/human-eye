"""Independent CPU probes for current S necessity; no learning or holdout meshes."""
from pathlib import Path
from hashlib import sha256
import itertools
import json
import math
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from human_eye_fast.tensor_deform import _top_faces, compute_cross_frame_deformation_tensor
from verification.cf_salience_fixtures import bucket_ids, manifest_document


def main():
    source_root = ROOT / 'artifacts/cf/s_preflight_001'
    source = json.loads((source_root / 'source-identity.json').read_bytes())
    checked = []
    for group in ('source', 'artifacts'):
        for item in source[group].values():
            data = (ROOT / item['path']).read_bytes()
            assert len(data) == item['bytes'] and sha256(data).hexdigest() == item['sha256']
            checked.append(item['path'])
    for split in ('train', 'validation', 'evaluation', 'diagnostic'):
        current = json.loads(json.dumps(manifest_document(split=split)))
        assert current == json.loads((source_root / f'manifest-{split}.json').read_bytes())

    rng = np.random.default_rng(610306)
    selection_checks = 0
    # The independent comparator is Python's stable sort over finite IDs.
    for n in (0, 1, 5, 6, 7, 17, 70):
        for run in range(31):
            score = rng.integers(-3, 8, size=n).astype(float)
            if n and run % 3 == 0:
                score[run % n] = np.nan
            for k in (0, 1, 2, 6, 90):
                expected = sorted((i for i in range(n) if not math.isnan(score[i])), key=lambda i: (-score[i], i))[:k]
                assert _top_faces(score, k).tolist() == expected
                selection_checks += 1

    centers = np.column_stack((np.arange(9) * 3., np.zeros(9), np.zeros(9)))
    local = np.array([[-.5, -.5, 0.], [.5, -.5, 0.], [0., 1., 0.]])
    reference = (centers[:, None] + local).reshape(-1, 3)
    triangles = np.arange(27).reshape(9, 3)
    current = reference.copy()
    current[triangles[0]] = centers[0] + local * [4., .25, 1.]
    theta = math.radians(150)
    rotation = np.array([[1, 0, 0], [0, math.cos(theta), -math.sin(theta)], [0, math.sin(theta), math.cos(theta)]])
    current[triangles[1]] = centers[1] + local @ rotation.T
    current[triangles[2]] += [0, 0, 2.]
    current[triangles[3:]] = centers[3:, None] + 2 * local
    actual = compute_cross_frame_deformation_tensor((current,), triangles, reference_vertices=reference, top_k=6)
    top = actual['witness_triangle_ids'].tolist()
    assert top == list(range(3, 9))
    winners = {
        'stretch': int(np.argmax(actual['max_principal_stretch'])),
        'area': int(np.argmax(actual['max_area_strain'])),
        'normal': int(np.argmax(actual['max_normal_angle_deg'])),
        'displacement': int(np.argmax(actual['max_centroid_displacement'])),
    }
    assert winners == dict(stretch=0, area=3, normal=1, displacement=2)
    np.testing.assert_allclose(actual['max_principal_stretch'][:3], [4, 1, 1], atol=1e-14)
    np.testing.assert_allclose(actual['max_normal_angle_deg'][:3], [0, 150, 0], atol=1e-12)
    # Enumerate every six-face subset: exact same-score task already attains
    # maximum sum and overlap with its prescribed target, without a learned prior.
    maximal = sum(actual['score'][top])
    alternatives = list(itertools.combinations(range(9), 6))
    assert all(sum(actual['score'][list(ids)]) <= maximal + 1e-14 for ids in alternatives)

    centers = np.repeat([[0., 0, 0], [8., 0, 0], [16., 0, 0]], 5, axis=0)
    reference = (centers[:, None] + local).reshape(-1, 3)
    triangles = np.arange(len(reference)).reshape(-1, 3)
    assigned = bucket_ids(reference, triangles)
    hidden = [4, 9, 14]
    sampled = np.array([i for i in range(15) if i not in hidden])
    # Four equal-centroid faces per bucket are chosen first by ID; the fifth
    # can change without changing any permitted sample, reference, count or task.
    hot_buckets = []
    for face in hidden:
        current = reference.copy()
        current[triangles[face]] = centers[face] + local * [4., .25, 1.]
        assert np.array_equal(current[triangles[sampled]], reference[triangles[sampled]])
        actual = compute_cross_frame_deformation_tensor((current,), triangles, reference_vertices=reference)
        assert np.argmax(actual['max_principal_stretch']) == face
        hot_buckets.append(int(assigned[face]))
    assert len(set(hot_buckets)) == 3
    all_choices = list(itertools.combinations(sorted(set(hot_buckets)), 2))
    assert all(any(bucket not in pair for bucket in hot_buckets) for pair in all_choices)

    result = {'status': 'PASS', 'identity_files_checked': len(checked), 'manifest_splits_checked': 4,
              'selection_cases': selection_checks, 'enumerated_six_face_subsets': len(alternatives),
              'independent_analytic_composite_top6': top, 'independent_metric_winners': winners,
              'indistinguishable_hot_buckets': hot_buckets,
              'limitation': 'No latency, GPU, model fitting, evaluation geometry or blanket impossibility of learned prefetch.'}
    (Path(__file__).parent / 'need_probe.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
