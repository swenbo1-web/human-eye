# CF-S：现有 AO 消费合同独立核对

结论：**CURRENT_CONSUMER_SUPPORTS_NO_LEARNED_S**。当前已验收的 AO 第 13 题需要完整 TD 归约后的有序六行及真实指标、原面 ID、世界质心。未发现这一任务包含早于完整 TD 的消费截止、预取接口或分阶段首卡发布。该结论支持当前不新增学习 S；不等于证明未来所有提前消费场景都无收益。

## 实际复放

`consumer_probe.py` 直接读取已验收 `artifacts/ao/refinement_supplement_001/process-1/method-R/` 的 schema，以及 state-0/state-1 的 tasks.json 和 13.c.json，调用独立公开消费者 `verification.ao_public_consumer.consume`。reader 会拒绝任何媒体或额外文件读取。两个状态均通过；公开结果与本次 CF-S 交付中的 `ao-case13-replay.json` 逐字段一致。

- 任务原文要求 reduction size、ordered top six original face rows、six metrics 和 frame-8 world centroids；任务字段只有 id/question，没有 early deadline、prefetch 或阶段输出字段。
- 两个状态均 reduced_face_count=70，top_face_ids 和实际六行顺序为 0–5，reference_frame=7、sample_frames=[8]、position_frame=8，原对象 O13-A。位置语义是 face_centroid，不能冒称极值发生帧。
- 六项数值分别为 σmax=1、σmin=1、面积应变=0、世界法向角=0、位移=1/64 m、score=(1/64)/hypot(9+3/8,6+3/8)。第 i 面质心为 `[i+1/8+1/64+state/8, 1/8-state/4, state/2]`，均一致。
- 探针未使用原夹具构造器或私有真值，自行按上述解析几何重建每状态 70 面并调用生产 TD；140 个原面所有六列与解析值一致，精确同分按原 ID 选 0–5。

输出身份、源 SHA256 和完整公开结果保存在 `consumer_probe.json`。没有启动 Blender、GPU、训练或留出构造，没有写入生产代码和原档案。

## 代码数据流核对

`ao_fixtures.py` 的 `_td_case` 先调用 `compute_cross_frame_deformation_tensor` 完成全索引面归约，再建立 `DeformationFact`；case 13 固定 top_k=6，没有额外 selected_face_ids。生产 `tensor_deform._top_faces` 对已有完整 score 数组做分区选界，再按 score 降序、原 ID 升序确定完整有序 Top-K。它没有每面全排序的必要开销。

`fast_affordance_out._deformation` 从已完成 metrics 的 witness_triangle_ids 开始发布，再追加去重的明确 selected_face_ids；不执行 S 推理，不提前发未验证卡片。公开消费者的任务 13 分支读取已发布 deformation，并核对 top_face_ids 与实际前缀行对应。消费者自身不能从只发布的六行重新证明未发布 64 行的全局最优性；本次解析重建和已验收 TD 是这一事实的独立依据。

因此，在同一个已定义复合 score、同一六行预算下，精确 Top-6 的召回和顺序已经达到该任务目标。学习排序若替换真正 Top-6，会改变输出或降低该目标质量；若仍保持它，新增模型不能提高这项召回。能否改善首卡/总延迟是另一命题，本次无性能证据，不声称已证明学习必然更慢。

## 必须保留的边界

1. 当前 AO-13 是平移后全部面同分的解析任务，验证原 ID tie 和公开位置，但不能单凭两个状态证明所有非平凡热点分布。精确 Top-K 的一般性来自算法定义与相应 TD 验收，不来自这两行样本数。
2. 复合 score Top-6 不等于每个单项指标的全局极值。公开包只有发出的面，下游无法推断未发布面；新单项查询应在生产者已持有的完整数组上直接选面，并保留明确的原 ID/指标语义。AO 已支持显式附加选面，不需要以 S 分数改写原始 TD。
3. 当前消费合同没有提前阶段，不说明任何未来流式消费者、昂贵定位准备或远程读取需求都不存在。若真实新入口需要提前结果，必须另行冻结准确的预测截止、强基线和端到端成本，不能拿此次无提前需求的合同证明预取收益。
4. 不接入学习 S 是当前范围的架构选择，不可标记为“学习 S 训练/性能验收通过”，也不能把原附件的完整三学习头称为已实现。

当前审查无阻塞。建议根端按现行 AO 消费范围收口 S 的必要性判断，继续未完成的统一引擎集成。
