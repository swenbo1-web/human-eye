"""Optional parent-run native CPU diagnostic. No render, depsgraph or model calls.

Run with the same archived Blender binary, e.g. --background --factory-startup
--python <this file>. This file was prepared, not executed, by the camera reviewer.
It creates and removes only unlinked temporary camera objects. It does not edit VG,
the scorer, input fixtures, tolerances, or any existing scene objects.
"""
from pathlib import Path
import json
from hashlib import sha256

import bpy
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "artifacts/integration/preflight_001/native_002"
OUT = Path(__file__).with_suffix(".json")


def rows(matrix):
    return [list(row) for row in matrix]


def main():
    result = {"blender": bpy.app.version_string,
              "binary": bpy.app.binary_path, "samples": []}
    for case, phase in (("I-carried-screen-0", "before"),
                        ("I-carried-screen-0", "after"),
                        ("I-open-tip-0", "after")):
        path = BASE / case / (phase + ".visual.json")
        payload = path.read_bytes()
        meta = json.loads(payload)["evidence"]["metadata"]
        direction = Vector(meta["selection"]["direction"])
        archived = meta["views"]["local"]["rna"]["matrix_world"]
        quat = direction.to_track_quat("Z", "Y")
        rotation = quat.to_matrix().to_4x4()
        sample = {"case": case, "phase": phase,
                  "source_sha256": sha256(payload).hexdigest(),
                  "direction": list(direction), "quaternion": list(quat),
                  "before_assignment": rows(rotation),
                  "archived_rna_matrix": archived, "round_trips": []}
        for label, location in (("origin", (0., 0., 0.)),
                                ("archived_location", [row[3] for row in archived[:3]])):
            data = bpy.data.cameras.new("camera-review-unlinked")
            camera = bpy.data.objects.new("camera-review-unlinked", data)
            try:
                matrix = rotation.copy()
                matrix.translation = location
                camera.matrix_world = matrix
                sample["round_trips"].append({
                    "location_label": label,
                    "assigned_matrix": rows(matrix),
                    "readback_matrix": rows(camera.matrix_world.copy()),
                    "rotation_mode": camera.rotation_mode,
                    "rotation_euler": list(camera.rotation_euler),
                    "rotation_quaternion": list(camera.rotation_quaternion),
                    "scale": list(camera.scale),
                })
            finally:
                bpy.data.objects.remove(camera)
                bpy.data.cameras.remove(data)
        result["samples"].append(sample)
    OUT.write_text(json.dumps(result, indent=2, allow_nan=False), encoding="utf-8")
    print(str(OUT))


if __name__ == "__main__":
    main()
