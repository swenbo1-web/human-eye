"""CPU-only integration contract probes; no Blender, GPU, timings or runtime edits."""

from contextlib import nullcontext
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace as NS
from unittest.mock import patch

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from human_eye_fast.control import Action, BlenderControl, Goal, SetShapeKey
from human_eye_fast.cerebellar_flash import ExperienceBank
from verification import integration_reference as ref


def main():
    records = {}
    child = subprocess.run(
        [sys.executable, "-c", "import sys,json; import human_eye_fast; "
         "import human_eye_fast.control; import human_eye_fast.cerebellar_flash; "
         "print(json.dumps({'bpy': 'bpy' in sys.modules, 'gpu': 'gpu' in sys.modules}))"],
        cwd=ROOT, capture_output=True, text=True, check=True,
    )
    records["ordinary_import"] = json.loads(child.stdout)
    assert records["ordinary_import"] == {"bpy": False, "gpu": False}

    class Renderer:
        def __init__(self):
            self.prepare_count = self.observe_count = 0

        def prepare(self, meshes):
            self.prepare_count += 1
            return meshes

        def observe(self, *args, **kwargs):
            self.observe_count += 1
            return NS(png=b"placeholder", metadata={})

    renderer = Renderer()
    surface = NS(triangle_a=0, distance_m=1.0)
    readback = NS(surface=surface, target_ids=("moving", "reference"), frame_id=3,
                  observation_id="before")
    control = NS(scene_context=nullcontext,
                 _scene=NS(unit_settings=NS(scale_length=1.0)))
    rendered, ticket = ref._render(control, renderer, {}, readback, None, "F", None, False)
    records["baseline_mode_none"] = {
        "prepare_calls": renderer.prepare_count, "observe_calls": renderer.observe_count,
        "returned_image": rendered is not None, "returned_ticket": ticket is not None,
        "matches_proposed_disabled_image_contract": rendered is None,
    }
    assert renderer.observe_count == 1 and rendered is not None

    mesh = NS(world_m=np.array([[0., 0., 0.], [1., 0., 0.], [0., 1., 0.]]),
              triangles=np.array([[0, 1, 2]], dtype=np.int32))
    control.mesh_ids = ("moving", "reference", "context")
    control.bridge = NS(get=lambda key: mesh)
    reference = ref.WorldReference(1, 7, mesh.world_m.copy())
    with patch.object(ref, "_render", return_value=(None, None)), patch.object(
            ref, "compute_cross_frame_deformation_tensor", return_value=None):
        frame = ref._frame(control, renderer, reference, readback, mode=None,
                           view_arm="F", model=None, audit=False, top_k=1,
                           selected_face_ids=())
    records["baseline_object_generations"] = {
        row.object_id: row.topology_generation for row in frame.fact.objects}
    assert records["baseline_object_generations"] == {
        "moving": 7, "reference": 7, "context": 7}

    class KeyData:
        def __init__(self, coordinates):
            self.coordinates = np.asarray(coordinates, dtype=np.float32)

        def __len__(self):
            return len(self.coordinates)

        def foreach_get(self, attribute, destination):
            assert attribute == "co"
            destination[:] = self.coordinates.ravel()

    relative_coordinates = np.array([[2., 3., 4.], [5., 6., 7.]])
    delta = np.array([[.25, .5, .75], [1., .5, .25]])
    relative_key = NS(data=KeyData(relative_coordinates))
    key = NS(data=KeyData(relative_coordinates + delta), relative_key=relative_key)
    keys = NS(key_blocks={"RelKey": key})
    keys.evaluated_get = lambda graph: NS(key_blocks={"RelKey": NS(value=.125)})
    moving = NS(data=NS(shape_keys=keys))
    basis = ref.relative_basis_from_rna(moving, "RelKey")
    matrix = np.array([[1., -.3, 0., 11.], [.2, 2., .1, 13.],
                       [0., .2, .5, 17.], [0., 0., 0., 1.]])
    control._objects = (moving, None)
    control._target_ids = ("moving", "reference")
    control._goal = Goal("moving", "reference", 0., 0.)
    control._context = NS(evaluated_depsgraph_get=lambda: object())
    control._scene.unit_settings.scale_length = .001
    control.bridge = NS(get=lambda key: NS(world_from_local=matrix))
    finite = ref.finite_action(control, SetShapeKey("RelKey", .625), basis=basis)
    expected = (delta * .001) @ matrix[:3, :3].T
    np.testing.assert_array_equal(basis.local_delta_bu, delta)
    np.testing.assert_allclose(finite.basis_world_m, expected, atol=0., rtol=0.)
    np.testing.assert_allclose(finite.displacement(np.array([0, 1])), .5 * expected,
                               atol=0., rtol=0.)
    records["relative_basis_cpu"] = {
        "non_basis_relative_difference": True, "world_linear_only": True,
        "unit_applied_once": True, "evaluated_q": finite.control_before,
        "owned_readonly_local_basis": not basis.local_delta_bu.flags.writeable,
    }

    # Simulate the documented after seam failing after a successful host write.
    # This proves existing control's exception boundary; it is not a native probe.
    value = NS(value=.25)
    keys = NS(key_blocks={"k": value})
    keys.evaluated_get = lambda graph: keys
    native = BlenderControl.__new__(BlenderControl)
    native._goal = Goal("moving", "reference", 0., 0.)
    native._latest = NS(observation_id="before", surface=NS(distance_m=1.))
    native._objects = (NS(data=NS(shape_keys=keys)), None)
    native._scene = NS(unit_settings=NS(scale_length=1.))
    native._view_layer = object()
    native._context = NS(temp_override=lambda **kwargs: nullcontext(),
                         evaluated_depsgraph_get=lambda: object())

    def failed_after(*args):
        raise RuntimeError("synthetic context capture failure after target measurement")

    native._capture = failed_after
    try:
        native.execute(Action("act", "before", SetShapeKey("k", .625)), "after")
    except RuntimeError as error:
        records["post_write_seam_exception"] = {
            "host_value": value.value,
            "before_binding_invalidated": native._latest is None,
            "error_carries_outcome": hasattr(error, "outcome"),
            "note": "CPU stub demonstrates boundary; no Blender measurement is claimed",
        }
    else:
        raise AssertionError("Expected synthetic failure")
    assert value.value == .625 and native._latest is None

    # A chronological export needs no saved write count to preserve 1NN tie order.
    source = ExperienceBank((16, 5), (16, 2), (16,), capacity=4)
    feature = np.zeros((16, 5))
    for index in range(6):
        source.append_view(feature, index, True, index + 1)
    oldest = source.writes % source.capacity
    order = list(range(oldest, source.capacity)) + list(range(oldest))
    deployed = ExperienceBank((16, 5), (16, 2), (16,), capacity=4)
    for index in order:
        deployed.append(source.keys[index], source.values[index], source.known[index])
    assert source.rank(feature, np.ones((16, 5))) == deployed.rank(feature, np.ones((16, 5)))
    source.append_view(feature, 7, True, 8)
    deployed.append_view(feature, 7, True, 8)
    assert source.rank(feature, np.ones((16, 5))) == deployed.rank(feature, np.ones((16, 5)))
    records["deployment_ring_chronology_cpu"] = {"wrapped_tie_order_and_next_write_equal": True}

    records["source_sha256"] = {
        name: sha256((ROOT / name).read_bytes()).hexdigest() for name in (
            "verification/integration_reference.py", "human_eye_fast/control.py",
            "human_eye_fast/blender_resident_bridge.py", "human_eye_fast/cerebellar_flash.py")}
    destination = Path(__file__).with_name("state_probe.json")
    destination.write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(records, indent=2))


if __name__ == "__main__":
    main()
