"""Read-only CPU audit of the integration preflight provenance and fixtures."""
from collections import Counter
from difflib import unified_diff
from hashlib import sha256
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from verification.integration_fixtures import build_fixture, fixture_manifest, manifest_document
from verification.test_integration_preflight import _world_arrays, _pair_truth

BASE = ROOT / "artifacts/integration/preflight_001"
OUT = Path(__file__).parent
identity = json.loads((BASE / "source-identity.json").read_text(encoding="utf-8"))
issues = []
verified = []
for group in ("source", "artifacts"):
    for name, row in identity[group].items():
        data = (ROOT / row["path"]).read_bytes()
        actual = sha256(data).hexdigest()
        ok = actual == row["sha256"] and len(data) == row["bytes"]
        verified.append({"group": group, "name": name, "ok": ok})
        if not ok:
            issues.append({"path": row["path"], "actual": actual, "bytes": len(data)})

manifest_bytes = (json.dumps(manifest_document(), ensure_ascii=False, allow_nan=False, indent=2) + "\n").encode()
manifest_exact = manifest_bytes == (BASE / "manifest.json").read_bytes()
main = fixture_manifest()
controls = fixture_manifest(partition="control")
geometry = []
for spec in main:
    fixture = build_fixture(spec)
    stages = []
    for after, expected in ((False, fixture.expected_before_m), (True, fixture.expected_after_m)):
        actual, tolerance = _pair_truth(_world_arrays(fixture, after=after), fixture.target_ids)
        assert abs(actual - expected) <= max(tolerance, 1e-12), (spec.case_id, after, actual, expected)
        stages.append({"after": after, "actual_m": actual, "expected_m": expected})
    geometry.append({"case": spec.case_id, "stages": stages})

archive_diffs = {}
for first in sorted((BASE / "native_001-source").glob("*.py")):
    second = BASE / "native_002-source" / first.name
    if first.read_bytes() != second.read_bytes():
        archive_diffs[first.name] = "".join(unified_diff(first.read_text().splitlines(True), second.read_text().splitlines(True), fromfile="native_001", tofile="native_002"))

summary = json.loads((BASE / "native_002/summary.json").read_text())
scores = []
for path in sorted((BASE / "native_002").glob("*/*.visual.json")):
    score = json.loads(path.read_text())["score"]
    scores.append({"path": str(path.relative_to(ROOT)).replace("\\", "/"), "passed": score["passed"],
                   "pixel_success": score["pixel_success"],
                   "failed_checks": [key for key, value in score["checks"].items() if not value]})
replay = json.loads((BASE / "public-replay.json").read_text())
read_mismatches = []
for row in replay["actual_reads"]:
    data = Path(row["path"]).read_bytes()
    if sha256(data).hexdigest() != row["sha256"] or len(data) != row["bytes"]:
        read_mismatches.append(row["path"])
snapshot = ROOT / "artifacts/cf/formal_001/20261105/seal/frozen.npz"
snapshot_hash = sha256(snapshot.read_bytes()).hexdigest()
assert not issues and manifest_exact and not read_mismatches
assert snapshot_hash == summary["snapshot_sha256"] == identity["snapshot_sha256"]
assert len(main) == 24 and len(controls) == 7
assert len(scores) == 8 and sum(row["passed"] for row in scores) == 7

result = {
    "scope": "CPU only; no Blender, GPU, performance measurement, training or delivery edits",
    "source_identity_sha256": sha256((BASE / "source-identity.json").read_bytes()).hexdigest(),
    "hash_checks": {"passed": len(verified), "mismatches": issues},
    "manifest_byte_exact": manifest_exact,
    "families": dict(Counter(spec.family for spec in main)),
    "control_ids": [spec.case_id for spec in controls],
    "portable_geometry": geometry,
    "archive_diffs": archive_diffs,
    "native_case_ids": [row["case"] for row in summary["cases"]],
    "native_feedback_writes": {row["case"]: row.get("feedback_writes", [0, 0]) for row in summary["cases"]},
    "visual_scores": scores,
    "public_replay_identity_checks": {"reads": len(replay["actual_reads"]), "mismatches": read_mismatches,
                                      "packages": replay["public_packages"], "unique_PNGs": replay["unique_PNGs"]},
    "snapshot_sha256": snapshot_hash,
    "per_run_source_files": [row["Path"] for row in json.loads((BASE / "native_002-sources.json").read_text())],
    "provenance_gap": "Per-run source archive excludes RB/BC/TD/_cf_features and visual scorer/import dependencies; formal runs need a complete tracked source snapshot or transitive import inventory plus dirty patch.",
}
(OUT / "contract_probe.json").write_text(json.dumps(result, ensure_ascii=False, allow_nan=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"hash_checks": len(verified), "manifest_byte_exact": manifest_exact,
                  "portable_main_geometry": len(geometry), "source_diff_files": list(archive_diffs),
                  "native_cases": len(summary["cases"]), "visual_pass": sum(row["passed"] for row in scores),
                  "visual_total": len(scores), "public_identity_reads": len(replay["actual_reads"])}, ensure_ascii=False))
