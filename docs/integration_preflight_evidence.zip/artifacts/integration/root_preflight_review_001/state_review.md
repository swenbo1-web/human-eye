# 统一接线预检：状态、物理语义与最小 control seam 独立审查

日期：2026-11-06。审查者：integration_state_review。范围为阶段一冻结候选；未修改生产代码，未运行 Blender、GPU、训练或性能测试。

结论：一份 controller bridge/index + 同依赖图 context 回调足以完成本阶段接线，无理由扩大为通用 CaptureState 或重开 BC/VG/TD/CF 优化。坐标、实际 relative key 差分、before 位置快照的方向正确。但下面的契约空缺须在阶段二实施指令里明确冻结；现有 B 是局部能力预检，不能直接声称覆盖完整公开会话 API。

## 冻结前需要解决的契约空缺

### 1. context TOPOLOGY 更新缺少新代号入口（高优先级）

API 构造接收每对象 generations，随后允许 context_changes 声明 TOPOLOGY；observe/execute 却没有携带对应新 generation 的位置，也未定义构造 mapping 是否动态借用。AO ObjectFact 要求逐对象 topology_generation。B 的 `_frame` 更直接把每个对象写成 `reference.topology_generation`（verification/integration_reference.py:188），当前同代夹具隐藏了这个错误。

建议冻结：构造时复制逐对象代号；目标拓扑/外观保持该会话内固定；上下文仍允许原计划的 TOPOLOGY 变化，但该次请求必须显式给该对象的新代号，例如 `context_generations` 关键字，或把 context_changes 值固定为含 `changes,generation` 的记录。TOPOLOGY 的 RB 重建及 AO 新代号在同一次观察生效，前 AO 保持旧代号。不能把 moving 的 reference generation 用作所有对象的代号，也不能通过扫描/hash 自动猜代。

同时冻结掩码：每个 context 自上次捕获起的真实变更由调用者声明；NONE 只复用已拥有数据；首次登记仍完整读取。场景单位改变时，所有需要重编码的 context 必须声明 UNITS。静态 context 与随动屏的 after 掩码在 B/I 两侧完全相同。既有 probe 记录了 masks，但只断言每对象捕获次数，正式预检还须断言其值与新代号。

### 2. after 回调位置与“错误携带实测 Outcome”之间存在窗口（高优先级）

现行 control.execute 在宿主写入前撤销 `_latest`，after `_capture` 返回后才读 control_after 并构造 Outcome（human_eye_fast/control.py:129–157）。建议的 context 回调放在 `_capture` 的目标 BC 之后。如果 context 回调报错，宿主已经写入、目标 BC 也可能已经测得，Outcome 却尚未构造；当前“成像或发布失败携带已经实测 Outcome”的条款没有涵盖此窗口。B 在获得 Outcome 后的 `_frame`/encode 报错也会直接丢失返回通道（verification/integration_reference.py:255–260）。

建议冻结两个明确层次：

- 一旦 target after/control_after 已完成，后续 context、TD、VG、AO 失败均保留该次真实 Outcome，并通过具名错误的 `.outcome` 暴露；无自动重试、无回滚暗示、无替代图片。可将 after context 回调安排到 control_after/Outcome 已建立之后、同一原 graph/context 尚有效时执行，仍不增加目标 capture/BC。
- 若宿主写入已发生但目标回读本身尚未完成，不能捏造 Outcome。错误至少明确操作绑定及 `write_applied=True, outcome=None`；旧 plan/current 不再可执行，后续恢复由新的显式 observe 开始。写入前失败与该状态区分。

发布失败不能留下一个对外没有成功发布、但仍能用其 ID 执行的 current observation。资源关闭和旧 bytes 消费仍有效。这个调整是执行语义，不是重试、容错链或运行时校验扫描。

### 3. 票据生命周期尚未完整冻结（中优先级）

草案已明确单次消费、会话身份、唯一 observation ID、允许迟到 V，无需 pending registry。需要再写明 A 的迟到、reference replacement、close、新会话重开及复制的语义，避免两端实现不同。当前 B 的两个反馈 helper 无 owner/consumed 标志；action_feedback 仅比较 Action 值相等（verification/integration_reference.py:264–276），不能充当完整接口门的验证。

建议冻结：

- PreparedAction 绑定会话身份和当前成功发布的 observation；新 observe、execute 开始、replace_reference、close 撤销其可执行性。多个同观察 plan 最多执行一个，无需历史字典。
- V 票据拥有当时 16×5 特征、canonical index、selected probe rays、native stop、observation/attachment 绑定；消费者只提供同一绑定的像素判断。A 票据拥有对应前特征/尺度及实测 Outcome delta，调用者不传 delta。
- 活跃会话内迟到 V/A 可一次更新，包括已开始下一观察或替换参考之后；它们仍是当时真实样本。reference replacement 只撤销未执行 plan，不撤销已实际呈现/执行的学习证据。若主干选择 A 必须立即反馈，也须明文冻结并在 B/I 同样执行。
- close 释放资源并关闭会话；旧 bytes 仍可读，旧未消费票据不能更新已经关闭或重新创建的模型，foreign owner 与已消费票据是调用错误。身份用独立轻量 token，不必让调用者持有整个会话。
- 复制票据是否支持必须固定。建议不支持复制；若普通 shallow copy 仍可构造，则共享同一 consumption token 或让 copy 返回原票据。不要声称仅每副本一个 bool 已能拒绝所有复制重放，更不需要为此引入登记账本。

正式 B 用等价轻量 wrapper 承担同样的绑定和消费操作，尤其反馈时间极短时不能让 B 省略生产 I 的实际责任。

### 4. “静态 relative basis”缓存的有效期要明文固定（中优先级）

实际 `key.co-relative_key.co`、乘一次 RNA scale、仅乘完整世界线性部分、使用 evaluated q 的公式正确。CPU 探针对非 Basis relative key 和一般线性矩阵成立；有限变换平移不应进入差分。草案仅说“静态 RNA 基可预备”，但没有说明 authored key 坐标或 relative_key 指向在两次 observe 之间变化如何处理。固定拓扑不意味着该差分不变。

建议首版最小条款：预备 BU basis 绑定明确 moving 对象/key/relative_key 定义；该定义及 authored 坐标在其缓存期固定，仅 q 可改变。修改 key 定义时显式重新预备或建立新会话；不扫描 RNA/hash。缓存局部 BU 差分，世界 basis 按本次真实 scale/A 产生。G/L 继续要求原支持域，越域用调用者明确选择的 NONE。原 B 仅检查 basis.key_name，不能跨对象复用同名 key 的基。

## 阶段二正式测量前必须补齐的 B/API 缺口

这些不需要阶段一扩大成生产实现，但必须作为明确实施项和功能门，不能把现有 2 项 CPU/7 个 native probe 当成它们已通过。

1. `image_mode=None` 当前 B 仍执行 prepare + renderer.observe，可能生成错误 mode 的图像/元数据，且计费错误（integration_reference.py:144–167）。先直接返回无图/无 V ticket，不能把 None 转成 NATURAL。CPU stub 已确认一次 prepare/observe。
2. 无图状态应固定 enum：至少 `disabled`、`empty_surface`、`section_requires_positive_gap`，正常图为明确成功状态。沿用 AO image=null，不改既有 AO schema；将状态作为公开返回 wrapper 字段，并允许公开消费者读该字段。NoAction 原因至少区分 empty_surface、goal_reached。零距 NATURAL 有图但无搜索/V ticket；零距 SECTION 无图；零距未达到 Goal 可显式开缝并获得实际 Outcome。
3. B 的 predictor 使用小写 `none`，草案公开值为 `NONE`；统一公开拼写并让 reference-follows 控制实际经该入口执行。B 的 generation、view_layer、context masks、禁图/票据/错误语义均需跟冻结能力对应；不要求把 B 的内部 dataclass 伪装成生产 API。
4. 失败探针需注入至少 after 渲染异常和 context-after 异常，验证真实动作发生恰好一次、可得的 Outcome 未丢失、旧 plan 不可复用、可正常 close。不用补任何 fallback 或重算。
5. reference replacement、同帧不同 ID、两会话交错、迟到/重复/跨会话/close 后反馈，以及目标新代重开、context 自身拓扑更新都要有针对性状态验证。

## 已确认可以沿用的设计

- 最小 control seam 不需要第二份 bridge/index，不要求改 RB/BC 算法；明确 view_layer 及共享 graph 是必要接线参数。目标 observe 的 VERTICES|TRANSFORM|UNITS 与 after 的 VERTICES|TRANSFORM 成立的前提是动作期间单位稳定。
- 世界米制 reference 独立持有、固定世界参考下刚体运动仍可贡献 TD，是明文物理选择，不应通过去平移/逆刚体配准“修正”。建议 ReferenceFrame 构造/替换拥有一次只读快照，调用者继续修改原数组不能改变过去或当前参考；baseline 已做复制。
- 联合 AO 前保存一份 moving world positions 是必要所有权动作；TD 摘要独立拥有、before PNG/AO bytes 复用正确，没理由保存全量历史。
- VG `target_support==2` 在现行 `_select` 中确实等同原生提前返回：只有 aperture 9 taps 通过才进入 support，support 2 时立刻 return（raycast_saccade_gpu.py:199–218）。selected probe rays 与总 search rays 是不同量；当前 receipt 取 selected probe rays，符合既有 CF 学习输入，统计总 search rays 另留元数据。
- 部署数组维数与既有 CF 一致：V 线性 6/二次 21、A 线性 24/二次 300，二次项包含对角线。旧到新导出活跃环行、加载按序 append 足以保存 1NN 等距最早语义；无需把历史总 writes 当部署状态恢复。验证探针含环绕与随后一次写入。
- 部署 `allow_pickle=False`、v1 键/形状检查只在加载边界、每实例私有 weights/banks、无 Blender 普通 import 方向正确。新 loader 尚未存在；应按三个旧冻结模型逐字段验证含 unknown mask、环槽序、初始预测和一次更新。普通包导入当前 CPU 验证未加载 bpy/gpu；新增 __init__ 出口必须继续保持这条门。

## 复核证据与限制

- `state_probe.py` 与 `state_probe.json`：CPU mock 证明禁图缺口、统一 generation 的现状、relative-key/单位公式、post-write 异常边界、部署环顺序及普通 import；JSON 包含所读源码 SHA256。mock 不等同 Blender 原生控制验证，报告不据此声称 native 行为或性能通过。
- `python -m unittest verification.test_integration_preflight.IntegrationDesignPreflight -v`：现有 2 项通过（2026-11-06 本次重跑）。仅是 manifest/独立解析几何，不覆盖上述状态门。
- 已读 API/协议草案、integration_reference/fixtures/test、control、RB、CF 及 VG 关键 selection/observe。未改任何已验收算法，未改变样本或图像容差。

建议主干结论：阶段一架构方向可接受；先冻结上述具体状态条款，再派发一次有界阶段二接线实施。现有预检不足以直接冻结为“完整 B 已等价”，但不构成回头优化已验收模块的理由。
