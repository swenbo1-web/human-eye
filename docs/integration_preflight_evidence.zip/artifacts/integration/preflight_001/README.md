# 统一生产引擎接线预检

本目录验证接线设计和手工薄基线 B。生产会话 I、部署 NPZ 载入及正式性能尚待协议冻结后实施。当前固定 24 个同场景主案例、7 个单列控制。原生预检只运行主序号 0/1/20 及四个控制。

| 探针 | 真正执行 | 原生实测间隙，m | V/A 写入 |
| --- | --- | --- | --- |
| I-open-tip-0 | NATURAL 平移 | 4.799999641e-5 → 3.839989261e-5 | 2 / 0 |
| I-open-tip-1 | SECTION 父变换、.001 m/BU 的相对 key | 3.149999083e-4 → 2.677497130e-4 | 2 / 1 |
| I-carried-screen-0 | NATURAL 平移和随动遮挡 | 4.800006126e-5 → 3.839998530e-5 | 2 / 0 |
| nonbasis-key | SECTION 非 Basis 相对 key | 3.150001323e-4 → 2.677499142e-4 | 2 / 1 |
| contact-zero、empty-reference、already-reached | 按任务政策只观察 | 零距、空表面、已达目标 | 0 / 0 |

4 条动作链分别用实际宿主回读发布联合 AO，之后真实外部反馈，再进行下一次公开查询。预测和反馈阶段没有 RB 采集。真实前观察、动作回读和下一次观察各自每对象一次；后发布复用 `Outcome.after`。原生断言验证世界米制形状、见证归属、相对 key 读回及随动屏位移。预检中的参考由同场景显式捕获并拥有。更换参考、拓扑代及两个生产会话交错仍待阶段二。

八次独立 V 反馈中七次完整评分合格。随动屏后图的网格、实际像素和射线通过，局部相机方向与所选方向一个分量差约 `4.24e-6`，超过既有方向检查容差，按实写入负标签。主清单保留该例，正式口径待主干冻结。`public-replay.json` 是现有独立公开消费者使用 schema、AO 和引用 PNG 的额外回放，共接受 15 份 AO、14 幅唯一 PNG，联合包中的前观察与原前包一致。此回放核验公开语义，与独立方向评分分别报告。

`native_001.log` 记录首轮的联合 AO 编码失败。原因是夹具容差为 NumPy float32。保留失败版本源码和输入身份后，仅将两个夹具容差强制为相同数值的 Python float，随后固定同样例复跑。`native_002` 记录第二轮原生、评分、公开数据与媒体。模型由验证侧显式加载一个原封存快照，本次没有生产 NPZ 加载验证。

## 复跑

仓库根执行。每次使用新的 `--out` 子目录。

```powershell
$cfPy = 'D:\human eye\venv\Scripts\python.exe'
$cfBlender = 'C:\Program Files\Blender Foundation\Blender 5.2\blender.exe'
$cfOut = 'artifacts/integration/preflight_001'
& $cfPy -B -m unittest verification.test_integration_preflight -v
& $cfPy -B verification/integration_fixtures.py --output "$cfOut/manifest-replay.json"
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:OPENBLAS_NUM_THREADS = '1'
$env:OMP_NUM_THREADS = '1'
$env:MKL_NUM_THREADS = '1'
& $cfBlender --background --factory-startup --disable-autoexec --threads 1 --python-exit-code 1 --python verification/test_integration_preflight.py -- --out "$cfOut/native_replay" --snapshot artifacts/cf/formal_001/20261105/seal/frozen.npz --pillow-python $cfPy
```

公开重放用 venv 导入 `verification.ao_public_consumer.Reader` 和 `normalize`。对每个 `native_replay/*/*.ao.json` 调用 `normalize(schema, raw, package_path, reader)`，只读同一输出目录的 schema 与引用 PNG。存在联合包的场景比较其首观察与 standalone before，核对后观察和 next 的新 ID 及同帧绑定。归档输入身份、源码及产物摘要见 `source-identity.json`。
