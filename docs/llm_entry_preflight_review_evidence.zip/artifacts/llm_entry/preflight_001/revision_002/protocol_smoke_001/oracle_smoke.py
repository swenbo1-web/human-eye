"""Exercise the formal quality checker using only mathematical fixtures."""

from collections import Counter
from copy import deepcopy
import json
from pathlib import Path
import sys

import numpy as np


sys.path.insert(0, str(Path(__file__).resolve().parents[5]))
from verification.llm_task_reference import build_episode, case_manifest, check_numeric


def mathematical_snapshot(episode):
    fixture = episode.fixture
    world_matrices = {}
    snapshot = {}
    for spec in (*fixture.parents, *fixture.meshes):
        matrix = spec.local_matrix_m.copy()
        if spec.parent_id is not None:
            matrix = world_matrices[spec.parent_id] @ matrix
        world_matrices[spec.object_id] = matrix
        blender_matrix = matrix.copy()
        blender_matrix[:3, 3] /= fixture.scale_length
        value = {"matrix_world_bu": blender_matrix}
        if hasattr(spec, "triangles"):
            value["world_vertices_m"] = spec.vertices_local_m @ matrix[:3, :3].T + matrix[:3, 3]
            value["triangles"] = spec.triangles.copy()
        snapshot[spec.object_id] = value
    return snapshot


def task_states(episode, steps):
    before = mathematical_snapshot(episode)
    moving, reference = episode.fixture.target_ids
    first = before[moving]["world_vertices_m"][0]
    second = before[reference]["world_vertices_m"][0]
    initial_gap_m = float(np.linalg.norm(second - first))
    target_m = episode.target_gap_m
    after = deepcopy(before)
    if steps:
        delta = (second - first) * ((1 - target_m / initial_gap_m) / steps)
        for _ in range(steps):
            after[moving]["world_vertices_m"] += delta
            after[moving]["matrix_world_bu"][:3, 3] += delta / episode.fixture.scale_length
    terminal_gap_m = float(np.linalg.norm(second - after[moving]["world_vertices_m"][0]))
    receipt = {
        "moving_id": moving, "reference_id": reference, "unit": "m",
        "target_gap_m": target_m, "tolerance_m": episode.tolerance_m,
        "before_gap_m": initial_gap_m, "after_gap_m": terminal_gap_m if steps else None,
        "error_m": abs(terminal_gap_m - target_m), "goal_reached": True,
        "write_status": "written" if steps else "not_written",
        "actual_delta_world_m": (after[moving]["world_vertices_m"][0] - first).tolist() if steps else None,
    }
    return before, after, receipt


def expect_rejection(case, arm, writes, states):
    try:
        check_numeric(case, *states, arm=arm, writes=writes)
    except AssertionError:
        return
    raise AssertionError(f"Checker incorrectly accepted {case.case.case_id} {arm=} {writes=}")


def main():
    cases = case_manifest()
    counts = Counter(case.family for case in cases)
    assert counts == {"dense-nonconvex": 4, "transformed": 4, "occluded-visual": 4, "control": 2}, counts
    assert len({case.case_id for case in cases}) == 14
    rows = []
    for case in cases:
        episode = build_episode(case)
        writes = 0 if case.case_id == "C02" else 1
        for arm, steps in (("I", writes), ("N", writes * 3)):
            states = task_states(episode, steps)
            result = check_numeric(episode, *states, arm=arm, writes=steps)
            rows.append({"id": case.case_id, "arm": arm, "writes": steps, **result})

    simple = build_episode(cases[-2])
    no_write = build_episode(cases[-1])
    good = task_states(simple, 1)
    negatives = {
        "candidate_multiple_writes": (simple, "I", 2, task_states(simple, 2)),
        "native_multiple_writes_on_already_reached": (no_write, "N", 2, task_states(no_write, 2)),
        "candidate_write_on_already_reached": (no_write, "I", 1, task_states(no_write, 1)),
        "claimed_zero_writes_on_changed_geometry": (simple, "N", 0, good),
        "unrecognized_arm": (simple, "other", 1, good),
        "boolean_write_count": (simple, "I", True, good),
    }
    for label, key, value in (
        ("reported_target_changed", "target_gap_m", simple.target_gap_m * 2),
        ("reported_error_changed", "error_m", simple.tolerance_m),
        ("reported_distance_not_actual", "after_gap_m", simple.initial_gap_m),
    ):
        before, after, receipt = good
        negatives[label] = (simple, "N", 1, (before, after, {**receipt, key: value}))
    before, after, receipt = deepcopy(good)
    after["reference"]["matrix_world_bu"][0, 3] += 0.01
    negatives["reference_transform_changed"] = (simple, "N", 1, (before, after, receipt))
    before, after, receipt = deepcopy(good)
    for snapshot in (before, after):
        vertices = snapshot["moving"]["triangles"]
        vertices[vertices == 0] = 1
    negatives["tip_not_on_surface"] = (simple, "N", 1, (before, after, receipt))

    for arguments in negatives.values():
        expect_rejection(*arguments)
    print(json.dumps({"kind": "portable_math_only", "family_counts": counts,
                      "accepted": rows, "rejected": list(negatives)}, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
