"""Read the archived native receipts without re-running Blender or inferring RNA."""

import base64
from hashlib import sha256
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[3]))

from verification.test_raycast_saccade_gpu import decode_png


def _load(path):
    return json.loads(path.read_bytes())


def _hash(raw):
    return sha256(raw).hexdigest()


def _audit_case(folder, job, output):
    raw = (folder / "responses.jsonl").read_bytes()
    report = _load(folder / "client.json")
    responses = [json.loads(line) for line in raw.splitlines()]
    tools = [row["result"] for row in responses if "content" in row.get("result", {})]
    assert tools == report["results"], folder
    assert all("structuredContent" not in result and result["content"][0]["type"] == "text"
               for result in tools), folder
    assert all(not result["isError"] for result in tools), folder
    fields = [json.loads(result["content"][0]["text"]) for result in tools]
    run_index = next(index for index, receipt in enumerate(fields) if receipt.get("task") == "close_gap")
    receipt = fields[run_index]
    witness = next(receipt for receipt in fields if receipt.get("evidence") == "witness")
    assert witness["observation_id"] == receipt["observation_id"]
    measured = receipt["after_gap_m"] if receipt["write_status"] == "written" else receipt["before_gap_m"]
    assert witness["gap_m"] == measured and abs(measured - receipt["target_gap_m"]) <= receipt["tolerance_m"]
    relay = report["stdio_relay"]
    assert relay["exit_code"] == 0 and relay["stdin_eof"] and relay["stdout_eof"], folder
    assert job["status"] == "failed" and 'client["client_pid"] == child.pid' in job["traceback"]
    blocks = tools[run_index]["content"]
    png_record = None
    if len(blocks) == 2:
        image = receipt["image"]
        assert image["mode"] == "SECTION" and image["scene_object_ids"] == ["moving", "reference", "screen", "overhang"]
        points = np.asarray([witness["moving_point_m"], witness["reference_point_m"]])
        np.testing.assert_allclose(image["section"]["point_m"], points.mean(axis=0), atol=8e-9, rtol=0)
        assert blocks[1]["mimeType"] == "image/png" and blocks[1]["type"] == "image"
        png = base64.b64decode(blocks[1]["data"], validate=True)
        pixels = decode_png(png)
        interior = pixels[45:465, :512, :3].astype(np.int16)
        color = np.rint(255 * np.asarray([.22, .78, .32])).astype(np.int16)
        green = int(np.count_nonzero(np.max(np.abs(interior - color), axis=2) <= 3))
        assert green > 25
        (output / "received-terminal.png").write_bytes(png)
        png_record = {"bytes": len(png), "sha256": _hash(png), "width": pixels.shape[1],
                      "height": pixels.shape[0], "screen_pixels": green, "mode": image["mode"]}
    else:
        assert len(blocks) == 1 and "image" not in receipt
    assert not (folder / "after-rna.json").exists()
    return {"case": job["name"], "archived_response_sha256": _hash(raw), "relay": relay,
            "receipt": receipt, "witness": witness, "received_png": png_record,
            "independent_after_rna": "missing; preexisting PID assertion failed before capture"}


def main():
    source = HERE / "native_001"
    output = HERE / "native_001_receipt_audit"
    output.mkdir()
    summary = {"scope": "offline audit of raw native wire output", "native_qualification": "failed",
               "source_manifest_sha256": _hash((source / "manifest.json").read_bytes()),
               "audit_source_sha256": _hash(Path(__file__).read_bytes()), "modes": {}}
    for mode in ("background", "gui"):
        path = source / mode / "result"
        report = _load(path / "summary.json")
        summary["modes"][mode] = {
            "pid": report["pid"], "status": report["status"],
            "hidden_windows": report.get("hidden_windows"), "hidden_windows_at_end": report.get("hidden_windows_at_end"),
            "cases": [_audit_case(path / job["folder"], job, output) for job in report["jobs"]],
        }
    (output / "summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(output / "summary.json")


if __name__ == "__main__":
    main()
