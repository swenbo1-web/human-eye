"""Register and execute the bounded LLM entry preflight."""

from argparse import ArgumentParser
from hashlib import sha256
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
from zipfile import ZIP_DEFLATED, ZipFile


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
BASE = "37c672c"
PYTHON = Path(r"D:\human eye\venv\Scripts\python.exe")
BLENDER = Path(r"C:\Program Files\Blender Foundation\Blender 5.2\blender.exe")
DEPLOYMENT = ROOT / "artifacts/integration/production_functional_001/deployments/20261105.npz"
DEPLOYMENT_SHA = "8375c84b871e89388774fb229175db2134b4e4568343dd9e85011366844bb19e"
PROTOCOL = "2025-06-18"
ENV = {name: "1" for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                             "BLIS_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS",
                             "PYTHONDONTWRITEBYTECODE")}
ENV_KEYS = (*ENV, "PYTHONPYCACHEPREFIX", "PYTHONPATH", "PYTHONHASHSEED",
            "OMP_DYNAMIC", "MKL_DYNAMIC", "CUDA_VISIBLE_DEVICES", "BLENDER_GPU_BACKEND")
sys.path.insert(0, str(ROOT))

from artifacts.integration.method_diagnostic_001.runtime_identity import identity, write_json


def _relative(path):
    return path.resolve().relative_to(ROOT).as_posix()


def _engine_sources():
    tracked = subprocess.check_output(["git", "ls-tree", "-r", "--name-only", BASE, "human_eye_fast"],
                                      cwd=ROOT, text=True).splitlines()
    paths = [path for path in tracked if path.endswith(".py")]
    if len(paths) != 17:
        raise RuntimeError("Expected the 17 frozen production engine files")
    subprocess.run(["git", "diff", "--exit-code", BASE, "--", *paths], cwd=ROOT, check=True)
    return {ROOT / path for path in paths}


def _source_bytes(phase):
    paths = _engine_sources()
    paths.update((Path(__file__), ROOT / "docs/LLM_ENTRY_ARCHITECTURE.md",
                  ROOT / "docs/LLM_ENTRY_WORK_ORDER.md", ROOT / "human_eye_llm_stdio.py",
                  ROOT / "human_eye_fast/blender_llm_bridge.py",
                  ROOT / "artifacts/integration/method_diagnostic_001/runtime_identity.py"))
    if phase == "transport":
        paths.add(ROOT / "verification/test_llm_transport.py")
    else:
        paths.update((ROOT / "human_eye_fast/llm_entry.py", ROOT / "docs/LLM_ENTRY_API_DRAFT.md"))
        if phase == "entry":
            paths.add(ROOT / "verification/test_llm_entry.py")
        else:
            paths.update(ROOT.glob("verification/**/*.py"))
            paths.update(path for path in HERE.glob("*.py"))
            paths.update((ROOT / "examples/blender_llm_entry.py", ROOT / "docs/LLM_ENTRY_PROTOCOL_DRAFT.md"))
    return {_relative(path): path.read_bytes() for path in sorted(paths)}


def _hash_bytes(data):
    return sha256(data).hexdigest()


def _manifest(phase, out):
    engine_checked = _source_bytes(phase)
    exe = {"portable_python": identity(PYTHON), "launcher_python": identity(sys.executable)}
    inputs = {}
    cases = None
    if phase == "native":
        from verification.llm_entry_fixtures import manifest_document

        exe["blender"] = identity(BLENDER)
        inputs[_relative(DEPLOYMENT)] = identity(DEPLOYMENT)
        if inputs[_relative(DEPLOYMENT)]["sha256"] != DEPLOYMENT_SHA:
            raise RuntimeError("Unexpected deployment bytes")
        cases = manifest_document()
        options = []
        for mode in ("background", "gui"):
            argv = [str(BLENDER), "--factory-startup", "--disable-autoexec", "--threads", "1",
                    "--python-exit-code", "1", "--python", str(HERE / "native_worker.py"), "--",
                    "--mode", mode, "--out", str(out / mode / "result"), "--python", str(PYTHON),
                    "--deployment", str(DEPLOYMENT)]
            if mode == "background":
                argv.insert(1, "--background")
            options.append((mode, argv))
    else:
        options = [(phase, [str(PYTHON), "-B", "-m", "unittest", "-v",
                           f"verification.test_llm_{phase}"])]
    jobs = []
    for name, argv in options:
        folder = out / name
        overrides = {**ENV, "PYTHONPYCACHEPREFIX": str(folder / "isolated-pycache")}
        effective = {key: ({**os.environ, **overrides}).get(key) for key in ENV_KEYS}
        jobs.append({"name": name, "argv": argv, "environment_overrides": overrides,
                     "environment_effective": effective, "timeout_s": 180 if name in ("background", "gui") else 60,
                     "windows_startup_hidden": name == "gui"})
    manifest = {
        "scope": phase, "work_order_commit": BASE,
        "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        "profile": {"mcp_protocol": None if phase == "transport" else PROTOCOL,
                    "transport": "Opaque pipe/TCP bytes" if phase == "transport" else "UTF-8 line JSON-RPC through opaque pipe/TCP relay",
                    "target_host": "installed Codex CLI 0.167.0-alpha.3.2; official stdio support and static version literals",
                    "actual_host_registration_or_model_image_delivery": "UNVERIFIED",
                    "scope": "transport qualification only; no public tool contract frozen" if phase == "transport" else
                    "provisional tool candidate"},
        "runtime": {"executables": exe, "launcher_python_version": sys.version,
                    "platform": platform.platform(), "processor": platform.processor(), "logical_cpus": os.cpu_count()},
        "input_files": inputs, "cases": cases, "jobs": jobs,
        "sources": {name: _hash_bytes(data) for name, data in engine_checked.items()},
    }
    return manifest, engine_checked


def _launch(job, out, manifest_path, manifest, original):
    folder = out / job["name"]
    folder.mkdir()
    env = {**os.environ, **job["environment_overrides"]}
    if {key: env.get(key) for key in ENV_KEYS} != job["environment_effective"]:
        raise RuntimeError("Environment changed after registration")
    if original != _source_bytes(manifest["scope"]):
        raise RuntimeError("Source changed after registration")
    write_json(folder / "launch.json", {**job, "manifest": identity(manifest_path)})
    kwargs = {}
    if job["windows_startup_hidden"]:
        startup = subprocess.STARTUPINFO()
        startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startup.wShowWindow = subprocess.SW_HIDE
        kwargs["startupinfo"] = startup
    print(f"Starting {job['name']}", flush=True)
    timeout = False
    with (folder / "worker.log").open("wb") as log:
        try:
            child = subprocess.run(job["argv"], cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT,
                                   timeout=job["timeout_s"], check=False, **kwargs)
            exit_code = child.returncode
        except subprocess.TimeoutExpired:
            exit_code, timeout = None, True
    stable_inputs = all(identity(ROOT / name) == item for name, item in manifest["input_files"].items())
    summary_path = folder / "result/summary.json"
    worker = json.loads(summary_path.read_bytes()) if summary_path.is_file() else {}
    native = job["name"] in ("background", "gui")
    import_mismatches = []
    observed_path = folder / "result/project-imports.json"
    if observed_path.is_file():
        observed = json.loads(observed_path.read_bytes())
        import_mismatches = [name for name, sha in observed["paths"].items()
                             if manifest["sources"].get(name) != sha]
    result = {"job": job["name"], "exit_code": exit_code, "timeout": timeout,
              "stable_sources": original == _source_bytes(manifest["scope"]), "stable_inputs": stable_inputs,
              "native_report_status": worker.get("status") if native else None,
              "native_report_jobs": len(worker.get("jobs", [])) if native else None,
              "observed_project_import_mismatches": import_mismatches}
    result["passed"] = bool(exit_code == 0 and result["stable_sources"] and stable_inputs
                            and not import_mismatches and (not native or
                                worker.get("status") == "passed" and 0 < len(worker.get("jobs", [])) <= 6))
    write_json(folder / "process.json", result)
    print(json.dumps(result), flush=True)
    return result


def run(phase, attempt):
    out = HERE / f"{phase}_{attempt:03d}"
    if out.exists():
        raise FileExistsError(out)
    manifest, sources = _manifest(phase, out)
    out.mkdir()
    with ZipFile(out / "sources.zip", "x", compression=ZIP_DEFLATED) as archive:
        for path, data in sources.items():
            archive.writestr(path, data)
    manifest_path = out / "manifest.json"
    write_json(manifest_path, manifest)
    print(f"Registered {phase}: {identity(manifest_path)['sha256']}", flush=True)
    results = [_launch(job, out, manifest_path, manifest, sources) for job in manifest["jobs"]]
    passed = all(result["passed"] for result in results)
    write_json(out / "summary.json", {"phase": phase, "passed": passed, "processes": results})
    return 0 if passed else 1


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("transport", "entry", "native"))
    parser.add_argument("--attempt", type=int, default=1)
    args = parser.parse_args()
    if not 1 <= args.attempt <= 999 or (args.attempt != 1 and args.phase != "transport"):
        parser.error("Only transport can use a numbered retry from 2 through 999")
    sys.exit(run(args.phase, args.attempt))
