"""Bounded Blender qualification and its independent external MCP client."""

from argparse import ArgumentParser
from base64 import b64decode
from contextlib import contextmanager, ExitStack
from dataclasses import replace
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
import traceback
from types import SimpleNamespace
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
NO_WINDOW = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0

from artifacts.integration.method_diagnostic_001.runtime_identity import clock_anchor, identity, native_fingerprint
from human_eye_fast.llm_entry import LLMEntry, PROTOCOL_VERSION
from verification.llm_entry_fixtures import EPISODES, NATIVE_TASKS, case, command_document
from verification.test_integration_preflight import _write


def _json(path):
    return json.loads(path.read_bytes())


def _digest(data):
    return sha256(data).hexdigest()


class _Rpc:
    def __init__(self, relay, folder):
        self.relay = relay
        self.requests = (folder / "requests.jsonl").open("xb")
        self.responses = (folder / "responses.jsonl").open("xb")
        self.index = 0

    def close(self):
        self.requests.close()
        self.responses.close()

    def send(self, method, params=None, *, notify=False):
        frame = {"jsonrpc": "2.0", "method": method, "params": params or {}}
        if not notify:
            self.index += 1
            frame["id"] = self.index
        raw = json.dumps(frame, separators=(",", ":"), allow_nan=False).encode("utf-8") + b"\n"
        self.requests.write(raw)
        self.requests.flush()
        self.relay.stdin.write(raw)
        self.relay.stdin.flush()
        if notify:
            return None
        line = self.relay.stdout.readline()
        assert line.endswith(b"\n"), "Missing complete MCP response line"
        self.responses.write(line)
        self.responses.flush()
        response = json.loads(line)
        assert response.get("jsonrpc") == "2.0" and response.get("id") == self.index, response
        assert "error" not in response, response
        return response["result"]

    def tool(self, name, **arguments):
        result = self.send("tools/call", {"name": name, "arguments": arguments})
        assert not result.get("isError"), result
        return result


def _publication(result, expected_status, schema=None, *, expected_schema=False, prior=None):
    from verification.test_fast_affordance_out import decode_public

    meta, content = result["structuredContent"], result["content"]
    assert meta["status"] == expected_status and meta["executable"] is True, meta
    assert meta["schema"] is expected_schema
    assert content[0]["type"] == "text"
    ao = content[0]["text"].encode("utf-8")
    offset = 1
    if expected_schema:
        assert content[1]["type"] == "text"
        current_schema = json.loads(content[1]["text"])
        assert schema is None or schema == current_schema
        schema = current_schema
        offset = 2
    images = {}
    for binding, item in zip(meta["images"], content[offset:], strict=True):
        assert item["type"] == "image" and item["mimeType"] == "image/png"
        key = binding["attachment_key"]
        assert key == f"{binding['observation_id']}.png" and key not in images
        png = b64decode(item["data"], validate=True)
        assert png.startswith(b"\x89PNG\r\n\x1a\n")
        images[key] = png
    package = decode_public(ao, schema)
    assert package["observations"][-1]["observation_id"] == meta["observation_id"]
    assert package["observations"][-1]["frame_id"] == meta["frame_id"]
    if prior is not None:
        key = f"{prior.meta['observation_id']}.png"
        assert meta["before_ref"] == {"attachment_key": key, "observation_id": prior.meta["observation_id"],
                                      "delivery": "prior_result"}
        assert key not in images and key in prior.images
        bound_images = {key: prior.images[key], **images}
    else:
        assert "before_ref" not in meta
        bound_images = images
    assert list(bound_images) == [obs["image"]["path"] for obs in package["observations"]
                                  if obs["image"] is not None]
    assert meta["image_status"] == "rendered" if images else meta["image_status"] != "rendered"
    return SimpleNamespace(meta=meta, package=package, ao=ao, images=images, bound_images=bound_images,
                           schema=schema)


def _score(folder, phase, publication):
    from verification.cf_visual_acceptance import score_png

    key = f"{publication.meta['observation_id']}.png"
    if key not in publication.images:
        assert not (folder / f"{phase}.audit.json").exists()
        return None
    audit = _json(folder / f"{phase}.audit.json")
    png = publication.images[key]
    assert _digest(png) == audit["native_png_sha256"]
    verdict = score_png(png, audit["evidence"])
    assert verdict["png_sha256"] == _digest(png)
    _write(folder / f"{phase}.score.json", verdict)
    return verdict


def _view_arg(publication, score, episode):
    ident = publication.meta["observation_id"]
    if episode.view_arm != "L":
        assert publication.meta["v_pending"] == []
        return {}
    assert publication.meta["v_pending"] == [ident]
    assert score is not None
    return {"view_feedback": {"observation_id": ident, "pixel_pass": score["pixel_success"]}}


def _capture_publication(folder, name, publication):
    (folder / f"{name}.ao.json").write_bytes(publication.ao)
    return {"id": publication.meta["observation_id"], "ao_sha256": _digest(publication.ao),
            "png_sha256": {key: _digest(png) for key, png in publication.bound_images.items()}}


def _external_workflow(rpc, folder, episode, command):
    init = rpc.send("initialize", {"protocolVersion": PROTOCOL_VERSION, "capabilities": {},
                                   "clientInfo": {"name": "native-qualification", "version": "1"}})
    assert init["protocolVersion"] == PROTOCOL_VERSION
    rpc.send("notifications/initialized", notify=True)
    listing = rpc.send("tools/list")
    assert [tool["name"] for tool in listing["tools"]] == ["eye_open", "eye_step", "eye_close"]
    before = _publication(rpc.tool("eye_open"), "opened", expected_schema=True)
    assert before.meta["defaults"]["view_arm"] == episode.view_arm
    assert before.meta["defaults"]["predictor"] == episode.predictor
    assert not before.meta["a_pending"] and before.package["outcome"] is None
    first_score = _score(folder, "before", before)
    if first_score is not None:
        assert first_score["passed"]
    (folder / "schema.json").write_text(json.dumps(before.schema, allow_nan=False), encoding="utf-8")
    before_id = before.meta["observation_id"]
    report = {"before": _capture_publication(folder, "before", before), "close_method": episode.close_method}
    args = {"from": before_id, "command": command}
    if episode.terminal:
        terminal = rpc.tool("eye_step", op="act", **args)
        meta = terminal["structuredContent"]
        assert meta["status"] == "no_action" and meta["reason"] == episode.terminal, meta
        assert meta["observation_id"] == before_id and terminal["content"] == []
        recovered = _publication(rpc.tool("eye_step", op="read"), "read", before.schema)
        assert recovered.ao == before.ao and recovered.images == before.images
        report["terminal"] = meta
    else:
        response = rpc.tool("eye_step", op="predict", **args)
        predicted = response["structuredContent"]
        assert predicted["status"] == "predicted" and predicted["observation_id"] == before_id
        assert predicted["plan_id"] and response["content"] == []
        acted = rpc.tool("eye_step", op="act", **args, **_view_arg(before, first_score, episode))
        after = _publication(acted, "acted", before.schema, prior=before)
        assert not after.meta["a_pending"]
        assert after.package["outcome"] is not None
        after_score = _score(folder, "after", after)
        assert after_score is not None and after_score["passed"]
        recovered = _publication(rpc.tool("eye_step", op="read", schema=True), "read",
                                 before.schema, expected_schema=True)
        assert recovered.ao == after.ao and recovered.images == after.bound_images
        observed = rpc.tool("eye_step", op="observe", **_view_arg(after, after_score, episode))
        following = _publication(observed, "observed", before.schema)
        next_score = _score(folder, "next", following)
        assert next_score is not None and next_score["passed"]
        assert following.package["outcome"] is None
        report.update(predict=predicted, after=_capture_publication(folder, "after", after),
                      next=_capture_publication(folder, "next", following))
    if episode.close_method == "close":
        closed = rpc.tool("eye_close")["structuredContent"]
        assert closed["status"] == "closed" and closed["executable"] is False
    return report


def _external_client(config_path):
    config = _json(config_path)
    folder = config_path.parent
    episode = EPISODES[config["episode"]]
    with (folder / "relay.stderr").open("xb") as stderr:
        with subprocess.Popen(
            [sys.executable, "-B", str(ROOT / "human_eye_llm_stdio.py"), "--port", str(config["port"])],
            cwd=ROOT, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr,
            creationflags=NO_WINDOW,
        ) as relay:
            rpc = _Rpc(relay, folder)
            try:
                report = _external_workflow(rpc, folder, episode, config["command"])
                relay.stdin.close()
                assert relay.stdout.read(1) == b"", "Unexpected transport stdout after final response"
                assert relay.wait(timeout=8) == 0
                report["stdio_relay"] = {"pid": relay.pid, "exit_code": relay.returncode,
                                        "request_bytes": rpc.requests.tell(), "response_bytes": rpc.responses.tell()}
                _write(folder / "client.json", report)
            finally:
                rpc.close()
                if relay.poll() is None:
                    relay.kill()


@contextmanager
def _owned_gui_scene(frame, scale):
    import bpy

    assert not bpy.app.background and bpy.context.window is not None
    window = bpy.context.window
    old_scene = window.scene
    scene = bpy.data.scenes.new("LLM entry verification fixture")
    scene.unit_settings.system = "METRIC"
    scene.unit_settings.scale_length = scale
    scene.frame_set(frame)
    window.scene = scene
    try:
        yield scene
    finally:
        window.scene = old_scene
        objects = list(scene.objects)
        meshes = [obj.data for obj in objects if obj.type == "MESH"]
        bpy.data.scenes.remove(scene)
        for obj in objects:
            bpy.data.objects.remove(obj)
        for mesh in meshes:
            bpy.data.meshes.remove(mesh)


def _owned_window():
    from ctypes import WinDLL, WINFUNCTYPE, byref, create_unicode_buffer, wintypes

    user = WinDLL("user32", use_last_error=True)
    callback_type = WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    user.EnumWindows.argtypes = (callback_type, wintypes.LPARAM)
    user.GetWindowThreadProcessId.argtypes = (wintypes.HWND, wintypes.LPDWORD)
    user.GetClassNameW.argtypes = (wintypes.HWND, wintypes.LPWSTR, ctypes_int := wintypes.INT)
    user.IsWindowVisible.argtypes = (wintypes.HWND,)
    user.ShowWindow.argtypes = (wintypes.HWND, ctypes_int)
    windows = []

    @callback_type
    def collect(handle, _):
        process = wintypes.DWORD()
        thread = user.GetWindowThreadProcessId(handle, byref(process))
        name = create_unicode_buffer(256)
        if process.value == os.getpid() and user.GetClassNameW(handle, name, len(name)):
            if name.value.startswith("GHOST"):
                visible = bool(user.IsWindowVisible(handle))
                if visible:
                    user.ShowWindow(handle, 0)
                windows.append({"hwnd": handle, "thread_id": thread, "pid": process.value, "class": name.value,
                                "visible_on_first_observation": visible,
                                "visible": bool(user.IsWindowVisible(handle))})
        return True

    assert user.EnumWindows(collect, 0) and windows and not any(row["visible"] for row in windows), windows
    return windows


class _AuditedEntry:
    def __init__(self, binding, phase, renders, folder, receipts):
        self.entry = LLMEntry(binding)
        self.phase = phase
        self.renders = renders
        self.folder = folder
        self.receipts = receipts
        receipts["connections"] += 1

    def handle_line(self, line):
        from verification.test_blender_radical_session import _model_digest

        assert threading.current_thread() is threading.main_thread()
        request = json.loads(line)
        params = request.get("params", {})
        phase = {"eye_open": "before", "eye_close": "close"}.get(params.get("name"))
        if params.get("name") == "eye_step":
            op = params["arguments"]["op"]
            phase = {"act": "after", "observe": "next"}.get(op, op)
        self.phase.name = phase
        reply = self.entry.handle_line(line)
        if phase in self.renders:
            rendered, evidence = self.renders[phase]
            _write(self.folder / f"{phase}.audit.json",
                   {"native_png_sha256": _digest(rendered.png), "evidence": evidence})
        if phase == "next" and self.phase.model is not None:
            self.receipts["model_state"] = _model_digest(self.phase.model)
        return reply

    def close(self):
        assert threading.current_thread() is threading.main_thread()
        self.entry.close()
        self.receipts["transport_closes"] += 1


def _binding(episode, fixture, scene, objects, deployment):
    from examples.blender_llm_entry import binding_for, capture_current_reference
    from human_eye_fast import CaptureChange, Goal
    from verification.integration_fixtures import _formal_plan
    from verification.test_blender_radical_session import _changes

    plan = _formal_plan(fixture.spec)
    generations = plan["before"]["topology_generations"]
    goal = Goal(*fixture.target_ids, fixture.goal_distance_m, fixture.goal_tolerance_m)
    moving = fixture.target_ids[0]
    layer = scene.view_layers[0]
    reference = capture_current_reference(scene, layer, moving, objects[moving], generations[moving])
    key = fixture.command.key_name if fixture.command is not None else None
    observation_number = 0

    def changes(operation):
        nonlocal observation_number
        observation_number += 1
        name = {1: "before", 2: "after_readback_and_publication", 3: "next"}[observation_number]
        assert operation == ("execute" if observation_number == 2 else "observe")
        return _changes(plan[name], CaptureChange)

    return binding_for(scene, layer, objects, goal, generations, reference=reference, changes=changes,
                       image_mode=fixture.mode, view_arm=episode.view_arm, predictor=episode.predictor,
                       deployment=deployment if episode.view_arm != "F" else None,
                       shape_keys=() if key is None else (key,)), generations


def _wire_run(opts, folder, episode, fixture, binding, phase, renders, receipts):
    from human_eye_fast.blender_llm_bridge import start

    bridge = start(lambda: _AuditedEntry(binding, phase, renders, folder, receipts))
    child = None
    try:
        config_path = folder / "client-config.json"
        _write(config_path, {"episode": episode.name, "port": bridge.address[1],
                             "command": command_document(fixture.command)})
        with (folder / "client.stderr").open("xb") as stderr:
            child = subprocess.Popen(
                [str(opts.python), "-B", str(Path(__file__).resolve()), "--client", str(config_path)],
                cwd=ROOT, stdout=stderr, stderr=stderr, creationflags=NO_WINDOW,
            )
            deadline = time.monotonic() + 40
            while child.poll() is None or not receipts["transport_closes"]:
                if child.poll() not in (None, 0):
                    raise RuntimeError(f"Independent MCP client exited {child.returncode}")
                if time.monotonic() > deadline:
                    raise TimeoutError("Independent MCP client or its EOF close did not finish")
                yield bridge
            receipts["client_pid"] = child.pid
            assert receipts["connections"] == receipts["transport_closes"] == 1
            assert len(receipts["sessions"]) == 1 and receipts["sessions"][0]._closed
    finally:
        if child is not None and child.poll() is None:
            child.kill()
            child.wait(timeout=5)
        bridge.stop()
    report = _json(folder / "client.json")
    return report, _json(folder / "schema.json")


def _reference_run(opts, folder, episode, fixture, binding, phase, renders, wire):
    from human_eye_fast.fast_affordance_out import public_schema
    from verification.cf_visual_acceptance import PillowWorker
    from verification.llm_entry_reference import reference_observe, reference_step
    from verification.test_blender_radical_session import _model_digest
    from verification.test_integration_preflight import _command

    schema = public_schema()
    records = {}

    def save(name, result, scorer):
        png = result.attachments[f"{result.observation_id}.png"]
        rendered, evidence = renders[name]
        assert png == rendered.png
        score = scorer.score(png, evidence)
        assert score["passed"] and score["png_sha256"] == _digest(png)
        _write(folder / f"{name}.audit.json", {"native_png_sha256": _digest(png), "evidence": evidence})
        _write(folder / f"{name}.score.json", score)
        (folder / f"{name}.ao.json").write_bytes(result.ao_bytes)
        records[name] = {"id": result.observation_id, "ao_sha256": _digest(result.ao_bytes),
                         "png_sha256": {key: _digest(png) for key, png in result.attachments.items()}}
        return score["pixel_success"]

    with binding.open_session() as session, PillowWorker(opts.python) as scorer:
        phase.name = "before"
        before = reference_observe(session, binding, wire["before"]["id"])
        first_pass = save("before", before, scorer)
        phase.name = "predict"
        command = _command(fixture.command)
        predicted = session.predict_action(before.observation_id, wire["predict"]["plan_id"],
                                           command, predictor=episode.predictor)
        phase.name = "after"
        action_id = f"a{int(predicted.action_id[1:]) + 1}"
        after = reference_step(session, binding, before, command, action_id, wire["after"]["id"],
                               pixel_pass=first_pass)
        after_pass = save("after", after, scorer)
        phase.name = "next"
        following = reference_observe(session, binding, wire["next"]["id"], prior=after,
                                      pixel_pass=after_pass)
        save("next", following, scorer)
        model = _model_digest(phase.model)
    return {**records, "predict": {"predicted_delta_m": predicted.predicted_delta_m},
            "model_state": model}, schema


def _native_validation(folder, episode, fixture, generations, schema, report, before_meshes, after_meshes,
                       renders, captures, model_calls, receipts):
    import numpy as np
    from verification.test_blender_radical_session import _verify_meshes, _verify_public
    from verification.test_fast_affordance_out import decode_public
    from verification.test_integration_preflight import _pair_truth

    def check(name, snapshot, expected):
        package = decode_public((folder / f"{name}.ao.json").read_bytes(), schema)
        ident = report[name]["id"]
        if expected is None:
            row = package["observations"][-1]
            assert row["observation_id"] == ident and row["image"] is None
            assert row["clearance"]["status"] == "empty_surface"
            assert row["clearance"]["witness_a"] is None and row["clearance"]["witness_b"] is None
        else:
            row = _verify_public(package, snapshot, fixture, expected,
                                 {"observation_id": ident, "frame_id": fixture.spec.frame_id, "td_top_k": 12,
                                  "attachment_key_if_applicable": f"{ident}.png"}, generations)
        return package, row

    _verify_meshes(before_meshes, fixture)
    _, before = check("before", before_meshes, fixture.expected_before_m)
    _verify_meshes(after_meshes, fixture, after=not episode.terminal)
    if episode.terminal:
        assert set(renders) == ({"before"} if episode.terminal == "GOAL_REACHED" else set())
        for name, (vertices, _) in before_meshes.items():
            np.testing.assert_array_equal(vertices, after_meshes[name][0])
        assert not model_calls and {row["phase"] for row in captures} == {"before"}
        return {"terminal_reason": episode.terminal, "mesh_unchanged": True}

    joined, after = check("after", after_meshes, fixture.expected_after_m)
    _, following = check("next", after_meshes, fixture.expected_after_m)
    assert joined["observations"][0] == before
    assert after["clearance"] == following["clearance"] and after["deformation"] == following["deformation"]
    outcome = joined["outcome"]
    assert outcome["before_observation_id"] == report["before"]["id"]
    assert outcome["after_observation_id"] == report["after"]["id"]
    assert outcome["distance_before_m"] == before["clearance"]["distance_m"]
    assert outcome["distance_after_m"] == after["clearance"]["distance_m"]
    measured = outcome["distance_after_m"] - outcome["distance_before_m"]
    assert measured == outcome["measured_delta_m"]
    assert not outcome["goal_reached"]
    analytic = [_pair_truth(meshes, fixture.target_ids)[0] for meshes in (before_meshes, after_meshes)]
    assert abs(measured - (analytic[1] - analytic[0])) <= 2 * fixture.host_tolerance_m
    if episode.predictor != "L":
        assert outcome["predicted_delta_m"] == report["predict"]["predicted_delta_m"]
    spec = fixture.command
    assert outcome["command"]["kind"] == spec.kind
    if spec.kind == "set_shape_key":
        assert outcome["command"]["key_name"] == spec.key_name
        assert outcome["control_before"] == spec.control_before and outcome["control_after"] == spec.target_value
    else:
        np.testing.assert_allclose(outcome["command"]["delta_world_m"], spec.delta_world_m, rtol=0, atol=0)
        np.testing.assert_allclose(np.subtract(outcome["control_after"], outcome["control_before"]),
                                   spec.delta_world_m, rtol=0, atol=fixture.host_tolerance_m)

    assert set(renders) == {"before", "after", "next"}
    assert len({row["bridge"] for row in captures}) == 1
    for name in renders:
        assert [row["object"] for row in captures if row["phase"] == name] == list(generations)
    model_state = receipts.get("model_state", report.get("model_state"))
    learning = [event for event in model_calls if event["method"].startswith("learn_")]
    if episode.view_arm == "L":
        assert [row["method"] for row in learning] == ["learn_view",
                                                       *(["learn_action"] if episode.predictor == "L" else []),
                                                       "learn_view"]
        assert [row["phase"] for row in learning] == ["after", *(["after"] if episode.predictor == "L" else []),
                                                     "next"]
        assert model_state["writes"] == {"v": 242, "a": 240 + (episode.predictor == "L")}
        if episode.predictor == "L":
            assert [row["method"] for row in model_calls if row["phase"] == "after"] == [
                "learn_view", "predict_delta", "rank_view", "learn_action"]
    else:
        assert not model_calls and model_state is None
    return {"measured_delta_m": measured, "predicted_delta_m": outcome["predicted_delta_m"],
            "independent_distances_m": analytic, "control_before": outcome["control_before"],
            "control_after": outcome["control_after"], "model_state": model_state}


def _run_job(opts, folder, name, role, deployment, previous):
    from verification import test_blender_control
    from verification.test_blender_radical_session import _audit
    from verification.test_integration_preflight import _materialize, _native_snapshot

    episode = EPISODES[name]
    fixture = case(episode)
    phase = SimpleNamespace(name=None, model=None)
    receipts = {"connections": 0, "transport_closes": 0, "sessions": []}
    with ExitStack() as stack:
        if opts.mode == "gui":
            stack.enter_context(patch.object(test_blender_control, "_scene", _owned_gui_scene))
        scene, objects = stack.enter_context(_materialize(fixture))
        before = _native_snapshot(scene, objects)
        binding, generations = _binding(episode, fixture, scene, objects, deployment)
        renders, captures, calls = stack.enter_context(_audit(scene, objects, phase))
        if role == "I":
            open_session = binding.open_session

            def register():
                session = open_session()
                receipts["sessions"].append(session)
                return session

            report, schema = yield from _wire_run(opts, folder, episode, fixture,
                                                   replace(binding, open_session=register), phase, renders, receipts)
        else:
            report, schema = _reference_run(opts, folder, episode, fixture, binding, phase, renders, previous[name])
        after = _native_snapshot(scene, objects)
        native = _native_validation(folder, episode, fixture, generations, schema, report, before, after,
                                    renders, captures, calls, receipts)
        if role == "B":
            for key in ("before", "after", "next"):
                assert report[key] == previous[name][key], key
            assert native == previous[name]["native"]
        else:
            previous[name] = {**report, "native": native}
        _write(folder / "native.json", {"geometry": native, "model_calls": calls, "captures": captures,
                                        "publications": report,
                                        "transport": {key: val for key, val in receipts.items() if key != "sessions"}})
    return native


def _run_all(opts, report):
    from human_eye_fast.cf_deployment import load_cf_deployment

    deployment = load_cf_deployment(opts.deployment)
    previous = {}
    for index, (name, role) in enumerate(NATIVE_TASKS[opts.mode], 1):
        folder = opts.out / f"{index:02d}-{name}-{role}"
        folder.mkdir()
        job = {"episode": name, "role": role, "folder": folder.name}
        report["jobs"].append(job)
        try:
            job["native"] = yield from _run_job(opts, folder, name, role, deployment, previous)
            job["status"] = "passed"
        except Exception:
            job.update(status="failed", traceback=traceback.format_exc())
            _write(folder / "failure.json", job)
        yield None


def _native_main(opts):
    import bpy

    anchor = clock_anchor()
    report = {"mode": opts.mode, "pid": os.getpid(), "status": "running", "clock_anchor": anchor,
              "blender_background": bpy.app.background, "jobs": []}
    opts.out.mkdir(parents=True, exist_ok=True)
    jobs = _run_all(opts, report)
    started = False

    def finish():
        try:
            report["runtime"] = native_fingerprint(anchor)
            report["runtime"]["imported_project_files"] = {
                name: identity(module.__file__) for name, module in sorted(sys.modules.items())
                if name.startswith(("human_eye_fast", "verification.llm_entry", "examples.blender_llm_entry"))
                and getattr(module, "__file__", None)
            }
        except Exception:
            report["runtime_error"] = traceback.format_exc()
        report["status"] = "passed" if (len(report["jobs"]) == len(NATIVE_TASKS[opts.mode])
                                         and all(job["status"] == "passed" for job in report["jobs"])
                                         and "fatal" not in report and "runtime_error" not in report) else "failed"
        _write(opts.out / "summary.json", report)

    def advance():
        nonlocal started
        assert threading.current_thread() is threading.main_thread()
        if not started:
            assert bpy.app.background == (opts.mode == "background")
            if opts.mode == "gui":
                assert bpy.context.window is not None
                report["hidden_windows"] = _owned_window()
            report["driver"] = "bpy.app.timers" if opts.mode == "gui" else "background main-thread pump"
            started = True
        return next(jobs)

    if opts.mode == "background":
        try:
            while True:
                bridge = advance()
                if bridge is not None:
                    bridge.pump()
                time.sleep(.002)
        except StopIteration:
            pass
        except Exception:
            report["fatal"] = traceback.format_exc()
            jobs.close()
        finish()
        if report["status"] != "passed":
            raise RuntimeError(f"Native qualification failed; see {opts.out / 'summary.json'}")
        return

    def tick():
        try:
            advance()
            return .01
        except StopIteration:
            pass
        except Exception:
            report["fatal"] = traceback.format_exc()
            jobs.close()
        finish()
        bpy.ops.wm.quit_blender()
        return None

    bpy.app.timers.register(tick, first_interval=.2)


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--mode", choices=tuple(NATIVE_TASKS))
    parser.add_argument("--out", type=Path)
    parser.add_argument("--python", type=Path)
    parser.add_argument("--deployment", type=Path)
    parser.add_argument("--client", type=Path)
    arguments = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else sys.argv[1:]
    opts = parser.parse_args(arguments)
    if opts.client is not None:
        _external_client(opts.client)
    elif None not in (opts.mode, opts.out, opts.python, opts.deployment):
        _native_main(opts)
    else:
        parser.error("Provide a client config or all native qualification arguments")
