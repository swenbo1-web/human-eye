本轮可接收为E0通道/回执的CPU资格，以及E1固定对象 `close_gap` 的数值协议候选；不能接收为原生功能、视觉判定或真实LLM收益通过。当前14个案例保留为既有数值/坐标草案，主模型协议暂不冻结。按主干收口决定，正式前仅替换其中至少两D例为edge-edge或vertex-face interior最近点，保持总样本数与平移动作域；另补实际证据入口、V评分及合理N实装，不重优内核。

本次仅离线读取、哈希和小型数学计算，无Blender/GPU/模型/性能运行。独立 [qualification_probe.py](<D:/human eye/human-eye/artifacts/llm_entry/implementation_root_001/qualification_probe.py>) exit 0，结果在 [qualification_probe.json](<D:/human eye/human-eye/artifacts/llm_entry/implementation_root_001/qualification_probe.json>)；未导入任何 `human_eye_fast` 模块，未修改作者源或旧记录。

**身份与执行证据。**

| 检查 | 独立观察 | 能证明的范围 |
| --- | --- | --- |
| delivery绑定 | 38个源SHA、10个证据SHA及38成员sources.zip逐项一致；zip SHA为b8e04f01…fafde3e。读到的当前文件也匹配 | 标识这次交付，不把文件一致冒充模型使用成功 |
| cpu_001→002 | 两个29成员zip只有 `test_local_tasks.py` 改动；全文差精确等于 `_outcome(`→`_make_outcome(`。原3 fail＋1 error、exit 1仍在，第二次24/24、exit 0 | unittest实例的 `_outcome` 遮蔽同名helper；没有伴随生产修改或删测试刷通过 |
| CPU范围 | `test_local_tasks`替换bpy和BlenderControl，`test_llm_entry`使用StubTaskSession；直接模拟实际delta与预期delta不同、测量未达标和未知写入 | 真实/预期不混写、无自动重试、结果关联及按需证据合同有覆盖；不能证明真实setter、depsgraph、主线程或最终RNA |
| CPU图像 | 测试PNG为8字节签名＋“图像证据”UTF-8，共20 B；Pillow独立解码抛UnidentifiedImageError | `assert_png`只证明base64还原同一占位bytes、缓存与结果绑定，不是有效PNG、更非可见性证据 |
| transport | 已读transport_003原日志：5/5、真实TCP/pipe测试通过；本轮不重复边界测试 | stdio/socket转发资格，不等于真实Blender事件循环、MCP宿主或模型实际收图 |
| protocol_smoke | 4源zip、登记、输出4项SHA/尺寸全部一致；原件含14案例、28合成正例、11反例，两个命令exit 0 | `task_states`直接按已知端点构造before/after，I一次、N三次均为数学数组操作；不是28次真实双臂动作或N效率基线 |

CPU启动argv与环境和manifest一致，runner检查执行前后源/解释器并只保存稳定性布尔值；没有CPU实际导入模块逐项receipt。因此本次核验是“归档源＋启动＋日志＋现文件”，不额外宣称历史加载集合独立可重建。此限制不否定单元测试结论，也无需为CPU合同资格再搭大型来源系统。[Mock位置](<D:/human eye/human-eye/verification/test_local_tasks.py:38>) [占位PNG](<D:/human eye/human-eye/verification/test_llm_entry.py:16>) [smoke构造](<D:/human eye/human-eye/artifacts/llm_entry/preflight_001/revision_002/protocol_smoke_001/oracle_smoke.py:35>) [runner](<D:/human eye/human-eye/artifacts/llm_entry/preflight_001/revision_002/run_preflight.py:128>)

交付manifest本身明确记载原生正式0/5、缺最终独立RNA、宿主/模型unverified、收益unmeasured。本审查不将其工具回包或数学smoke重新标为原生通过；原生失败原因及修正后入口资格由父端另审。[delivery manifest](<D:/human eye/human-eye/artifacts/llm_entry/preflight_001/revision_002/delivery_001/manifest.json:1>)

**数值oracle不是候选自证，但成立范围窄。**

`check_numeric`没有读取BC、AO或Outcome，使用所有实际顶点沿一个单位轴的支撑平面距离作为下界、两个确在表面上的顶点距离作为上界。三角面在线性投影上的极值出现在顶点，因而上下界同值时能认证全表面距离；不是仅检查一对预期顶点。平移长度 `d0-target` 达到距离函数的1-Lipschitz下界，端点见证又达到目标，所以这些已分离几何的最短平移论证成立。[oracle:121](<D:/human eye/human-eye/verification/llm_task_reference.py:121>) [结果核验:142](<D:/human eye/human-eye/verification/llm_task_reference.py:142>)

我独立重算14个recipe几何的前后支撑上下界，全在原容差内；再让一个非tip顶点侵入间隙，同时保留“正确tip和回执”，oracle拒绝，说明不是只相信已知tip。所有这些仍是数学数组。实际执行时，before/after必须由独立evaluated RNA读出；顶点顺序、世界米换算和实际对象/父级对应都要来自本次场景。候选返回图/数值不能喂回oracle当输入。终态快照不能发现“写错对象后又恢复”，协议已要求独立写入审计，该路径必须实际接通。[独立RNA和写入约定](<D:/human eye/human-eye/docs/LLM_TASK_PROTOCOL_DRAFT.md:32>)

这个oracle共享场景recipe是可接受的：它验证可计算边界，不调用候选算法；但当前smoke的after与expected同源生成，只验证检查器正负分支，不验证Blender导入/单位/写回。真实输入冻结和RNA前后读回是不可由现有28正例替代的最后一段。

**任务复杂度与模型有效性。**

D族细分的是两个目标mesh，不是堆无关物体；T族父矩阵、非均匀变换和单位换算是有效工程负载；V族遮挡物实际服务于图像问题。这些样本不是纯数量作弊。[协议:28](<D:/human eye/human-eye/docs/LLM_TASK_PROTOCOL_DRAFT.md:28>)

但D的凹入只发生在背面环，细分不改变最近端及其支撑方向；14例均通过同一tip分离轴认证。物体已指定、目标固定、最短平移一次可解，未测语义目标选择、多解规划、表面切换后的再决策或一般三维编辑。应将成绩准确命名为“固定对象间隙任务自动化/稠密网格与坐标负载”。正式清单用至少两例真实edge-edge或vertex-face interior替换现D中的两例，缓解全靠同类顶点见证的覆盖不足；不增加样本数、不增加旋转或shape动作。[recipe:59](<D:/human eye/human-eye/verification/llm_task_reference.py:59>) [端点轴:105](<D:/human eye/human-eye/verification/llm_task_reference.py:105>)

候选最小回执、不默认带AO/全部schema、必要时一次返回终态图的方向合理；单元测试确认未请求图时不渲染，计划与实际delta分别公开。但“对LLM有效”仍要求模型实际使用这些公开结果正确答题，CPU判断字段存在不能替代。若合理N也用一个通用helper一次求解，模型往返优势可能不存在；应如实保留，不把smoke中人为N三步当事实。

**公平性已经具备的部分。** 协议允许N使用NumPy/BVH、预置通用helper、常驻函数、缓存和批处理，一次完成测量/求解/写入/核验，不强制模型逐步调度；两臂同初态、写域、图像能力与开发预算，冷启动和helper加载计入。I一次写入是自身实现合同，N允许多次而C02双方零写，未给N附加人为劣势。这些可冻结。[N能力](<D:/human eye/human-eye/docs/LLM_TASK_PROTOCOL_DRAFT.md:42>) [计量](<D:/human eye/human-eye/docs/LLM_TASK_PROTOCOL_DRAFT.md:44>)

180秒失败截断、12配对全部保留、每族均值和p95不得劣化，有利于避免仅挑成功样本。n=12的最近秩p95就是最大值，协议已正确限定。两臂的“首次正确答案事件”应离线从当时已交付内容识别，评分不在线给任何一臂暗示或补数。[指标](<D:/human eye/human-eye/docs/LLM_TASK_PROTOCOL_DRAFT.md:48>)

**正式开跑前只补三项，不扩大模块。**

1. **完成同数量清单及真实证据/N入口。** 保留当前草案原件，替换两D案例后先用独立oracle证明最近点在边/面内部，并认证全表面距离；可用全顶点支撑下界与经独立线段/面内参数证明的表面见证上界，不能仍写死0号顶点或调用候选BC作真值。随后固定最终提示、公开输入、两臂工具/helper、实际执行命令、RNA读回及写入审计。N只能用实际公开几何通用求解，不用隐藏轴、固定索引或target fraction；I同样不能从oracle取答案。不增加正式次数、不借此重开算法优化。
2. **将V的文字设想变成确定评分。** 目前没有各V实际相机/切面、5样点坐标、有效画布规则、色标容差、正负真值及评分实现；CPU占位PNG不填补此缺项。保留本次已生成PNG及原metadata；后续生成时同步保存实际相机、切面与面板数据，不能通过重渲染为旧图补证。`至少3/5样点可判定`还未定义样点意见混合时如何给标签，应固定“至少3个同意可见/同意遮挡”或另一明确规则。SECTION的ray cast须作用于实际显示的切开几何，不能用未切场景射线代替GPU裁切；depth对象和PNG色彩需同时支持结论。现有V例须至少保留有证据的可见与遮挡判定，不能四例均unknown却称视觉有效；做不到就保留该项未验证，不降低阈值。N使用同等模式与视图条件，不能强制更差相机；若允许各自选图，则逐臂根据实际图评分，不能套用另一臂标签。[V草案](<D:/human eye/human-eye/docs/LLM_TASK_PROTOCOL_DRAFT.md:36>)
3. **固定不可检验指标的出口。** “N多轮子集”由N实际轮数选择，只能是条件诊断，不代表全12例轮数减半；同时报告全部12配对真实轮数，若N全单轮则该减半主张不成立。文字token若宿主不提供，保持未测，不能用字节/固定图片token补算；在首份成绩前明确E1总通过是否要求该门，或将其独立标为未验子项，不能结果出来后改成可选。2倍时间目标可以先冻结，真实模型未跑仍为无成绩。[轮数/token门](<D:/human eye/human-eye/docs/LLM_TASK_PROTOCOL_DRAFT.md:54>)

可冻结：局部平移任务定义、固定14例总数及控制项、合理N能力、全任务计时原则；当前tip数学oracle只对应当前归档，不能自动覆盖替换后的边/面内见证。当前数值/坐标草案继续保留。主模型协议暂不冻结：需落实两D替换及独立oracle、实际RNA/写入审计和N通用helper、V标签/评分、缺测指标出口。保持原型失败和未测状态；补齐这三个接缝后按一次事前固定的真实任务比较决定E1，不重开内核或扩大到E2。
