"""Independent offline qualification audit; no Blender, GPU, model, or timing.

Writes only qualification_probe.json beside this file.  Mathematical scenes
remain in memory and must not be confused with evaluated Blender RNA evidence.
"""
from pathlib import Path
import ast
import copy
import hashlib
import io
import json
import re
import sys
import zipfile

ROOT = Path('D:/human eye/human-eye')
ARCHIVE = ROOT / 'artifacts/llm_entry/preflight_001/revision_002'
OUT = Path(__file__).with_suffix('.json')
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT))

def sha(blob):
    return hashlib.sha256(blob).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def record(path):
    blob = path.read_bytes()
    return {'path': str(path), 'bytes': len(blob), 'sha256': sha(blob)}

errors = []
delivery = read(ARCHIVE / 'delivery_001/manifest.json')
records = [record(ARCHIVE / 'delivery_001/manifest.json')]
for group in ('source_sha256', 'evidence_sha256'):
    for name, expected in delivery[group].items():
        path = ROOT / name
        current = sha(path.read_bytes()) if path.is_file() else None
        records.append({'group': group, 'path': name, 'expected': expected, 'actual': current})
        if current != expected:
            errors.append({'identity': name, 'group': group})
with zipfile.ZipFile(ARCHIVE / 'delivery_001/sources.zip') as z:
    assert set(z.namelist()) == set(delivery['source_sha256'])
    for name, expected in delivery['source_sha256'].items():
        assert sha(z.read(name)) == expected, name
assert sha((ARCHIVE / 'delivery_001/sources.zip').read_bytes()) == delivery['sources_zip_sha256']

cpu = []
archives = {}
for case in ('cpu_001', 'cpu_002'):
    folder = ARCHIVE / case
    manifest = read(folder / 'manifest.json')
    with zipfile.ZipFile(folder / 'sources.zip') as z:
        assert set(z.namelist()) == set(manifest['sources'])
        archives[case] = {name: z.read(name) for name in z.namelist()}
        for name, expected in manifest['sources'].items():
            assert sha(z.read(name)) == expected, (case, name)
    log = (folder / 'cpu/worker.log').read_text(encoding='utf-8-sig')
    process = read(folder / 'cpu/process.json')
    launch = read(folder / 'cpu/launch.json')
    assert launch['manifest']['sha256'] == sha((folder / 'manifest.json').read_bytes())
    assert launch['argv'] == manifest['jobs'][0]['argv']
    assert launch['environment_effective'] == manifest['jobs'][0]['environment_effective']
    cpu.append({'case': case, 'source_count': len(manifest['sources']),
                'exit_code': process['exit_code'], 'reported_stable': process['sources_stable'],
                'log_test_count': int(re.search(r'Ran (\d+) tests', log)[1]),
                'log_terminal': log.strip().splitlines()[-1],
                'log_hash': sha(log.encode()),
                'runtime_limit': 'No actual imported-module file receipt in this CPU archive; '
                                 'source/executable stability is runner boolean plus source snapshots.'})
changed = [n for n in archives['cpu_001'] if archives['cpu_001'][n] != archives['cpu_002'][n]]
assert changed == ['verification/test_local_tasks.py'], changed
old = archives['cpu_001'][changed[0]].decode()
new = archives['cpu_002'][changed[0]].decode()
assert old.replace('_outcome(', '_make_outcome(') == new

smoke = ARCHIVE / 'protocol_smoke_001'
prereg = read(smoke / 'preregistration.json')
execution = read(smoke / 'execution.json')
assert execution['preregistration_sha256'] == sha((smoke / 'preregistration.json').read_bytes())
assert execution['sources_zip_sha256'] == sha((smoke / 'sources.zip').read_bytes())
with zipfile.ZipFile(smoke / 'sources.zip') as z:
    for item in prereg['sources']:
        assert sha(z.read(Path(item['path']).name)) == item['sha256']
for item in execution['outputs']:
    blob = (smoke / item['path']).read_bytes()
    assert (len(blob), sha(blob)) == (item['bytes'], item['sha256'])
stored = read(smoke / 'oracle_smoke.json')
assert len(stored['accepted']) == 28 and len(stored['rejected']) == 11

# Inspect placeholder bytes without importing test_llm_entry or the engine.
source = archives['cpu_002']['verification/test_llm_entry.py'].decode()
assign = next(n for n in ast.parse(source).body
              if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'PNG' for t in n.targets))
assert ast.unparse(assign.value) == "b'\\x89PNG\\r\\n\\x1a\\n' + '图像证据'.encode('utf-8')"
png = b'\x89PNG\r\n\x1a\n' + '图像证据'.encode('utf-8')
from PIL import Image
try:
    Image.open(io.BytesIO(png)).verify()
    png_result = {'valid_png': True}
except Exception as exc:
    png_result = {'valid_png': False, 'exception': type(exc).__name__, 'bytes': len(png)}

import numpy as np
from verification.llm_task_reference import build_episode, case_manifest, check_numeric

def math_snapshot(episode):
    result, matrices = {}, {}
    for item in (*episode.fixture.parents, *episode.fixture.meshes):
        world = item.local_matrix_m.copy()
        if item.parent_id is not None:
            world = matrices[item.parent_id] @ world
        matrices[item.object_id] = world
        matrix_bu = world.copy()
        matrix_bu[:3, 3] /= episode.fixture.scale_length
        row = {'matrix_world_bu': matrix_bu}
        if hasattr(item, 'triangles'):
            row['world_vertices_m'] = item.vertices_local_m @ world[:3, :3].T + world[:3, 3]
            row['triangles'] = item.triangles.copy()
        result[item.object_id] = row
    return result

math_rows = []
for case in case_manifest():
    episode = build_episode(case)
    snap = math_snapshot(episode)
    a, b = [snap[k]['world_vertices_m'] for k in episode.fixture.target_ids]
    unit = episode.axis
    # Independent support gap formula and endpoint-pair upper bound.
    lower = float(np.min(b @ unit) - np.max(a @ unit))
    upper = float(np.linalg.norm(b[0] - a[0]))
    gap_error = max(abs(lower - episode.initial_gap_m), abs(upper - episode.initial_gap_m))
    assert gap_error <= episode.tolerance_m, case.case_id
    delta = (episode.initial_gap_m - episode.target_gap_m) * unit
    lower_after = float(np.min(b @ unit) - np.max((a + delta) @ unit))
    upper_after = float(np.linalg.norm(b[0] - a[0] - delta))
    assert max(abs(lower_after - episode.target_gap_m), abs(upper_after - episode.target_gap_m)) <= episode.tolerance_m
    math_rows.append({'case': case.case_id, 'family': case.family, 'initial_bounds': [lower, upper],
                     'after_bounds': [lower_after, upper_after], 'target_m': episode.target_gap_m,
                     'tolerance_m': episode.tolerance_m, 'vertex_counts': [len(a), len(b)],
                     'note': 'Synthetic recipe geometry, not evaluated RNA or candidate execution.'})

# One additional targeted semantic negative: a non-tip vertex invades the gap.
episode = build_episode(case_manifest()[-2])
before = math_snapshot(episode)
moving, reference = episode.fixture.target_ids
delta = (episode.initial_gap_m - episode.target_gap_m) * episode.axis
after = copy.deepcopy(before)
after[moving]['world_vertices_m'] += delta
after[moving]['matrix_world_bu'][:3, 3] += delta / episode.fixture.scale_length
receipt = {'moving_id': moving, 'reference_id': reference, 'unit': 'm',
           'target_gap_m': episode.target_gap_m, 'tolerance_m': episode.tolerance_m,
           'before_gap_m': episode.initial_gap_m, 'after_gap_m': episode.target_gap_m,
           'error_m': 0., 'goal_reached': True, 'write_status': 'written',
           'actual_delta_world_m': delta.tolist()}
check_numeric(episode, before, after, receipt, arm='N', writes=1)
before[moving]['world_vertices_m'][1] = before[moving]['world_vertices_m'][0] + episode.axis * episode.initial_gap_m * .75
after[moving]['world_vertices_m'][1] = before[moving]['world_vertices_m'][1] + delta
try:
    check_numeric(episode, before, after, receipt, arm='N', writes=1)
except AssertionError:
    invaded_vertex_rejected = True
else:
    invaded_vertex_rejected = False
assert invaded_vertex_rejected

result = {'scope': 'CPU read/hash and mathematical checks only; no imported engine, Blender, model, or performance trial.',
          'identity_errors': errors, 'delivery_source_count': len(delivery['source_sha256']),
          'delivery_evidence_count': len(delivery['evidence_sha256']), 'file_checks': records,
          'cpu': cpu, 'cpu_change': {'paths': changed, 'only_helper_rename': True},
          'protocol_smoke': {'stored_accepted': len(stored['accepted']), 'stored_rejected': len(stored['rejected']),
                             'exit_codes': execution['exit_codes'], 'scope': execution['scope']},
          'mock_image': png_result, 'independent_math_intervals': math_rows,
          'additional_semantic_negative': {'intruding_non_tip_vertex_rejected': invaded_vertex_rejected},
          'loaded_engine_modules': [n for n in sys.modules if n == 'human_eye_fast' or n.startswith('human_eye_fast.')],
          'not_evidence_for': ['actual RNA', 'native helper quality', 'visual labels', 'actual MCP host', 'LLM benefit']}
OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'output': str(OUT), 'identity_errors': errors, 'cpu': cpu,
                  'math_cases': len(math_rows), 'mock_image': png_result,
                  'intruding_vertex_rejected': invaded_vertex_rejected,
                  'engine_imports': result['loaded_engine_modules']}, ensure_ascii=False))
