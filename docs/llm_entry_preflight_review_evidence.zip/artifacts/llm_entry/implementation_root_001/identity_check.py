"""Independent identity audit of a delivered candidate, without running Blender."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
DELIVERY = ROOT / 'artifacts/llm_entry/preflight_001/revision_002/delivery_001'
sha = lambda data: hashlib.sha256(data).hexdigest()
manifest_bytes = (DELIVERY / 'manifest.json').read_bytes()
manifest = json.loads(manifest_bytes)
assert sha(manifest_bytes) == '4b4da2c2825aef8b84d1bc6f2f2b1dc4b4fac7f5b33ed0ebab624bb25316f56c'
archive = DELIVERY / 'sources.zip'
assert sha(archive.read_bytes()) == manifest['sources_zip_sha256']
current = {p: sha((ROOT / p).read_bytes()) == expected for p, expected in manifest['source_sha256'].items()}
evidence = {p: sha((ROOT / p).read_bytes()) == expected for p, expected in manifest['evidence_sha256'].items()}
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    frozen = {p: sha(z.read(p)) == expected for p, expected in manifest['source_sha256'].items()}
engine = json.loads((ROOT / 'docs/radical_acceptance_engine_v1.json').read_bytes())
unchanged = {p: sha((ROOT / p).read_bytes()) == row['sha256'] for p, row in engine['production_sources'].items()}
spec = sha((ROOT / 'docs/RADICAL_V1_SPEC_REVIEW.md').read_bytes())
result = dict(delivery_manifest_sha256=sha(manifest_bytes), sources_zip_sha256=sha(archive.read_bytes()),
              current_sources=current, frozen_sources=frozen, evidence=evidence,
              engine_unchanged=unchanged, user_spec_sha256=spec,
              passed=all((*current.values(), *frozen.values(), *evidence.values(), *unchanged.values()))
                     and spec == '30b921d6a8f24863b6a1be7aaf9e5ad1e580988db2fc55ea161f0300a8cd50ec')
(OUT / 'identity_check.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(passed=result['passed'], source_count=len(current), evidence_count=len(evidence),
                     engine_count=len(unchanged))))
assert result['passed']
