# E0/E1 冻结候选：架构与算法独立复审

结论：**REWORK_BEFORE_NATIVE_QUALIFICATION**。解析主干正确，数值路径的算子裁剪也正确；不建议重写公式或重开 BC/CF/VG 优化。但候选新增两层永久写锁、每任务依赖审查和额外 witness 阈值，且终态图片逐次生灭 renderer，偏离本阶段可信合同与常驻资源设计。先一次修完这些明确项目，再用修订源完成有限 native 资格，避免先重跑旧候选再重跑新候选。

## 审计范围与身份

本审计全部读取 `artifacts/llm_entry/preflight_001/revision_002/delivery_001/sources.zip`，核对 archive SHA256 与其中全部 **38 个** source manifest 项；指定三个当前磁盘文件也与冻结字节一致。未执行 Blender、GPU、socket、安装、正式计量，未改作者源、旧失败或 Git。

| 冻结项 | SHA256 |
| --- | --- |
| `sources.zip` | `b8e04f01a331d21e4d1f53ab72f41a77c8f49fc9589a66593089a51b8fafde3e` |
| `human_eye_fast/local_tasks.py` | `90a1ca8e23e5a3f3464ccda4211f1f16376c72417039bb298646b80a52b4bb25` |
| `human_eye_fast/llm_entry.py` | `f051b48489b024e0c9a9524b601976a16d28305d4746e3d7f3260d514069f3e3` |
| `examples/blender_llm_entry.py` | `49a4834fef18dbbf2e90b6f449520b62d961c62853a9e1a531941db3511b9a4a` |
| 主干架构 | `877f727ac52af82c9e1de36c5579b05641c633844df065549bc41528a73def13` |
| 主干工作单 | `d51a9a0b763c021c0dcd0590f55e9739b65500f390d87173ec0f9c0eae42f886` |

自有 `algorithm_probe.py/json` 从 ZIP 编译候选到独立 CPU 进程，使用控制器/GPU 双件检查编排；额外只运行 16 个双单三角形的冻结 BC 查询来检查新 witness 门，不重做 BC 验收。不导入真实 bpy/GPU。probe 断言 PASS 意味着**成功复现以下行为和缺陷**，不是产品通过。

## 可以承接的实现

- `local_tasks.py:175,193–205` 获取全局真实 before，再按 `(d-g)*(b-a)/d` 生成一次 `Translate`，只执行一次。不是候选搜索，不读取 Session 私有几何，不通过 CF 推理批准公式。证明所需的统一 moving 平移、固定 reference、稳定拓扑/单位/帧须由绑定合同成立；不扩展成增大间隙、旋转或避障。
- `BlenderControl.execute` 重新取得 evaluated graph，回读两个对象的世界米几何并重做全局 BC。候选传 `VERTICES|TRANSFORM` 和明确 observation IDs，保留 `ActionStageError` 的阶段/write_status；达标来自实际 after gap，`not_reached` 不隐藏重试/回滚。LLM 层还从 Outcome.control_after/before 生成实际位移，不把命令当实际位移。
- 数值任务没有 Session、TD、AO 编码/解析、CF 预测/学习或图片。一个 `eye_run` 在本地观察→求解→写入→回读→结果，未强制 open、预测、确认、评分等模型往返。脚本 probe 的正常两次明确请求是一次 reached、一次 already_reached，累计两次 observe、一次 execute，位移为 `(1.8,2.4,0)` 的浮点表示。
- 紧凑结果含对象/任务/观测/frame/米单位、目标/容差、前后距离、实测误差、goal_reached、命令位移与实际位移；异常保留阶段和已知 Outcome。已测不达标附 witness，成功时按需 inspect。正文与 ImageContent 分开，没有 structuredContent 再重复一份全文。
- 图片从同一控制器的 current readback 与 bridge 生成；目标只补 appearance，context 按传入顺序真实捕获，使用保存的 scale_length、明确 scene/view_layer override。不会再开第二个 Session 或再测一次目标 BC。数值路径没有 PNG 文件；输出 PNG 仅最终 base64 一次，同模式当前图缓存复用。
- 三个被审实现文件内无源 hash/compile 扫描、WAL、权限账本、TTL、自动重发、后台 Blender 线程或 mesh 外传。`threading.current_thread` 只是主线程断言，不创建线程。不能把这一点扩大成整个旧 addon 也没有线程。

## 必修 R1：移除永久写锁，保留真实错误和显式新任务

`local_tasks.py:106,165–166,207–219` 的 `_blocked` 使写后异常永久变成 `write_locked`。`llm_entry.py:21,136–159` 的 Binding `_write_blocked` 又跨新 task、新 LLMEntry、断线重连保留；连已有有限实测 Outcome、只是 result.status=`error` 的情况都被永久暂停。作者 API 草案第 11 行确实把“宿主复核并重新绑定”写入合同，且测试主动断言锁存在；**这是候选添加的新策略，不能据此覆盖主干可信输入/去防御要求**。

独立 probe：第一次抛 `ActionStageError('target_readback','written')` 后，移除异常再发送不同 before/after ID 的新任务，observe 仍只执行过一次，新任务直接 `write_locked`。另一 probe 先返回真实 after_gap=3、实际位移=(1.2,1.6,0) 的已测 error，换目标及重连均返回 `unverified_prior_write`，open/run 仍各一次。

最小修复：删除两层 latch；本次错误如实报告，清空失效 current/不可确认的证据，不自动重试本次 action。后续新的显式 run 原本就从 fresh observe 开始，应允许它按新状态执行。保留已知 Outcome 的数值作为该次错误证据，不把未知 after 换成 before 冒充当前。同步改掉要求永久 latch 的候选测试/API 描述；无需新增 unlock 工具或恢复审批流程。

## 必修 R2：可信前提移到绑定合同，删掉热路径重复算法门

`_eligible/_fixed_parents/_plain_mesh`（57–77,109–118,168）每次 run 都重新遍历对象和父链，检查动画、库/override、约束、rigid body、modifier、shape key、编辑模式与锁等。即使第二次已在目标内、不需要动作，仍走同一遍。probe 两次 run 记录 `plain_mesh` 为 `A,B,A,B`。这不是全场景 hash，但确实是新的逐次依赖防御审查；也会拒绝数学上平移等变、但存在静态 modifier/shape 的绑定。主干要求的是绑定方声明支持域，不每次重新“证明全部依赖”。

最小修复：保持第一版**同一已声明独立刚体支持域**，由可信 host binding 持有前提与生命周期；移出/删除每 run 的通用 dependency walk。不得因此宣传已支持任意 modifier/驱动对象。保留目标数值、当前 observation、主线程与真实写状态等直接语义所需检查，不恢复另一套来源/权限系统。

另一个具体新拒绝点是 `local_tasks.py:193–196` 的 `isclose(hypot(b-a), distance, rel_tol=1e-9)`。这在已验收 BC 之外又设置未经误差合同支持的硬门：冻结 BC 对一个合法两三角形输入返回 `distance=0.000999998934674593`、公开 witness norm=`0.0009999989860627878`，差异只是约 `5.1388e-11 m`，却因相对差 `5.1388e-8` 被新门拒绝。输入世界偏置为 `1e7`，完整顶点/witness 及全部 16 例保存于 probe JSON。该 CPU 例子证明新门与已验收核的浮点输出不兼容，**不证明这个远坐标案例能在 Blender float32 控制下完成**；后者应由真实 after/tolerance 判定。

建议删去这项重复 witness 一致性门，而不是看样本把 `1e-9` 调大；有限精度读回的误差依然公开。没有理由为此修改 BC 或增加一次完整查询。

## 必修 R3：renderer 惰性常驻，避免每张新图生灭 GPU 资源

`examples/blender_llm_entry.py:31–41` 在每次 render_image 构造 VGRenderer，并 finally close。真实 VG 构造包含 GPUOffScreen、shader、两台 camera 和 scratch arrays。独立 frozen-example 双件 probe 对两次新图调用得到 create=2、close=2、prepare=2、observe=2；LLMEntry 当前同模式缓存确实能避免完全相同的 inspect 再渲染，但新任务或换图模式仍重建 renderer。

最小修复：图像第一次需要时创建一份 renderer，归当前连接/LLMEntry 的明确 owner 管理；后续新任务/新图使用同实例，close/EOF/stop 在主线程同 GPU context 释放。单纯更改目标间隙而替换 Control 时无需重复构造 renderer。每次真实新图仍 prepare 当前 meshes，不把 stale PreparedScene 当缓存。数值模式必须始终零 renderer 构造。所有权要接入现有 close，不能把闭包中的 renderer 留到 bridge 消亡后泄漏。

这里只确认结构性的创建次数退化，尚无时延/内存收益数字，不要求新增独立性能优化实验；随同一次修订做小型 lifecycle 验证即可。

## 必修 R4：可取回当前结果及当前图的详细证据

`_run` 的 compact fields 只在回包时临时构造，没有留存当前任务的结果；`eye_inspect` 仅支持 directory/witness/image。因此新上下文能读到当前间隙和图，却无法取回该次 goal、实际位移、write_status、阶段等完整结果，除非再次 run（那会产生另一任务，并不恢复旧动作结果）。独立 probe 对已完成回包的 task_id 请求 `evidence='result'`，返回 `Unknown evidence kind`。最小修复是保存一份当前 compact result，增加 `inspect result`；不重跑算法、不再写入、不增加多任务历史/TTL。缓存引用的图片仍按既有按需 image 取，不需要把 base64 复制进结果正文。

example 第 37–39 行仅保留 mode/mesh_ids/section，丢弃实际 `rendered.metadata` 的 views、selection、meters_per_blender_unit 等；LLMEntry 第 39 行和 227 行也只支持 directory/witness/image，没有详细相机取证入口。probe 向假 renderer 注入完整相机元数据后，冻结 example 仅返回三个键。这与主干第 65 行“反投影需求才附匹配相机数据”之间尚有未实现部分，也会影响正式 V 族所需的独立样点投影依据。

最小补齐：将**本次实际图像**的完整 VG metadata 与当前图一起保留；默认输出仍保持紧凑。显式 `inspect camera` 才取同一图的相机/切面/单位等，资格记录另留完整 selection；不必为补相机再渲染。不能仅凭 PNG 与主干旧相机假定一致，不需要默认全量暴露。

## 不应扩大为返工的事项

- first no-op 的 after_gap 为 null、before_gap 为有限实测且 goal_reached=true，是一次只读完成的明确表述，不必为填 after 强制再捕获。
- 零 gap 请求 SECTION 时返回实际 NATURAL，当前候选 API 已明示且回包标注实际 mode；无需扩写 SECTION 几何。
- 按需 context 全量捕获/prepare 是当前声明的信息来源；没有额外状态变化声明时不应为了“更激进”随意将其改成 stale geometry。后续是否可按可信变更复用由实际瓶颈决定。
- 公共结果不含全 AO/Top-K/训练状态属于这次任务依赖裁剪，不是功能退化。新增测试不要重新穷举 BC、CF 或完整 Session。

## 放行边界与下一步

可接受为“解析技能实现基础与 CPU 编排候选”：闭式求解、单次实际动作接口、实际 after 结果投影、数值模式零 TD/AO/图片、当前图按需交付。**不能**据此放行原生功能或收益验收。

delivery manifest 自身登记 native `0/5`、缺独立 final RNA、真实宿主/模型与成本未验。本审计没有通过 CPU stub 把这些失败改成通过，也没有复跑 native。建议一次固定返工单包含 R1–R4，同时修正 native 夹具后，用新冻结源在同一次限定的 2 进程/5 原案例补验中完成 native 资格；不先重跑旧候选，已失败证据原样保留。实际宿主图片消费、任务成功率、2倍耗时/输出 token/往返收益仍分别待测，未通过前不推进 E2。
