"""Freeze author failures and root review before dispatching corrective work."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
AUTHOR = ROOT / 'artifacts/llm_entry/preflight_001'
sha = lambda data: hashlib.sha256(data).hexdigest()
delivery = json.loads((AUTHOR / 'revision_002/delivery_001/manifest.json').read_bytes())
identity = json.loads((HERE / 'identity_check.json').read_bytes())
assert identity['passed']
spec_hash = sha((ROOT / 'docs/RADICAL_V1_SPEC_REVIEW.md').read_bytes())
assert spec_hash == identity['user_spec_sha256']
decision = dict(
    decision='REWORK_BEFORE_NATIVE_QUALIFICATION', date='2026-11-06', review_number=24,
    delivery_manifest_sha256=identity['delivery_manifest_sha256'],
    delivery_sources_zip_sha256=identity['sources_zip_sha256'],
    reviewed_source_count=38, reviewed_evidence_references=10, frozen_engine_sources_unchanged=17,
    accepted_evidence={'transport_contract_tests':5, 'cpu_mock_stub_contract_tests':24,
                       'formal_recipe_mathematical_cases':14, 'synthetic_math_positive_pairs':28,
                       'synthetic_math_negatives':11},
    native_original={'processes':2, 'cases':5, 'passed':0, 'status':'FAIL',
                     'independent_final_rna':'missing', 'receipts_are_not_final_geometry_proof':True,
                     'gui_exit_zero_not_pass':True, 'gui_initially_visible':True},
    mandatory_corrections=[
        'remove per-session and cross-connection permanent write latches; next explicit task starts with fresh observe',
        'remove per-run dependency traversal and unsupported 1e-9 repeated witness consistency gate',
        'lazy resident renderer owned by connection, released on close/EOF; no GPU on numerical-only tasks',
        'retain only current task result and actual image metadata for explicit retrieval without rerun or rerender'],
    recheck={'new_native_processes':2, 'unchanged_scene_cases':5,
             'case_names':['nonconvex','parented','already-reached','occluded','parented-rescaled'],
             'sequence':'make all source corrections, focused CPU checks, then one background and one owned GUI',
             'evidence_root':'artifacts/llm_entry/preflight_001/revision_003',
             'old_failures_and_launch_markers_immutable':True,
             'additional_functional_calls':'image/result/camera lifecycle in existing occluded case; not task-efficiency counts',
             'gui':'hidden during test operations; initial GHOST creation invisibility unproved; never touch user process',
             'no_formal_model_or_performance_run':True},
    formal_task_protocol_frozen=False,
    formal_remaining=['replace two D recipes with edge-edge and vertex-face-interior plus independent oracle',
                      'actual reasonable native helper and RNA/write audit',
                      'V actual PNG/camera/section labels and deterministic mixed-sample rule',
                      'actual host and model consumption; unavailable token usage remains unqualified'],
    native_entry_accepted=False, llm_task_benefit_accepted=False, advance_E2=False,
    new_performance_result=False, user_spec_sha256=spec_hash,
    review='docs/LLM_ENTRY_PREFLIGHT_REVIEW.md', recheck_protocol='docs/LLM_ENTRY_RECHECK_PROTOCOL.md',
    evidence_archive='docs/llm_entry_preflight_review_evidence.zip')
target = ROOT / 'docs/radical_acceptance_llm_entry_preflight.json'
target.write_text(json.dumps(decision, indent=2) + '\n', encoding='utf-8')

author_paths = sorted(p for p in AUTHOR.rglob('*') if p.is_file())
root_paths = sorted(p for p in HERE.iterdir() if p.is_file())
docs = [ROOT / p for p in ('docs/LLM_ENTRY_PREFLIGHT_REVIEW.md', 'docs/LLM_ENTRY_RECHECK_PROTOCOL.md',
                          'docs/radical_acceptance_llm_entry_preflight.json')]
payload = {p.relative_to(ROOT).as_posix():p.read_bytes() for p in [*author_paths, *root_paths, *docs]}
manifest = {name:{'bytes':len(data),'sha256':sha(data)} for name, data in payload.items()}
archive = ROOT / 'docs/llm_entry_preflight_review_evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in payload.items():
        z.writestr(name, data)
    z.writestr('MANIFEST.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(sha(z.read(name)) == row['sha256'] for name,row in manifest.items())
print(json.dumps(dict(files=len(payload), author_files=len(author_paths),
                     bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()))))
