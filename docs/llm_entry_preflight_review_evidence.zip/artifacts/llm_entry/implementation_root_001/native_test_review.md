# E0/E1 原生失败与限定复验审查

结论：**原 `native_001` 仍为 0/5 FAIL；修正版是测试仪器修正，没有改生产接入或任务算法。允许准备恰好原 2 个进程、原 5 个案例的限定复验，不能用回包补判原批通过。** 新版 `finally` 能独立保存真实 RNA 的设计成立，但尚未在 Blender 中执行。GUI 首次可见问题尚未由本次修正解决；如果复验要求“从未出现可见窗口”，当前启动器不能保证这一点，应先明确可执行的隐藏约束，不能直接沿用 `hidden: true` 作证明。

本审查只读冻结 ZIP、原记录和交付源。未启动 Blender、GPU、模型、IPC 或性能测试；仅运行 `native_review_probe.py` 的离线记录核算与 AST 隔离 CPU doubles。输出位于本目录 `native_review_probe.py/json`。没有修改作者证据、生产文件、文档或 Git。

## 来源身份与改动范围

| 来源 | SHA-256 |
|---|---|
| 原执行 worker，`native_001/sources.zip` | `4ef23b02540532b54042c295d6a02bd4f863089eab77597da7e9e2cafa0cca3f` |
| 修正 worker，`delivery_001/sources.zip` 及阅读时工作区 | `cb0da332bdd3822e659e3e655d94755cdea00f7bbf7427b99112ba6b103be8a1` |
| 原/交付/工作区 `revision_002/run_preflight.py` | `358fa57e71d895e94b25039d6658dad951661aa0cb3dbac44fafd055fa6157ca` |
| 原 native manifest | `cc03843d90c45a7c279f4314ffe32171f72b39301ad34003b28212f6421312d4` |
| 交付 ZIP | `b8e04f01a331d21e4d1f53ab72f41a77c8f49fc9589a66593089a51b8fafde3e` |

独立 probe 核对了原 ZIP 的全部 manifest source hashes、交付 ZIP 的全部 source hashes。两个 ZIP 的公共源仅 worker 不同。其完整 diff 保存在 probe JSON：增加 `client_parent_pid`；允许 direct/Windows immediate-child 并先保存 native transport 记录再判断归属；把 after snapshot 移入 `finally`。没有更改案例、调用序列、误差门、产线源、渲染参数或验证算法。

下述新行号绑定修正版 worker `cb0da332…`；原失败行号绑定原 ZIP，不混用。

## 原批到底证明了什么

独立重读五组 `requests.jsonl/responses.jsonl/client.json/failure.json`，核对请求响应 ID、回包原字节数量、client 保存的结果与 raw responses 一致，以及审核摘要 receipt 与原记录一致：

| 模式/案例 | 请求帧/响应帧 | 请求/响应 bytes | 已收到的任务状态 | 原生最终判定 |
|---|---:|---:|---|---|
| background/nonconvex | 6/5 | 671/2626 | reached / written | FAIL，缺 after RNA |
| background/parented | 5/4 | 556/2297 | reached / written | FAIL，缺 after RNA |
| background/already-reached | 5/4 | 554/2241 | no_action / not_written | FAIL，缺 after RNA |
| GUI/occluded | 5/4 | 579/43384 | reached / written | FAIL，缺 after RNA |
| GUI/parented-rescaled | 5/4 | 555/2287 | reached / written | FAIL，缺 after RNA |

每组唯一记录的失败均为原 worker `wire_run:236` 的 `assert client["client_pid"] == child.pid`；不是工具结果中的任务错误。所有工具回包 `isError=false`，见证 observation 与测量数值匹配任务回包，四例 reached 与一例 no_action 的回包数值在各自 tolerance 内。这只是**回包内部一致与传输成功**，不能证明原生几何最终值。

SECTION 回包包含 PNG，独立核对解码出的 bytes 与归档 `received-terminal.png` 完全一致：30521 bytes，SHA `289588ac5334a2af8e2beeb479ed472c333cfb8b5489d3ad2b0f84aecbe0ed33`，IHDR 1024×512。作者原离线审计另解码颜色像素；本次未重做视觉验收。PNG 存在不等于 LLM 看过图，更不能代替 after RNA 或实际宿主资格。

可以承接的原生证据需分两级：

- **直接留存：** 请求响应 raw、不同进程的 client/relay 记录、relay stdin/stdout EOF、relay exit 0、五例 before RNA；GUI 的首见/末次窗口状态。真实 IPC 已发生，没有拿 stub 代替原生交互。
- **由原冻结代码及失败到达位置支持：** `TrackedEntry` 在 main thread 创建、处理、close 的断言；单连接、预期 handler 次数、EOF 前只 close 一次、session `_closed`、显式 stop 后 listener 关闭与 timer 注销的断言均位于 PID 断点前，未先报错。GUI 由 `bpy.app.timers` 驱动，background 由主线程显式 pump。它们是有效的执行路径证据，但实际 thread IDs、连接计数等字典没有写出，因为 `native-transport.json` 写入位于失败断言后；不要称这些数值已有原始记录可独立重算。

五例 `after-rna.json` 和 `native-transport.json` 均确实不存在。因此后续 `validate`、执行/渲染次数门、独立 oracle 距离、只移动目标/参考及父级不变、终态 SECTION 截面与实际几何对应等检查均未完成。不能因前段 IPC 成功就宣称 E1 原生功能过门。

退出码判断没有假阳性：background 因结尾抛错 exit 1；GUI 在 timer 中记录失败后正常 quit，exit 0。`run_preflight.py:124–133` 同时要求 exit 0、源/可执行文件稳定和 `summary.status=passed`，故 GUI 和总批次都正确为 false。不要仅改成依退出码判定，也无需为了形式一致重写 GUI 退出机制。

## PID 修正与 finally 独立性

**PID：** 原独立 venv probe 保存 `launched_pid=304`、实际解释器 `pid=36192`、`parent_pid=304`，base executable 指向 Python 3.13.12。它直接支持本机 Windows venv 启动器与真正解释器可能为父子进程，而非同一 PID。新 worker `127,236–248` 接受 `client_pid==child.pid`，或仅在 Windows 接受 `client_parent_pid==child.pid`；不接受任意后代、任意相异 PID。CPU probe 对这四种情况执行原 AST：direct、Windows immediate-child 通过，无关父 PID 和 POSIX 冒用父 PID 拒绝，并在拒绝前保存关系记录。这是合理的最小测量修正，不是为生产新增校验链。

原五例未记录 parent PID 或 launched PID；不能把单独 venv probe 的关系当作五例逐个已证父子关系。新 native 复验应保存这三个数及关系，才关闭此项。没有必要新增进程谱系服务、签名或来源账本。

**finally：** `_run_case:314–334` 在 fixture context 内先保存 before，再构造绑定/执行 wire；无论该块正常退出还是抛错，都直接再次调用 `fixture.snapshot()` 写 after，之后才退出 fixture。wire 自身先完成 bridge stop/reap；所以正常路径的终态是 EOF/关闭之后而非伪造的预测值。异常路径同样会留下当前实际场景，而不将失败改为通过。

`verification/llm_entry_fixtures.py:51–76` 的 snapshot 从指定 scene/view_layer 的 evaluated depsgraph 取得对象、实际矩阵、网格顶点及三角形，转换为米，覆盖 moving/reference/context 和 parent；不读取 `run_fields`、Outcome、session 缓存或 JSON 回包。`validate:167–194` 再检查目标位移、拓扑、线性变换、其他对象/parent 不变，并用 `test_bc_acceptance.exhaustive_convex_oracle` 的所有三角形对、独立凸支持最小二乘数值算法核对距离。名字中的 convex 指每个三角形凸包，不是把 nonconvex 整个网格取凸包。这足以构成该范围内独立终态证据，不需要新测试引擎或第二套原生进程。

本次 CPU doubles 从交付 AST 原样抽出 `_run_case`（只去掉内部 import，以隔离 native 依赖）。绑定失败、模拟 wire/PID 边界失败、generator.close 三种路径均实际产生两次 snapshot，顺序为 before → wire cleanup（如有）→ after → fixture cleanup；原异常仍传播。这证明 Python 控制流修正，不证明真实 Blender RNA 已被采集。进程崩溃/强制 kill 无法靠 finally 保证记录；这不是本轮须增加的防御框架。

## GUI 首次可见及复验范围

原 launcher 已传 `STARTF_USESHOWWINDOW/SW_HIDE`（`run_preflight:108–112`），但 GUI 原始记录明确：owned PID 37808 的 GHOST window 首次观测 `visible_on_observation=true`，调用 hide 后 false，末次观测也 false。这意味着**启动隐藏请求没有保证 GHOST 首次不可见**。worker 唯一主动 hide 在首个 timer tick（`415–416`），所以隐藏发生于该窗口已可见之后。现有记录不包含窗口首次显示时间，不能量化可见时长，也不能精确断言 Blender 内部哪次窗口 API 覆盖了启动提示。

修正版没有改这段。把首次 owned-window hide 提前到 GUI Python 初始化、注册 case timer 之前，可以减少 Python 已开始后仍等待首个 tick 的间隔；仍不能证明操作系统创建窗口至 Python 执行前完全不可见。没有证据支持“再加一个隐藏标志便已解决”。不建议为本轮新造 Win32 监控/隔离桌面平台或额外启动批次。若根侧允许“最早可执行点隐藏，案例开始与结束均不可见”，应明确记录并在原定 GUI 复验中取证；若要求绝不闪现，当前方案未满足，先解决启动方式，不得借复验自行放宽。

最小功能复验保持原案例、顺序和门：

1. 一个 background：nonconvex、parented、already-reached；一个 factory GUI：occluded/SECTION、parented-rescaled。共 2 次 Blender 启动、5 案例；不新增模型、性能、CPU 边界或传输压力批次。
2. 冻结同一生产/fixture/oracle 源；仅登记本次测试修正以及必要的隐藏时点改变。新目录保留原 `native_001` 的 0/5，不覆盖旧 raw。
3. 每例必须实际保存独立 after RNA、PID 关系和 native transport 字段；完成原 `validate`、执行次数/渲染次数、EOF close/stop/timer 断言。写入四例必须一笔真实控制执行；already-reached 必须零执行且 moving 完全不变。SECTION 必须从实际 after 几何验证截面并保留 PNG。
4. outer runner 继续同时审退出码和 summary。当前 `run_preflight:143–145` 会因原 launch markers 拒绝再次 native，CLI 也限制 native attempt 1；根侧应明确授权并冻结一次新限定复验入口/目录，**不要删标记、改旧 summary 或以 delivery 取代原失败**。不复现/再失败即回报，不自动追加批次。

之所以需要两进程而非只补一个无图案例，是五例最终 RNA 全部缺失，原案例分别承担 nonconvex、父级/负非均匀尺度、无动作、原生 timer/SECTION/遮挡上下文及 scene unit rescale 责任。恰好重做原两进程即可补齐这些责任；仅重放 JSON 或一例 PID 成功不能验证五种最终场景，也无需扩大成全协议测试。

这次限定复验即使全过，也只补 E0/E1 的原生功能资格：真实 MCP 宿主、模型消费图像、完整任务效率和 provider tokens 仍未验证，应由对应阶段处理，不能据此宣布接入整体收益达标。
