"""Independent CPU-only probes of frozen E1 orchestration; never imports bpy/GPU."""
from pathlib import Path
import hashlib
import json
import math
import sys
import types
import zipfile
from contextlib import nullcontext

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().with_suffix('.json')
DELIVERY = ROOT / 'artifacts/llm_entry/preflight_001/revision_002/delivery_001'
manifest = json.loads((DELIVERY / 'manifest.json').read_text(encoding='utf8'))
zip_bytes = (DELIVERY / 'sources.zip').read_bytes()
assert hashlib.sha256(zip_bytes).hexdigest() == manifest['sources_zip_sha256']
archive = zipfile.ZipFile(DELIVERY / 'sources.zip')
identity = {}
for name, digest in manifest['source_sha256'].items():
    blob = archive.read(name)
    assert hashlib.sha256(blob).hexdigest() == digest, name
    identity[name] = digest

package = types.ModuleType('human_eye_fast')
package.__path__ = []
sys.modules['human_eye_fast'] = package

def frozen(name, path):
    mod = types.ModuleType(name)
    mod.__file__ = '<frozen>/' + path
    sys.modules[name] = mod
    exec(compile(archive.read(path), mod.__file__, 'exec'), mod.__dict__)
    return mod

frozen('human_eye_fast.resident_bridge', 'human_eye_fast/resident_bridge.py')
bridge = frozen('human_eye_fast.blender_resident_bridge', 'human_eye_fast/blender_resident_bridge.py')
bc = frozen('human_eye_fast.fast_bvh_clearance', 'human_eye_fast/fast_bvh_clearance.py')
control = frozen('human_eye_fast.control', 'human_eye_fast/control.py')
tasks = frozen('human_eye_fast.local_tasks', 'human_eye_fast/local_tasks.py')
entry = frozen('human_eye_fast.llm_entry', 'human_eye_fast/llm_entry.py')
NS = types.SimpleNamespace
IDS = ('A', 'B')

def surface(distance=5.):
    return bc.SurfaceDistance(distance, 0, 1, (0., 0., 0.), (.6 * distance, .8 * distance, 0.))

def context():
    def obj(name):
        return NS(name=name, type='MESH', mode='OBJECT', instance_type='NONE', constraints=[],
                  rigid_body=None, rigid_body_constraint=None, modifiers=[], parent=None,
                  parent_type='OBJECT', lock_location=(False, False, False),
                  data=NS(shape_keys=None, is_editmode=False))
    objects = dict(zip(IDS, (obj('A'), obj('B'))))
    layer = NS(name='L', objects=objects)
    scene = NS(view_layers={'L': layer}, frame_current=3, frame_subframe=0.,
               unit_settings=NS(scale_length=.001))
    return scene, layer, objects

class FakeControl:
    def __init__(self, scene, objects, goal, *, view_layer):
        self.goal = goal
        self.observes = self.executes = self.closes = 0
        self.fail = False
        self.distance = 5.
    def observe(self, oid):
        self.observes += 1
        self.before = control.ClearanceReadback(oid, 3, IDS, surface(self.distance))
        return self.before
    def execute(self, action, after_id, *, target_changes):
        self.executes += 1
        if self.fail:
            raise control.ActionStageError('target_readback', 'written')
        self.command = action.command
        self.distance = self.goal.distance_m
        after = control.ClearanceReadback(after_id, 3, IDS, surface(self.distance))
        return control.Outcome(self.goal, action, self.before, after, (0., 0., 0.),
                               action.command.delta_world_m, self.distance - self.before.surface.distance_m, True)
    def close(self):
        self.closes += 1

tasks.BlenderControl = FakeControl
scene, layer, objects = context()
session = tasks.CloseGapSession(scene, layer, objects, tasks.CloseGapTask(*IDS, 2., 1e-7))
plain_calls = []
original_plain = tasks._plain_mesh
def counted_plain(obj):
    plain_calls.append(obj.name)
    return original_plain(obj)
tasks._plain_mesh = counted_plain
first = session.run(before_id='one-before', after_id='one-after')
second = session.run(before_id='two-before', after_id='two-after')
assert first.status == 'reached' and second.reason == 'already_reached'
normal = {'first_status': first.status, 'second_reason': second.reason,
          'delta': first.command.delta_world_m, 'observes': session._control.observes,
          'executes': session._control.executes, 'plain_mesh_hot_checks': plain_calls.copy()}
np.testing.assert_allclose(first.command.delta_world_m, [1.8, 2.4, 0.], atol=0, rtol=1e-15)
assert plain_calls == ['A', 'B', 'A', 'B']
session.close()
tasks._plain_mesh = original_plain

scene, layer, objects = context()
session = tasks.CloseGapSession(scene, layer, objects, tasks.CloseGapTask(*IDS, 2., 1e-7))
session._control.fail = True
failure = session.run(before_id='failure-before', after_id='failure-after')
session._control.fail = False
fresh = session.run(before_id='fresh-before', after_id='fresh-after')
local_lock = {'first': (failure.status, failure.write_status), 'fresh_reason': fresh.reason,
              'observes_after_two_explicit_runs': session._control.observes,
              'executes_after_two_explicit_runs': session._control.executes}
assert fresh.reason == 'write_locked' and session._control.observes == 1
session.close()

before = control.ClearanceReadback('before', 3, IDS, surface(5.))
after = control.ClearanceReadback('after', 3, IDS, surface(3.))
command = control.Translate((1.2, 1.6, 0.))
action = control.Action('action', 'before', command, -2.)
outcome = control.Outcome(control.Goal(*IDS, 2., 1e-7), action, before, after,
                          (0., 0., 0.), command.delta_world_m, -2., False)
counts = {'open': 0, 'run': 0, 'close': 0}
class KnownWrittenError:
    def run(self, **kw):
        counts['run'] += 1
        return tasks.CloseGapResult('error', 'execution_failed', 'written', before,
                                    outcome, command, 2., 'context')
    def close(self):
        counts['close'] += 1
def open_task(*args):
    counts['open'] += 1
    return KnownWrittenError()
binding = entry.Binding(*IDS, open_task)
def initialized(binding):
    e = entry.LLMEntry(binding)
    e.handle_line(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'initialize',
                              'params': {'protocolVersion': entry.PROTOCOL_VERSION}}).encode())
    e.handle_line(b'{"jsonrpc":"2.0","method":"notifications/initialized"}')
    return e
def rpc_run(e, target=2.):
    response = json.loads(e.handle_line(json.dumps({'jsonrpc': '2.0', 'id': 2,
        'method': 'tools/call', 'params': {'name': 'eye_run', 'arguments': {
            'task': 'close_gap', 'target_gap_m': target, 'tolerance_m': 1e-7}}}).encode()))
    return json.loads(response['result']['content'][0]['text'])
e = initialized(binding)
known = rpc_run(e)
result_request = json.loads(e.handle_line(json.dumps({'jsonrpc': '2.0', 'id': 3,
    'method': 'tools/call', 'params': {'name': 'eye_inspect', 'arguments': {
        'task_id': known['task_id'], 'evidence': 'result'}}}).encode()))
result_lookup = json.loads(result_request['result']['content'][0]['text'])
assert result_lookup['reason'] == 'Unknown evidence kind'
blocked = rpc_run(e, 1.)
e.close()
reconnected = initialized(binding)
blocked_again = rpc_run(reconnected, 1.)
reconnected.close()
assert known['after_gap_m'] == 3. and known['actual_delta_world_m'] == [1.2, 1.6, 0.]
assert blocked['reason'] == blocked_again['reason'] == 'unverified_prior_write'
assert counts['run'] == 1
binding_lock = {'known_error': known, 'new_task': blocked, 'new_connection': blocked_again, 'counts': counts}

# An actual accepted-BC result can fail the added relative witness guard.
# Only sixteen pairs of single triangles, not a rerun of BC acceptance.
rng = np.random.default_rng(731)
witness_rows = []
for origin in [0., 1e3, 1e5, 1e7]:
    for k in range(4):
        n = rng.normal(size=3); n /= np.linalg.norm(n)
        u = np.cross(n, [0., 0., 1.]); u /= np.linalg.norm(u)
        v = np.cross(n, u)
        a = np.array([-u-v, u-v, 2*v]) + origin
        b = a + n * .001
        faces = np.array([[0, 1, 2]])
        answer = bc.surface_distance(bc.SurfaceIndex(a, faces), bc.SurfaceIndex(b, faces))
        length = math.dist(answer.point_a, answer.point_b)
        accepted = math.isclose(length, answer.distance_m, rel_tol=1e-9)
        row = {'origin': origin, 'ordinal': k, 'bc_distance': answer.distance_m,
               'witness_norm': length, 'candidate_guard_accepts': accepted}
        if not accepted:
            row.update(a=a.tolist(), b=b.tolist(), point_a=answer.point_a, point_b=answer.point_b)
        witness_rows.append(row)
assert sum(not row['candidate_guard_accepts'] for row in witness_rows) == 1

# Execute the frozen example's composition using doubles, never Blender/GPU.
fake_start = types.ModuleType('human_eye_fast.blender_llm_bridge')
fake_start.start = lambda *a, **k: None
sys.modules[fake_start.__name__] = fake_start
graphics = {'create': 0, 'close': 0, 'prepare': 0, 'observe': 0}
class FakeRenderer:
    def __init__(self): graphics['create'] += 1
    def prepare(self, meshes): graphics['prepare'] += 1; return meshes
    def observe(self, *a, **kw):
        graphics['observe'] += 1
        return NS(png=b'cpu-probe-image-not-a-real-png', metadata={
            'mode': kw['mode'], 'mesh_ids': list(IDS), 'section': None,
            'meters_per_blender_unit': .001, 'views': {'actual_camera': 'fixture'},
            'selection': {'direction': [1., 0., 0.]}})
    def close(self): graphics['close'] += 1
render_module = types.ModuleType('human_eye_fast.raycast_saccade_gpu')
render_module.VGRenderer = FakeRenderer
sys.modules[render_module.__name__] = render_module
sys.modules['bpy'] = NS(context=NS(temp_override=lambda **kw: nullcontext()))
example = frozen('algorithm_example', 'examples/blender_llm_entry.py')
scene, layer, objects = context()
binding = example.binding_for(scene, layer, objects, *IDS, image_mode='NATURAL')
visual_session = NS(evidence_meshes=lambda *a, **k: ({}, .001))
png, metadata = binding.render_image(visual_session, after, 'NATURAL')
binding.render_image(visual_session, after, 'SECTION')
assert graphics == {'create': 2, 'close': 2, 'prepare': 2, 'observe': 2}
assert set(metadata) == {'mode', 'scene_object_ids', 'section'}

report = {'scope': 'frozen-source CPU orchestration probes; no Blender, GPU, socket or native measurement',
          'sources_zip_sha256': hashlib.sha256(zip_bytes).hexdigest(), 'all_frozen_source_hashes_verified': identity,
          'normal_and_hot_checks': normal, 'local_permanent_write_lock': local_lock,
          'binding_permanent_write_lock': binding_lock, 'current_result_inspect': result_lookup,
          'witness_revalidation_cases': witness_rows,
          'example_renderer_lifecycle': graphics, 'example_retained_metadata_keys': list(metadata),
          'assertions': 'PASS; probes intentionally demonstrate candidate defects, not release acceptance'}
OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
print(json.dumps({'report': str(OUT), 'source_count': len(identity),
                  'normal': normal, 'local_lock': local_lock,
                  'renderer': graphics, 'witness_guard_rejections': 1}))
