"""Offline root audit. Reads frozen evidence; never imports bpy or opens IPC."""
from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
from types import SimpleNamespace
from contextlib import contextmanager
from unittest.mock import patch
import ast
import base64
import difflib
import json
import struct

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "artifacts/llm_entry/preflight_001/revision_002"
OUT = Path(__file__).with_suffix(".json")
WORKER = "artifacts/llm_entry/preflight_001/task_native_worker.py"
RUNNER = "artifacts/llm_entry/preflight_001/revision_002/run_preflight.py"


def load(path):
    return json.loads(path.read_bytes())


def digest(raw):
    return sha256(raw).hexdigest()


def pid_probe(source):
    function = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == "wire_run")
    start = next(i for i, n in enumerate(function.body) if isinstance(n, ast.Assign)
                 and any(isinstance(t, ast.Name) and t.id == "client_pid" for t in n.targets))
    body = function.body[start:-1]  # Exact corrected PID statements; omit generator return.
    code = compile(ast.fix_missing_locations(ast.Module(body=body, type_ignores=[])), "frozen-pid", "exec")
    records = []
    for system, actual, parent, expected in (
        ("nt", 100, 9, "direct"), ("nt", 101, 100, "windows_immediate_child"),
        ("nt", 101, 99, "mismatch"), ("posix", 101, 100, "mismatch"),
    ):
        captured = []
        env = {"client": {"client_pid": actual, "client_parent_pid": parent},
               "child": SimpleNamespace(pid=100), "os": SimpleNamespace(name=system),
               "native": {}, "folder": Path("unused"),
               "_write_json": lambda p, value: captured.append(dict(value))}
        rejected = False
        try:
            exec(code, env)
        except AssertionError:
            rejected = True
        relationship = env["native"]["client_process"]["relationship"]
        assert relationship == expected and rejected == (expected == "mismatch")
        assert len(captured) == 1
        records.append({"os": system, "client_pid": actual, "parent_pid": parent,
                        "relationship": relationship, "rejected": rejected,
                        "record_written_before_rejection": True})
    return records


def finally_probe(source):
    function = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == "_run_case")
    function.body = [n for n in function.body if not isinstance(n, (ast.Import, ast.ImportFrom))]
    code = compile(ast.fix_missing_locations(ast.Module(body=[function], type_ignores=[])), "frozen-case", "exec")
    records = []
    for mode in ("binding_raises", "wire_raises", "generator_closed"):
        events = []

        class Fixture:
            scene = view_layer = objects = context = None

            def snapshot(self):
                ordinal = sum(e == "snapshot" for e in events) + 1
                events.append("snapshot")
                return {"rna_read_ordinal": ordinal}

        @contextmanager
        def case(spec):
            events.append("fixture_enter")
            try:
                yield Fixture()
            finally:
                events.append("fixture_cleanup")

        def binding_for(*args, **kwargs):
            events.append("binding")
            if mode == "binding_raises":
                raise RuntimeError("injected binding failure")
            return SimpleNamespace(render_image=None)

        def wire_run(**kwargs):
            events.append("wire_enter")
            try:
                yield 0
                raise RuntimeError("injected PID-boundary failure")
            finally:
                events.append("wire_cleanup")

        writes = []
        env = {"EPISODES": {"probe": None}, "request_arguments": lambda spec: {},
               "BlenderControl": SimpleNamespace(execute=lambda *a, **kw: None),
               "case": case, "binding_for": binding_for, "MOVING": "moving", "REFERENCE": "reference",
               "patch": patch, "wire_run": wire_run,
               "_write_json": lambda p, data: (events.append(p.name), writes.append((p.name, data)))}
        exec(code, env)
        generator = env["_run_case"](SimpleNamespace(python=None), Path("unused"), "probe", (), None)
        error = None
        try:
            next(generator)
            if mode == "generator_closed":
                generator.close()
            else:
                next(generator)
        except RuntimeError as exc:
            error = str(exc)
        assert writes == [("before-rna.json", {"rna_read_ordinal": 1}),
                          ("after-rna.json", {"rna_read_ordinal": 2})]
        assert events.index("after-rna.json") < events.index("fixture_cleanup")
        if mode != "binding_raises":
            assert events.index("wire_cleanup") < events.index("after-rna.json")
        records.append({"mode": mode, "events": events, "error_preserved": error})
    return records


def main():
    delivery = load(BASE / "delivery_001/manifest.json")
    attempted = load(BASE / "native_001/manifest.json")
    with ZipFile(BASE / "native_001/sources.zip") as old, ZipFile(BASE / "delivery_001/sources.zip") as new:
        assert all(digest(old.read(p)) == h for p, h in attempted["sources"].items())
        assert all(digest(new.read(p)) == h for p, h in delivery["source_sha256"].items())
        changed = [p for p in old.namelist() if p in new.namelist() and old.read(p) != new.read(p)]
        assert changed == [WORKER]
        source = new.read(WORKER).decode()
        result = {"scope": "offline frozen-source/raw-record audit; AST harness probes use CPU doubles, not native Blender",
                  "sources": {"old_worker": digest(old.read(WORKER)), "corrected_worker": digest(new.read(WORKER)),
                              "runner": digest(new.read(RUNNER)), "changed_common_sources": changed},
                  "worker_diff": "".join(difflib.unified_diff(old.read(WORKER).decode().splitlines(True), source.splitlines(True))),
                  "pid_cases": pid_probe(source), "finally_cases": finally_probe(source), "native_cases": []}
    audit = load(BASE / "native_001_receipt_audit/summary.json")
    for mode in ("background", "gui"):
        folder = BASE / "native_001" / mode
        summary = load(folder / "result/summary.json")
        for job in summary["jobs"]:
            case = folder / "result" / job["folder"]
            raw = (case / "responses.jsonl").read_bytes()
            responses = [json.loads(line) for line in raw.splitlines()]
            requests = [json.loads(line) for line in (case / "requests.jsonl").read_bytes().splitlines()]
            client = load(case / "client.json")
            assert [r["id"] for r in responses] == [r["id"] for r in requests if "id" in r]
            results = [r["result"] for r in responses if "content" in r.get("result", {})]
            assert results == client["results"]
            fields = [json.loads(r["content"][0]["text"]) for r in results]
            receipt = next(r for r in fields if r.get("task") == "close_gap")
            witness = next(r for r in fields if r.get("evidence") == "witness")
            assert all(r["isError"] is False and "structuredContent" not in r for r in results)
            assert witness["observation_id"] == receipt["observation_id"]
            measured = receipt["after_gap_m"] if receipt["write_status"] == "written" else receipt["before_gap_m"]
            assert measured == witness["gap_m"]
            assert abs(measured - receipt["target_gap_m"]) <= receipt["tolerance_m"]
            assert job["status"] == "failed" and 'assert client["client_pid"] == child.pid' in job["traceback"]
            assert not (case / "after-rna.json").exists() and not (case / "native-transport.json").exists()
            relay = client["stdio_relay"]
            assert relay["exit_code"] == 0 and relay["stdin_eof"] and relay["stdout_eof"]
            assert relay["request_bytes"] == (case / "requests.jsonl").stat().st_size
            assert relay["response_bytes"] == len(raw)
            pngs = []
            for block in (block for row in results for block in row["content"]):
                if block["type"] == "image":
                    png = base64.b64decode(block["data"], validate=True)
                    assert png[:8] == b"\x89PNG\r\n\x1a\n"
                    assert png == (BASE / "native_001_receipt_audit/received-terminal.png").read_bytes()
                    pngs.append({"bytes": len(png), "sha256": digest(png), "ihdr_size": struct.unpack(">II", png[16:24])})
            prior = next(r for r in audit["modes"][mode]["cases"] if r["case"] == job["name"])
            assert prior["receipt"] == receipt and prior["archived_response_sha256"] == digest(raw)
            result["native_cases"].append({"mode": mode, "case": job["name"], "request_frames": len(requests),
                "response_frames": len(responses), "request_bytes": relay["request_bytes"], "response_bytes": len(raw),
                "status": receipt["status"], "write_status": receipt["write_status"], "pngs": pngs,
                "reported_client_pid": client["client_pid"], "historical_parent_pid_available": "client_parent_pid" in client,
                "final_rna": "missing", "failure": "PID equality assertion", "native_result": "failed"})
    pid = load(BASE / "venv_pid_probe_001/stdout.txt")
    assert pid["reported"]["parent_pid"] == pid["launched_pid"] != pid["reported"]["pid"]
    result["archived_venv_pid_probe"] = pid
    result["native_processes"] = load(BASE / "native_001/summary.json")
    result["gui_windows"] = {k: load(BASE / "native_001/gui/result/summary.json")[k]
                             for k in ("hidden_windows", "hidden_windows_at_end")}
    result["checks_passed"] = True
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(OUT), "cases": len(result["native_cases"]), "checks_passed": True}))


if __name__ == "__main__":
    main()
