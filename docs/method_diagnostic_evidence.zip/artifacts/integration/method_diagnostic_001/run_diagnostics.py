"""Preregister and run the approved two B/B diagnostics and one B resource probe."""

from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
from zipfile import ZIP_DEFLATED, ZipFile


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT))

from artifacts.integration.method_diagnostic_001.runtime_identity import (
    THREAD_ENV, effective_environment, identity, write_json,
)


BLENDER = Path(r"C:\Program Files\Blender Foundation\Blender 5.2\blender.exe")
LEGACY = HERE.parent / "preflight_002"
ORIGINAL = LEGACY / "manifest.json"
ORIGINAL_SHA = "62e2d7ad5a2e26088b95bece1e7f0908e00444775dee4d6e92d9e33f7f59a4ab"
REVIEW = ROOT / "docs/radical_acceptance_integration_rework.json"
PHASES = ("bb-p0", "bb-p1", "resource")


def relative(path):
    return path.resolve().relative_to(ROOT).as_posix()


def hash_bytes(data):
    return sha256(data).hexdigest()


def sources():
    paths = {*ROOT.glob("human_eye_fast/**/*.py"), *ROOT.glob("verification/**/*.py"),
             *ROOT.glob("docs/ENGINE_INTEGRATION*.md"), *LEGACY.glob("*.py"),
             *HERE.glob("*.py"), REVIEW}
    return {relative(path): path.read_bytes() for path in sorted(paths)}


def input_files(previous, review, phase):
    bb = previous["method_probe"]["bb"]
    deployment = previous["deployments"][bb["deployment_process_index"]]
    assert int(deployment["seed"]) == 20261105
    records = {relative(ORIGINAL): ORIGINAL_SHA,
               relative(REVIEW): identity(REVIEW)["sha256"],
               deployment["sealed_path"]: deployment["sealed_sha256"]}
    evidence_root = bb["archived_feedback_root"]
    cases = ("I-open-tip-0",) if phase == "resource" else tuple(bb["archived_feedback"])
    for case in cases:
        for row in bb["archived_feedback"][case]:
            records[f"{evidence_root}/{row['archive_record']}"] = row["archive_record_sha256"]
            records[f"{evidence_root}/{case}/{row['attachment_key']}"] = row["png_sha256"]
    for path, source in review["sources"].items():
        records[path] = source["sha256"]
    return records


def verify_inputs(registered):
    for path, expected in registered.items():
        if identity(ROOT / path)["sha256"] != expected:
            raise RuntimeError(f"Registered input changed: {path}")


def preregister(original, review, source_bytes):
    manifest_path = HERE / "manifest.json"
    source_hashes = {path: hash_bytes(data) for path, data in source_bytes.items()}
    executable = identity(BLENDER)
    python_launcher = identity(sys.executable)
    overrides = {**THREAD_ENV, "PYTHONDONTWRITEBYTECODE": "1"}
    jobs = []
    for index, phase in enumerate(PHASES):
        folder = HERE / phase
        probe = "resource_diagnostic.py" if phase == "resource" else "bb_diagnostic.py"
        if folder.exists():
            raise FileExistsError(folder)
        overrides_for_job = {**overrides, "PYTHONPYCACHEPREFIX": str(folder / "isolated-pycache")}
        environment = {**os.environ, **overrides_for_job}
        records = input_files(original, review, phase)
        verify_inputs(records)
        jobs.append({
            "phase": phase, "process_index": index if phase != "resource" else None,
            "entry": relative(HERE / probe), "inputs": records,
            "argv": list(map(os.fspath, [
                BLENDER, "--background", "--factory-startup", "--disable-autoexec", "--threads", "1",
                "--python-exit-code", "1", "--python", HERE / "worker.py", "--",
                "--phase", phase, "--manifest", manifest_path, "--folder", folder,
            ])),
            "environment_overrides": overrides_for_job,
            "environment_effective": effective_environment(environment),
        })
    old_bb = original["method_probe"]["bb"]
    manifest = {
        "scope": "42ddcf2 B/B next and resource method diagnostics only. Exactly 2+1 serial Blender workers.",
        "frozen_review": {"commit_prefix": "42ddcf2", "decision": review["decision"]},
        "approved_test": "seed 20261105, ordinals 0/1/20, 5 warm and 31 measured pairs per case",
        "deployments": original["deployments"],
        "formal_plans": original["formal_plans"],
        "method_probe": original["method_probe"],
        "bb_diagnostic": {
            "seed": 20261105, "case_ordinals": [0, 1, 20],
            "warm_pair_indices": old_bb["warm_pair_indices"],
            "measured_pair_indices": old_bb["measured_pair_indices"],
            "processes": [{"process_index": 0, "lane_creation_order": [0, 1]},
                          {"process_index": 1, "lane_creation_order": [1, 0]}],
            "execution_order": "(process_index + case_ordinal + pair_index) % 2",
            "threshold": 1.05, "any_gate_observation_does_not_qualify_formal_method": True,
            "within_interval_instrumentation": "one extra QPC timestamp separating next observe and predict; GC callback records timestamps",
            "outside_interval_instrumentation": "actual PNG/plan/CF and active model comparison and artifact writes after t4",
        },
        "resource": {
            "case": "I-open-tip-0", "seed": 20261105, "complete_chains": 1,
            "preflight_manifest_path": relative(ORIGINAL), "preflight_manifest_sha256": ORIGINAL_SHA,
            "adapter_description": "NVIDIA GeForce RTX 3060", "adapter_luid": [0, 83164],
            "node": 0, "interval_ns": 2_000_000,
            "scope": "traced hot window and PID/LUID/node current readings; sampled visible peaks only",
        },
        "registration_environment": {
            "blender_executable": executable, "launcher_python_executable": python_launcher,
            "launcher_python_version": sys.version,
        },
        "source_superset": source_hashes,
        "jobs": jobs,
    }
    with ZipFile(HERE / "sources.zip", "x", compression=ZIP_DEFLATED) as archive:
        for path, data in source_bytes.items():
            archive.writestr(path, data)
    write_json(manifest_path, manifest)
    return manifest_path, manifest


def run_job(job, manifest_path, manifest_identity, source_bytes):
    if source_bytes != sources():
        raise RuntimeError("Frozen source bytes changed before the registered worker")
    if identity(manifest_path) != manifest_identity:
        raise RuntimeError("Registration manifest changed")
    verify_inputs(job["inputs"])
    environment = {**os.environ, **job["environment_overrides"]}
    if effective_environment(environment) != job["environment_effective"]:
        raise RuntimeError("Effective environment changed from registration")
    folder = HERE / job["phase"]
    folder.mkdir()
    write_json(folder / "launch.json", {**job, "manifest_identity": manifest_identity})
    print(f"Starting registered {job['phase']}", flush=True)
    with (folder / "worker.log").open("wb") as output:
        completed = subprocess.run(job["argv"], cwd=ROOT, env=environment,
                                   stdout=output, stderr=subprocess.STDOUT, check=False)
    stable_sources = source_bytes == sources()
    stable_inputs = identity(manifest_path) == manifest_identity
    try:
        verify_inputs(job["inputs"])
    except RuntimeError:
        stable_inputs = False
    imports_path = folder / "project-imports.json"
    observed = json.loads(imports_path.read_bytes())["modules"] if imports_path.exists() else {}
    discrepancies = [name for name, item in observed.items()
                     if item["path"] not in source_bytes
                     or hash_bytes(source_bytes[item["path"]]) != item["sha256"]]
    runtime_path = folder / "runtime.json"
    runtime = json.loads(runtime_path.read_bytes()) if runtime_path.exists() else None
    stable_runtime_environment = bool(runtime and runtime["environment"] == job["environment_effective"])
    record = {"exit_code": completed.returncode, "stable_sources": stable_sources,
              "stable_inputs": stable_inputs, "observed_project_imports": len(observed),
              "import_discrepancies": discrepancies, "runtime_observed": runtime is not None,
              "stable_runtime_environment": stable_runtime_environment}
    write_json(folder / "process.json", record)
    print(f"Finished {job['phase']}: {record}", flush=True)
    return (completed.returncode == 0 and stable_sources and stable_inputs and observed
            and not discrepancies and stable_runtime_environment)


def main():
    if (HERE / "manifest.json").exists():
        raise FileExistsError("Existing diagnostic registration is immutable")
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    if not head.startswith("42ddcf2"):
        raise RuntimeError(f"Expected frozen B tree at 42ddcf2, got {head}")
    subprocess.run(["git", "diff", "--exit-code", "HEAD", "--", "human_eye_fast", "verification",
                    "docs/ENGINE_INTEGRATION_API.md", "docs/ENGINE_INTEGRATION_REWORK_REVIEW.md",
                    "docs/radical_acceptance_integration_rework.json"], cwd=ROOT, check=True)
    original = json.loads(ORIGINAL.read_bytes())
    review = json.loads(REVIEW.read_bytes())
    assert review["decision"] == "ACCEPT_API_ONLY_COST_NOT_QUALIFIED"
    source_bytes = sources()
    manifest_path, manifest = preregister(original, review, source_bytes)
    manifest_identity = identity(manifest_path)
    print(f"Registered all three diagnostics: {manifest_identity['sha256']}", flush=True)
    results = [run_job(job, manifest_path, manifest_identity, source_bytes)
               for job in manifest["jobs"]]
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
