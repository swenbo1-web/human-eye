"""Crossed two-process B/B diagnostic for the frozen 42ddcf2 baseline."""

from contextlib import ExitStack
from dataclasses import asdict, dataclass
import gc
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np

from artifacts.integration.preflight_002 import bb_probe as old


@dataclass
class Lane:
    control: object
    renderer: object
    model: object
    initial: tuple
    reference: object
    reset: object
    basis: object


def _active_arrays(model):
    arrays = {
        "v_weights": model.view_head.weights,
        "a_weights": model.action_head.weights,
    }
    for name, bank in (("v", model.views), ("a", model.actions)):
        assert len(bank) == bank.writes and bank.writes < bank.capacity
        arrays[f"{name}_writes"] = np.array(bank.writes, dtype="<i8")
        for attr in ("keys", "values", "known"):
            arrays[f"{name}_{attr}"] = getattr(bank, attr)[:bank.writes]
    return arrays


def _arrays_digest(arrays):
    digest = sha256()
    for name, array in arrays.items():
        digest.update(json.dumps((name, array.dtype.str, array.shape),
                                 separators=(",", ":")).encode())
        digest.update(memoryview(array).cast("B"))
    return digest.hexdigest()


def _save_state(directory, model):
    arrays = _active_arrays(model)
    key = _arrays_digest(arrays)
    path = directory / f"{key}.npz"
    if not path.exists():
        np.savez(path, **arrays)
    return key


def _lane(stack, case, phases, frozen, ref_changes):
    import bpy
    from human_eye_fast.control import Goal
    from human_eye_fast.raycast_saccade_gpu import VGRenderer
    from verification.integration_reference import (
        SharedCaptureControl, reference_from_capture, relative_basis_from_rna,
    )
    from verification.test_integration_preflight import _materialize

    scene, objects = stack.enter_context(_materialize(case))
    moving = objects[case.target_ids[0]]
    with bpy.context.temp_override(scene=scene, view_layer=scene.view_layers[0]):
        renderer = VGRenderer()
    model = frozen.session()
    goal = Goal(*case.target_ids, case.goal_distance_m, case.goal_tolerance_m)
    control = SharedCaptureControl(scene, objects, goal,
                                   generations=phases[0]["topology_generations"],
                                   renderer=renderer, model=model)

    def close_in_context():
        with control.scene_context():
            control.close()

    stack.callback(close_in_context)
    initial = old._state(model)
    assert initial[-1] == (240, 240)
    assert model.views.capacity > 242 and model.actions.capacity > 241
    reference = reference_from_capture(control, control.observe("reference", changes=ref_changes))
    basis = None
    if case.command.kind == "set_shape_key":
        block = moving.data.shape_keys.key_blocks[case.command.key_name]
        q = float(block.value)
        basis = relative_basis_from_rna(moving, case.command.key_name)

        def reset():
            block.value = q
    else:
        assert moving.rotation_mode == "XYZ"
        location = tuple(moving.location)
        rotation = tuple(moving.rotation_euler)
        scale = tuple(moving.scale)

        def reset():
            moving.location = location
            moving.rotation_euler = rotation
            moving.scale = scale

    return Lane(control, renderer, model, initial, reference, reset, basis)


def _next_proof(directory, following, plan, model, names, ids, predictor):
    from mathutils import Vector
    from human_eye_fast.raycast_saccade_gpu import _EPS32, _FIXED, _ORBIT, _transverse

    receipt = following.view
    assert receipt is not None and not receipt.consumed and receipt.arm == "L"
    assert receipt.observation_id == following.readback.observation_id == names["next"]
    assert receipt.attachment_key == f"{names['next']}.png"
    assert plan.action.before_observation_id == names["next"]
    assert plan.action.action_id == ids["next-act"] and not plan.consumed
    assert plan.before is following.readback
    png = following.attachments[receipt.attachment_key]
    png_key = old._digest(png)
    png_path = directory / f"{png_key}.png"
    if not png_path.exists():
        png_path.write_bytes(png)

    surface = following.readback.surface
    axis = (Vector(surface.point_b) - Vector(surface.point_a)).normalized()
    u = _transverse(_FIXED, axis)
    u = u.normalized() if u.length_squared > _EPS32**2 else axis.orthogonal().normalized()
    v = axis.cross(u).normalized()
    canonical = [tuple((c*u + s*v).normalized()) for c, s in _ORBIT]
    ranked = model.rank_view(receipt.features, receipt.arm)
    selected = following.fact.image.rendered.metadata["selection"]
    probes = selected["probes"]
    visited = [canonical.index(tuple(row["direction"])) for row in probes]
    selected_index = canonical.index(tuple(selected["direction"]))
    assert tuple(visited) == ranked[:len(visited)]
    assert selected_index == receipt.index and selected_index in visited
    assert sum(probe["ray_count"] for probe in probes) == selected["ray_count"]
    selected_probe = probes[visited.index(selected_index)]
    assert selected_probe["ray_count"] == receipt.rays
    assert (selected_probe["target_support"] == 2) == receipt.native_stop
    if predictor == "L":
        assert plan.features is not None and plan.meters is not None
        assert model.predict_delta(plan.features, plan.meters) == plan.action.predicted_delta_m
    else:
        assert plan.features is None and plan.meters is None

    return {
        "image_status": following.image_status,
        "png_sha256": png_key,
        "frame_id": following.readback.frame_id,
        "target_ids": following.readback.target_ids,
        "witness": following.fact.image.rendered.metadata["witness"],
        "canonical_directions": canonical,
        "canonical_rank": ranked,
        "visited_canonical_indices": visited,
        "selected_canonical_index": selected_index,
        "selected_direction": selected["direction"],
        "total_rays": selected["ray_count"],
        "probes": probes,
        "v_input": receipt.features.tolist(),
        "a_predictor": predictor,
        "a_command": asdict(plan.action.command),
        "a_input": None if plan.features is None else plan.features.tolist(),
        "a_meters": plan.meters,
        "predicted_delta_m": plan.action.predicted_delta_m,
    }


def _expected_feedback_state(frozen, lane, before, result, feedback, action_arm):
    expected = frozen.session()
    try:
        view_writes, action_writes = lane.initial[-1]
        for offset, (frame, archived) in enumerate(zip((before, result.after), feedback, strict=True)):
            receipt = frame.view
            assert receipt.consumed and receipt.features is None
            expected.learn_view(lane.model.views.keys[view_writes + offset], receipt.index,
                                archived["safe"], archived["selected_probe_rays"])
        if action_arm == "L":
            ticket = result.action_ticket
            assert ticket.consumed and ticket.features is None
            expected.learn_action(lane.model.actions.keys[action_writes], ticket.meters,
                                  result.outcome.measured_delta_m)
        return _arrays_digest(_active_arrays(expected))
    finally:
        expected.close()


def _case(case, plan, bb, frozen, feedback, out, process_index, creation_order, pristine_digest):
    from verification.integration_reference import (
        ViewFeedback, action_feedback, execute, observe, predict, view_feedback,
    )
    from verification.test_integration_preflight import _command

    clock = time.perf_counter_ns
    case_id = case.spec.case_id
    phases = [plan[name] for name in ("reference_capture", "before", "after_readback_and_publication", "next")]
    ref_changes, before_changes, after_changes, next_changes = map(old._changes, phases)
    mode = case.mode
    action_arm = plan["arms"]["deployment"]["predictor"]
    command = _command(case.command)
    followup_command = _command(case.followup_command)
    reference_proof = None
    expected_state = None
    rows = []

    with ExitStack() as stack:
        lanes = {physical: _lane(stack, case, phases, frozen, ref_changes) for physical in creation_order}
        for pair in (*bb["warm_pair_indices"], *bb["measured_pair_indices"]):
            phase = (process_index + case.spec.ordinal + pair) % 2
            order = (0, 1) if phase == 0 else (1, 0)
            for execution_index, physical in enumerate(order):
                lane = lanes[physical]
                control, renderer, model, reference = lane.control, lane.renderer, lane.model, lane.reference
                lane.reset()
                old._restore(model, lane.initial)
                assert _arrays_digest(_active_arrays(model)) == pristine_digest
                names = {key: fmt.format(pair=pair, lane=physical)
                         for key, fmt in bb["observation_id_templates"].items()}
                ids = {key: fmt.format(pair=pair, lane=physical)
                       for key, fmt in bb["action_id_templates"].items()}
                feedback_values = tuple(ViewFeedback(names[role], f"{names[role]}.png",
                                                     record["canonical_index"], record["strict_verdict"])
                                        for role, record in zip(("before", "after"), feedback, strict=True))

                t0 = clock()
                before = observe(control, renderer, reference, names["before"], mode=mode,
                                 view_arm="L", model=model, changes=before_changes)
                t1 = clock()
                prepared = predict(control, before, command, ids["act"], action_arm=action_arm,
                                   model=model, basis=lane.basis)
                result = execute(control, renderer, reference, before, prepared, names["after"],
                                 mode=mode, view_arm="L", model=model, changes=after_changes)
                t2 = clock()
                view_feedback(control, model, before.view, feedback_values[0])
                view_feedback(control, model, result.after.view, feedback_values[1])
                if result.action_ticket is not None:
                    action_feedback(control, model, result.action_ticket)
                t3 = clock()
                following = observe(control, renderer, reference, names["next"], mode=mode,
                                    view_arm="L", model=model, changes=next_changes)
                t_next_observed = clock()
                next_plan = predict(control, following, followup_command, ids["next-act"],
                                    action_arm=action_arm, model=model, basis=lane.basis)
                t4 = clock()

                row = {
                    "case": case_id, "case_ordinal": case.spec.ordinal, "pair": pair,
                    "warmup": pair in bb["warm_pair_indices"], "physical_lane": physical,
                    "creation_index": creation_order.index(physical), "execution_index": execution_index,
                    "execution_order": order,
                    "counter_ns": {"t0": t0, "t1": t1, "t2": t2, "t3": t3,
                                   "t_next_observed": t_next_observed, "t4": t4},
                    "ns": {"before": t1-t0, "action": t2-t1, "feedback": t3-t2, "next": t4-t3,
                           "continuous_total": t4-t0, "next_observe": t_next_observed-t3,
                           "next_predict": t4-t_next_observed},
                }
                old._append(out / "intervals.jsonl", row)
                rows.append(row)
                for frame, archive in zip((before, result.after), feedback, strict=True):
                    old._verify_frame(frame, archive, frame.fact.image.rendered.metadata["selection"], out)
                assert model.views.writes == lane.initial[-1][0] + 2
                assert model.actions.writes == lane.initial[-1][1] + int(action_arm == "L")
                assert result.outcome.before.frame_id == result.outcome.after.frame_id
                state = _save_state(out / "states", model)
                if expected_state is None:
                    expected_state = _expected_feedback_state(frozen, lane, before, result, feedback, action_arm)
                proof = _next_proof(out / "png", following, next_plan, model, names, ids, action_arm)
                proof_key = old._digest(json.dumps(proof, allow_nan=False, sort_keys=True,
                                                   separators=(",", ":")).encode())
                if reference_proof is None:
                    reference_proof = proof_key
                old._append(out / "next_and_state.jsonl", {
                    "case": case_id, "pair": pair, "physical_lane": physical,
                    "next_observation_id": names["next"], "next_attachment_key": following.view.attachment_key,
                    "next_action_id": ids["next-act"], "next_ticket_consumed": following.view.consumed,
                    "state_sha256": state, "expected_state_sha256": expected_state,
                    "matches_expected_active_state": state == expected_state,
                    "next_work_sha256": proof_key, "expected_next_work_sha256": reference_proof,
                    "matches_first_next_work": proof_key == reference_proof, "next": proof,
                })
                row["next_and_state_equivalent"] = state == expected_state and proof_key == reference_proof
                del before, result, following, next_plan, prepared
    return rows


def _summarize(cases, original_segments):
    segments = {}
    for segment in (*original_segments, "next_observe", "next_predict"):
        descriptions = {}
        for key, rows in cases.items():
            measured = [row for row in rows if not row["warmup"]]
            lanes = [[row for row in measured if row["physical_lane"] == lane] for lane in (0, 1)]
            durations = [[row["ns"][segment] for row in arm] for arm in lanes]
            pair_differences = [b-a for a, b in zip(*durations, strict=True)]
            descriptions[key] = {
                "lane_medians_ns": [float(np.median(values)) for values in durations],
                "lane_medians_by_execution_index_ns": [
                    [float(np.median([row["ns"][segment] for row in arm
                                      if row["execution_index"] == position]))
                     for position in (0, 1)] for arm in lanes
                ],
                "paired_lane_1_minus_0_ns": pair_differences,
                "paired_difference_median_ns": float(np.median(pair_differences)),
                "paired_difference_p95_ns": float(np.quantile(pair_differences, .95, method="linear")),
                "ABBA_adjacent_pair_mean_differences_ns": [
                    (pair_differences[index] + pair_differences[index+1]) / 2
                    for index in range(0, len(pair_differences)-1, 2)
                ],
                "ABBA_unpaired_last_difference_ns": pair_differences[-1],
                "chronological_third_lane_medians_ns": [
                    [float(np.median(block)) for block in np.array_split(values, 3)]
                    for values in durations
                ],
            }
        p95 = np.quantile([case["lane_medians_ns"] for case in descriptions.values()],
                          .95, axis=0, method="linear").tolist()
        ratios = [p95[0]/p95[1], p95[1]/p95[0]]
        segments[segment] = {"case_descriptives": descriptions, "lane_p95_ns": p95, "ratios": ratios,
                             "original_gate_segment": segment in original_segments,
                             "within_5_percent": max(ratios) <= 1.05 if segment in original_segments else None}
    return segments


def _anchor():
    before = time.perf_counter_ns()
    utc = time.time_ns()
    after = time.perf_counter_ns()
    return {"counter_before_ns": before, "utc_unix_ns": utc, "counter_after_ns": after}


def run(manifest_path, out_dir, process_index):
    import bpy
    import gpu
    from verification.cf_training import load_frozen
    from verification.integration_fixtures import build_fixture, fixture_manifest

    assert bpy.app.background
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    for name in ("states", "png"):
        (out_dir / name).mkdir()
    manifest_path = Path(manifest_path)
    manifest = old._load(manifest_path)
    settings = manifest["bb_diagnostic"]
    process = settings["processes"][process_index]
    creation_order = process["lane_creation_order"]
    assert process["process_index"] == process_index
    assert creation_order == ([0, 1] if process_index == 0 else [1, 0])
    bb = manifest["method_probe"]["bb"]
    assert bb["warm_pair_indices"] == list(range(5)) and bb["measured_pair_indices"] == list(range(5, 36))
    feedback, reads = old._archive_feedback(bb)
    deployment = manifest["deployments"][bb["deployment_process_index"]]
    assert int(deployment["seed"]) == settings["seed"] == 20261105
    snapshot = ROOT / deployment["sealed_path"]
    model_data = snapshot.read_bytes()
    assert old._digest(model_data) == deployment["sealed_sha256"]
    reads.append({"path": deployment["sealed_path"], "sha256": deployment["sealed_sha256"]})
    frozen = load_frozen(BytesIO(model_data))
    initial_model = frozen.session()
    pristine = _save_state(out_dir / "states", initial_model)
    initial_model.close()

    start_anchor = _anchor()
    empty = []
    for _ in range(1000):
        a = time.perf_counter_ns()
        b = time.perf_counter_ns()
        empty.append(b-a)
    old._write(out_dir / "clock.json", {"start_anchor": start_anchor, "clock": vars(time.get_clock_info("perf_counter")),
                                       "empty_ns": empty})
    gc_events = []
    active_gc = []

    def gc_event(event, info):
        counter_ns = time.perf_counter_ns()
        if event == "start":
            active_gc.append(counter_ns)
        duration = counter_ns - active_gc.pop() if event == "stop" and active_gc else None
        gc_events.append({"counter_ns": counter_ns, "event": event, "duration_ns": duration, **info})

    gc.callbacks.append(gc_event)
    start_gc = {"enabled": gc.isenabled(), "thresholds": gc.get_threshold(), "counts": gc.get_count()}
    try:
        specs = {spec.case_id: spec for spec in fixture_manifest()}
        plans = {row["case_id"]: row for row in manifest["formal_plans"]}
        assert [specs[key].ordinal for key in bb["case_ids"]] == settings["case_ordinals"] == [0, 1, 20]
        cases = {key: _case(build_fixture(specs[key]), plans[key], bb, frozen, feedback[key],
                            out_dir, process_index, creation_order, pristine) for key in bb["case_ids"]}
    finally:
        gc.callbacks.remove(gc_event)
        old._write(out_dir / "gc.json", {"start": start_gc, "end_counts": gc.get_count(), "events": gc_events})
        old._write(out_dir / "time_anchors.json", {"start": start_anchor, "end": _anchor()})

    segments = _summarize(cases, bb["segments"])
    work_equal = all(row["next_and_state_equivalent"] for rows in cases.values() for row in rows)
    old._write(out_dir / "summary.json", {
        "scope": "one process of two crossed B/B diagnostic processes; no production I or method requalification",
        "process_index": process_index,
        "physical_lane_creation_order": creation_order,
        "manifest_sha256": old._digest(manifest_path.read_bytes()),
        "actual_data_reads": reads,
        "blender": bpy.app.version_string,
        "gpu": gpu.platform.renderer_get(),
        "pristine_state_sha256": pristine,
        "next_work_and_active_state_equivalent": work_equal,
        "original_gate_within_this_process": all(segments[name]["within_5_percent"] for name in bb["segments"]),
        "segments": segments,
        "instrumentation": "GC callback and one additional QPC timestamp within next; hashing, comparisons, PNG/NPZ/JSON output and pristine checks outside t0..t4 can affect cadence.",
        "comparison": "Exact state/normalized next work against first repeat and both physical lanes; expected first feedback state reproduced offline from actual bank input keys and bound archived safe/ray labels plus actual measured A delta.",
        "all_rays": "Existing VG selection exposes direction-by-direction full probe counts and outcomes, not individual native BVH ray geometry.",
        "project_imports": old._project_imports(),
    })
    if not work_equal:
        raise AssertionError("Next-work or active state equivalence failed. Full raw results retained.")
