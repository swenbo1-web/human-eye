"""Measure instrumentation visibility for one frozen B resource chain."""

from contextlib import ExitStack
from ctypes import (
    POINTER, Structure, WinDLL, byref, c_int32, c_int64, c_size_t, c_uint32,
    c_void_p, get_last_error, sizeof,
)
from hashlib import sha256
from io import BytesIO
import json
import os
from pathlib import Path
import threading
import time
import tracemalloc

import numpy as np

from artifacts.integration.preflight_002.bb_probe import _changes, _verify_frame
from artifacts.integration.preflight_002.resource_probe import DxgiProcessUsage, VideoInfo


ROOT = Path(__file__).resolve().parents[3]
_CLOCK = time.perf_counter_ns
_SAMPLE_CAPACITY = 4096


class _Counters(Structure):
    _fields_ = [
        ("cb", c_uint32),
        ("PageFaultCount", c_uint32),
        ("PeakWorkingSetSize", c_size_t),
        ("WorkingSetSize", c_size_t),
        ("QuotaPeakPagedPoolUsage", c_size_t),
        ("QuotaPagedPoolUsage", c_size_t),
        ("QuotaPeakNonPagedPoolUsage", c_size_t),
        ("QuotaNonPagedPoolUsage", c_size_t),
        ("PagefileUsage", c_size_t),
        ("PeakPagefileUsage", c_size_t),
        ("PrivateUsage", c_size_t),
    ]


class _Sample(Structure):
    _fields_ = [
        ("scheduled_qpc_ns", c_int64),
        ("start_qpc_ns", c_int64),
        ("end_qpc_ns", c_int64),
        ("process", _Counters),
        ("local", VideoInfo),
        ("nonlocal", VideoInfo),
        ("win32_error", c_uint32),
        ("local_hresult", c_int32),
        ("nonlocal_hresult", c_int32),
    ]


def _fields(structure):
    return {name: getattr(structure, name) for name, _ in structure._fields_}


def _record(sample):
    row = _fields(sample)
    row["process"] = _fields(row["process"])
    row["local"] = _fields(row["local"])
    row["nonlocal"] = _fields(row["nonlocal"])
    return row


class _Sampler:
    """Collect native counters into preallocated storage in the measured PID."""

    def __init__(self, dxgi, interval_ns, node):
        self.dxgi = dxgi
        self.interval_ns = interval_ns
        self.node = node
        dll = WinDLL("kernel32", use_last_error=True)
        dll.GetCurrentProcess.restype = c_void_p
        self.handle = dll.GetCurrentProcess()
        self.get_memory = dll.K32GetProcessMemoryInfo
        self.get_memory.argtypes = (c_void_p, POINTER(_Counters), c_uint32)
        self.get_memory.restype = c_int32
        self.samples = (_Sample * _SAMPLE_CAPACITY)()
        self.count = 0
        self.error = None
        self.ready = threading.Event()
        self.started = threading.Event()
        self.stopped = threading.Event()
        self.thread = threading.Thread(target=self._poll, name="B-resource-qpc-sampler")

    def _capture(self, sample, scheduled):
        sample.scheduled_qpc_ns = scheduled
        sample.start_qpc_ns = _CLOCK()
        counters = sample.process
        counters.cb = sizeof(_Counters)
        if not self.get_memory(self.handle, byref(counters), counters.cb):
            sample.win32_error = get_last_error()
        sample.local_hresult = self.dxgi.query(self.dxgi.adapter, self.node, 0, byref(sample.local))
        sample.nonlocal_hresult = self.dxgi.query(
            self.dxgi.adapter, self.node, 1, byref(getattr(sample, "nonlocal")))
        sample.end_qpc_ns = _CLOCK()

    def _poll(self):
        self.ready.set()
        self.started.wait()
        target = _CLOCK()
        try:
            while not self.stopped.is_set() and self.count < len(self.samples):
                delay_ns = target - _CLOCK()
                if delay_ns > 0 and self.stopped.wait(delay_ns / 1e9):
                    break
                self._capture(self.samples[self.count], target)
                self.count += 1
                target += self.interval_ns
                now = _CLOCK()
                if target < now:
                    target += ((now - target) // self.interval_ns + 1) * self.interval_ns
        except Exception as error:
            self.error = repr(error)

    def prepare(self):
        self.thread.start()
        self.ready.wait()

    def stop(self):
        self.stopped.set()
        self.started.set()
        self.thread.join()

    def point(self, phase):
        sample = _Sample()
        self._capture(sample, _CLOCK())
        return {"phase": phase, **_record(sample)}

    def records(self):
        return [_record(self.samples[i]) for i in range(self.count)]


def _numpy_inventory(roots):
    """Attribute unique backing owners across explicitly declared roots."""
    owners = {}
    per_root = {}
    for name, root in roots.items():
        visited = set()
        reachable = set()

        def visit(value):
            identity = id(value)
            if identity in visited:
                return
            visited.add(identity)
            if isinstance(value, np.ndarray):
                owner = value
                while True:
                    if isinstance(owner, memoryview):
                        base = owner.obj
                    else:
                        base = getattr(owner, "base", None)
                    if base is None:
                        break
                    owner = base
                identity = id(owner)
                owners[identity] = memoryview(owner).nbytes
                reachable.add(identity)
            elif isinstance(value, dict):
                for child in value.values():
                    visit(child)
            elif isinstance(value, (tuple, list)):
                for child in value:
                    visit(child)
            elif type(value).__module__.startswith(("human_eye_fast.", "verification.integration_reference")):
                if hasattr(value, "__dict__"):
                    visit(vars(value))
                for cls in type(value).__mro__:
                    slots = getattr(cls, "__slots__", ())
                    if isinstance(slots, str):
                        slots = (slots,)
                    for slot in slots:
                        if hasattr(value, slot):
                            visit(getattr(value, slot))

        visit(root)
        per_root[name] = reachable

    def summarize(identities):
        return {"unique_backings": len(identities), "backing_bytes": sum(owners[i] for i in identities)}

    return {"per_root_may_overlap": {name: summarize(ids) for name, ids in per_root.items()},
            "deduplicated": summarize(owners)}


class _OffscreenRelease:
    """Audit the real GPUOffScreen.free call outside the hot trace window."""

    def __init__(self, target):
        self.target = target
        self.completed_calls = 0

    def free(self):
        self.target.free()
        self.completed_calls += 1
        self.target = None


def _digest(data):
    return sha256(data).hexdigest()


def _registered_bytes(path, expected, reads):
    data = (ROOT / path).read_bytes()
    actual = _digest(data)
    if actual != expected:
        raise ValueError(f"Registered input changed: {path}")
    reads.append({"path": path, "sha256": actual})
    return data


def _write(path, value):
    path.write_text(json.dumps(value, allow_nan=False, indent=2) + "\n", encoding="utf-8")


def _feedback_inputs(registration, case_id, reads):
    bb = registration["method_probe"]["bb"]
    rows = bb["archived_feedback"][case_id]
    root = Path(bb["archived_feedback_root"])
    for row in rows:
        visual = _registered_bytes((root / row["archive_record"]).as_posix(),
                                   row["archive_record_sha256"], reads)
        _registered_bytes((root / case_id / row["attachment_key"]).as_posix(),
                          row["png_sha256"], reads)
        score = json.loads(visual)["score"]
        assert score["passed"] == row["strict_verdict"] and score["safe"] == row["safe"]
    return rows


def _roots(control, reference, model, renderer, *, caller_outputs=(), caller_tickets=(),
           internal_results=()):
    return {
        "session_reference": control.reference,
        "session_model": control._model,
        "session_bridge": control.bridge,
        "session_indexes": control._indexes,
        "session_renderer": control._renderer,
        "session_current_readback": control._latest,
        "fixture_supplied_reference": reference,
        "diagnostic_model_shell": model,
        "diagnostic_renderer_shell": renderer,
        "caller_output_bytes": caller_outputs,
        "caller_tickets": caller_tickets,
        "internal_B_return_facts": internal_results,
    }


def _archive_outputs(out_dir, outputs):
    from human_eye_fast.fast_affordance_out import public_schema

    columns = public_schema()["columns"]
    directory = out_dir / "outputs"
    directory.mkdir()
    attachment_keys = set()
    recorded = {}
    for name, data in outputs.items():
        assert isinstance(data, bytes)
        if name.endswith(".ao.json"):
            package = dict(zip(columns["package"], json.loads(data), strict=True))
            assert package["version"] == "he-ao/1"
            for item in package["observations"]:
                observation = dict(zip(columns["observation"], item, strict=True))
                image = dict(zip(columns["image"], observation["image"], strict=True))
                assert image["path"] == observation["observation_id"] + ".png"
                attachment_keys.add(image["path"])
        else:
            assert data.startswith(b"\x89PNG\r\n\x1a\n")
        (directory / name).write_bytes(data)
        recorded[name] = {"bytes": len(data), "sha256": _digest(data)}
    assert attachment_keys == {name for name in outputs if name.endswith(".png")}
    return recorded


def _sample_summary(rows, interval, start, end):
    hot = [row for row in rows if start <= row["start_qpc_ns"] and row["end_qpc_ns"] <= end]
    starts = [row["start_qpc_ns"] for row in rows]
    gaps = [right - left for left, right in zip(starts, starts[1:])]
    hot_anchors = [start, *(row["start_qpc_ns"] for row in hot), end]
    hot_gaps = [right - left for left, right in zip(hot_anchors, hot_anchors[1:])]
    valid = [row for row in hot if not row["win32_error"]
             and row["local_hresult"] >= 0 and row["nonlocal_hresult"] >= 0]
    peaks = None
    if valid:
        peaks = {"working_set_bytes": max(row["process"]["WorkingSetSize"] for row in valid),
                 "dxgi_local_current_usage_bytes": max(row["local"]["current_usage"] for row in valid),
                 "dxgi_nonlocal_current_usage_bytes": max(row["nonlocal"]["current_usage"] for row in valid)}
    return {"target_interval_ns": interval, "samples": len(rows), "wholly_in_hot_window": len(hot),
            "valid_hot_samples": len(valid), "maximum_observed_start_gap_ns": max(gaps, default=None),
            "maximum_hot_gap_including_boundaries_ns": max(hot_gaps),
            "maximum_query_duration_ns": max((row["end_qpc_ns"] - row["start_qpc_ns"] for row in rows),
                                             default=None),
            "sampled_hot_peaks": peaks}


def run(manifest_path, out_dir):
    import bpy
    import gpu
    from human_eye_fast.control import Goal
    from human_eye_fast.raycast_saccade_gpu import VGRenderer
    from verification.cf_training import load_frozen
    from verification.integration_fixtures import build_fixture, fixture_manifest
    from verification.integration_reference import (
        SharedCaptureControl, ViewFeedback, action_feedback, execute, observe, predict,
        reference_from_capture, view_feedback,
    )
    from verification.test_integration_preflight import _command, _materialize

    assert bpy.app.background
    manifest_path, out_dir = Path(manifest_path), Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    raw = manifest_path.read_bytes()
    registration = json.loads(raw)
    config = registration["resource"]
    reads = []
    _registered_bytes(config["preflight_manifest_path"], config["preflight_manifest_sha256"], reads)
    case_id = "I-open-tip-0"
    interval = config["interval_ns"]
    assert interval == 2_000_000 and config["node"] == 0
    plan = next(row for row in registration["formal_plans"] if row["case_id"] == case_id)
    deployed = registration["deployments"][0]
    assert deployed["seed"] == "20261105"
    feedback = _feedback_inputs(registration, case_id, reads)
    report = {
        "scope": "One frozen B resource chain; sampled visibility only, no I comparison.",
        "manifest_sha256": _digest(raw),
        "actual_registered_reads": reads,
        "case": case_id,
        "seed": deployed["seed"],
        "pid": os.getpid(),
        "node": config["node"],
        "clock": vars(time.get_clock_info("perf_counter")),
        "phase_points": [],
        "managed_checkpoints": {},
        "numpy_inventory": {},
        "limits": [
            "QPC sampling runs in a Python thread in this PID. GIL, scheduler and native queries can delay samples.",
            "A sampled maximum cannot detect a transient between samples. The Win32 lifetime peak is separate.",
            "Traced current/peak includes any Python sampler churn in the window. Native sampling storage was preallocated before tracing.",
            "NumPy backing bytes are a separate attribution inventory. Do not add them to traced bytes.",
            "Frozen B facts borrow internal mesh arrays. Only immutable AO/PNG bytes and caller-held tickets survive the close check.",
        ],
    }
    points = report["phase_points"]
    managed = report["managed_checkpoints"]
    owners = report["numpy_inventory"]
    phases = [plan[name] for name in ("reference_capture", "before", "after_readback_and_publication", "next")]
    ref_phase, before_phase, after_phase, next_phase = phases
    ref_changes, before_changes, after_changes, next_changes = map(_changes, phases)
    view_arm = plan["arms"]["deployment"]["view"]
    action_arm = plan["arms"]["deployment"]["predictor"]

    with ExitStack() as stack:
        dxgi = DxgiProcessUsage(stack, config["adapter_description"])
        assert dxgi.identity["luid"] == config["adapter_luid"]
        sampler = _Sampler(dxgi, interval, config["node"])
        report["dxgi_adapter"] = dxgi.identity
        left = _CLOCK()
        utc = time.time_ns()
        report["clock_anchor"] = {"qpc_before_ns": left, "utc_unix_ns": utc, "qpc_after_ns": _CLOCK()}
        tracemalloc.start()
        stack.callback(tracemalloc.stop)
        managed["cold_before_session"] = dict(zip(("current_bytes", "cumulative_peak_bytes"),
                                                  tracemalloc.get_traced_memory(), strict=True))
        points.append(sampler.point("cold_before_session"))
        case = build_fixture(fixture_manifest()[0])
        assert case.spec.case_id == case_id
        with _materialize(case) as (scene, objects):
            model_data = _registered_bytes(deployed["sealed_path"], deployed["sealed_sha256"], reads)
            model = load_frozen(BytesIO(model_data)).session()
            del model_data
            goal = Goal(*case.target_ids, case.goal_distance_m, case.goal_tolerance_m)
            with bpy.context.temp_override(scene=scene, view_layer=scene.view_layers[0]):
                renderer = VGRenderer()
            control = SharedCaptureControl(scene, objects, goal,
                                           generations=ref_phase["topology_generations"],
                                           renderer=renderer, model=model)
            try:
                gpu_renderer = gpu.platform.renderer_get()
                assert config["adapter_description"].casefold() in gpu_renderer.casefold()
                report["gpu"] = {"renderer": gpu_renderer, "backend": gpu.platform.backend_type_get()}
                managed["after_init"] = dict(zip(("current_bytes", "cumulative_peak_bytes"),
                                                 tracemalloc.get_traced_memory(), strict=True))
                points.append(sampler.point("after_init"))
                reference = reference_from_capture(
                    control, control.observe(ref_phase["observation_id"], changes=ref_changes))
                control.replace_reference(reference)
                owners["after_reference"] = _numpy_inventory(_roots(control, reference, model, renderer))
                commands = (_command(case.command), _command(case.followup_command))
                requests = tuple(ViewFeedback(row["observation_id"], row["attachment_key"],
                                              row["canonical_index"], row["strict_verdict"])
                                 for row in feedback)
                counts = model.views.writes, model.actions.writes
                points.append(sampler.point("before_hot_reset"))
                sampler.prepare()
                try:
                    pre_current = tracemalloc.get_traced_memory()[0]
                    tracemalloc.reset_peak()
                    t0 = _CLOCK()
                    sampler.started.set()
                    before = observe(control, renderer, reference, before_phase["observation_id"],
                                     mode=before_phase["mode"], view_arm=view_arm, model=model,
                                     top_k=before_phase["td_top_k"], changes=before_changes)
                    t1 = _CLOCK()
                    planned = predict(control, before, commands[0], plan["first_command"]["action_id"],
                                      action_arm=action_arm, model=model)
                    result = execute(control, renderer, reference, before, planned, after_phase["observation_id"],
                                     mode=after_phase["mode"], view_arm=view_arm, model=model,
                                     top_k=after_phase["td_top_k"], changes=after_changes)
                    t2 = _CLOCK()
                    view_feedback(control, model, before.view, requests[0])
                    view_feedback(control, model, result.after.view, requests[1])
                    if result.action_ticket is not None:
                        action_feedback(control, model, result.action_ticket)
                    t3 = _CLOCK()
                    following = observe(control, renderer, reference, next_phase["observation_id"],
                                        mode=next_phase["mode"], view_arm=view_arm, model=model,
                                        top_k=next_phase["td_top_k"], changes=next_changes)
                    next_plan = predict(control, following, commands[1],
                                        plan["next_command_prediction_only"]["action_id"],
                                        action_arm=action_arm, model=model)
                    t4 = _CLOCK()
                    end_current, hot_peak = tracemalloc.get_traced_memory()
                finally:
                    sampler.stop()
                    points.append(sampler.point("after_hot_before_audit"))
                    samples = sampler.records()
                    _write(out_dir / "samples.json", {"pid": report["pid"], "adapter": dxgi.identity,
                                                      "node": config["node"], "periodic": samples})

                managed["hot_window"] = {"current_before_reset_bytes": pre_current,
                                         "current_at_return_bytes": end_current,
                                         "peak_since_reset_bytes": hot_peak,
                                         "peak_above_start_bytes": hot_peak - pre_current}
                report["chain_boundaries_qpc_ns"] = dict(zip(
                    ("t0_before", "t1_action", "t2_feedback", "t3_next", "t4_return"),
                    (t0, t1, t2, t3, t4), strict=True))
                report["sampling"] = _sample_summary(samples, interval, t0, t4)
                report["sampling"].update({"sampler_error": sampler.error,
                                           "storage_saturated": sampler.count == len(sampler.samples)})
                for frame, expected in zip((before, result.after), feedback, strict=True):
                    _verify_frame(frame, expected, frame.fact.image.rendered.metadata["selection"], out_dir)
                assert next_plan.action.before_observation_id == next_phase["observation_id"]
                assert (model.views.writes, model.actions.writes) == (counts[0] + 2, counts[1] + (action_arm == "L"))
                outputs = {"before.ao.json": before.ao_bytes, "transition.ao.json": result.ao_bytes,
                           "next.ao.json": following.ao_bytes, **result.attachments, **following.attachments}
                tickets = (before.view, result.after.view, result.action_ticket, following.view)
                owners["at_hot_return_before_projection"] = _numpy_inventory(
                    _roots(control, reference, model, renderer, caller_outputs=outputs, caller_tickets=tickets,
                           internal_results=(before, result, following, planned, next_plan)))
                del before, result, following, planned, next_plan
                owners["before_close"] = _numpy_inventory(
                    _roots(control, reference, model, renderer, caller_outputs=outputs, caller_tickets=tickets))

                cameras = [(camera.name, camera.data.name) for camera in renderer.cameras]
                assert all(bpy.data.objects.get(obj) is not None and bpy.data.cameras.get(data) is not None
                           for obj, data in cameras)
                release = _OffscreenRelease(renderer.offscreen)
                renderer.offscreen = release
                control.close()
                managed["after_close_caller_retained"] = {"current_bytes": tracemalloc.get_traced_memory()[0]}
                points.append(sampler.point("after_close_caller_retained"))
                assert release.completed_calls == 1 and release.target is None
                assert all(bpy.data.objects.get(obj) is None and bpy.data.cameras.get(data) is None
                           for obj, data in cameras)
                assert not control.bridge._objects and control._indexes is None and control._latest is None
                assert control.reference is None and control._model is None and control._renderer is None
                assert model.view_head is None and model.action_head is None and model.retrieval_scale is None
                assert all(bank.keys is None and bank.values is None and bank.known is None
                           for bank in (model.views, model.actions))
                assert all(getattr(renderer, key) is None
                           for key in ("rgb", "rgb_deltas", "scanlines", "previous_row"))
                owners["after_close_caller_retained"] = _numpy_inventory(
                    _roots(control, reference, model, renderer, caller_outputs=outputs, caller_tickets=tickets))
                owned_after_close = owners["after_close_caller_retained"]["per_root_may_overlap"]
                assert not any(value["unique_backings"] for key, value in owned_after_close.items()
                               if key.startswith(("session_", "diagnostic_")))
                report["close_checks"] = {"offscreen_free_completed": release.completed_calls,
                                          "camera_objects_and_data_removed": cameras,
                                          "session_numpy_owners_cleared": True,
                                          "old_bytes_read_after_close": _archive_outputs(out_dir, outputs)}
                outputs.clear()
                tickets = ()
                reference = None
                managed["after_external_release"] = {"current_bytes": tracemalloc.get_traced_memory()[0]}
                points.append(sampler.point("after_external_release"))
                owners["after_external_release"] = _numpy_inventory(_roots(control, reference, model, renderer))
                assert owners["after_external_release"]["deduplicated"]["unique_backings"] == 0
            finally:
                control.close()
        points.append(sampler.point("after_fixture_teardown"))
        report["win32_dxgi_current_available"] = (
            all(not row["win32_error"] and row["local_hresult"] >= 0 and row["nonlocal_hresult"] >= 0
                for row in points)
            and bool(report["sampling"]["valid_hot_samples"]) and sampler.error is None
        )
    _write(out_dir / "summary.json", report)
    return report
