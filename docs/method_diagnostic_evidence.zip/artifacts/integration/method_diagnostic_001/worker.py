"""Run one registered probe and preserve its runtime and observed project imports."""

from argparse import ArgumentParser
import json
import os
from pathlib import Path
import sys
import traceback


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.dont_write_bytecode = True
sys.pycache_prefix = os.environ["PYTHONPYCACHEPREFIX"]
sys.path.insert(0, str(ROOT))

from artifacts.integration.method_diagnostic_001.runtime_identity import (
    clock_anchor, identity, native_fingerprint, write_json,
)


def record_project_imports(path, entry):
    observed = {}
    for name, module in tuple(sys.modules.items()):
        raw = getattr(module, "__file__", None)
        if raw:
            file = Path(raw).resolve()
            if file.is_relative_to(ROOT) and file.is_file():
                observed[name] = {"path": file.relative_to(ROOT).as_posix(),
                                  "sha256": identity(file)["sha256"]}
    for file in (Path(__file__), Path(entry)):
        file = file.resolve()
        observed[f"entry:{file.name}"] = {"path": file.relative_to(ROOT).as_posix(),
                                          "sha256": identity(file)["sha256"]}
    write_json(path, {"scope": "observed project imports at exit and explicit entry", "pid": os.getpid(),
                      "modules": observed})


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--phase", choices=("bb-p0", "bb-p1", "resource"), required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--folder", type=Path, required=True)
    args = parser.parse_args(sys.argv[sys.argv.index("--") + 1:])
    manifest = json.loads(args.manifest.read_bytes())
    job = next(job for job in manifest["jobs"] if job["phase"] == args.phase)
    anchor = clock_anchor()
    try:
        if args.phase == "resource":
            from artifacts.integration.method_diagnostic_001 import resource_diagnostic
            resource_diagnostic.run(args.manifest, args.folder / "result")
        else:
            from artifacts.integration.method_diagnostic_001 import bb_diagnostic
            bb_diagnostic.run(args.manifest, args.folder / "result", job["process_index"])
    finally:
        record_project_imports(args.folder / "project-imports.json", ROOT / job["entry"])
        try:
            write_json(args.folder / "runtime.json", native_fingerprint(anchor))
        except Exception:
            (args.folder / "runtime-error.txt").write_text(traceback.format_exc(), encoding="utf-8")


if __name__ == "__main__":
    main()
