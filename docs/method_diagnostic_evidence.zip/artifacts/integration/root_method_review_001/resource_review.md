# method_diagnostic_001 资源方法独立复核

结论：**可以在产生 I 成绩之前冻结主干提出的有限资源测法，不需要再开方法探针。** 托管门使用明确保留态及完整热窗的 I−B 差额；RSS/GPU 门明确命名为 observed sampled maximum，并增加逻辑 GPU 资源等价和关闭/重开的所有权硬门。当前只验证旧 B 的测法及归档，不能给 I 填入任何“资源通过”结果。

本报告按 ZIP 中 `42ddcf2` 的旧 B 源码审查，未修改历史诊断脚本或运行数据，未运行 Blender/GPU。CPU 复算见 `provenance_probe.py/.json`。

## 原始数值和测量范围

| 项目 | 独立复算值 |
| --- | ---: |
| 完整热窗 t0→t4 | 98.4804 ms |
| reset 前 traced current | 6,621,253 B |
| t4 返回时 traced current | 6,818,879 B |
| reset 后 traced peak | 7,445,833 B |
| peak 减 reset 前 current | 824,580 B |
| 目标采样间隔 | 2 ms |
| 完全位于热窗内、无 API 错误的周期样本 | 6 |
| 最大真实 start 间隔（含热窗边界） | 22.402 ms |
| 最大单轮 Win32+DXGI 查询时长 | 0.554 ms |
| 周期采样最大 WorkingSetSize | 285,716,480 B |
| 周期采样最大 DXGI LOCAL | 11,931,648 B |
| 周期采样最大 DXGI NON_LOCAL | 12,652,544 B |
| 同一条样本 LOCAL+NON_LOCAL 的最大和 | 24,584,192 B |

含边界的实际采样间隔为 `0.1151, 22.4020, 10.8427, 17.4586, 17.1842, 11.9651, 18.5127 ms`。raw 与 summary 数值一致，sampler_error 为 null，固定存储没有饱和。2 ms 是请求周期，不能写成已达到的有效分辨率；QPC 时钟自身分辨率 100 ns 与采样能每隔多久执行是两个指标。

这 6 条是周期样本，原 summary.sampled_hot_peaks 没有混入热窗后的阶段点。`after_hot_before_audit` 的 RSS 为 285,757,440 B，比周期最大值多 40,960 B；不能追溯改写旧 summary 口径。正式新协议若定义取“阶段点+有效周期样本”的最大值，应明确使用新定义并保留各点来源。

## 热窗和显式所有权比上一轮补齐了什么

tracemalloc 在创建 fixture、模型、会话之前开始。reference、准备命令、外部反馈及 NumPy root census 完成后，紧贴 t0 调用 reset_peak；t4 后立即读取 current/peak，再停止采样线程、构建详细审计字典和归档。该次 7,445,833 B 确实是重置之后的追踪峰，不再是上一轮含初始化的未隔离累计峰。[Python reset_peak 语义](https://docs.python.org/3/library/tracemalloc.html#tracemalloc.reset_peak)

窗口包含完整 before→predict/execute/after→实际反馈更新→next observe/predict，采样线程自己的 Python 分配也被追踪。此方法探针如实披露了扰动。正式 managed 与 OS/驱动实验应分开：managed 不运行周期采样，OS/驱动不运行 tracemalloc；不能将本次混合仪表值当正式资源收益。

root 清单覆盖 reference、model、bridge/index、renderer、当前 readback、调用者 bytes/tickets 和 B 的私有返回事实。新的 walker 支持沿一般 `.base` 继续追 owner、遍历继承层 slots，并按 root 报重叠数量、全根集合去重。CPU 对一个实际 backing 的两条 root/view 路径验证为全局 1 buffer/1024 B，不是 2 buffer。按 root 的数值可重叠，不能相加后代替 deduplicated，也不能把 NumPy backing 字节再加到 tracemalloc 上重复计费。

close 前，root 清单为 84 个 backing/6,377,864 B；close 后 session/diagnostic roots 归零，但外部仍持有参考 888 B 和票据 640 B，总计 2 个/1,528 B。随后清外部根，所枚举根归零。close 后 6 个 AO/PNG bytes 实际读取与归档，全部摘要匹配。

原生生命周期证据也比上一轮具体：真实 offscreen.free 完成 1 次，wrapper target 清空；两组相机 object/data 名称在关闭前存在、关闭后均从 bpy.data 移除；bridge/index/reference/model/renderer 字段和模型库清空有明确断言。这认证这些 owner 责任，不能扩张为“驱动用量瞬时归零”。Win32 工作集是当前进程驻留页统计，DXGI CurrentUsage 是当前进程在指定 adapter/node 的分组用量。[Win32 字段](https://learn.microsoft.com/en-us/windows/win32/api/psapi/ns-psapi-process_memory_counters_ex) · [DXGI 查询与 node 语义](https://learn.microsoft.com/en-us/windows/win32/api/dxgi1_4/nf-dxgi1_4-idxgiadapter3-queryvideomemoryinfo)

## 一个诊断 harness 遗漏，正式 harness 局部修正即可

归档 `resource_diagnostic.py:446` 的 `for frame, expected in zip((before, result.after), ...)` 在结束后仍留下局部变量 `frame`，指向最后一个 B 私有 ObservedFrame。随后只删除 before/result/following/planned/next_plan，没有删除 frame。CPU AST 核对了这一点，不需要原生重跑证明 Python 局部绑定仍然存在。

因此“close 后只剩不可变 bytes 和 tickets”的注释超过实际情况；“after_external_release 枚举根为零”仍正确，但不能解释为所有活 NumPy backing 均为零。frame 不在 `_roots` 内，可能继续持有 B 的图像、TD 或借用 mesh 事实。它不会推翻 offscreen/free、相机移除或 session 字段已清空的证据。

不改旧归档。正式 before-census 先删除 `frame/expected` 等验证侧循环变量，并释放 B 私有返回包、prepared/native 审计临时引用；只保留协议要求的 public bytes、票据和会话内部状态。B/I 用同一持有责任测 current，避免 B 因验证侧隐藏引用被额外加重。root walker 必须列入 I 新增的会话/返回对象或其显式数组，不能依靠原 B 类模块名前缀自动覆盖。close/reopen 与 GPU 逻辑资源审计只在验证层执行，不为生产增加防御链。

## 可冻结的门及判定

接受主干这次事前提出的口径，明确它是尚无 I 成绩时对原“峰”承诺的修订，不是采样精度提高：

1. **Managed current ≤256 KiB、完整热窗 peak ≤1 MiB 的新增量门可冻结。** 每臂导入后、创建模型/会话前开始追踪，按同样输出/票据/参考持有状态取对应点；热窗 t0 前 reset_peak，t4 后先读取再整理审计。逐对应点/窗口比较 I−B，门分别为 262,144 B 和 1,048,576 B，全部点/窗须满足，不用平均掩盖超限。完整 traced peak 为比较对象；peak_above_start 另报机制信息，不能拿它代替峰值而漏掉 I 预先常驻的成本。保留 raw current、total traced peak、起点及 owner attribution，避免混淆。
2. **逻辑 GPU 资源等价和生命周期作为硬门。** 在相同 VG 调用和输出责任下，I 使用的 offscreen/attachment、相机、shader、geometry batch/buffer 等逻辑资源数量、尺寸、格式与 B 对账；I 不得凭统一入口额外保持一套持久 GPU 资源，不得重复 prepare/capture 以隐藏成本。以组件边界的验证包装记录资源创建、活跃峰和释放，不修改已验收 VG 算法。close 清掉该会话拥有的资源，调用者 bytes 仍可读；固定 close→reopen 控制不能继承旧 owner/句柄或呈逐轮增长。相同驱动缓存读数不替代这个门。
3. **RSS/GPU 的 observed sampled maximum 增量 ≤8 MiB 门可冻结。** 每 case 前后必有同步阶段点，窗口内保留全部有效周期样本。RSS 取 WorkingSetSize；GPU 取每一条查询记录的 LOCAL+NON_LOCAL 之和，再取阶段点及有效样本的最大值；分别比较对应 I−B ≤8,388,608 B。两组也单列，不把各自不同时间的最大值相加，不与 RSS 相加。计量线程仍请求 2 ms，实际 gap、查询起止和错误全部归档，不伪造“达到 2 ms”的资格。LOCAL/NON_LOCAL 查询是顺序操作，所以“同点之和”指同一条有起止时间界的记录，非原子瞬时读取。
4. **上述 observed gate 不认证未观测瞬时峰。** 不对 22.402 ms 间隙作插值保证，也不再要求为此无限开探针或临时转 ETW。GPU 资源等价门覆盖新增 API 造成的额外逻辑资源责任，tracemalloc 则独立覆盖其可追踪的托管分配。若相关计量 API 不可用、必要阶段点缺失、无有效窗口样本或存储饱和，该项标为 UNVERIFIED/INCOMPLETE，不能算 PASS，不能靠删样补成通过。

建议下一次直接以此固定协议随正式 B/I 验收执行一次预登记批次：使用既定三个部署和 24 例、既定状态/输出持有、固定各臂新进程与顺序，managed 和 OS/驱动分别采集。所有成功、失败、间隔与原始数据保留；出现缺测就报告缺测，不自动换场景/统计/门槛，也不追加方法探针到看见想要的数值。以上是可执行的资源协议冻结建议，不放行尚未满足的其它性能资格，也不声称当前 I 已达标。
