"""Offline review of archived B/B diagnostic data; never imports live project code."""
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
import csv
import json
from pathlib import Path
from zipfile import ZipFile
import numpy as np

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'artifacts/integration/method_diagnostic_001'
OUT=Path(__file__).parent
manifest=json.loads((BASE/'manifest.json').read_bytes())
bb=manifest['method_probe']['bb']
segments=bb['segments']
all_segments=segments+['next_observe','next_predict']
cases=bb['case_ids']

def read_json(path):return json.loads(path.read_bytes())
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def desc(x):
    a=np.asarray(x,dtype=float)
    if not len(a):return {'n':0}
    return {'n':len(a),'min':float(a.min()),'median':float(np.median(a)),
            'p95':float(np.quantile(a,.95)),'max':float(a.max()),'mean':float(a.mean())}
def array_equal_bits(a,b):return a.dtype.str==b.dtype.str and a.shape==b.shape and a.tobytes()==b.tobytes()
def array_digest(arrays):
    digest=sha256()
    for k,a in arrays.items():
        digest.update(json.dumps((k,a.dtype.str,a.shape),separators=(',',':')).encode())
        digest.update(a.tobytes())
    return digest.hexdigest()
def utc(ns):return datetime.fromtimestamp(ns/1e9,timezone.utc).isoformat()

out={'scope':'Offline arithmetic, archived state/PNG byte comparisons, source ZIP inspection; no Blender/GPU/new timing/training',
     'input_hashes':{f:sha256((BASE/f).read_bytes()).hexdigest() for f in ('manifest.json','sources.zip')},
     'source_inventory':{},'processes':{},'cross_process':{}}
with ZipFile(BASE/'sources.zip') as archive:
    discrepancies=[]
    for name,expected in manifest['source_superset'].items():
        if sha256(archive.read(name)).hexdigest()!=expected:discrepancies.append(name)
    out['source_inventory']={'entries':len(manifest['source_superset']),'discrepancies':discrepancies,
        'frozen_control_sha256':sha256(archive.read('human_eye_fast/control.py')).hexdigest(),
        'frozen_reference_sha256':sha256(archive.read('verification/integration_reference.py')).hexdigest()}
    assert not discrepancies
    frozen_source_hashes={name:sha256(archive.read(name)).hexdigest() for name in archive.namelist() if not name.endswith('/')}

dataset={};state_sets={};proof_sets={};csv_rows=[]
for process_index in (0,1):
    name=f'bb-p{process_index}';base=BASE/name/'result'
    rows=[json.loads(line) for line in (base/'intervals.jsonl').read_text().splitlines()]
    proofs=[json.loads(line) for line in (base/'next_and_state.jsonl').read_text().splitlines()]
    summary=read_json(base/'summary.json');gc=read_json(base/'gc.json');anchors=read_json(base/'time_anchors.json')
    assert len(rows)==len(proofs)==216
    assert sha256((BASE/'manifest.json').read_bytes()).hexdigest()==summary['manifest_sha256']
    imported=[]
    for module,value in summary['project_imports'].items():
        assert frozen_source_hashes[value['path']]==value['sha256'],module
        imported.append(value['path'])
    state_set={}
    for path in (base/'states').glob('*.npz'):
        with np.load(path,allow_pickle=False) as z:arrays={k:z[k].copy() for k in z.files}
        assert array_digest(arrays)==path.stem
        state_set[path.stem]=arrays
    state_sets[name]=state_set
    lookup={};proof_lookup={}
    for row,proof in zip(rows,proofs,strict=True):
        key=(row['case'],row['pair'],row['physical_lane'])
        assert key not in lookup and key==(proof['case'],proof['pair'],proof['physical_lane'])
        lookup[key]=row;proof_lookup[key]=proof
        q=row['counter_ns'];v=row['ns']
        assert q['t0']<q['t1']<q['t2']<q['t3']<q['t_next_observed']<q['t4']
        assert [v[s] for s in segments[:-1]]==[q['t1']-q['t0'],q['t2']-q['t1'],q['t3']-q['t2'],q['t4']-q['t3']]
        assert sum(v[s] for s in segments[:-1])==v['continuous_total']==q['t4']-q['t0']
        assert v['next_observe']==q['t_next_observed']-q['t3'] and v['next_predict']==q['t4']-q['t_next_observed']
        expected_order=[0,1] if (process_index+row['case_ordinal']+row['pair'])%2==0 else [1,0]
        assert row['execution_order']==expected_order and expected_order[row['execution_index']]==row['physical_lane']
        assert row['creation_index']==([0,1] if process_index==0 else [1,0]).index(row['physical_lane'])
        assert row['warmup']==(row['pair'] in bb['warm_pair_indices'])
        assert not proof['next_ticket_consumed']
        png=(base/'png'/f"{proof['next']['png_sha256']}.png").read_bytes()
        assert sha256(png).hexdigest()==proof['next']['png_sha256']
        proof_bytes=canon(proof['next'])
        assert sha256(proof_bytes).hexdigest()==proof['next_work_sha256']
        assert proof['state_sha256'] in state_set
        # Compare actual stored proof bytes and NPZ arrays, not boolean/hash claims.
        reference=proof_lookup[(row['case'],0,0)] if (row['case'],0,0) in proof_lookup else proof_lookup[(row['case'],0,1)]
        assert proof_bytes==canon(reference['next'])
        actual_state=state_set[proof['state_sha256']];reference_state=state_set[reference['state_sha256']]
        assert list(actual_state)==list(reference_state)
        assert all(array_equal_bits(actual_state[k],reference_state[k]) for k in actual_state)
        assert proof['expected_state_sha256']==proof['state_sha256']
        csv_rows.append({'process':process_index,**{k:row[k] for k in ('case','pair','physical_lane','creation_index','execution_index','warmup')},**q,**v})
    assert all(rows[i]['counter_ns']['t4']<=rows[i+1]['counter_ns']['t0'] for i in range(len(rows)-1))
    dataset[name]=lookup;proof_sets[name]=proof_lookup
    measured=[r for r in rows if not r['warmup']]
    assert len(measured)==186
    # Pair GC callback start/stop records and intersect actual counter intervals.
    open_gc=[];gc_spans=[]
    for event in gc['events']:
        if event['event']=='start':open_gc.append(event)
        else:
            start=open_gc.pop();assert start['generation']==event['generation']
            assert event['counter_ns']-start['counter_ns']==event['duration_ns']
            gc_spans.append({'start':start['counter_ns'],'end':event['counter_ns'],**{k:event[k] for k in ('generation','duration_ns','collected','uncollectable')}})
    assert not open_gc
    overlap=[]
    bounds={'before':('t0','t1'),'action':('t1','t2'),'feedback':('t2','t3'),'next':('t3','t4'),'continuous_total':('t0','t4'),
            'next_observe':('t3','t_next_observed'),'next_predict':('t_next_observed','t4')}
    for row in rows:
        for s,(a,b) in bounds.items():
            lo,hi=row['counter_ns'][a],row['counter_ns'][b]
            for g in gc_spans:
                duration=max(0,min(hi,g['end'])-max(lo,g['start']))
                if duration:overlap.append({**{k:row[k] for k in ('case','pair','physical_lane','warmup')},'segment':s,'overlap_ns':duration,'generation':g['generation'],'gc_start':g['start']})
    clock=read_json(base/'clock.json')
    mid=lambda anchor:(anchor['counter_before_ns']+anchor['counter_after_ns'])/2
    anchor0,anchor1=anchors['start'],anchors['end']
    q0,q1=mid(anchor0),mid(anchor1);u0,u1=anchor0['utc_unix_ns'],anchor1['utc_unix_ns']
    result={'rows':len(rows),'measured_pairs':93,'warm_pairs':15,'proof_rows_byte_checked':len(proofs),
        'state_files_byte_checked':len(state_set),'project_imports_vs_archive':len(imported),
        'clock_empty_ns':desc(clock['empty_ns']),'gc_start':gc['start'],
        'gc_spans':gc_spans,'gc_span_counts_by_generation':dict(Counter(g['generation'] for g in gc_spans)),
        'gc_duration_ns':desc([g['duration_ns'] for g in gc_spans]),'gc_overlaps':overlap,
        'absolute_time':{'start_utc':utc(u0),'end_utc':utc(u1),'anchor_span_s':(q1-q0)/1e9,
            'utc_minus_counter_elapsed_ns':(u1-u0)-(q1-q0),'first_t0':rows[0]['counter_ns']['t0'],'last_t4':rows[-1]['counter_ns']['t4'],
            'service_sum_s':sum(r['ns']['continuous_total'] for r in rows)/1e9,
            'inter_arm_gap_ms':desc([(rows[i+1]['counter_ns']['t0']-rows[i]['counter_ns']['t4'])/1e6 for i in range(len(rows)-1)])},
        'segments':{},'cases':{}}
    for s in all_segments:
        medians={case:[float(np.median([lookup[(case,p,l)]['ns'][s] for p in bb['measured_pair_indices']])) for l in (0,1)] for case in cases}
        p95=np.quantile(list(medians.values()),.95,axis=0,method='linear')
        assert np.array_equal(p95,summary['segments'][s]['lane_p95_ns'])
        for case in cases:
            assert medians[case]==summary['segments'][s]['case_descriptives'][case]['lane_medians_ns']
        result['segments'][s]={'case_medians_ns':medians,'p95_ns':p95.tolist(),'max_bidirectional_ratio':float(max(p95)/min(p95)),
            'original_gate':s in segments,'within_original_gate':bool(max(p95)/min(p95)<=1.05) if s in segments else None}
    for case in cases:
        result['cases'][case]={}
        for s in all_segments:
            pair_values=np.array([[lookup[(case,p,l)]['ns'][s] for l in (0,1)] for p in bb['measured_pair_indices']],dtype=float)
            difference=(pair_values[:,1]-pair_values[:,0])/1e6
            blocks=np.array([(pair_values[i]+pair_values[i+1])/2 for i in range(0,30,2)])
            by_position={f'lane{l}_position{pos}':desc([r['ns'][s]/1e6 for r in measured if r['case']==case and r['physical_lane']==l and r['execution_index']==pos]) for l in (0,1) for pos in (0,1)}
            thirds=[[float(np.median(block))/1e6 for block in np.array_split(pair_values[:,l],3)] for l in (0,1)]
            result['cases'][case][s]={'paired_difference_ms':desc(difference),'lane1_slower_pairs':int((difference>0).sum()),
                'paired_ratio':desc(pair_values[:,1]/pair_values[:,0]),'by_position_ms':by_position,'temporal_thirds_ms':thirds,
                'abba_block_ratio':desc(blocks[:,1]/blocks[:,0]),'unmatched_pair35_ratio':float(pair_values[-1,1]/pair_values[-1,0]),
                'top_slow_rows':[{**{k:r[k] for k in ('pair','physical_lane','execution_index')},'ms':r['ns'][s]/1e6,
                                  'gc_overlap_ns':sum(o['overlap_ns'] for o in overlap if o['case']==case and o['pair']==r['pair'] and o['physical_lane']==r['physical_lane'] and o['segment']==s)}
                                 for r in sorted([r for r in measured if r['case']==case],key=lambda r:r['ns'][s],reverse=True)[:3]]}
    out['processes'][name]=result

# Cross-process checks use actual normalized JSON/PNG/NPZ bytes.
cross=[]
for key in dataset['bb-p0']:
    a,b=(proof_sets[p][key] for p in ('bb-p0','bb-p1'))
    assert canon(a['next'])==canon(b['next'])
    aa,bbstate=(state_sets[p][q['state_sha256']] for p,q in (('bb-p0',a),('bb-p1',b)))
    assert list(aa)==list(bbstate) and all(array_equal_bits(aa[n],bbstate[n]) for n in aa)
    pa=(BASE/'bb-p0/result/png'/f"{a['next']['png_sha256']}.png").read_bytes()
    pb=(BASE/'bb-p1/result/png'/f"{b['next']['png_sha256']}.png").read_bytes()
    assert pa==pb
    cross.append(key)
out['cross_process']['same_case_pair_lane_actual_comparisons']=len(cross)
out['cross_process']['distinct_next_proofs']=len({canon(p['next']) for p in proof_sets['bb-p0'].values()})
out['cross_process']['state_fields']={k:list(next(iter(state_sets[k].values()))) for k in state_sets}
for key,arr in state_sets['bb-p0'].items():
    other=state_sets['bb-p1'][key]
    assert all(array_equal_bits(arr[n],other[n]) for n in arr)
out['cross_process']['all_four_state_files_actual_array_equal']=True

# Independent NumPy arithmetic using frozen parameter bytes, not current project imports.
deployment=manifest['deployments'][manifest['method_probe']['bb']['deployment_process_index']]
snapshot=ROOT/deployment['sealed_path']
assert sha256(snapshot.read_bytes()).hexdigest()==deployment['sealed_sha256']
with np.load(snapshot,allow_pickle=False) as z:params={k:z[k].copy() for k in z.files}
pristine_key=read_json(BASE/'bb-p0/result/summary.json')['pristine_state_sha256']
pristine=state_sets['bb-p0'][pristine_key]
assert array_equal_bits(pristine['v_weights'],params['view_head_weights'])
assert array_equal_bits(pristine['a_weights'],params['action_head_weights'])
assert array_equal_bits(pristine['v_keys'],params['view_keys'])
# Frozen feedback is int64; ExperienceBank append stores it in float64 buffers.
assert array_equal_bits(pristine['v_values'],params['view_feedback'].astype(np.float64))
assert array_equal_bits(pristine['a_keys'],params['action_keys'])
assert array_equal_bits(pristine['a_values'],params['action_labels'].reshape(-1,1))
assert pristine['v_known'].all() and pristine['a_known'].all()
out['pristine_actual_arrays_match_sealed_parameters']=True
out['pristine_storage_conversion']='view_feedback int64 -> float64, action_labels (240,) -> (240,1), known masks broadcast True; matches archived ExperienceBank append'
def design(feature,prefix,view):
    d=len(feature);weights=params[prefix+'_weights'];x=np.empty(len(weights),dtype=np.float64)
    x[:d]=feature
    if view:np.log1p(x[2:d],out=x[2:d])
    x[:d]-=params[prefix+'_mean'];x[:d]/=params[prefix+'_scale']
    if bool(params[prefix+'_quadratic']):
        i,j=np.triu_indices(d);np.multiply(x[i],x[j],out=x[d:-1])
    x[-1]=1
    return x
def update(weights,x,error,regularization):
    rate=.05/(1+x@x);weights[:-1]*=1-rate*regularization;weights-=rate*error*x
state_arithmetic={}
for case in cases:
    proof=proof_sets['bb-p0'][(case,0,0)];state=state_sets['bb-p0'][proof['state_sha256']]
    assert int(state['v_writes'])==242
    for p in ('v','a'):
        for field in ('keys','values','known'):assert array_equal_bits(state[f'{p}_{field}'][:240],pristine[f'{p}_{field}'])
    v=pristine['v_weights'].copy();a=pristine['a_weights'].copy()
    for i,feedback in enumerate(bb['archived_feedback'][case]):
        slot=240+i;index=feedback['canonical_index'];safe=feedback['safe'];rays=feedback['selected_probe_rays']
        known=np.zeros(16,dtype=bool);known[index]=True
        values=np.zeros((16,2));values[index]=(safe,rays)
        assert array_equal_bits(state['v_known'][slot],known) and array_equal_bits(state['v_values'][slot],values)
        x=design(state['v_keys'][slot,index],'view_head',True)
        error=np.exp(-np.logaddexp(0.,-x@v))-safe
        update(v,x,error,params['view_head_lambda'])
    if proof['next']['a_predictor']=='L':
        assert int(state['a_writes'])==241 and bool(state['a_known'][240,0])
        x=design(state['a_keys'][240],'action_head',False)
        update(a,x,x@a-state['a_values'][240,0],params['action_head_lambda'])
        nxt=proof['next'];x=design(np.asarray(nxt['a_input']),'action_head',False)
        prediction=float(nxt['a_meters']*(nxt['a_input'][1]+x@a))
        prediction_equal=np.float64(prediction).tobytes()==np.float64(nxt['predicted_delta_m']).tobytes()
    else:
        assert int(state['a_writes'])==240;prediction_equal=None
    view_scores=np.asarray([design(np.asarray(f),'view_head',True) for f in proof['next']['v_input']])@v
    view_rank=list(map(int,np.argsort(-view_scores,kind='stable')))
    state_arithmetic[case]={'v_weights_bit_equal':array_equal_bits(v,state['v_weights']),
        'a_weights_bit_equal':array_equal_bits(a,state['a_weights']),'next_L_prediction_bit_equal':prediction_equal,
        'next_v_rank_equal':view_rank==proof['next']['canonical_rank'],
        'v_max_abs_error':float(np.max(np.abs(v-state['v_weights']))),'a_max_abs_error':float(np.max(np.abs(a-state['a_weights'])))}
out['state_arithmetic']=state_arithmetic
(OUT/'timing_analysis.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n',encoding='utf-8')
with (OUT/'timing_rows.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(csv_rows[0]));w.writeheader();w.writerows(csv_rows)
print('SOURCE',out['source_inventory'])
print('CROSS',out['cross_process']['same_case_pair_lane_actual_comparisons'],'STATE_ARITHMETIC',state_arithmetic)
for proc,result in out['processes'].items():
    print(proc,'P95', {s:round(v['max_bidirectional_ratio'],9) for s,v in result['segments'].items()})
    print(proc,'TIME',result['absolute_time'],'GC',result['gc_span_counts_by_generation'],result['gc_duration_ns'])
    print(proc,'MEASURED_GC',dict(Counter(o['segment'] for o in result['gc_overlaps'] if not o['warmup'])))
    for case in cases:
        print(proc,case,'NEXT_MED',result['segments']['next']['case_medians_ns'][case],
              'NEXT_ORDER',{k:v['median'] for k,v in result['cases'][case]['next']['by_position_ms'].items()},
              'NEXT_THIRDS',result['cases'][case]['next']['temporal_thirds_ms'],
              'PAIR_DELTA',result['cases'][case]['next']['paired_difference_ms']['median'],
              'ABBA',result['cases'][case]['next']['abba_block_ratio']['median'])
