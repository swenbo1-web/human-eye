"""Archive the fixed method diagnostic and CPU review without touching implementation."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[3]
DIRECTORIES = ("artifacts/integration/method_diagnostic_001", "artifacts/integration/root_method_review_001")
DOCUMENTS = ("docs/INTEGRATION_COST_PROTOCOL.md", "docs/METHOD_DIAGNOSTIC_REVIEW.md")


def main():
    paths = {p for name in DIRECTORIES for p in (ROOT / name).rglob("*")
             if p.is_file() and not any(part in {"__pycache__", "isolated-pycache"} for part in p.parts)}
    paths.update(ROOT / name for name in DOCUMENTS)
    destination = ROOT / "docs/method_diagnostic_evidence.zip"
    manifest = {}
    with ZipFile(destination, "w", compression=ZIP_DEFLATED) as archive:
        for path in sorted(paths):
            name = path.relative_to(ROOT).as_posix()
            data = path.read_bytes()
            manifest[name] = {"bytes": len(data), "sha256": sha256(data).hexdigest()}
            archive.writestr(name, data)
        archive.writestr("manifest.json", json.dumps({
            "scope": "Two bounded B/B diagnostics, one B resource-method process, independent CPU review, and prospective cost protocol; no I performance acceptance",
            "files": manifest,
        }, ensure_ascii=False, indent=2) + "\n")
    with ZipFile(destination) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == set(manifest) | {"manifest.json"}
        for name, meta in manifest.items():
            data = archive.read(name)
            assert data == (ROOT / name).read_bytes()
            assert len(data) == meta["bytes"] and sha256(data).hexdigest() == meta["sha256"]
    print(json.dumps({"files": len(manifest), "bytes": destination.stat().st_size,
                      "sha256": sha256(destination.read_bytes()).hexdigest(), "exact_roundtrip": True}))


if __name__ == "__main__":
    main()
