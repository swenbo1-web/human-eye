# method_diagnostic_001：冻结 next/state 证明覆盖审查

本审查仅从 `artifacts/integration/method_diagnostic_001/sources.zip` 读取冻结的 bb_diagnostic.py、旧 bb_probe.py、integration_reference.py、cerebellar_flash.py 及相关模型源。未以正在修改的生产 control 解释旧结果，未运行 Blender、GPU 或训练，未修改实施源。另只读查看已存 next_and_state 的字段和 NPZ dtype/shape。432 条原始 next 与 NPZ/PNG 的逐字节重算由 integration_contract_review 独立负责，本文不冒称已重复完成。

## 判断

**本轮 next/state 证明设计足以支持有界 B/B 方法诊断，没有发现应退回实施的状态证明阻塞。** 它证明的是所保存的活跃 CF 状态、规范化 next 视角/动作责任和 PNG 可重复；不能扩大解释为所有公开 AO/TD 事实、全部网格或每项内部工作量都已独立逐字节证明相等。

归档代码确实在 t3→t4 调用了真实下一观察（capture/BC、TD、VG、AO encode）及预测，并使用刚完成反馈的同一个活动 model。没有发现 shadow 状态、用旧结果替代下一观察或省略下一预测的分支。现有证明盲区应准确列在结论边界，不要求增加每根 ray 底层几何日志，也不因此重开已封存算法优化。

## 活跃 CF 状态：覆盖充分且有明确适用范围

冻结 bb_diagnostic.py:33–61 保存两头 weights、两库 writes、全部活跃 keys/values/known；每个数组的名称、dtype、shape 与原始 bytes 均进摘要。实际 NPZ 为：

- 初始 V/A writes=240/240。
- 三例都写两张 V，故 V 为242；平移 G 的 A 仍240，shape L 的 A 为241。
- V keys/values/known 分别为 (242,16,5)/(242,16,2)/(242,16)，A 为 (240或241,23)/(240或241,1)/(240或241,1)。两头 weights 为21和24维。

本轮显式 assert 未环绕且容量大于242/241。CF append 只写游标对应新槽，rank 只读取活跃前缀。旧 `_restore` 虽仅恢复 weights 和 writes，但每次计时前又对**所有活跃行**计算 pristine digest 并断言等于新冻结模型；因此在本轮轨迹上，旧行污染或不完整恢复不会悄悄通过。无须要求清零 inactive 尾部，也不能把这个恢复策略推广到已环绕或会修改旧活跃行的实验。

NPZ 未保存头 mean/scale/quadratic/regularization、retrieval_scale、capacity。这些由共同冻结部署构造，所审热路径只读而不更新；因而不是本轮遗漏的可变学习状态。以后若改变这些参数的运行责任，须重新界定快照范围。此处保存发生在 next 查询后；冻结源码的 next 是只读推理，不追加训练，因此所存状态仍是反馈后的活动状态。

## expected_state 是独立编排重放，不是独立学习或几何 oracle

bb_diagnostic.py:176–192 从新的 frozen.session 启动，用归档 safe/ray 标签、真实 Outcome delta，按前V→后V→A的顺序重放；第一轮得到的 expected digest 约束该案例所有后续重复和两个物理臂。它不是拿实际 digest 原样当 expected：能发现漏更/额外更新、顺序或标签错误、ring mask/value 写错，以及整段活动状态漂移。

但是重放输入 key 来自**实际写入后的新增 bank rows**，更新计算也调用同一份 `learn_view/learn_action`。因此不能独立证明：

- 特征提取本身正确，或写库 key 与被消费前 receipt 的输入绝无共同接线错误；
- 学习公式、归一化残差公式没有共同实现错误；
- 作为 A 标签的 Outcome 本身是独立几何真值。

例如，若实现同时用同一错误 key 写库并更新头，expected 会沿相同 key 重放，可能仍相等。这是证明能力边界，不是已观测到的错误；原组件质量验收及正式集成真值门承担这些责任。不能以该 expected digest 宣称重新独立验证了 CF 算法。

## next proof 实际覆盖的责任

bb_diagnostic.py:114–173、274–287 保存并比较：

- 实际 PNG 的 bytes 摘要和可复查文件，image_status、frame、target pair、渲染 metadata 中的完整 witness；
- 从当前 gap 轴构造的16个 canonical directions、更新后模型的完整 rank、实际访问前缀、selected candidate/direction、每个 probe 的计数/结果、总 rays；断言总 rays 为逐 probe 之和，selected probe rays/native stop 与 receipt 一致；
- 实际 next 的16×5 V 输入；
- 实际 followup command、predictor、预测结果；L 时另有23维 A 输入和尺度，并在同一个活动模型上复算预测；G 时明确不伪造 L 输入；
- 在生成证明前断言实际 observation/attachment/action ID 与该重复模板匹配，plan.before 指向 following.readback，next 票据/计划尚未消费。不同物理臂的字符串 ID 不进规范化 next hash，但其合法绑定并未因此跳过。

冻结 reference 的 rank callback 和 predict 直接读取此 model，CF L 分支直接使用当前 weights，没有缓存旧头或 shadow 路径。因此“下一查询使用反馈后的活动模型”有源代码及状态/推理一致性证据共同支持。若只看相等的输出 rank 本身，则不能证明更新必然改变了决策；本轮也不应声称这种因果收益。

## hash 相等仍不能单独排除的差异

next proof 未包含：

- next AO bytes 或解析后的全部 AO 事实；尤其完整 TD 原值/精确 Top-K、每对象 generation/center、reference/sample/position 帧和选中面展示事实；
- 当前全量目标/上下文顶点、拓扑、变换、外观及原 polygon 映射；
- G 的完整有限几何输入、basis/control_before（只保存 command 和最终预测）；
- 每次 RB capture/BC/TD/encode 调用计数、BVH 内部搜索量、独立相机/GPU 矩阵或完整内部渲染状态。

因此存在逻辑上的反例：两个运行可以得到同一 witness/PNG/CF 输入/预测，却有不同的未呈现网格或 TD 摘要；或者重复执行了一项无状态查询，最后输出相同而成本不同。这些情况不会被当前 next hash 单独发现。

不过，冻结 reference 的 `_frame` 明确无条件计算 TD，observe 明确调用 capture 与 encode；同清单、同源码及独立物理臂没有观察到按 lane 省略责任的路径。当前目标是查两份同一 B 的计量偏差，不能把上述逻辑盲区直接当作真实缺陷，更不应因此扩大为新一轮完整几何审计。正式 I/B 仍要执行已冻结的公开消费、完整事实、采集次数和质量等价门。

## 对主干报告的建议表述

可用：“本次诊断中保存的活跃 CF 数组、规范化下一查询视角/动作字段和 PNG 在各重复/物理臂相同；冻结源码显示下一观察完整执行并使用实际反馈后的活动模型。”

避免：“完整下一观察的所有事实和每项内部工作量已由 hash 独立证明相等”或“expected_state 独立证明学习算法正确”。

不建议为本覆盖审查追加运行。实际432条跨进程一致性、计时资格与资源计量结论，继续由整体计量审查及主干裁定。
