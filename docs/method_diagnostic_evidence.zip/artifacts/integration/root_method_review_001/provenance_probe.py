"""CPU-only review of immutable method_diagnostic_001 archives.

Project source identities are checked against sources.zip and frozen Git 42ddcf2,
never against an actively changing implementation working tree.
"""
import ast
from hashlib import sha256
import json
from pathlib import Path
import subprocess
from zipfile import ZipFile

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "artifacts/integration/method_diagnostic_001"
OUT = Path(__file__).with_suffix(".json")
EXPECTED = "a2d5d9639c174de13fe46f3ff7b04f8473b23206e5fe2cca46554e6410325508"


def digest(data):
    return sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def main():
    manifest_bytes = (BASE / "manifest.json").read_bytes()
    assert digest(manifest_bytes) == EXPECTED
    manifest = json.loads(manifest_bytes)
    with ZipFile(BASE / "sources.zip") as archive:
        names = archive.namelist()
        assert len(names) == len(set(names))
        sources = {name: archive.read(name) for name in names}
    assert {name: digest(data) for name, data in sources.items()} == manifest["source_superset"]
    committed = {}
    for name in ("verification/integration_reference.py", "verification/integration_fixtures.py",
                 "verification/test_integration_preflight.py", "human_eye_fast/control.py",
                 "human_eye_fast/raycast_saccade_gpu.py"):
        git_bytes = subprocess.check_output(["git", "show", "42ddcf2:"+name], cwd=ROOT)
        exact = git_bytes == sources[name]
        normalized = git_bytes.replace(b"\r\n", b"\n") == sources[name].replace(b"\r\n", b"\n")
        assert normalized, name
        committed[name] = {"archive_sha256": digest(sources[name]), "git_blob_sha256": digest(git_bytes),
                           "byte_identical": exact, "LF_normalized_identical": normalized}
    assert manifest["frozen_review"]["commit_prefix"] == "42ddcf2"
    jobs = manifest["jobs"]
    assert [j["phase"] for j in jobs] == ["bb-p0", "bb-p1", "resource"]
    reviewed_jobs = []
    runtime_objects = []
    for job in jobs:
        folder = BASE / job["phase"]
        launch = read(folder / "launch.json")
        process = read(folder / "process.json")
        runtime = read(folder / "runtime.json")
        imports = read(folder / "project-imports.json")
        assert {k:v for k,v in launch.items() if k != "manifest_identity"} == job
        assert launch["manifest_identity"]["sha256"] == EXPECTED
        assert launch["manifest_identity"]["bytes"] == len(manifest_bytes)
        assert runtime["pid"] == imports["pid"]
        assert runtime["environment"] == job["environment_effective"]
        assert process["exit_code"] == 0 and process["stable_sources"] and process["stable_inputs"]
        assert process["runtime_observed"] and process["stable_runtime_environment"]
        assert not process["import_discrepancies"]
        assert len(imports["modules"]) == process["observed_project_imports"]
        assert job["entry"] in {item["path"] for item in imports["modules"].values()}
        for item in imports["modules"].values():
            assert digest(sources[item["path"]]) == item["sha256"]
        checked_inputs = []
        for name, expected in job["inputs"].items():
            # Source inputs are resolved from the immutable ZIP; data from registered paths.
            data = sources[name] if name in sources else (ROOT / name).read_bytes()
            assert digest(data) == expected, name
            checked_inputs.append({"path": name, "checked_from": "sources.zip" if name in sources else "registered_data"})
        assert runtime["blender_executable"] == manifest["registration_environment"]["blender_executable"]
        for key in ("blender_executable", "python_executable", "python_dll"):
            item = runtime[key]
            data = Path(item["path"]).read_bytes()
            assert len(data) == item["bytes"] and digest(data) == item["sha256"]
        assert runtime["numpy"]["version"] == "2.3.4" and runtime["pillow"] is None
        assert runtime["clock"]["resolution_seconds"] == 1e-7 and runtime["clock"]["monotonic"]
        assert runtime["gpu"]["backend"] == "OPENGL"
        summary = read(folder / "result/summary.json")
        assert summary["manifest_sha256"] == EXPECTED
        for actual in summary.get("actual_registered_reads", []):
            assert actual["sha256"] == job["inputs"][actual["path"]]
        reviewed_jobs.append({"phase": job["phase"], "pid": runtime["pid"], "exit_code": 0,
                              "project_imports": len(imports["modules"]), "inputs": checked_inputs,
                              "runtime_environment_matches_registration": True,
                              "reported_source_and_input_stability": True,
                              "clock_start": runtime["clock"]["start"], "clock_end": runtime["clock"]["end"]})
        runtime_objects.append(runtime)
    for first, second in zip(runtime_objects, runtime_objects[1:]):
        assert first["clock"]["end"]["monotonic_after_ns"] < second["clock"]["start"]["monotonic_before_ns"]
    report = read(BASE / "resource/result/summary.json")
    samples = read(BASE / "resource/result/samples.json")
    assert samples["pid"] == report["pid"] == runtime_objects[-1]["pid"]
    assert samples["adapter"] == report["dxgi_adapter"]
    assert samples["node"] == report["node"] == manifest["resource"]["node"] == 0
    assert samples["adapter"]["luid"] == manifest["resource"]["adapter_luid"]
    boundary = report["chain_boundaries_qpc_ns"]
    start, end = boundary["t0_before"], boundary["t4_return"]
    rows = samples["periodic"]
    valid = [r for r in rows if start <= r["start_qpc_ns"] <= r["end_qpc_ns"] <= end
             and r["win32_error"] == 0 and r["local_hresult"] >= 0 and r["nonlocal_hresult"] >= 0]
    assert len(rows) == len(valid) == 6
    starts = [r["start_qpc_ns"] for r in rows]
    gaps = np.diff([start, *starts, end]).astype(int)
    duration = [r["end_qpc_ns"]-r["start_qpc_ns"] for r in rows]
    peaks = {"working_set_bytes": max(r["process"]["WorkingSetSize"] for r in valid),
             "dxgi_local_current_usage_bytes": max(r["local"]["current_usage"] for r in valid),
             "dxgi_nonlocal_current_usage_bytes": max(r["nonlocal"]["current_usage"] for r in valid)}
    stat = report["sampling"]
    assert stat["sampled_hot_peaks"] == peaks
    assert stat["maximum_hot_gap_including_boundaries_ns"] == max(gaps) == 22_402_000
    assert stat["maximum_observed_start_gap_ns"] == max(np.diff(starts))
    assert stat["maximum_query_duration_ns"] == max(duration) == 554000
    assert stat["sampler_error"] is None and stat["storage_saturated"] is False
    managed = report["managed_checkpoints"]["hot_window"]
    assert managed["peak_since_reset_bytes"] - managed["current_before_reset_bytes"] == managed["peak_above_start_bytes"]
    close = report["close_checks"]
    assert close["offscreen_free_completed"] == 1 and len(close["camera_objects_and_data_removed"]) == 2
    assert close["session_numpy_owners_cleared"]
    for name, recorded in close["old_bytes_read_after_close"].items():
        data = (BASE / "resource/result/outputs" / name).read_bytes()
        assert digest(data) == recorded["sha256"] and len(data) == recorded["bytes"]
    owners = report["numpy_inventory"]
    retained = owners["after_close_caller_retained"]
    assert retained["deduplicated"] == {"unique_backings":2, "backing_bytes":1528}
    assert retained["per_root_may_overlap"]["fixture_supplied_reference"]["backing_bytes"] == 888
    assert retained["per_root_may_overlap"]["caller_tickets"]["backing_bytes"] == 640
    assert all(v["unique_backings"] == 0 for k,v in retained["per_root_may_overlap"].items()
               if k.startswith(("session_", "diagnostic_")))
    assert owners["after_external_release"]["deduplicated"] == {"unique_backings":0, "backing_bytes":0}
    source = sources["artifacts/integration/method_diagnostic_001/resource_diagnostic.py"]
    tree = ast.parse(source)
    inventory_fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "_numpy_inventory")
    namespace = {"np":np}
    exec(compile(ast.Module(body=[inventory_fn], type_ignores=[]), "archived_resource_diagnostic.py", "exec"), namespace)
    backing = np.arange(128, dtype=np.float64)
    inventory_check = namespace["_numpy_inventory"]({"owned":backing, "borrowed":backing[::2]})
    assert inventory_check["deduplicated"] == {"unique_backings":1, "backing_bytes":1024}
    # Report the archived loop-local retention directly; do not execute the native run.
    run = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "run")
    deletes = [target.id for n in ast.walk(run) if isinstance(n, ast.Delete)
               for target in n.targets if isinstance(target, ast.Name)]
    assert "frame" not in deletes
    assignments_to_frame = [n.lineno for n in ast.walk(run) if isinstance(n, ast.For)
                            and isinstance(n.target, ast.Tuple)
                            and any(isinstance(x, ast.Name) and x.id == "frame" for x in n.target.elts)]
    result = {
        "scope":"CPU archive/source/resource arithmetic audit only; no native or GPU invocation",
        "manifest_sha256":EXPECTED, "source_zip_sha256":digest((BASE/"sources.zip").read_bytes()),
        "source_files":len(sources), "frozen_git_code":committed, "jobs":reviewed_jobs,
        "archive_provenance_consistent":True,
        "runtime_binary_current_hash_rechecks":True,
        "resource":{"hot_duration_ns":end-start, "managed":managed, "valid_samples":len(valid),
                    "sample_start_gaps_with_boundaries_ns":[int(v) for v in gaps],
                    "query_durations_ns":duration, "maximum_gap_ns":int(max(gaps)),
                    "sampled_peaks":peaks,
                    "sampled_gpu_sum_peak_bytes":max(r["local"]["current_usage"]+r["nonlocal"]["current_usage"] for r in valid),
                    "close_retained_deduplicated":retained["deduplicated"],
                    "owner_inventory_synthetic_dedup":inventory_check,
                    "loop_local_frame_assignment_lines":assignments_to_frame,
                    "loop_local_frame_explicitly_deleted":False,
                    "close_bytes_identity_checks":len(close["old_bytes_read_after_close"]),
                    "offscreen_free_calls":1, "camera_pairs_removed":2},
        "limitations":["Sources verified against immutable archive/frozen commit, not current implementation tree.",
                       "Project imports hash on-disk bytes at exit, not import-open event bytes.",
                       "NumPy runtime has version/path, not a full NumPy binary dependency hash closure.",
                       "Resource close zero applies to enumerated roots; undeleted loop-local frame remains outside roots.",
                       "Six periodic samples cannot certify an instantaneous RSS/GPU maximum."]}
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    print(json.dumps({k:v for k,v in result.items() if k not in ("jobs","frozen_git_code","limitations")},indent=2))


if __name__ == "__main__":
    main()
