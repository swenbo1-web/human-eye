# method_diagnostic_001 来源独立复核

结论：封存 manifest、580 项源码 ZIP、三个启动/导入/运行时回执、注册输入及资源结果身份一致。没有以正在实施的工作树充当旧 B 源码；本轮只做 CPU 读档、散列校验、Git 只读比对和原始记录运算。复核脚本及结果见同目录 `provenance_probe.py/.json`。

- manifest SHA-256：`a2d5d9639c174de13fe46f3ff7b04f8473b23206e5fe2cca46554e6410325508`。
- sources.zip SHA-256：`1b984d7a4daa6646a0579217817eda5b9af472d36f9a6a717ec1646e1119cab4`。580 个无重复路径条目的实际字节摘要逐项等于 manifest.source_superset。
- 封存 B 定位到 `42ddcf2`。独立读取该提交的 `integration_reference.py`、`integration_fixtures.py`、`test_integration_preflight.py`、生产 `control.py` 和 `raycast_saccade_gpu.py`，与 ZIP 逐字节相同。当前实现树发生变化不影响此历史结论。
- bb-p0、bb-p1、resource 的 launch 去掉 manifest_identity 后逐字段等于 manifest 对应 job。三个启动都绑定同一 manifest 字节数和摘要；记录的实际注册读取与 job.inputs 匹配。源文件类输入在 ZIP 中验证，原部署和原历史反馈类输入按登记路径核对，未用当前实现源文件替换旧输入。
- 三过程退出码均为 0；各 process 记载 stable_sources、stable_inputs、stable_runtime_environment 均为 true，import_discrepancies 为空。独立核对全部项目导入回执条目的路径和摘要均在同一 ZIP 内，数量为 25、25、26，PID 与 runtime 一致。
- 有效线程/GPU/Python 环境字段与预登记值逐项相等。三组 runtime 时间锚确认 bb-p0→bb-p1→resource 串行、区间无重叠。
- Blender 5.2.3 LTS、内嵌 Python 3.13.13、NumPy 2.3.4、OpenGL、RTX 3060、NVIDIA 610.88/WDDM。注册 launcher Python 为另一个 venv 3.13.14，未将其误作 Blender 实际 Python。
- 三过程实际 Blender executable、Python executable、python313.dll 均保存路径、字节数和 SHA-256；独立读取当前这些二进制再次核对吻合。Blender 二进制还与启动前注册身份一致。Pillow 为 null，与这些 worker 没有导入 Pillow 的范围一致，不属于缺失评分结果的伪造标记。

资源进程 PID 30984、adapter LUID `[0,83164]`、node 0 同时出现在 summary 与 samples 并匹配预登记。6 个 close 后归档的 AO/PNG 输出文件，其当前字节数和 SHA-256 均等于 close_checks 记录。资源所有数字的复算结果见 `resource_review.md`。

本报告认证的是归档自洽、可追溯及运行记录，不把“退出时源未变”的记录倒称为本审查亲历了当时每次读取。回执仍是退出时在 sys.modules 中的项目模块和显式入口；NumPy 保留版本/路径但未保存整个 NumPy C 扩展依赖闭包。当前证据已补足上一轮所缺的可执行程序、内嵌 Python DLL、有效关键环境和 GPU runtime 身份，不建议为扩大闭包范围再重启方法探针。

来源通过不代表 B/B 性能资格或 I 资源结果通过。该轮只有旧 B 的两个计量诊断和一个资源方法探针，不包含 I 成绩，也不修订已验收 VG 算法。
