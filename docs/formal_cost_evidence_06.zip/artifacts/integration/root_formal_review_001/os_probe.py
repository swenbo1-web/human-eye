"""Recompute sampled RSS/DXGI maxima directly from recorded native queries."""
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'artifacts/integration/formal_cost_001/formal'
STAGES=('pre_t0','post_t1','post_t2','post_t3','post_t_next_observed','post_t4')
def read(p):return json.loads(p.read_bytes())
def lines(p):return [json.loads(x) for x in p.read_text().splitlines()]

all_windows=[];comparisons=[]
manifest=read(BASE/'manifest.json')
cfg=manifest['resource']
for seed in (20261105,79463,310519):
    observed={}
    for role in ('B','I'):
        folder=BASE/f'os-{seed}-{role}/result'
        meta=read(folder/'summary.json');raw=lines(folder/'os_samples.jsonl');cases=lines(folder/'cases.jsonl')
        assert len(raw)==len(cases)==24
        for sample,case in zip(raw,cases,strict=True):
            assert sample['case']==case['case']
            assert sample['pid']==meta['pid'] and sample['role']==role
            assert sample['adapter']['luid']==cfg['adapter_luid'] and sample['node']==cfg['node']
            assert not any(sample[k] for k in ('sampler_error','adapter_error','buffer_saturated','workload_error'))
            stamps=sample['stamps_qpc_ns'];t0,t4=stamps['t0'],stamps['t4']
            stage=sample['phase_points'];periodic=sample['periodic']
            assert [r['phase'] for r in stage]==list(STAGES)
            assert len(periodic)<sample['buffer_capacity']
            rows=stage+periodic
            for q in rows:
                assert q['start_qpc_ns']<=q['end_qpc_ns']
                assert q['win32_error']==0 and q['local_hresult']>=0 and q['nonlocal_hresult']>=0
                assert q['process']['WorkingSetSize']>0
            for index,q in enumerate(stage):
                point='t0' if index==0 else q['phase'].removeprefix('post_')
                assert q['phase_boundary_qpc_ns']==stamps[point]
                if index==0:assert q['end_qpc_ns']<=t0
                else:assert q['start_qpc_ns']>=stamps[point]
                if 0<index<len(stage)-1:
                    next_stamp=stamps[stage[index+1]['phase'].removeprefix('post_')]
                    assert q['end_qpc_ns']<=next_stamp
            hot=[q for q in periodic if t0<=q['start_qpc_ns']<=q['end_qpc_ns']<=t4]
            assert hot
            valid=stage+hot
            rss=max(q['process']['WorkingSetSize'] for q in valid)
            gpu=max(q['local']['current_usage']+q['nonlocal']['current_usage'] for q in valid)
            anchors=[t0]+[q['start_qpc_ns'] for q in hot]+[t4]
            assert anchors==sorted(anchors)
            gap=max(b-a for a,b in zip(anchors,anchors[1:]))
            duration=max(q['end_qpc_ns']-q['start_qpc_ns'] for q in rows)
            claim=case['os']
            assert claim['observed_sampled_maximum']['rss_bytes']==rss
            assert claim['observed_sampled_maximum']['gpu_same_record_sum_bytes']==gpu
            assert claim['max_window_start_gap_including_boundaries_ns']==gap
            assert claim['max_query_duration_ns']==duration
            summary={'seed':seed,'role':role,'case':sample['case'],'rss_bytes':rss,'gpu_bytes':gpu,
                'valid_hot_periodic':len(hot),'phase_points':len(stage),
                'max_window_gap_ns':gap,'max_query_duration_ns':duration,
                'first_gap_ns':hot[0]['start_qpc_ns']-t0,'last_gap_ns':t4-hot[-1]['end_qpc_ns']}
            observed[role,sample['case']]=summary;all_windows.append(summary)
    comparison=read(BASE/f'os-comparison-{seed}.json')
    for row in comparison['cases']:
        b,i=(observed[r,row['case']] for r in ('B','I'))
        delta={k:i[k]-b[k] for k in ('rss_bytes','gpu_bytes')}
        assert all(v<=8_388_608 for v in delta.values())
        assert row['metric_deltas']['rss_bytes']['I_minus_B_bytes']==delta['rss_bytes']
        assert row['metric_deltas']['gpu_same_record_sum_bytes']['I_minus_B_bytes']==delta['gpu_bytes']
        comparisons.append({'seed':seed,'case':row['case'],'I_minus_B':delta})
result={'scope':'Only observed sampled maximum from fixed stage points plus whole-window periodic queries; no instantaneous peak claim',
        'arm_windows':len(all_windows),'paired_windows':len(comparisons),'adapter_luid':cfg['adapter_luid'],
        'max_RSS_delta_bytes':max(x['I_minus_B']['rss_bytes'] for x in comparisons),
        'max_GPU_delta_bytes':max(x['I_minus_B']['gpu_bytes'] for x in comparisons),
        'max_actual_window_gap_ns':max(x['max_window_gap_ns'] for x in all_windows),
        'max_query_duration_ns':max(x['max_query_duration_ns'] for x in all_windows),
        'windows':all_windows,'comparisons':comparisons}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ('windows','comparisons')}))
