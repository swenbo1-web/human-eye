"""Archive the single formal batch, qualifications, failures and independent review."""
import gzip
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT=Path(__file__).resolve().parents[3]
AUTHOR=ROOT/'artifacts/integration/formal_cost_001'
REVIEW=Path(__file__).resolve().parent
identity=json.loads((AUTHOR/'formal/artifact-identity.json').read_bytes())
for name, meta in identity['files'].items():
    path=AUTHOR/'formal'/name
    data=path.read_bytes()
    assert len(data)==meta['bytes'] and sha256(data).hexdigest()==meta['sha256'],name
paths={p for directory in (AUTHOR,REVIEW) for p in directory.rglob('*') if p.is_file()
       and not any(part in {'__pycache__','isolated-pycache'} for part in p.parts)}
paths.update(ROOT/name for name in ('docs/FORMAL_COST_REVIEW.md',
    'docs/MANAGED_CURRENT_DIAGNOSTIC_PROTOCOL.md','docs/INTEGRATION_COST_PROTOCOL.md',
    'artifacts/integration/root_preflight_review_001/camera_cpu_review.py'))
for seed in (20261105,79463,310519):
    paths.add(ROOT/f'artifacts/integration/production_functional_001/deployments/{seed}.npz')
    paths.add(ROOT/f'artifacts/cf/formal_001/{seed}/seal/frozen.npz')
batches=[];current=[];count=0
for path in sorted(paths):
    size=path.stat().st_size
    if current and count+size>64*1024*1024:
        batches.append(current);current=[];count=0
    current.append(path);count+=size
if current:batches.append(current)
index={'scope':'Original formal cost batch, prior qualifications, post-batch control supplement failures/successes and root independent review. Current numeric failures and pending production F qualification preserved. No new diagnostics included.',
       'author_formal_identity_sha256':sha256((AUTHOR/'formal/artifact-identity.json').read_bytes()).hexdigest(),
       'archives':[],'files':{}}
for number,members in enumerate(batches,1):
    target=ROOT/f'docs/formal_cost_evidence_{number:02}.zip'
    manifest={}
    with ZipFile(target,'x',compression=ZIP_DEFLATED) as z:
        for path in members:
            data=path.read_bytes();name=path.relative_to(ROOT).as_posix()
            manifest[name]={'bytes':len(data),'sha256':sha256(data).hexdigest()}
            z.writestr(name,data)
        z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    with ZipFile(target) as z:
        assert z.testzip() is None
        assert set(z.namelist())==set(manifest)|{'manifest.json'}
        for name,meta in manifest.items():
            data=z.read(name)
            assert data==(ROOT/name).read_bytes()
            assert sha256(data).hexdigest()==meta['sha256']
            index['files'][name]={**meta,'archive':target.name}
    index['archives'].append({'path':target.relative_to(ROOT).as_posix(),'files':len(manifest),
        'bytes':target.stat().st_size,'sha256':sha256(target.read_bytes()).hexdigest()})
target=ROOT/'docs/formal_cost_evidence_index.json.gz'
target.write_bytes(gzip.compress((json.dumps(index,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
print(json.dumps({'files':len(index['files']),'archives':index['archives'],'roundtrip_exact':True}))
