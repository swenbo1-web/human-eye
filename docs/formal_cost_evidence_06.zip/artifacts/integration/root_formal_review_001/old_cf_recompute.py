"""CPU-only independent audit of preserved formal CF records; no project imports."""
from collections import Counter
from contextlib import ExitStack
from datetime import datetime, timezone
from hashlib import sha256
import gzip
import json
from pathlib import Path
import statistics
import subprocess
from zipfile import ZipFile

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'artifacts/integration/formal_cost_001'
OUT = Path(__file__).parent
SEEDS = (20261105, 79463, 310519)
ARMS = ('F', 'R', 'L')
ORDERS = (('F','R','L'), ('R','L','F'), ('L','F','R'), ('L','R','F'), ('F','L','R'), ('R','F','L'))
STAGES = ('total_ns', 'V_ns', 'A_ns')

def read(path):
    return json.loads(Path(path).read_bytes())

def lines(path):
    return [json.loads(line) for line in Path(path).read_bytes().splitlines()]

def digest(raw):
    return sha256(raw).hexdigest()

def compact(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(',', ':')).encode()

def normalize(raw):
    doc = json.loads(raw)
    rows = doc[3]
    roles = ('before', 'after') if len(rows) == 2 else ('view',) if 'view' in rows[0][0] else ('before',)
    for row, role in zip(rows, roles, strict=True):
        row[0] = role
        if row[5] is not None:
            row[5][0] = role + '.png'
    if doc[4] is not None:
        doc[4][:3] = ['apply', 'before', 'after']
    return doc

def old_image(metadata, objects):
    def view(v):
        r, g = v['rna'], v['gpu']
        return [v['viewport'], r['type'], r['matrix_world'], r['ortho_scale'], r['clip_start'],
                r['clip_end'], r['shift_x'], r['shift_y'], r['projection'],
                g['view'], g['projection'], g['view_projection']]
    s = metadata['section']
    return ['view.png', 1024, 512, metadata['meters_per_blender_unit'], metadata['mode'],
            [objects.index(k) for k in metadata['target_ids']], [objects.index(k) for k in metadata['mesh_ids']],
            [s['point_m'], s['normal'], s['kept_side']] if s else None,
            view(metadata['views']['global']), view(metadata['views']['local'])]

def p95(values):
    return float(np.quantile(values, .95, method='linear'))

def clock(path):
    c = read(path)['clock']
    return {k: datetime.fromtimestamp(c[k]['utc_ns']/1e9, timezone.utc).isoformat() for k in ('start','end')}

manifest = read(BASE / 'formal/manifest.json')
result = {'scope': 'Offline preserved evidence audit; no Blender/GPU/test runs', 'seeds': {}, 'source_checks': {}}
with ZipFile(BASE / 'formal/sources.zip') as formal, ZipFile(BASE / 'qualified_old_001/sources.zip') as qual:
    sources = manifest['source_superset']
    assert len(formal.namelist()) == len(sources)
    assert all(digest(formal.read(p)) == d for p, d in sources.items())
    result['source_checks']['formal_source_count'] = len(sources)
    result['source_checks']['qualified_old_source_count'] = len(qual.namelist())
    qm = read(BASE/'qualified_old_001/manifest.json')
    assert all(digest(qual.read(p)) == h for p,h in qm['source_superset'].items())
    for name in ('human_eye_fast/control.py', 'human_eye_fast/blender_radical_session.py',
                 'human_eye_fast/cf_deployment.py', 'verification/cf_native.py', 'verification/cf_report.py',
                 'artifacts/integration/formal_cost_001/old_cf.py'):
        assert formal.read(name) == qual.read(name)
    for name in ('human_eye_fast/control.py','human_eye_fast/blender_radical_session.py',
                 'human_eye_fast/cf_deployment.py', 'verification/cf_native.py','verification/cf_report.py'):
        original = subprocess.run(['git','show','79f8bcc:'+name], cwd=ROOT, check=True, capture_output=True).stdout
        assert original == formal.read(name)
    result['source_checks']['production_79f8bcc_and_qualification_equal'] = True
with ZipFile(ROOT/'artifacts/integration/method_diagnostic_001/sources.zip') as old:
    for name in ('human_eye_fast/control.py','verification/cf_native.py'):
        expected = subprocess.run(['git','show','42ddcf2:'+name], cwd=ROOT, check=True, capture_output=True).stdout
        assert old.read(name) == expected
        result['source_checks'][name+'@42ddcf2'] = digest(expected)
for m in (manifest, read(BASE/'qualified_old_001/manifest.json')):
    for job in m['jobs']:
        if job['kind'] in ('old-cf','old-qualification'):
            assert all(digest((ROOT/p).read_bytes())==h for p,h in job['input_files'].items())
result['source_checks']['all_old_job_registered_inputs_match'] = True

for seed_index, config in enumerate(manifest['seeds']):
    seed = config['seed']
    assert seed == SEEDS[seed_index]
    old = config['old_cf']
    quality = read(ROOT/old['quality_summary'])
    report = {}
    g_differences = {}
    actual_actions = []
    original_rows = {}
    for archive in old['records_archives']:
        with gzip.open(ROOT/archive, 'rt', encoding='utf8') as stream:
            for row in map(json.loads, stream):
                original_rows[row['id'], row.get('arm')] = row
    with ExitStack() as stack:
        originals = [stack.enter_context(ZipFile(ROOT/name)) for name in old['media_archives']]
        media = {name: z for z in originals for name in z.namelist()}
        def old_read(name):
            return media[name].read(name)
        for stage, prefix, data_name, raw_name, kept_repeat in (
            ('qualified_old_001','old-qualification','qualification.jsonl','arm_qualification.jsonl',0),
            ('formal','old-cf','timing.jsonl','arm_timing.jsonl',5)):
            folder = BASE/stage/f'{prefix}-{seed}'
            episodes = lines(folder/'result'/data_name)
            raw_arms = lines(folder/'result'/raw_name)
            by_key = {(r['ordinal'],r['repeat'],r['arm']):r for r in raw_arms}
            assert len(by_key) == len(raw_arms) == (1800 if stage=='formal' else 180)
            assert len(episodes) == 60 and [r['ordinal'] for r in episodes] == list(range(60))
            summary = read(folder/'result/summary.json')
            assert not summary['equivalence_failures'] and summary['quality_reference_matched']
            spans = []
            saved = 0
            normalized_docs = {}
            with ZipFile(folder/'result/public_proof.zip') as proof:
                assert len(proof.namelist()) == 1081
                for ep in episodes:
                    i = ep['ordinal']
                    assert ep['view_id'] == quality['views']['F'][i]['id']
                    assert ep['action_id'] == quality['actions'][i]['id']
                    assert len(ep['samples']) == (10 if stage=='formal' else 1)
                    for s in ep['samples']:
                        repeat = s['repeat']
                        assert tuple(s['order']) == ORDERS[(seed_index+i+repeat)%6]
                        assert 'paired_equivalence_failure' not in s
                        assert s['arms']['R']['v_features_sha256'] == s['arms']['L']['v_features_sha256'] == s['legacy_v_features_sha256']
                        assert len({r['view_fact_sha256'] for r in s['arms'].values()}) == 1
                        for arm in ARMS:
                            row = s['arms'][arm]
                            assert 'equivalence_failure' not in row
                            expected_raw = dict(ordinal=i,repeat=repeat,order=s['order'],arm=arm,**row)
                            assert by_key[i,repeat,arm] == expected_raw
                            expected_pred = quality['actions'][i]['comparison']['L'] if arm=='L' else s['arms']['F']['predicted_delta_m']
                            assert float(row['predicted_delta_m']).hex() == float(expected_pred).hex(), (stage, seed, i, repeat, arm, row['predicted_delta_m'], expected_pred)
                            if arm == 'F':
                                delta = abs(expected_pred-quality['actions'][i]['comparison']['G'])
                                assert delta <= quality['actions'][i]['delta_budget_m']
                                if delta:
                                    g_differences[i] = delta
                            if stage=='formal':
                                assert s['warmup'] == (repeat<5)
                                assert row['V_ns'] == row['t1_ns']-row['t0_ns'] > 0
                                assert row['A_ns'] == row['t2_ns']-row['t1_ns'] > 0
                                assert row['total_ns'] == row['t2_ns']-row['t0_ns'] == row['V_ns']+row['A_ns']
                                spans.append((row['t0_ns'],row['t2_ns']))
                            if repeat != kept_repeat:
                                continue
                            prefix_name = f'{i:02d}/{repeat:02d}/{arm}/'
                            data = {name: proof.read(prefix_name+name) for name in row['proof_sha256']}
                            for name, payload in data.items():
                                assert digest(payload) == row['proof_sha256'][name]
                                saved += 1
                            view = normalize(data['view.ao.json'])
                            original = original_rows[ep['view_id'],arm]
                            vrow = quality['views'][arm][i]
                            assert data['view.png'] == old_read(f"{ep['view_id']}/{arm}.png")
                            assert digest(data['view.png']) == vrow['png_sha256'] == original['score']['png_sha256']
                            assert view[3][0][5] == old_image(original['audit']['metadata'],view[2])
                            view[3][0][5] = None
                            assert digest(compact(view)) == row['view_fact_sha256']
                            before = normalize(data['before.ao.json'])
                            joint = normalize(data['joint.ao.json'])
                            assert before == normalize(old_read(f"{ep['action_id']}/before.json"))
                            expected_joint = normalize(old_read(f"{ep['action_id']}/after.json"))
                            assert joint[3][0] == before[3][0]
                            assert joint[4][9] == quality['actions'][i]['measured_delta_m']
                            assert joint[4][10] == expected_pred
                            expected_joint[4][10] = expected_pred
                            assert joint == expected_joint
                            assert data['before.png'] == old_read(f"{ep['action_id']}/before.png")
                            assert data['after.png'] == old_read(f"{ep['action_id']}/after.png")
                            normalized_docs[i,arm] = {'view':view,'before':before,'joint':joint}
                            if stage=='formal' and arm=='L':
                                a = dict(quality['actions'][i]); a['comparison'] = dict(a['comparison'])
                                a['comparison']['L'] = joint[4][10]; a['comparison']['G'] = s['arms']['F']['predicted_delta_m']; a['measured_delta_m'] = joint[4][9]
                                actual_actions.append(a)
                assert all(normalized_docs[i,'F']['view'] == normalized_docs[i,'R']['view'] == normalized_docs[i,'L']['view'] for i in range(60))
            if spans:
                spans.sort()
                assert all(a[1] <= b[0] for a,b in zip(spans,spans[1:]))
                timings = {}
                for metric in STAGES:
                    values = {arm:[statistics.median(s['arms'][arm][metric] for s in e['samples'] if not s['warmup']) for e in episodes] for arm in ARMS}
                    ratio = p95(values['L'])/p95(values['F'])
                    assert ratio == summary['timing'][metric]['all']['L']['p95_ratio_to_F']
                    assert p95(values['L']) == summary['timing'][metric]['all']['L']['p95_ns']
                    local = [l/f for l,f in zip(values['L'],values['F'])]
                    timings[metric] = {'F_p95_ns':p95(values['F']), 'L_p95_ns':p95(values['L']), 'L_over_F':ratio,'passed':ratio<=1.10,
                        'paired_increment_p95_ns':p95([l-f for l,f in zip(values['L'],values['F'])]),
                        'cases_above_1_10':sum(x>1.1 for x in local), 'worst_case_ratio':max(local),
                        'worst_ordinal':local.index(max(local)), 'case_medians_ns':values}
                report['timing'] = timings
            report[stage] = {'episodes':len(episodes),'arm_records':len(raw_arms),'actual_saved_files_hash_and_contents_verified':saved,
                             'clock_utc':clock(folder/'runtime.json'),'failures':0}
    qv = {}
    for arm in ('R','L'):
        f, a = quality['views']['F'], quality['views'][arm]
        ratio = statistics.median(r['rays'] for r in a)/statistics.median(r['rays'] for r in f)
        lost = [x['id'] for x,y in zip(f,a) if x['success'] and not y['success']]
        families = set(r['family'] for r in f)
        declined = [fam for fam in families if sum(r['success'] for r in a if r['family']==fam)<sum(r['success'] for r in f if r['family']==fam)]
        qv[arm] = {'median_ray_ratio':ratio,'F_success_lost':lost,'families_declined':declined,
                   'strict_pass_count':sum(r['success'] for r in a),'unsafe_count':sum(not r['safe'] for r in a),
                   'passed':ratio<=.75 and not lost and not declined}
    maes = {arm:float(np.mean([abs(a['comparison'][arm]-a['measured_delta_m']) for a in actual_actions])) for arm in ('C','G','L','shuffle')}
    strongest = min(('C','G'),key=lambda k:maes[k]);ratio=maes['L']/maes[strongest]
    floor=float(np.mean([a['delta_budget_m'] for a in actual_actions]))
    report['quality']={'V':qv,'A':{'MAE_m':maes,'strongest':strongest,'ratio':ratio,'mean_budget_m':floor,'passed':ratio<=.8 and maes[strongest]>floor}}
    report['historical_summary_G_roundoff'] = {'cases':len(g_differences),'max_abs_m':max(g_differences.values(),default=0),
        'values':g_differences,'all_within_original_delta_budget':True,'production_R_equals_concurrent_F_bitwise':True}
    result['seeds'][str(seed)]=report

result['supplements'] = {}
for run in ('run_001','run_002'):
    root = BASE/'control_supplement'/run
    m=read(root/'manifest.json')
    with ZipFile(root/'sources.zip') as z:
        assert all(digest(z.read(p))==h for p,h in m['source_superset'].items())
        result['source_checks'][run+'_source_count']=len(z.namelist())
    rows_by_seed={}
    for seed in SEEDS:
        rows=lines(root/str(seed)/'result/controls.jsonl')
        job=next(j for j in m['jobs'] if j['seed']==seed)
        expected_quality=read(ROOT/job['inputs']['quality'])
        expected_rows={r['id']:r for name in ('controls','diagnostic') for r in expected_quality[name]}
        with gzip.open(ROOT/job['inputs']['records'],'rt',encoding='utf8') as f:
            archived_records={r['id']:r for r in map(json.loads,f) if r['id'] in expected_rows}
        with ZipFile(root/str(seed)/'result/public_outputs.zip') as z:
            saved=0
            with ZipFile(ROOT/job['inputs']['media']) as archive:
                for row in rows:
                    case_id=row['case_id']; expected=expected_rows[case_id]
                    data={name:z.read(case_id+'/'+name) for name in row['public']}
                    for name,payload in data.items():
                        assert digest(payload)==row['public'][name]
                        saved+=1
                    if row['head']=='V':
                        if row['family']=='empty':
                            assert data['view.ao.json']==archive.read(case_id+'/empty.json')
                        else:
                            assert data['view.png']==archive.read(case_id+'/F.png')
                            doc=json.loads(data['view.ao.json'])
                            assert doc[3][0][5]==old_image(archived_records[case_id]['audit']['metadata'],doc[2])
                            assert row['rays']==expected['rays']
                            assert row['strict_pass']==archived_records[case_id]['score']['passed']
                            assert row['pixel_pass']==archived_records[case_id]['score']['pixel_success']
                    else:
                        assert data['before.ao.json']==archive.read(case_id+'/before.json')
                        for name in ('before.png','after.png'):
                            assert data[name]==archive.read(case_id+'/'+name)
                        doc=json.loads(data['joint.ao.json']); original=json.loads(archive.read(case_id+'/after.json'))
                        predicted=doc[4][10]
                        assert doc[4][9]==expected['measured_delta_m']==row['measured_delta_m']
                        if row['predictor']=='L':
                            assert predicted==expected['comparison']['L']
                        elif row['predictor']=='G':
                            assert abs(predicted-expected['comparison']['G'])<=row['prediction_budget_m']
                            assert abs(predicted-row['independent_G_m'])<=row['prediction_budget_m']
                        else:
                            assert predicted is None and row['control_after']==1
                        original[4][10]=predicted
                        assert doc==original
        rows_by_seed[str(seed)]={'recorded_cases':len(rows),'passed':sum(r['passed'] for r in rows),
            'families':dict(Counter(r['family'] for r in rows)),'actual_files_hash_verified':saved,
            'runtime_utc':clock(root/str(seed)/'runtime.json')}
        if run=='run_002':
            assert len(rows)==31 and all(r['passed'] for r in rows)
            assert sum(r.get('predictor')=='L' for r in rows)==6
            assert sum(r.get('predictor')=='NONE' for r in rows)==1
    result['supplements'][run]={'seeds':rows_by_seed,'exclusions':m['exclusions']}

result['all_nine_cost_gates_pass'] = all(x['passed'] for r in result['seeds'].values() for x in r['timing'].values())
result['all_original_L_quality_gates_preserved'] = all(r['quality']['A']['passed'] and r['quality']['V']['L']['passed'] for r in result['seeds'].values())
result['retained_historical_R_gate_failures'] = [seed for seed,r in result['seeds'].items() if not r['quality']['V']['R']['passed']]
result['production_functional_coverage'] = {
    'status':'INCOMPLETE_PRODUCTION_F_ORIGINAL_V_MAIN_SET',
    'explicit_requirement':'79f8bcc:docs/PRODUCTION_FUNCTIONAL_REVIEW.md:46 requires original three-seed V F/R/L through production session and v1',
    'missing_original_V_F_cases':180,
    'original_V_F_in_this_batch':'Historical _run_f only; not production I',
    'other_production_F_evidence':'Three new F/G scenarios, original A before/after observations, and old V controls 12 per seed do not replace the original V evaluation list',
    'minimal_completion':'Untimed production F once on each original V case, 60 per original seed; actual public bytes/audit equality and no-ticket/unchanged-model proof',
    'no_repetition_required':['old cost gates','A G/L','V R/L','31 original controls','training','optimization'],
    'historical_F_cost_gates_remain_valid':True,
    'later_completion_does_not_retroactively_qualify_formal_start':True,
}
formal_clocks=[clock(p) for p in (BASE/'formal').glob('*/runtime.json')]
result['formal_full_batch_utc']={'start':min(c['start'] for c in formal_clocks),'end':max(c['end'] for c in formal_clocks)}
(OUT/'old_cf_recompute.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in result.items() if k not in ('seeds','supplements')},indent=2))
for seed,r in result['seeds'].items():
    print(seed, {k:{kk:vv for kk,vv in v.items() if kk!='case_medians_ns'} for k,v in r['timing'].items()},r['quality'])
