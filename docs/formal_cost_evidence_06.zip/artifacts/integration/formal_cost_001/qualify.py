"""Establish real scored feedback and public equality before formal measurements."""

from contextlib import contextmanager
import json
from pathlib import Path
import time
from unittest.mock import patch

import numpy as np

from artifacts.integration.formal_cost_001.common import PHASES, ROOT, digest, load_workload
from artifacts.integration.method_diagnostic_001.runtime_identity import write_json
from human_eye_fast import load_cf_deployment
from human_eye_fast.fast_affordance_out import public_schema
from verification import test_blender_radical_session as functional
from verification.cf_training import load_frozen
from verification.cf_visual_acceptance import PillowWorker
from verification.integration_fixtures import build_fixture, fixture_manifest


NAMES = ("before.ao.json", "transition.ao.json", "next.ao.json", "before.png", "after.png", "next.png")
UNCHANGED = ("model_calls", "feedback_state", "measured_delta_m", "predicted_delta_m", "next_prediction_m")


class Consumer:
    def __init__(self, pillow):
        self.pillow = pillow
        self.calls = []

    def score(self, png, evidence):
        start = time.perf_counter_ns()
        score = self.pillow.score(png, evidence)
        end = time.perf_counter_ns()
        self.calls.append({"start_ns": start, "end_ns": end, "elapsed_ns": end - start})
        return score


def _run_scored(kind, fixture, plan, predictor, frozen, deployment, pillow, schema, out):
    """Keep this external consumer workflow separate from service timing."""
    stamps = {}
    scoring = Consumer(pillow)
    original_api = functional._api

    @contextmanager
    def timed_api(*args, **kwargs):
        with original_api(*args, **kwargs) as api:
            observe, predict = api.observe, api.predict

            def before(phase):
                if phase["observation_id"] == "before":
                    stamps["t0_before_observe"] = time.perf_counter_ns()
                return observe(phase)

            def next_prediction(current, command, action_id, arm):
                result = predict(current, command, action_id, arm)
                if action_id == "next-act":
                    stamps["t4_after_next_prediction"] = time.perf_counter_ns()
                return result

            api.observe, api.predict = before, next_prediction
            yield api

    with patch.object(functional, "_api", timed_api):
        outputs = functional._run_arm(kind, fixture, plan, "L", predictor, frozen, deployment, scoring, schema, out)
    assert len(scoring.calls) == 3
    stamps.update(full_elapsed_ns=stamps["t4_after_next_prediction"] - stamps["t0_before_observe"],
                  score_roundtrips=dict(zip(PHASES, scoring.calls, strict=True)),
                  score_wait_inside_ns=sum(call["elapsed_ns"] for call in scoring.calls[:2]))
    return outputs, stamps


def _score_new_seed(manifest, seed, out):
    schema = public_schema()
    frozen = load_frozen(ROOT / seed["snapshot"])
    deployment = load_cf_deployment(ROOT / seed["deployment"])
    target = out / "scored" / "L"
    plans = manifest["formal_plans"]
    external = []
    write_json(out / "public-schema.json", schema)
    with PillowWorker(Path(manifest["pillow_python"])) as scorer:
        for spec, plan in zip(fixture_manifest(), plans, strict=True):
            fixture = build_fixture(spec)
            assert plan["case_id"] == spec.case_id
            predictor = plan["arms"]["deployment"]["predictor"]
            paired = {}
            for role in ("B", "I"):
                paired[role], closure = _run_scored(role, fixture, plan, predictor, frozen, deployment,
                                                    scorer, schema, target / spec.case_id / role)
                external.append({"case": spec.case_id, "role": role, **closure})
            base, candidate = paired["B"], paired["I"]
            assert base[1:] == candidate[1:], (spec.case_id, "public bytes or real scores differ")
            assert all(base[0][field] == candidate[0][field] for field in UNCHANGED), spec.case_id
    write_json(out / "external-consumer.json", {
        "scope": "functional external scorer loop, not formal service timing",
        "includes": ["real Pillow child roundtrip", "native independent VisualAudit", "functional verification and archiving before feedback"],
        "note": "The next image score is reported separately and occurs after t4. Seed 20261105 reuses already scored evidence.",
        "rows": external,
    })
    return target


def _feedback(case_root):
    phases = {}
    for role in PHASES:
        visual_path, image_path = case_root / f"{role}.visual.json", case_root / f"{role}.png"
        raw = visual_path.read_bytes()
        record = json.loads(raw)
        native, score = record["evidence"], record["score"]
        metadata = native["metadata"]
        png_sha = digest(image_path.read_bytes())
        assert score["png_sha256"] == png_sha
        phases[role] = {
            "frame_id": metadata["frame_id"], "png_sha256": png_sha,
            "canonical_index": native["candidate"], "direction": metadata["selection"]["direction"],
            "order": native["order"], "total_rays": native["ray_count"], "selected_rays": native["selected_rays"],
            "native_stop": native["native_stop"], "safe": score["safe"], "pixel_success": score["pixel_success"],
            "strict_passed": score["passed"], "failed_checks": [name for name, ok in score["checks"].items() if not ok],
            "visual_path": visual_path.relative_to(ROOT).as_posix(), "visual_sha256": digest(raw),
            "png_path": image_path.relative_to(ROOT).as_posix(),
        }
    return phases


def run(manifest_path, out_dir, process_index):
    import bpy

    assert bpy.app.background
    out_dir.mkdir()
    manifest = json.loads(Path(manifest_path).read_bytes())
    seed = manifest["seeds"][process_index]
    if process_index == 0:
        scored = ROOT / seed["previous_functional_tree"]
    else:
        scored = _score_new_seed(manifest, seed, out_dir)
    feedback = {}
    for plan in manifest["formal_plans"]:
        case_id = plan["case_id"]
        case = scored / case_id
        for name in NAMES:
            assert (case / "B" / name).read_bytes() == (case / "I" / name).read_bytes(), (case_id, name)
        before_after_next = _feedback(case / "I")
        for phase in PHASES:
            visual_b = json.loads((case / "B" / f"{phase}.visual.json").read_bytes())
            visual_i = json.loads((case / "I" / f"{phase}.visual.json").read_bytes())
            assert visual_b["score"] == visual_i["score"]
        feedback[case_id] = before_after_next
    if process_index == 0:
        preserved = feedback["I-carried-screen-0"]["after"]
        assert not preserved["safe"] and preserved["failed_checks"] == ["directions"]
    seed["integration_feedback"] = feedback
    write_json(out_dir / "feedback.json", feedback)

    checks = []
    for case in load_workload(manifest, process_index):
        paired = {}
        for role in ("B", "I"):
            with case.lane(role) as lane:
                reset = lane.reset()
                _, outputs = lane.run(0, clock=lambda: 0)
                proof = lane.proof(outputs)
                assert all(proof["checks"].values()), (case.case_id, role, proof["checks"])
                proof["model"] = {key: array.copy() for key, array in proof["model"].items()}
                paired[role] = proof, reset
                del outputs, proof
        (base, base_reset), (candidate, candidate_reset) = paired["B"], paired["I"]
        assert base_reset == candidate_reset
        assert base["public"] == candidate["public"] and base["next"] == candidate["next"], case.case_id
        assert base["model"].keys() == candidate["model"].keys()
        assert all(np.array_equal(array, candidate["model"][key]) for key, array in base["model"].items()), case.case_id
        checks.append({"case": case.case_id, "public": {key: digest(value) for key, value in base["public"].items()},
                       "reset_digest": base_reset, "binding_checks": base["checks"],
                       "public_next_model_exact": True})
    write_json(out_dir / "summary.json", {
        "scope": "functional comparison of formal adapter, no service intervals",
        "seed": seed["seed"], "scored_path": scored.relative_to(ROOT).as_posix(),
        "all_cases_passed": True, "cases": checks,
    })
