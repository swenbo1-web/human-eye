"""Formal per-role resource worker over the frozen 24-case B/I workload."""

from collections import Counter
from contextlib import ExitStack
from hashlib import sha256
import json
import os
from pathlib import Path
import time
import traceback
import tracemalloc

from artifacts.integration.formal_cost_001.common import load_workload
from artifacts.integration.formal_cost_001.resource_instruments import (
    SerializedSampler, backing_census, logical_gpu_audit, os_window_summary,
)
from artifacts.integration.method_diagnostic_001.resource_diagnostic import _OffscreenRelease
from artifacts.integration.preflight_002.resource_probe import DxgiProcessUsage


WARM_PAIRS = range(5)
HOT_PAIR = 5
CLOSE_LIFECYCLE_PAIR = 36
REOPEN_LIFECYCLE_PAIR = 37
MANAGED_HOT_POINTS = ("hot_outputs_held", "hot_outputs_released", "hot_reference_replaced")


def _write(stream, value):
    stream.write(json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":")) + "\n")
    stream.flush()


def _identity(data):
    return {"sha256": sha256(data).hexdigest(), "bytes": len(data)}


def _current_point(stream, case_id, name, roots, reading=None):
    current, peak = tracemalloc.get_traced_memory() if reading is None else reading
    ownership = backing_census(roots())
    _write(stream, {"case": case_id, "point": name, "current_bytes": current,
                    "peak_since_latest_reset_bytes": peak, "ownership": ownership})
    return current, not ownership["uncovered_types"]


def _proof_summary(lane, outputs):
    from artifacts.integration.method_diagnostic_001.bb_diagnostic import _arrays_digest

    proof = lane.proof(outputs)
    return {
        "checks": proof["checks"],
        "public": {name: _identity(data) for name, data in proof["public"].items()},
        "active_model_sha256": _arrays_digest(proof["model"]),
        "next_sha256": sha256(json.dumps(proof["next"], allow_nan=False, sort_keys=True,
                                          separators=(",", ":")).encode()).hexdigest(),
    }


def _retained_public(outputs):
    before, transition, following = outputs.before, outputs.result, outputs.following
    return {"before.ao.json": before.ao_bytes, "transition.ao.json": transition.ao_bytes,
            "next.ao.json": following.ao_bytes,
            **before.attachments, **transition.attachments, **following.attachments}


def _read_after_close(payloads):
    from human_eye_fast.fast_affordance_out import public_schema

    columns = public_schema()["columns"]
    attachment_names = set()
    identities = {}
    for name, data in payloads.items():
        if type(data) is not bytes:
            raise TypeError(f"Public payload is not immutable: {name}")
        if name.endswith(".png"):
            if not data.startswith(b"\x89PNG\r\n\x1a\n"):
                raise ValueError(f"Invalid retained PNG {name}")
        else:
            decoded = dict(zip(columns["package"], json.loads(data), strict=True))
            if decoded["version"] != "he-ao/1":
                raise ValueError("Invalid retained AO")
            for record in decoded["observations"]:
                observation = dict(zip(columns["observation"], record, strict=True))
                image = dict(zip(columns["image"], observation["image"], strict=True))
                if image["path"] != f"{observation['observation_id']}.png":
                    raise ValueError("Retained attachment is no longer bound")
                attachment_names.add(image["path"])
        identities[name] = _identity(data)
    return {"public_bytes_valid": len(attachment_names) == 3
            and attachment_names == {name for name in payloads if name.endswith(".png")},
            "retained": identities}


def _ticket_owner(output, role):
    ticket = output.following.view_ticket
    return ticket._owner if role == "I" else ticket.owner


def _instrument_close(lane):
    import bpy

    model, controller, renderer = lane.model, lane.controller, lane.renderer
    cameras = tuple((camera.name, camera.data.name) for camera in renderer.cameras)
    cameras_present_before = all(bpy.data.objects.get(obj) is not None
                                 and bpy.data.cameras.get(data) is not None for obj, data in cameras)
    release = _OffscreenRelease(renderer.offscreen)
    renderer.offscreen = release

    def check():
        model_cleared = (model.view_head is None and model.action_head is None and model.retrieval_scale is None
                         and all(bank.keys is None and bank.values is None and bank.known is None
                                 for bank in (model.views, model.actions)))
        return {
            "one_offscreen_free": release.completed_calls == 1 and release.target is None,
            "camera_objects_and_data_removed": cameras_present_before and len(cameras) == 2
            and all(bpy.data.objects.get(obj) is None and bpy.data.cameras.get(data) is None
                    for obj, data in cameras),
            "renderer_cpu_buffers_cleared": all(getattr(renderer, name) is None
                                                for name in ("rgb", "rgb_deltas", "scanlines", "previous_row")),
            "model_arrays_cleared": model_cleared,
            "bridge_indexes_and_current_cleared": not controller.bridge._objects
            and controller._indexes is None and controller._latest is None and lane.current is None,
            "session_reference_and_renderer_cleared": lane.reference is None and lane.renderer is None
            and lane.model is None and not lane.basis,
        }

    return check


def _close_and_check(lane):
    check = _instrument_close(lane)
    lane.close()
    return check()


class _CallerAbort(Exception):
    """Exercise the cleanup path after an exception outside the service interval."""


def _managed_hot(lane, result, checkpoints):
    return_reading = None

    def after_t4():
        nonlocal return_reading
        return_reading = tracemalloc.get_traced_memory()

    start_current = tracemalloc.get_traced_memory()[0]
    tracemalloc.reset_peak()
    stamps, outputs = lane.run(HOT_PAIR, after_t4=after_t4)
    if return_reading is None:
        raise RuntimeError("No immediate t4 trace reading")
    result["stamps_qpc_ns"] = stamps
    result["managed"]["current_before_reset_bytes"] = start_current
    result["managed"]["window_peak_bytes"] = return_reading[1]
    result["managed"]["peak_above_start_bytes"] = return_reading[1] - start_current
    _record_hot_point(result, checkpoints, "hot_outputs_held", lambda: lane.owner_roots(outputs),
                      reading=return_reading)
    return outputs


def _record_hot_point(result, checkpoints, name, roots, *, reading=None):
    current, known = _current_point(checkpoints, result["case"], name, roots, reading)
    result["managed"]["current_bytes"][name] = current
    result["managed"]["ownership_covered"][name] = known


def _os_hot(lane, result, samples_stream, dxgi, adapter_error, config):
    interval_ns = config["interval_ns"]
    if adapter_error is None:
        import gpu

        if config["adapter_description"].casefold() not in gpu.platform.renderer_get().casefold():
            adapter_error = "DXGI adapter did not match the Blender renderer"
    sampler = None if adapter_error is not None else SerializedSampler(dxgi, interval_ns, config["node"])
    stage_points, samples, point_errors = [], [], []
    stamps = None
    pending = None

    def point(name, boundary=None):
        if sampler is not None:
            try:
                stage_points.append({**sampler.point(name), "phase_boundary_qpc_ns": boundary})
            except Exception as error:
                point_errors.append(f"{name}: {error!r}")

    def stage_hook(name, boundary):
        point(f"post_{name}", boundary)

    try:
        if sampler is not None:
            sampler.prepare()
            point("pre_t0")
            sampler.started.set()
        stamps, outputs = lane.run(HOT_PAIR, stage_hook=stage_hook)
        result["stamps_qpc_ns"] = stamps
        if stage_points and stage_points[0]["phase"] == "pre_t0":
            stage_points[0]["phase_boundary_qpc_ns"] = stamps["t0"]
    except Exception as error:
        pending = error
        raise
    finally:
        if sampler is not None and sampler.thread.ident is not None:
            sampler.stop()
            samples = sampler.records()
        sampling_error = "; ".join(point_errors) or None
        if sampler is not None and sampler.error is not None:
            sampling_error = f"{sampling_error or ''} {sampler.error}".strip()
        saturated = sampler is not None and sampler.count >= len(sampler.samples)
        _write(samples_stream, {
            "case": result["case"], "pid": os.getpid(), "role": result["role"],
            "adapter": None if dxgi is None else dxgi.identity, "node": config["node"],
            "stamps_qpc_ns": stamps, "phase_points": stage_points, "periodic": samples,
            "sampler_error": sampling_error, "adapter_error": adapter_error,
            "buffer_capacity": None if sampler is None else len(sampler.samples),
            "buffer_saturated": saturated, "workload_error": None if pending is None else repr(pending),
        })
        if stamps is not None:
            result["os"] = os_window_summary(stamps, stage_points, samples, interval_ns=interval_ns,
                                              saturated=saturated, sampler_error=sampling_error,
                                              adapter_error=adapter_error)
    return outputs


def _case_work(case, role, instrument, result, checkpoints, samples_stream, dxgi, adapter_error, config):
    managed = instrument == "managed"
    if managed:
        result["managed"] = {"current_bytes": {}, "ownership_covered": {}}
        _current_point(checkpoints, case.case_id, "cold_before_lane", dict)

    def setup_hook(name):
        _current_point(checkpoints, case.case_id, f"cold_{name}", dict)

    with case.lane(role, setup_hook=setup_hook if managed else None) as lane:
        if managed:
            _current_point(checkpoints, case.case_id, "cold_lane_ready", lane.owner_roots)
        for pair in WARM_PAIRS:
            lane.reset()
            _, warm = lane.run(pair)
            del warm
        del _
        lane.reset()
        if managed:
            outputs = _managed_hot(lane, result, checkpoints)
        else:
            outputs = _os_hot(lane, result, samples_stream, dxgi, adapter_error, config)
        result["hot_proof"] = _proof_summary(lane, outputs)
        del outputs
        if managed:
            _record_hot_point(result, checkpoints, "hot_outputs_released", lane.owner_roots)

        lane.reset()
        lane.replace_reference()
        if managed:
            _record_hot_point(result, checkpoints, "hot_reference_replaced", lane.owner_roots)
        _, lifecycle_outputs = lane.run(CLOSE_LIFECYCLE_PAIR)
        old_owner = _ticket_owner(lifecycle_outputs, role)
        payloads = _retained_public(lifecycle_outputs)
        retained_before_close = {name: _identity(data) for name, data in payloads.items()}
        del lifecycle_outputs, _
        lifecycle = {"close": _close_and_check(lane)}
        result["lifecycle"] = lifecycle
        if managed:
            _current_point(checkpoints, case.case_id, "closed_public_bytes_held",
                           lambda: lane.owner_roots(payloads))
        lifecycle["closed_public"] = _read_after_close(payloads)
        lifecycle["closed_public"]["unchanged_across_close"] = (
            retained_before_close == lifecycle["closed_public"]["retained"])
        del retained_before_close
        del payloads
        if managed:
            _current_point(checkpoints, case.case_id, "closed_public_bytes_released", lane.owner_roots)
    del lane

    if managed:
        _current_point(checkpoints, case.case_id, "cold_before_reopen", dict)
    with logical_gpu_audit() as logical:
        try:
            with case.lane(role) as reopened:
                lifecycle["fresh_reopen"] = (reopened.current is None and reopened.renderer is None
                                             and not reopened.controller.bridge._objects
                                             and reopened.model.views.writes == reopened.model.actions.writes == 240)
                if managed:
                    _current_point(checkpoints, case.case_id, "cold_reopened_lane_ready", reopened.owner_roots)
                reopened.reset()
                _, reopen_outputs = reopened.run(REOPEN_LIFECYCLE_PAIR)
                lifecycle["reopened_ticket_owner_is_distinct"] = _ticket_owner(reopen_outputs, role) is not old_owner
                lifecycle["reopened_proof"] = _proof_summary(reopened, reopen_outputs)
                if managed:
                    _current_point(checkpoints, case.case_id, "reopened_outputs_held",
                                   lambda: reopened.owner_roots(reopen_outputs))
                del reopen_outputs, _
                check_release = _instrument_close(reopened)
                raise _CallerAbort
        except _CallerAbort:
            lifecycle["reopened_close"] = check_release()
            lifecycle["reopened_close_trigger"] = "untimed caller exception through lane finally"
            del check_release
        result["logical_gpu"] = logical
    del reopened, old_owner
    if managed:
        _current_point(checkpoints, case.case_id, "reopened_released", dict)

    if (not all(result["hot_proof"]["checks"].values())
            or not all(lifecycle["close"].values()) or not all(lifecycle["reopened_close"].values())
            or not lifecycle["closed_public"]["public_bytes_valid"] or not lifecycle["fresh_reopen"]
            or not lifecycle["closed_public"]["unchanged_across_close"]
            or not lifecycle["reopened_ticket_owner_is_distinct"]
            or not all(lifecycle["reopened_proof"]["checks"].values())
            or logical["renderers"] != 1 or len(logical["offscreen"]) != 1 or len(logical["cameras"]) != 2
            or not logical["batches"]):
        result["status"] = "FAIL"
    elif ((managed and not all(result["managed"]["ownership_covered"].values()))
          or (not managed and result["os"]["status"] != "VERIFIED")):
        result["status"] = "UNVERIFIED"
    else:
        result["status"] = "VERIFIED"


def run(manifest_path, out_dir, process_index, role, instrument):
    """Run one registered B or I resource process, never a latency worker."""
    import bpy
    import gpu
    # Load the native renderer module before tracing initialization.
    from human_eye_fast import raycast_saccade_gpu

    if not bpy.app.background:
        raise RuntimeError("Use a dedicated Blender background process")
    if role not in ("B", "I") or instrument not in ("managed", "os"):
        raise ValueError("Unknown formal resource role or instrument")
    manifest_path, out_dir = Path(manifest_path), Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    manifest_data = manifest_path.read_bytes()
    manifest = json.loads(manifest_data)
    config = manifest["resource"]
    if config["interval_ns"] != 2_000_000:
        raise ValueError("The frozen periodic sampling target is 2 ms")
    statuses = Counter()
    dxgi = None
    adapter_error = None
    with ExitStack() as stack:
        records = stack.enter_context((out_dir / "cases.jsonl").open("x", encoding="utf-8", newline="\n"))
        checkpoints = samples_stream = None
        if instrument == "managed":
            checkpoints = stack.enter_context((out_dir / "checkpoints.jsonl").open("x", encoding="utf-8", newline="\n"))
            tracemalloc.start()
            stack.callback(tracemalloc.stop)
            _current_point(checkpoints, None, "cold_before_workload_load", dict)
        else:
            samples_stream = stack.enter_context((out_dir / "os_samples.jsonl").open("x", encoding="utf-8", newline="\n"))
            try:
                dxgi = DxgiProcessUsage(stack, config["adapter_description"])
                if dxgi.identity["luid"] != config["adapter_luid"]:
                    adapter_error = f"Unexpected adapter LUID {dxgi.identity['luid']}"
            except (OSError, ValueError) as error:
                adapter_error = repr(error)
        cases = load_workload(manifest_path, process_index)
        if instrument == "managed":
            _current_point(checkpoints, None, "cold_after_workload_load",
                           lambda: {"immutable_deployment_parameters": cases[0].deployment})
        for case in cases:
            result = {"case": case.case_id, "ordinal": case.ordinal, "family": case.family,
                      "role": role, "instrument": instrument}
            try:
                _case_work(case, role, instrument, result, checkpoints, samples_stream, dxgi,
                           adapter_error, config)
            except Exception:
                result["status"] = "UNVERIFIED"
                result["error"] = traceback.format_exc()
            statuses[result["status"]] += 1
            _write(records, result)
            del result
    status = "FAIL" if statuses["FAIL"] else "VERIFIED" if statuses["VERIFIED"] == 24 else "UNVERIFIED"
    try:
        gpu_identity = {"gpu_backend": gpu.platform.backend_type_get(),
                        "gpu_renderer": gpu.platform.renderer_get()}
    except SystemError as error:
        gpu_identity = {"gpu_backend": None, "gpu_renderer": None, "gpu_identity_error": repr(error)}
    summary = {
        "scope": "per-role resource evidence; B/I gates are evaluated by the parent runner",
        "manifest_sha256": _identity(manifest_data)["sha256"], "pid": os.getpid(),
        "process_index": process_index, "role": role, "instrument": instrument,
        "seed": manifest["seeds"][process_index]["seed"], "cases": 24, "warm_chains_per_case": 5,
        "measured_chains_per_case": 1, "measured_pair": HOT_PAIR,
        "untimed_resource_lifecycle_pairs": [CLOSE_LIFECYCLE_PAIR, REOPEN_LIFECYCLE_PAIR],
        "managed_hot_points": MANAGED_HOT_POINTS,
        **gpu_identity,
        "renderer_module": raycast_saccade_gpu.__name__,
        "dxgi_adapter": None if dxgi is None else dxgi.identity, "node": config["node"],
        "adapter_error": adapter_error, "status_counts": dict(statuses), "status": status,
        "clock": vars(time.get_clock_info("perf_counter")),
        "limitations": [
            "OS phase points plus valid periodic observations show only a sampled maximum.",
            "The managed traced peak is read before creating report dictionaries or owner censuses.",
            "NumPy backing inventory is attribution only and is not added to traced bytes.",
            "Logical allocation instrumentation runs on the separate close/reopen lifecycle only.",
        ],
    }
    with (out_dir / "summary.json").open("x", encoding="utf-8", newline="\n") as stream:
        _write(stream, summary)
    return summary


def _read_worker(directory):
    directory = Path(directory)
    rows = {}
    problems = []
    try:
        summary = json.loads((directory / "summary.json").read_bytes())
    except (OSError, ValueError) as error:
        problems.append(f"summary: {error!r}")
        summary = {}
    try:
        with (directory / "cases.jsonl").open(encoding="utf-8") as stream:
            for line_number, line in enumerate(stream, 1):
                try:
                    row = json.loads(line)
                    ordinal = row["ordinal"]
                    if type(ordinal) is not int or ordinal not in range(24) or ordinal in rows:
                        raise ValueError("Expected one distinct ordinal from 0 through 23")
                    rows[ordinal] = row
                except (ValueError, TypeError, KeyError) as error:
                    problems.append(f"case record {line_number}: {error!r}")
    except OSError as error:
        problems.append(f"case records: {error!r}")
    return summary, rows, problems


def _delta(base, candidate, limit, *, verified):
    difference = candidate - base if type(base) is int and type(candidate) is int else None
    if not verified or difference is None:
        status = "UNVERIFIED"
    else:
        status = "PASS" if difference <= limit else "FAIL"
    return {"B_bytes": base, "I_bytes": candidate, "I_minus_B_bytes": difference,
            "limit_bytes": limit, "status": status}


def _combine(statuses):
    if "FAIL" in statuses:
        return "FAIL"
    return "PASS" if statuses and all(status == "PASS" for status in statuses) else "UNVERIFIED"


def _check_same(left, right, *, verified=True):
    if not verified or left is None or right is None:
        return "UNVERIFIED"
    return "PASS" if left == right else "FAIL"


def _pair_proof(base, candidate):
    left, right = base.get("hot_proof"), candidate.get("hot_proof")
    if not left or not right:
        return "UNVERIFIED"
    if not all(left["checks"].values()) or not all(right["checks"].values()):
        return "FAIL"
    return _check_same(left, right)


def _logical_status(base, candidate):
    left, right = base.get("logical_gpu"), candidate.get("logical_gpu")
    if left is None or right is None:
        return "UNVERIFIED"
    for row, logical in ((base, left), (candidate, right)):
        lifecycle = row.get("lifecycle", {})
        if (logical.get("renderers") != 1 or len(logical.get("offscreen", ())) != 1
                or len(logical.get("cameras", ())) != 2 or not logical.get("batches")
                or not lifecycle.get("fresh_reopen") or not lifecycle.get("reopened_ticket_owner_is_distinct")
                or not all(lifecycle.get("close", {"missing": False}).values())
                or not all(lifecycle.get("reopened_close", {"missing": False}).values())):
            return "FAIL"
        closed = lifecycle.get("closed_public", {})
        if not closed.get("public_bytes_valid") or not closed.get("unchanged_across_close"):
            return "FAIL"
    return _combine([
        _check_same(left, right),
        _check_same(base["lifecycle"]["closed_public"]["retained"],
                    candidate["lifecycle"]["closed_public"]["retained"]),
        _check_same(base["lifecycle"].get("reopened_proof"), candidate["lifecycle"].get("reopened_proof")),
    ])


def compare(base_dir, candidate_dir, instrument=None):
    """Compare each corresponding frozen B/I resource window without pooling."""
    bmeta, base, berrors = _read_worker(base_dir)
    imeta, candidate, ierrors = _read_worker(candidate_dir)
    instrument = instrument or bmeta.get("instrument") or imeta.get("instrument")
    if (instrument not in ("managed", "os") or bmeta.get("instrument") != instrument
            or imeta.get("instrument") != instrument or bmeta.get("role") != "B"
            or imeta.get("role") != "I" or bmeta.get("seed") != imeta.get("seed")
            or bmeta.get("manifest_sha256") != imeta.get("manifest_sha256")):
        berrors.append("The worker manifests, seeds, roles or instruments do not match")
    matched_jobs = not berrors and not ierrors
    cases = []
    gate_values = {}
    for ordinal in range(24):
        b, i = base.get(ordinal, {}), candidate.get(ordinal, {})
        identity = b.get("case") or i.get("case")
        paired_case = matched_jobs and b.get("case") == i.get("case") and bool(identity)
        proof = _pair_proof(b, i) if paired_case else "UNVERIFIED"
        logical = _logical_status(b, i) if paired_case else "UNVERIFIED"
        row = {"case": identity, "ordinal": ordinal, "family": b.get("family") or i.get("family"),
               "public_and_model_equivalence": proof, "logical_gpu_and_lifecycle": logical,
               "role_status": {role: case.get("status", "UNVERIFIED")
                               for role, case in (("B", b), ("I", i))}}
        if instrument == "managed":
            mb, mi = b.get("managed", {}), i.get("managed", {})
            deltas = {}
            for point in MANAGED_HOT_POINTS:
                deltas[point] = _delta(mb.get("current_bytes", {}).get(point),
                                       mi.get("current_bytes", {}).get(point), 262_144,
                                       verified=proof == "PASS"
                                       and mb.get("ownership_covered", {}).get(point)
                                       and mi.get("ownership_covered", {}).get(point))
            deltas["window_peak"] = _delta(mb.get("window_peak_bytes"), mi.get("window_peak_bytes"),
                                           1_048_576, verified=proof == "PASS")
        elif instrument == "os":
            ob, oi = b.get("os", {}), i.get("os", {})
            verified = proof == "PASS" and ob.get("status") == oi.get("status") == "VERIFIED"
            deltas = {
                key: _delta((ob.get("observed_sampled_maximum") or {}).get(key),
                            (oi.get("observed_sampled_maximum") or {}).get(key), 8_388_608, verified=verified)
                for key in ("rss_bytes", "gpu_same_record_sum_bytes")
            }
        else:
            deltas = {}
        row["metric_deltas"] = deltas
        row["status"] = _combine([proof, logical, *(entry["status"] for entry in deltas.values())])
        cases.append(row)
        for key, entry in deltas.items():
            gate_values.setdefault(key, []).append((identity, entry))
    metrics = {}
    for key, entries in gate_values.items():
        usable = [(case, entry) for case, entry in entries if entry["status"] != "UNVERIFIED"]
        worst = max(usable, key=lambda pair: pair[1]["I_minus_B_bytes"]) if usable else None
        metrics[key] = {"status": _combine([entry["status"] for _, entry in entries]),
                        "verified_cases": len(usable),
                        "max_case": worst[0] if worst else None,
                        "maximum_I_minus_B_bytes": worst[1]["I_minus_B_bytes"] if worst else None}
    return {
        "seed": bmeta.get("seed") or imeta.get("seed"), "instrument": instrument,
        "status": _combine([row["status"] for row in cases]), "metrics": metrics, "cases": cases,
        "public_and_model_equivalence": _combine([row["public_and_model_equivalence"] for row in cases]),
        "logical_gpu_and_lifecycle": _combine([row["logical_gpu_and_lifecycle"] for row in cases]),
        "input_errors": {"B": berrors, "I": ierrors},
    }
