"""Aggregate the single registered formal batch without changing any gate."""

from argparse import ArgumentParser
from collections import Counter
from hashlib import file_digest
import json
from pathlib import Path
import sys

import numpy as np


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT))

from artifacts.integration.formal_cost_001 import old_cf, resources
from artifacts.integration.method_diagnostic_001.runtime_identity import write_json


GATE_SEGMENTS = ("before", "action", "feedback", "next", "continuous_total")


def read_optional(path):
    return json.loads(path.read_bytes()) if path.is_file() else None


def status_for(values):
    values = tuple(values)
    if "FAIL" in values:
        return "FAIL"
    return "PASS" if values and all(value == "PASS" for value in values) else "UNVERIFIED"


def identify(path):
    with path.open("rb") as stream:
        return {"sha256": file_digest(stream, "sha256").hexdigest(), "bytes": path.stat().st_size}


def _verified(directory):
    record = read_optional(directory / "process.json")
    return bool(record and record["verified_process"])


def _summary(directory):
    return read_optional(directory / "result/summary.json") or {}


def _latency(directory):
    result = _summary(directory)
    segments = result.get("segments", {})
    metrics = {name: {key: segments.get(name, {}).get(key) for key in ("p95_ns", "I_over_B", "gate")}
               for name in GATE_SEGMENTS}
    return {"status": result.get("status", "UNVERIFIED") if _verified(directory) else "UNVERIFIED",
            "quality_gate": result.get("quality_gate"), "latency_gate": result.get("latency_gate"),
            "matched_pairs": result.get("matched_pairs"), "raw_arm_records": result.get("raw_arm_records"),
            "segments": metrics, "details": f"{directory.name}/result/summary.json"}


def _old_cf(directory):
    result = _summary(directory)
    metrics = {name: row.get("all", {}).get("L", {}) for name, row in result.get("timing", {}).items()}
    return {"status": result.get("status", "UNVERIFIED") if _verified(directory) else "UNVERIFIED",
            "quality_reference_matched": result.get("quality_reference_matched"),
            "equivalence_failure_count": result.get("equivalence_failure_count"),
            "original_gate_metrics_L": metrics,
            "details": f"{directory.name}/result/summary.json"}


def _resource(out, instrument, seed):
    base, candidate = (out / f"{instrument}-{seed}-{role}" for role in ("B", "I"))
    result = resources.compare(base / "result", candidate / "result", instrument)
    if not _verified(base) or not _verified(candidate):
        result["process_invalid"] = True
        result["status"] = "UNVERIFIED"
    output = out / f"{instrument}-comparison-{seed}.json"
    write_json(output, result)
    failures = [row["case"] for row in result["cases"] if row["status"] == "FAIL"]
    unknown = [row["case"] for row in result["cases"] if row["status"] == "UNVERIFIED"]
    return {key: result[key] for key in ("status", "metrics", "public_and_model_equivalence",
                                        "logical_gpu_and_lifecycle")} | {
        "failed_cases": failures, "unverified_cases": unknown, "details": output.name}


def _latency_pooled(out, seeds):
    reports = [_summary(out / f"latency-{seed}") for seed in seeds]
    result = {}
    if not all(report.get("segments") for report in reports):
        return None
    for segment in GATE_SEGMENTS:
        rows = [case for report in reports for case in report["segments"][segment]["cases"].values()]
        p95 = {role: float(np.quantile([case["arms"][role]["median_ns"] for case in rows], .95,
                                      method="linear")) for role in ("B", "I")}
        result[segment] = {"case_seed_rows": len(rows), "p95_ns": p95,
                           "I_over_B": p95["I"] / p95["B"] if p95["B"] > 0 else None}
    return result


def _write_readme(out, result):
    lines = [
        "# 统一 Blender 正式成本结果", "",
        f"本轮结果为 **{result['status']}**，提交主干独立复审。"
        "正式批次沿用冻结的分种子时延门、旧 CF 原双场景门和资源观测门。"
        "聚合描述单列，历史 B/B 失败保留。 [登记清单](manifest.json) · [机器汇总](summary.json)", "",
        "| 种子 | 同场景时延 | 旧 CF | 托管资源 | RSS/DXGI |", "| --- | --- | --- | --- | --- |",
    ]
    for seed, values in result["seeds"].items():
        cells = [f"[{values[key]['status']}]({values[key]['details']})"
                 for key in ("latency", "old_cf", "managed", "os")]
        lines.append(f"| {seed} | {' | '.join(cells)} |")
    lines.extend(("", "RSS/DXGI 只比较预定阶段点和有效窗口样本的观测最大值。"
                  "时延门逐种子、逐段判定，资源门逐种子、逐案例判定。"
                  "完整原始时序、评分输入、已加载状态、进程读数和失败都保存在登记目录。", ""))
    (out / "README.md").write_text("\n".join(lines), encoding="utf-8", newline="\n")


def summarize(out):
    manifest = json.loads((out / "manifest.json").read_bytes())
    seeds = [item["seed"] for item in manifest["seeds"]]
    groups = {}
    for seed in seeds:
        groups[str(seed)] = {"latency": _latency(out / f"latency-{seed}"),
                             "old_cf": _old_cf(out / f"old-cf-{seed}"),
                             **{key: _resource(out, key, seed) for key in ("managed", "os")}}
    state = status_for(group["status"] for values in groups.values() for group in values.values())
    results = {
        "scope": "single preregistered formal cost batch; main acceptance pending independent review",
        "status": state, "manifest": identify(out / "manifest.json"), "seeds": groups,
        "latency_pooled_descriptive": _latency_pooled(out, seeds),
        "prior_b_b_next_failure_unchanged": manifest["prior_b_b_next_failure_unchanged"],
        "no_after_the_fact_reruns": True,
    }
    old_results = [out / f"old-cf-{seed}" / "result" for seed in seeds]
    if all((path / "timing.jsonl").is_file() and (path / "summary.json").is_file() for path in old_results):
        old_cf.pooled(old_results, out / "old-cf-pooled-descriptive.json")
        results["old_cf_pooled_descriptive"] = "old-cf-pooled-descriptive.json"
    write_json(out / "summary.json", results)
    _write_readme(out, results)
    files = {path.relative_to(out).as_posix(): identify(path) for path in sorted(out.rglob("*"))
             if path.is_file() and path.name != "artifact-identity.json"}
    write_json(out / "artifact-identity.json", {"file_count": len(files), "files": files})
    print(json.dumps({"status": state, "seeds": {seed: {key: group["status"] for key, group in rows.items()}
                                               for seed, rows in groups.items()},
                      "identity": identify(out / "artifact-identity.json"),
                      "file_types": dict(Counter(Path(name).suffix for name in files))}, indent=2))
    return results


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--formal-dir", type=Path, default=HERE / "formal")
    args = parser.parse_args()
    summarize(args.formal_dir)
