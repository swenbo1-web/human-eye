"""Isolated native counter sampling and logical resource audits."""

from collections.abc import Mapping
from contextlib import contextmanager
from dataclasses import fields, is_dataclass
from enum import Enum
import threading
from types import BuiltinMethodType, FunctionType, MethodType
from unittest.mock import patch

import numpy as np

from artifacts.integration.method_diagnostic_001.resource_diagnostic import _Sampler


OS_POINTS = ("pre_t0", "post_t1", "post_t2", "post_t3", "post_t_next_observed", "post_t4")


class SerializedSampler(_Sampler):
    """Use the measured process and serialize native access to the adapter."""

    def __init__(self, dxgi, interval_ns, node):
        self._query_lock = threading.Lock()
        super().__init__(dxgi, interval_ns, node)
        self.thread.name = "formal-resource-sampler"

    def _capture(self, sample, scheduled):
        with self._query_lock:
            super()._capture(sample, scheduled)


def _valid_os(row):
    return (row.get("win32_error") == 0 and row.get("local_hresult", -1) >= 0
            and row.get("nonlocal_hresult", -1) >= 0
            and row.get("process", {}).get("WorkingSetSize", 0) > 0)


def os_window_summary(stamps, phase_points, samples, *, interval_ns, saturated=False,
                      sampler_error=None, adapter_error=None):
    t0, t4 = stamps["t0"], stamps["t4"]
    hot = [row for row in samples if t0 <= row["start_qpc_ns"] <= row["end_qpc_ns"] <= t4]
    valid_hot = [row for row in hot if _valid_os(row)]
    stage_by_name = {row["phase"]: row for row in phase_points}
    required_stages = [stage_by_name[name] for name in OS_POINTS if name in stage_by_name]
    reasons = []
    if adapter_error:
        reasons.append({"adapter": adapter_error})
    if sampler_error:
        reasons.append({"sampler": sampler_error})
    if saturated:
        reasons.append("periodic buffer saturated")
    if len(required_stages) != len(OS_POINTS):
        reasons.append({"missing_phase_points": [name for name in OS_POINTS if name not in stage_by_name]})
    if len(stage_by_name) != len(phase_points):
        reasons.append("duplicate phase point")
    if any(row.get("phase_boundary_qpc_ns") != stamps[
            "t0" if row["phase"] == "pre_t0" else row["phase"].removeprefix("post_")]
           for row in required_stages):
        reasons.append("a phase point was not aligned to its recorded boundary")
    if not valid_hot:
        reasons.append("no valid periodic query wholly inside the hot window")
    if any(not _valid_os(row) for row in (*samples, *required_stages)):
        reasons.append("at least one native query failed")
    starts = [row["start_qpc_ns"] for row in samples]
    hot_starts = [row["start_qpc_ns"] for row in hot]
    hot_stops = [row["end_qpc_ns"] for row in hot]
    anchors = [t0, *hot_starts, t4]
    rows = [*samples, *required_stages]
    bounds = None
    if not reasons:
        observed = [*required_stages, *valid_hot]
        rss = max(observed, key=lambda row: row["process"]["WorkingSetSize"])
        gpu = max(observed, key=lambda row: row["local"]["current_usage"] + row["nonlocal"]["current_usage"])
        bounds = {
            "rss_bytes": rss["process"]["WorkingSetSize"],
            "gpu_same_record_sum_bytes": gpu["local"]["current_usage"] + gpu["nonlocal"]["current_usage"],
            "gpu_local_at_sum_max_bytes": gpu["local"]["current_usage"],
            "gpu_non_local_at_sum_max_bytes": gpu["nonlocal"]["current_usage"],
            "rss_record_start_qpc_ns": rss["start_qpc_ns"],
            "gpu_record_start_qpc_ns": gpu["start_qpc_ns"],
        }
    return {
        "status": "UNVERIFIED" if reasons else "VERIFIED",
        "unverified_reasons": reasons,
        "target_interval_ns": interval_ns,
        "periodic_samples": len(samples),
        "periodic_wholly_in_window": len(hot),
        "valid_periodic_in_window": len(valid_hot),
        "required_phase_points": list(OS_POINTS),
        "periodic_first_gap_from_t0_ns": hot_starts[0] - t0 if hot else None,
        "periodic_last_gap_to_t4_ns": t4 - hot_stops[-1] if hot else None,
        "max_periodic_start_gap_ns": max((b - a for a, b in zip(starts, starts[1:])), default=None),
        "max_window_start_gap_including_boundaries_ns": max(b - a for a, b in zip(anchors, anchors[1:])),
        "max_query_duration_ns": max((row["end_qpc_ns"] - row["start_qpc_ns"] for row in rows), default=None),
        "observed_sampled_maximum": bounds,
    }


def _array_owner(value):
    while True:
        if isinstance(value, np.ndarray):
            base = value.base
        elif isinstance(value, memoryview):
            base = value.obj
        else:
            base = getattr(value, "base", None)
        if base is None or base is value:
            return value
        value = base


def backing_census(roots):
    """Attribute actual backing buffers and explicit opaque native objects by root."""
    owners = {}
    opaque = {}
    unsupported = {}
    for root_name, root in roots.items():
        visited = set()

        def note_buffer(value, kind):
            address = id(value)
            if address not in owners:
                owners[address] = (memoryview(value).nbytes, set(), set())
            _, kinds, names = owners[address]
            names.add(root_name)
            kinds.add(kind)

        def note_opaque(value, labels):
            cls = type(value)
            labels.setdefault(root_name, set()).add(f"{cls.__module__}.{cls.__qualname__}")

        def visit(value):
            identity = id(value)
            if identity in visited:
                return
            visited.add(identity)
            if isinstance(value, (np.ndarray, memoryview)):
                owner = _array_owner(value)
                try:
                    note_buffer(owner, "numpy")
                except TypeError:
                    note_opaque(owner, unsupported)
            elif isinstance(value, bytes):
                note_buffer(value, "bytes")
            elif isinstance(value, Mapping):
                for child in value.values():
                    visit(child)
            elif isinstance(value, (tuple, list, set, frozenset)):
                for child in value:
                    visit(child)
            elif (value is None or type(value) is object or isinstance(value, (
                    str, int, float, bool, complex, Enum, np.generic, np.dtype,
                    MethodType, FunctionType, BuiltinMethodType))):
                return
            elif is_dataclass(value) and not isinstance(value, type):
                for entry in fields(value):
                    visit(getattr(value, entry.name))
            elif type(value).__module__.startswith((
                    "human_eye_fast.", "verification.integration_reference",
                    "artifacts.integration.formal_cost_001.")):
                if hasattr(value, "__dict__"):
                    visit(vars(value))
                for cls in type(value).__mro__:
                    slots = getattr(cls, "__slots__", ())
                    if isinstance(slots, str):
                        slots = (slots,)
                    for name in slots:
                        if name not in ("__dict__", "__weakref__") and hasattr(value, name):
                            visit(getattr(value, name))
            elif (type(value).__module__.split(".", 1)[0] in ("bpy", "bpy_types", "_bpy", "gpu", "mathutils")
                  or type(value).__name__ in ("GPUOffScreen", "GPUShader", "GPUBatch", "GPUTexture", "BVHTree")):
                note_opaque(value, opaque)
            else:
                note_opaque(value, unsupported)

        visit(root)
        del visit

    groups = {}
    for nbytes, kinds, names in owners.values():
        for kind in kinds:
            group = groups.setdefault((kind, tuple(sorted(names))), [0, 0])
            group[0] += 1
            group[1] += nbytes
    return {
        "per_root_numpy": {
            name: {
                "unique_backings": sum(n for (kind, names), (n, _) in groups.items() if kind == "numpy" and name in names),
                "backing_bytes": sum(b for (kind, names), (_, b) in groups.items() if kind == "numpy" and name in names),
            } for name in roots
        },
        "deduplicated_numpy": {
            "unique_backings": sum(n for (kind, _), (n, _) in groups.items() if kind == "numpy"),
            "backing_bytes": sum(b for (kind, _), (_, b) in groups.items() if kind == "numpy"),
        },
        "deduplicated_public_bytes_roots": {
            "unique_buffers": sum(n for (kind, _), (n, _) in groups.items() if kind == "bytes"),
            "bytes": sum(b for (kind, _), (_, b) in groups.items() if kind == "bytes"),
        },
        "attribution_groups": [{"kind": kind, "roots": names, "unique_backings": n, "bytes": b}
                               for (kind, names), (n, b) in sorted(groups.items())],
        "native_opaque_types": {name: sorted(types) for name, types in opaque.items()},
        "uncovered_types": {name: sorted(types) for name, types in unsupported.items()},
    }


class _GpuProxy:
    def __init__(self, target, **overrides):
        self._target = target
        self.__dict__.update(overrides)

    def __getattr__(self, key):
        return getattr(self._target, key)


def _batch_content(content):
    result = {}
    for name, values in content.items():
        if isinstance(values, np.ndarray):
            result[name] = {"shape": list(values.shape), "dtype": values.dtype.name}
        else:
            width = len(values[0]) if len(values) else 0
            result[name] = {"shape": [len(values), width], "dtype": "Blender shader attribute conversion"}
    return result


@contextmanager
def logical_gpu_audit():
    """Observe the actual renderer creations and batch inputs on one reopen chain."""
    import gpu
    from human_eye_fast import raycast_saccade_gpu as vg

    original_init = vg.VGRenderer.__init__
    original_offscreen = gpu.types.GPUOffScreen
    original_batch = vg.batch_for_shader
    original_camera = vg._camera
    audit = {"renderers": 0, "offscreen": [], "cameras": [], "batches": []}

    def renderer_init(renderer, *args, **kwargs):
        original_init(renderer, *args, **kwargs)
        audit["renderers"] += 1

    def offscreen(width, height, *, format):
        native = original_offscreen(width, height, format=format)
        color = native.texture_color
        color_format = getattr(color, "format", None)
        audit["offscreen"].append({
            "width": native.width, "height": native.height, "requested_format": format,
            "color_texture": {"width": color.width, "height": color.height,
                              "format": color_format or format,
                              "format_source": "texture" if color_format else "offscreen constructor"},
        })
        return native

    def batch(shader, primitive, content, **kwargs):
        native = original_batch(shader, primitive, content, **kwargs)
        audit["batches"].append({"primitive": primitive, "attributes": _batch_content(content),
                                 "has_indices": kwargs.get("indices") is not None})
        return native

    def camera(name):
        native = original_camera(name)
        audit["cameras"].append({"type": native.data.type})
        return native

    patched = _GpuProxy(gpu, types=_GpuProxy(gpu.types, GPUOffScreen=offscreen))
    with (patch.object(vg, "gpu", patched), patch.object(vg.VGRenderer, "__init__", renderer_init),
          patch.object(vg, "batch_for_shader", batch), patch.object(vg, "_camera", camera)):
        yield audit
