# formal_cost_001 独立来源审查

结论：归档来源、输入绑定、实际运行环境及运行顺序核验通过。该结论不等于正式成本总验收通过；作者最终总状态仍为 UNVERIFIED。控制补充在正式计时之后完成，不能追写成计时前已具备的门。所有工作限于 CPU 读档；没有运行 Blender/GPU、修改作者证据或生产实现。

可复核入口为本目录 `provenance_probe.py` 和 `provenance_probe.json`。脚本重算文件 SHA-256/大小、ZIP 成员、输入和导入收据，并比较各进程的实际 runtime；历史 stable_sources/stable_inputs 字段属于运行器留下的前后检查记录，不冒称本审查重新观察了过去的执行。

## 身份和范围

- `formal/manifest.json`：`093a0df0ea941eb7cc6bd1206490627ca8196e0951fff18e6601fb513816e8c7`。
- `formal/artifact-identity.json`：`05d93ebe31677cef58a1d722e8833abbfd3a9a60ec46c34f09bccf8ed493c91a`；其 16,160 项全部重新匹配 SHA-256 和大小，目录文件集合也完全一致（身份文件自身除外）。
- 该 16,160 项只覆盖 `formal/`。`qualified_001`、`qualified_old_001`、`control_supplement` 和 `postprocess` 位于外部，不能算进此身份清单。本审查另外核对其 manifest、来源 ZIP、launch、输入、导入和结果收据；可复核身份列在 JSON 中。
- 正式来源 ZIP 含 595 个成员，全部与 source_superset 一致。资格新场景、资格旧 CF、补充失败、补充成功 ZIP 分别含 590、589、580、580 个成员，也全部匹配；无重复 ZIP 成员。
- 前阶段最终 13 份交付源中，有 12 份被本批来源集合包含并与其原身份相同；`examples/blender_radical_session.py` 不在该批集合，不把以前的示例验证虚构为本批重新执行。当前 HEAD 为 `79f8bcc8ea4d9bf881d2f3d555310fc5b5ec998b`，仅作背景，结论依据各批自己的快照。

## 进程、环境与时间顺序

下表为归档 runtime 的 UTC 实际起止范围；脚本还按同机 QPC 锚点验证了相邻进程不重叠和登记顺序。共 30 个进程，正式成本部分为其中 18 个。

| 批次 | 实际起止 UTC（2026-11-06） | 进程结果 | 来源成员数 |
| --- | --- | --- | --- |
| qualified_001 | 03:44:29.901925–03:45:11.272478 | 3 个 exit 0 | 590 |
| qualified_old_001 | 03:46:18.005479–03:47:05.764419 | 3 个 exit 0 | 589 |
| formal | 03:48:23.893474–04:04:14.490412 | 18 个 exit 0 | 595 |
| control_supplement/run_001 | 04:04:30.362787–04:04:44.405260 | 3 个 exit 1，保留 | 580 |
| control_supplement/run_002 | 04:06:18.010266–04:06:32.845566 | 3 个 exit 0 | 580 |

正式 18 个进程依次是三个 seed 的 latency、三个 old-cf、六个 managed、六个 os；种子 79463 的资源 B/I 顺序反转，符合登记。逐一核对 launch 与 manifest job、manifest 哈希回执、全部登记输入、实际项目 imports。旧 CF 和补充的 reads.jsonl 还核对了实际读取的路径、字节数和 SHA。所有结果与归档来源/输入一致。进程摘要与各自 process.json 退出码一致，失败未被摘要覆盖。

runtime 的实际 Blender 为 5.2.3 LTS；Blender exe SHA `9d5df7a9ac2a7c5085aa0669700021bfa5c5e92de167a2510b0d0942c34deab0`；嵌入 Python 3.13.13、NumPy 2.3.4，NVIDIA GeForce RTX 3060、OpenGL、驱动报告 610.88。原生 Python exe/DLL 身份、设备报告和版本跨批一致；每进程有效环境与各自 launch 一致，包括单线程设置和独立 pycache 路径。native runtime 的 Pillow 为 null，明确表示原生 worker 未导入；不能将它误写为 Pillow 消费子进程的已观测模块回执。便携 Python/Pillow 的登记版本、exe 身份和固定评分源码另有记录，后者亦经本次 CPU 重算评分验证。

资格批与正式批的公共源只存在 `orchestrate.py` 差异：正式注册加入前置 common/qualify/old_cf 身份检查、资格 runtime 输入、native_expected 登记和严格 runtime 比较；不是生产算法或评分修改。common、qualify、old_cf 以及生产组件保持相同归档哈希。

## 评分固定与报告器修正

三个评分/渲染来源在五批 ZIP 中完全相同：

| 来源 | SHA-256 |
| --- | --- |
| verification/cf_visual_acceptance.py | `079c47c0ffa7f868a19819f942c068dc3cf4934d96514e1a54a5b98d81e7e797` |
| verification/test_raycast_saccade_gpu.py | `624c4a9be846ffd983c235c5aaee58e3c69c29d0142999fc3e03ba765c85eb0c` |
| human_eye_fast/raycast_saccade_gpu.py | `1aea7325bd5be1a7377ac4ec3817279564166d84ca7699434254a60bb6eb4a0b` |

资格评分在正式运行前完成并被正式 manifest 输入固定。评分文件、PNG SHA、反馈字段与每个正式任务的输入身份相符；各正式时延输出实际绑定验证见 visual_review.md。正式时延热链重用这些确定标签，不在计时区间临时放宽评分或等待外部评分器。

原 report.py SHA `78d703a32ce7fcabdee319eaf2cf11a9410d680c46ba35183c44b14cd1e3158b` 仍与正式 ZIP 一致。其 `_latency_pooled` 对数字 `cases` 调用 `.values()`，而实际逐例表名为 `by_case`，静态代码和实际 summary schema 可直接证明这个报错原因。后补 `postprocess/report_frozen.py` 没改原文件：只替换描述性 pooled 函数为读取 by_case，并从绝对时间戳复核既有门值；随后重写派生 comparisons/summary/README/identity。源码没有重跑原生测试、重写 raw intervals/proofs/PNG/模型或改变门的路径。本审查独立重算五段 pooled 数字，与最终汇总完全一致；逐 seed 正式时延门的全量独立复算由主干负责。

原 report 首次退出的独立终端日志没有被重定向进此归档。作者经主干提供的宿主事件定位是聊天 `01a1abad-9d70-7260-8536-1fcd0dc7ae14`、functions.wait cell `193`、下层 exec session `83955`、chunk `4b2534`，内容报告 `formal_batch_exit=0 report_exit=1` 和 report.py:91 traceback。本子审查没有读取该聊天原事件，故该退出事实标为**作者提供的宿主事件定位**，不虚构独立日志或声称它在 16,160 项内。归档仍包含有错的原 report.py，当前总状态 UNVERIFIED、托管 current 未确认项和历史 B/B next 比值 `1.0768101359922175` 均保留。

## 后补控制与验收边界

补充 run_001 三个 worker.log 都保留 `TypeError: Object of type float32 is not JSON serializable`，process/summary 保留 exit 1。run_002 与 run_001 的来源差异只有 worker.py 的结果写出：用支持 `default=np.generic.item` 的 json.dumps 替换 `_compact`。没有修改生产逻辑或质量判断；run_002 摘要为每 seed 31/31。具体原 CF 控制覆盖/排除范围由对应子审查判断，本报告只确认其来源与先后事实。

归档建议：将五套 manifest/ZIP/launch/runtime、正式 identity、失败 run_001 与原 report.py、后补 report_frozen.py 及本审查脚本/JSON 一并留存。新主干审查产物另立身份，不能插入作者原 16,160 项集合。来源和新增视觉范围无阻止继续验收的新增问题；资源 current UNVERIFIED、完整原 CF 范围及其它验收门仍由主干合并决定。
