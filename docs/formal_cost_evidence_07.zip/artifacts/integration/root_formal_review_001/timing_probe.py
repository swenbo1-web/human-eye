"""Independent CPU reconstruction of all formal paired intervals and saved state."""
from collections import defaultdict
from hashlib import sha256
import json
from pathlib import Path
from statistics import median
import numpy as np

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'artifacts/integration/formal_cost_001/formal'
OUT = Path(__file__).with_suffix('.json')
SEGMENTS = {'before': ('t0','t1'), 'action': ('t1','t2'), 'feedback': ('t2','t3'),
            'next': ('t3','t4'), 'continuous_total': ('t0','t4'),
            'next_observe': ('t3','t_next_observed'), 'next_predict': ('t_next_observed','t4')}

def read(path): return json.loads(path.read_bytes())
def lines(path): return [json.loads(line) for line in path.read_text().splitlines()]
def p95(values): return float(np.quantile(values, .95, method='linear'))
def design(query, deployment, prefix):
    x = np.array(query, dtype=float, copy=True)
    if prefix == 'v': x[...,2:] = np.log1p(x[...,2:])
    x = (x - deployment[prefix+'_mean']) / deployment[prefix+'_scale']
    columns=[x]
    if deployment[prefix+'_quadratic']:
        n=x.shape[-1]
        columns.append(np.stack([x[...,i]*x[...,j] for i in range(n) for j in range(i,n)],axis=-1))
    columns.append(np.ones((*x.shape[:-1],1)))
    return np.concatenate(columns,axis=-1)

reports=[]
public_cache={}
model_cache={}
for process, seed in enumerate((20261105,79463,310519)):
    folder=BASE/f'latency-{seed}/result'
    with np.load(ROOT/f'artifacts/integration/production_functional_001/deployments/{seed}.npz',allow_pickle=False) as z:
        deployment={k:z[k] for k in z.files}
    rows=lines(folder/'intervals.jsonl'); proofs=lines(folder/'proofs.jsonl'); pairs=lines(folder/'pairs.jsonl')
    assert len(rows)==len(proofs)==1728 and len(pairs)==864
    keys={(r['ordinal'],r['pair'],r['role']):r for r in rows}
    assert len(keys)==len(rows)
    assert set(keys)=={(c,p,r) for c in range(24) for p in range(36) for r in ('B','I')}
    proof_keys={(r['ordinal'],r['pair'],r['role']):r for r in proofs}
    assert set(proof_keys)==set(keys)
    measured=defaultdict(list)
    physical={}
    prior=None
    for row in rows:
        ordinal,pair,role=row['ordinal'],row['pair'],row['role']
        creation=list(('B','I') if (process+ordinal)%2==0 else ('I','B'))
        execution=list(('B','I') if (process+ordinal+pair)%2==0 else ('I','B'))
        assert row['creation_roles']==creation and row['creation_index']==creation.index(role)
        assert row['execution_roles']==execution and row['execution_index']==execution.index(role)
        assert row['warmup']==(pair<5)
        assert physical.setdefault((ordinal,role),row['physical_instance'])==row['physical_instance']
        stamps=row['counter_ns']; ordered=[stamps[k] for k in ('t0','t1','t2','t3','t_next_observed','t4')]
        assert ordered==sorted(ordered)
        if prior is not None: assert stamps['t0']>=prior
        prior=stamps['t4']
        for segment,(a,b) in SEGMENTS.items():
            value=stamps[b]-stamps[a]
            assert value==row['ns'][segment]
            if pair>=5: measured[ordinal,role,segment].append(value)
    assert all(physical[c,'B']!=physical[c,'I'] for c in range(24))
    for c in range(24):
        for p in range(36):
            b,i=(proof_keys[c,p,r] for r in ('B','I'))
            assert b['next']==i['next'] and b['model']['members']==i['model']['members']
            assert b['pristine_active_state']==i['pristine_active_state']
            assert b['checks'] and all(b['checks'].values()) and all(i['checks'].values())
            assert b['public'].keys()==i['public'].keys()
            for name in b['public']:
                assert b['public'][name]['sha256']==i['public'][name]['sha256']
            for proof in (b,i):
                for member in proof['public'].values():
                    path=folder/member['file']
                    if path not in public_cache:
                        data=path.read_bytes(); public_cache[path]=(len(data),sha256(data).hexdigest())
                    assert public_cache[path]==(member['bytes'],member['sha256'])
                model_path=folder/proof['model']['file']
                if model_path not in model_cache:
                    with np.load(model_path,allow_pickle=False) as z: arrays={k:z[k] for k in z.files}
                    assert set(arrays)==set(proof['model']['members'])
                    for name,array in arrays.items():
                        meta=proof['model']['members'][name]
                        assert array.dtype.str==meta['dtype'] and list(array.shape)==meta['shape']
                        assert sha256(array.tobytes()).hexdigest()==meta['sha256']
                    for prefix in ('v','a'):
                        for name in ('keys','values','known'):
                            assert np.array_equal(arrays[prefix+'_'+name][:240],deployment[prefix+'_'+name])
                    assert int(arrays['v_writes'])==242
                    assert int(arrays['a_writes'])==len(arrays['a_keys']) in (240,241)
                    vw=deployment['v_weights'].copy()
                    for slot in (240,241):
                        mask=arrays['v_known'][slot]
                        assert np.count_nonzero(mask)==1
                        direction=int(np.flatnonzero(mask)[0])
                        label,rays=arrays['v_values'][slot,direction]
                        assert label in (0,1) and rays>=0 and int(rays)==rays
                        d=design(arrays['v_keys'][slot,direction],deployment,'v')
                        error=np.exp(-np.logaddexp(0.0,-(d@vw)))-label
                        rate=.05/(1+d@d)
                        vw[:-1]*=1-rate*deployment['v_lambda']
                        vw-=rate*error*d
                    np.testing.assert_allclose(vw,arrays['v_weights'],rtol=2e-14,atol=2e-15)
                    aw=deployment['a_weights'].copy()
                    if len(arrays['a_keys'])==241:
                        d=design(arrays['a_keys'][240],deployment,'a')
                        error=d@aw-arrays['a_values'][240,0]
                        rate=.05/(1+d@d)
                        aw[:-1]*=1-rate*deployment['a_lambda']
                        aw-=rate*error*d
                    np.testing.assert_allclose(aw,arrays['a_weights'],rtol=2e-14,atol=2e-15)
                    model_cache[model_path]=arrays
                arrays=model_cache[model_path]
                follow=proof['next']
                vscore=design(follow['view_features'],deployment,'v')@arrays['v_weights']
                assert sorted(range(16),key=lambda k:(-vscore[k],k))==follow['view_audits']['next']['order']
                if follow['predictor']=='L':
                    features=np.asarray(follow['action_features'])
                    wanted=follow['action_meters']*(features[1]+design(features,deployment,'a')@arrays['a_weights'])
                    assert np.isclose(wanted,follow['predicted_delta_m'],rtol=2e-14,atol=1e-16)
    summary=read(folder/'summary.json')
    segments={}
    for segment in SEGMENTS:
        med={role:[float(median(measured[c,role,segment])) for c in range(24)] for role in ('B','I')}
        absolute={role:p95(values) for role,values in med.items()}
        ratio=absolute['I']/absolute['B']
        claimed=summary['segments'][segment]
        assert claimed['p95_ns']==absolute and ratio==claimed['I_over_B']
        local=[med['I'][c]/med['B'][c] for c in range(24)]
        worst=max(range(24),key=lambda c:local[c])
        segments[segment]={'p95_ns':absolute,'I_over_B':ratio,
            'case_medians_ns':med,'worst_case':keys[worst,5,'B']['case_id'],
            'worst_case_median_ratio':local[worst],
            'case_ratios_over_1_05':sum(x>1.05 for x in local)}
        if segment not in ('next_observe','next_predict'): assert ratio<=1.05
    gc=read(folder/'gc.json')
    assert gc['initial']['enabled']
    spans=[]; pending={}
    for event in gc['events']:
        if event['event']=='start':pending[event['generation']]=event['qpc_ns']
        else:spans.append((pending.pop(event['generation']),event['qpc_ns']))
    overlaps={role:{} for role in ('B','I')}
    for role in overlaps:
        for segment,(a,b) in SEGMENTS.items():
            durations=[sum(max(0,min(r['counter_ns'][b],stop)-max(r['counter_ns'][a],start)) for start,stop in spans)
                       for r in rows if r['role']==role and not r['warmup']]
            overlaps[role][segment]={'rows':sum(x>0 for x in durations),'max_overlap_ns':max(durations)}
    reports.append({'seed':seed,'rows':len(rows),'pairs':len(pairs),'measured_pairs':744,'segments':segments,
                    'GC_collections':len(spans),'GC_overlap':overlaps,'all_public_state_pairs_exact':True})
result={'scope':'CPU reconstruction from archived absolute timestamps, public files and active NPZ state; no new native run',
        'seeds':reports,'total_rows':sum(r['rows'] for r in reports),'public_files_verified':len(public_cache),
        'active_model_npz_verified_with_independent_updates':len(model_cache)}
OUT.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({**{k:v for k,v in result.items() if k!='seeds'},'ratios':{r['seed']:{k:v['I_over_B'] for k,v in r['segments'].items()} for r in reports}}))
