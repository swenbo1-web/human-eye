# formal_cost_001 托管内存、归属与生命周期独立审查

审查范围：冻结 formal/sources.zip 中 resources.py、resource_instruments.py、common.py、VG/控制/基线相关源，以及原始六托管 worker 和逻辑资源记录。只读 CPU 重算；未运行 Blender/GPU，未修改生产、正式数据或实施源。生产保持79f8bcc。本目录 resource_recompute.py 可复现本审查的全部数值。

## 首要结论：原 current 门存在数值失败，不只是类型未识别

对3 seed×24案例逐一重算，**72个对应窗口、216个正常热态 current 对应点中，33点超过262,144 B**；涉及12个 seed/案例组合，每个 seed 都是11点、4个案例。原 worker 报告归属 UNVERIFIED 不能遮盖这些原始超限，更不能仅添加 `_bpy_types` 类型分类后改判 PASS。

| 原冻结正常热态点 | 最大 I−B | 超限点数（72中） | 最大项 |
| --- | ---: | ---: | --- |
| hot_outputs_held | 389,457 B | 9 | seed310519 / I-staggered-wings-3 |
| hot_outputs_released | 487,784 B | 12 | seed310519 / I-single-panel-3 |
| hot_reference_replaced | 488,751 B | 12 | seed310519 / I-single-panel-3 |
| 完整 t0→t4 window peak | 513,429 B | 0（1,048,576 B门） | seed310519 / I-staggered-wings-0 |

每 seed 的失败案例均为 I-single-panel-3、I-staggered-wings-3、I-slotted-drum-0、I-slotted-drum-3；single-panel-3 只有 released/reference_replaced 两点超限，其余三例各三点超限。峰值差的最小值为−424,762 B，负差未删掉或抵消其他案例。

本审查建议：**current 原始数值未过门，归属仍未完整闭合；整机不能接收。** 窗口 peak 数值门可以单独接受，须保留其“完整 traced 窗口峰”范围。此结论不重开生产优化，也不将后续诊断代替正式原记录。

## 重算范围与证据

- 六 worker 共2,028条 census；全量检查 attribution_groups 与去重 NumPy/bytes合计、各 root NumPy合计内部一致。
- B/I 共1,014对保留点（含3 seed的2个全局冷点及每例14点）；所有 current 和 checkpoint peak 差均另存。checkpoint peak_since_latest_reset 在热窗之后会包含报告/生命周期分配，**不拿这些值冒充新的热窗 peak 门**。
- 72热窗口的 cases.jsonl 与 hot_outputs_held 原 checkpoint 的 current/peak 一致；peak_above_start 与 window_peak−start_current 一致。
- 144对逻辑生命周期记录（managed和OS各72）逐字段复核。所有相应逻辑GPU描述、关闭保留公开bytes、重开证明相等，释放断言为真；本审查没有只依赖总 PASS。

详细产物：resource_window_deltas.csv、resource_checkpoint_deltas.csv、resource_root_attribution.csv、resource_numeric_failures.json、resource_census_gaps.json、resource_logical_recheck.json、resource_summary.json。原始输入及冻结源码摘要另存 resource_input_hashes.json / summary。

## 576个未知 census：是什么，现有记录能闭合到哪里

全量重算确认未知集合确实只有 `renderer: ["_bpy_types.Object"]`，共576条，分别出现在三个hot点与reopened_outputs_held，每个点144条。分类器允许 bpy/bpy_types/_bpy/gpu/mathutils，却没有 `_bpy_types`，故落入 unsupported。这是实际的计量分类缺口，原代码没有偷偷把它填成0，而是导致当前门UNVERIFIED。

冻结VG构造器唯一持有的 Blender Object 字段是 `self.cameras`，来自两次 `_camera`，B的renderer子类只增加rank order。结合renderer根、同型运行记录、关闭前实际两相机存在且关闭后 object/data均删除的断言，可以**不启动原生重测地解释该类型名对应会话相机的opaque native引用**。它不是新的NumPy backing，不应给它捏造0字节，也不能把它与tracemalloc的Python分配简单相加。

但原 census 只保存root/type集合，没有逐对象 identity、字段路径、实例数或native分配大小；更重要的是，traced current中普通Python对象、验证者报告/宿主输入等并不由NumPy/bytes backing清单完整解释。因此现有原记录**不能严格补成全部当前内存归属已闭合**。可追加只读审计解释该漏识别类型，不能原地修改原census，更不能因此擦除33点数值失败。后续若修订归属工具，应将它显式记为native opaque、列所属camera字段/身份和释放证据，绝不能标作“0占用”。

## 已能定位的跨案例行为与仍不能证明的原因

所有1,014对应保留点的 NumPy backing 字节和公开bytes字节差均为0；**连 attribution_groups 的root共享关系、数量、字节也完全一致**。这排除了“当前清单内 I 额外常驻一套网格/索引/模型数组或公开bytes”这一解释。它不排除生产普通Python对象、RNA wrapper或验证者对象，也不代表全进程内存相等。

三seed出现近乎同形、非单调的差值跳变，明确带有跨案例存活状态：以seed310519为例：

- case7 I-single-panel-3：t4 held差为−149,869 B，经过held census、proof整理和删除outputs后，released变为+487,784 B，变化+637,653 B；ref replaced为+488,751 B。
- case7生命周期结束为+560,027 B；case8 cold_before_lane已是+559,899 B，在创建下一生产lane前差异已存在。case8 t0为+556,781 B，t4则降到−118,075 B。
- case10末端reopened_released为+393,519 B，case11 cold_before_lane正好+393,519 B；case11 held为+389,457 B。

这支持“既有存活对象/垃圾回收或验证流程使差值阶跃”的待验证解释，不支持把它直接叫作单调生产泄漏。**原资源worker未记录GC事件或tracemalloc分配快照，无法把变化严格归因到GC、报告dict、动态B renderer类、某个生产Python对象或具体文件行。** 不将未证原因写成结论，不用cold/t0差相减重定义原门。

## 验证者引用与B/I公平性逐项检查

| 保留对象/根 | 冻结实现中的存活与释放 |
| --- | --- |
| bridge/index/model/reference/current/basis/renderer | owner_roots明确列出。B current仅为当前fact/readback/attachments；不会把旧ObservedFrame作为额外历史留存。I对应当前状态同样计费。 |
| validation_reset_weights | 两臂持有同样weights副本，活跃时明确入root；Lane.close将_pristine置None。没有只给I扣除验证开销。 |
| caller_outputs | 两臂都使用同一Outputs/public wrapper。before/transition/next bytes、未消费next ticket/plan仍保留；反馈已消费票据的features已清除。热proof后del outputs，再测released。 |
| proof局部模型views、公开bytes、for循环变量 | 在Lane.proof和_proof_summary局部函数内，返回仅摘要/检查；函数返回后局部frame/row/png/array views不留在_case_work。结果报告保留hash/长度与标量，不保留原大数组或private frame。 |
| warm outputs | 每条链del warm；五轮之后del时间戳局部`_`，两臂相同。 |
| close审计model/controller/renderer引用 | _instrument_close闭包确实临时保留这些对象。正常_close_and_check返回后闭包离开作用域；reopen异常审计在check_release()之后明确del check_release，再做released点。没有发现旧renderer审计引用跨到该点。 |
| retained public bytes | lifecycle_outputs先转成6个公开bytes并删除原返回物，close后验证可消费和身份未变，然后删除payloads，再测closed_public_bytes_released。 |
| native宿主输入及验证壳 | Lane.scene/objects/moving、Case.fixture/deployment、运行清单和报告元数据不等于会话owned backing；host仍由外层materialize上下文持有至退出。traced current仍包含相应Python分配。root清单不是全进程引用普查。 |
| reopened_released | 此处根为显式空dict，零backing仅表示“不再持有所登记会话/输出根”，不能据此宣称全进程、宿主或驱动为零。原current仍是非零实测。 |

没有从冻结源发现只替B保留完整before/after事实、或只给I删除真实责任的明显不公平路径。但未保存分配级证据，不能据此排除全部Python/GC层计量差异。

## current门与生命周期点边界

冻结manifest明确 `resource.current_gate_points` 为上述3个hot点，与MANAGED_HOT_POINTS一致；它不是事后删点。协议要求冷点与异常轨迹单列。reopened_outputs_held在新实例未作五条预热、logical_gpu_audit开启的重开链中采集，之后通过CallerAbort触发finally关闭；因此不能事后把它等同正常热链而新增256KiB硬门。

其数值仍全部披露：reopened_outputs_held最大+561,252 B（15/72超过256KiB参考线），closed_public_bytes_held最大+565,555 B，closed_public_bytes_released最大+566,067 B，reopened_released最大+560,027 B。冷/生命周期单列不等于这些点满足256KiB，也不影响原3个热态点已经失败的结论。

## GPU逻辑资源及异常释放的证明边界

144对记录均为重开链创建1个renderer、1个1024×512 RGBA8 offscreen/color texture、2个ORTHO相机、6个batch（3次观察各surface+HUD），B/I批次属性形状/dtype/indices描述相同。

**创建尺寸/format/batch清单仅在重开链动态拦截。** 原热lane另有正常关闭时对实际offscreen.free的一次完成、目标清空、两相机object/data删除、CPU buffers/model arrays/bridge/index/current/reference清理的检查；热census也记录实际GPUOffScreen/GPUShader类型。它没有独立保存热窗每次allocation的创建明细。热lane与重开资源同构还依赖冻结VG与两臂相同调用路径，不能把重开日志谎称热窗allocation追踪。

异常轨迹是完成链之后验证者主动CallerAbort、由lane finally关闭，不是所有生产setter/TD/GPU异常的成本回放。记录支持这个限定的异常清理和新owner独立性；功能阶段更广泛的异常测试属于另外证据。驱动allocator未归零不能据此叫泄漏，逻辑根空也不能冒称全进程显存零。

## 下一步建议

仅作一次限定原因诊断，见 resource_diagnostic_plan.md。保持生产与原raw不动，固定seed310519按原顺序前缀0..7、B/I各一进程。GC事件加轻量阶段定位，case7原released读数后各取一次末端snapshot即停止计量，不需要前缀11或额外held终点进程。若不复现，不自动加跑。诊断不替换原current失败；先根据具体分配/GC证据再决定验证仪器修正或生产定点修复。
