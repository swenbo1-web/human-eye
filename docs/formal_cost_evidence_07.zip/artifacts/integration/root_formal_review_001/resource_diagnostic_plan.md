# current超限原因的一次限定诊断建议（不执行）

目的只定位原seed310519、case7从held到released的+637,653 B差值跳变。生产79f8bcc、正式raw和原33个超限点保持不变；不是补跑直至通过，不产生替代正式成绩。

## 最小范围

- B/I各一个串行后台进程，seed310519，原案例顺序0..7。保持原部署、masks、参考、五条warm+一条hot、GC开启及此前案例生命周期路径。
- 前缀0..7已经包含原首次数值失败与最大released跳变。前缀11主要观察前案遗留偏移，不是本次必需范围。
- 在case7 `hot_outputs_released` 原traced current读取后、该点新的census/参考替换/close/reopen之前，取**唯一一次**tracemalloc snapshot并落盘；之后只正常清理退出，不将被snapshot污染的后续读数用于比较。
- 不需要再各建一个held终点进程。两个endpoint进程会把不同运行/GC历史混入差分，成本翻倍；现有held原读数、阶段GC记录及B/I同一released终点的分配差足以先缩小归因。如果本轮无法归因，也先报告不确定，不自动扩成更多进程。

## 极少量新增观测

1. GC记录使用tracemalloc开始前预分配的固定容量buffer；每个start/stop只记QPC、generation、collected/uncollectable、case ordinal和当前phase。记录实际事件、溢出状态与开销；避免callback append大dict改变分配/GC阈值。
2. 保留原t4读数；另在held census完成、proof_summary完成记录轻量QPC/phase及current，接着使用del outputs后的原released读数。无需中途snapshot。这把原差值变化区间分为“held census”“proof”“输出释放”。
3. 末端两份snapshot按文件/行统计存活size/count差，分列生产、验证/报告、Python/NumPy及未知来源。保持快照原文件和原GC事件，不只给归因结论。snapshot自身及落盘后的分配不再进入任何验收读数。

## 事前判据

- 先报告是否在相同原阶段再见超过262,144 B，以及held→released是否出现同向显著跃迁；这只是诊断复现标记，不改变正式FAIL。不能把“不复现”写成原结果通过。
- 若跃迁严格对齐某臂GC stop，且终点snapshot能把存活差指向验证/report来源，可提出有证据的仪器修正；仅时间相邻而没有分配来源不足以证明全部原因。
- 若差异主要为生产源仍应存活/未应存活的对象，须指出具体分配行、对象责任、生命周期和大小，再提出定点修复；不能仅由总current差推断新算法泄漏。
- 若快照与current差不能闭合，或GC记录饱和/观测改变触发轨迹，则明确仍未知；不得自动加跑、改阈值、扣冷起点或重开算法优化。
- `_bpy_types.Object`分类解释可作为单独只读审计注记；后续工具如修正类型处理，必须native opaque显式归属，不能计0，且修正分类不能抵销数值超限。
