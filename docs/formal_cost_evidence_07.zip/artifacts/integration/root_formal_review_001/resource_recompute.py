"""Read-only CPU recomputation of frozen managed and logical-resource records."""

from collections import Counter, defaultdict
import csv
from hashlib import sha256
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[3]
FORMAL = ROOT / "artifacts/integration/formal_cost_001/formal"
OUT = Path(__file__).parent
SEEDS = (20261105, 79463, 310519)
HOT = ("hot_outputs_held", "hot_outputs_released", "hot_reference_replaced")


def read_jsonl(path):
    return [json.loads(row) for row in path.read_text(encoding="utf-8").splitlines()]


def summarize(rows, field):
    worst = max(rows, key=lambda row: row[field])
    return {"count": len(rows), "min": min(row[field] for row in rows), "max": worst[field],
            "max_seed": worst["seed"], "max_case": worst["case"]}


def main():
    manifest = json.loads((FORMAL / "manifest.json").read_bytes())
    assert tuple(manifest["resource"]["current_gate_points"]) == HOT
    checkpoint_pairs, windows, attribution, census_unknown, logical_pairs = [], [], [], [], []
    raw_hashes = {}
    source_hashes = {}
    validations = Counter()
    with zipfile.ZipFile(FORMAL / "sources.zip") as archive:
        for name in ("resources.py", "resource_instruments.py", "common.py"):
            key = "artifacts/integration/formal_cost_001/" + name
            data = archive.read(key)
            source_hashes[key] = sha256(data).hexdigest()
            assert data == (ROOT / key).read_bytes()
    for seed in SEEDS:
        checkpoints, cases = {}, {}
        for role in ("B", "I"):
            folder = FORMAL / f"managed-{seed}-{role}" / "result"
            for name in ("checkpoints.jsonl", "cases.jsonl", "summary.json"):
                path = folder / name
                raw_hashes[path.relative_to(ROOT).as_posix()] = sha256(path.read_bytes()).hexdigest()
            point_rows = read_jsonl(folder / "checkpoints.jsonl")
            checkpoints[role] = {(row["case"], row["point"]): row for row in point_rows}
            assert len(checkpoints[role]) == len(point_rows) == 338
            cases[role] = {row["case"]: row for row in read_jsonl(folder / "cases.jsonl")}
            assert len(cases[role]) == 24
            for row in point_rows:
                ownership = row["ownership"]
                groups = ownership["attribution_groups"]
                for kind, category, count_key, byte_key in (
                    ("numpy", "deduplicated_numpy", "unique_backings", "backing_bytes"),
                    ("bytes", "deduplicated_public_bytes_roots", "unique_buffers", "bytes"),
                ):
                    total = ownership[category]
                    assert total[count_key] == sum(g["unique_backings"] for g in groups if g["kind"] == kind)
                    assert total[byte_key] == sum(g["bytes"] for g in groups if g["kind"] == kind)
                for label, value in ownership["per_root_numpy"].items():
                    selected = [g for g in groups if g["kind"] == "numpy" and label in g["roots"]]
                    assert value["unique_backings"] == sum(g["unique_backings"] for g in selected)
                    assert value["backing_bytes"] == sum(g["bytes"] for g in selected)
                validations["internally_consistent_censuses"] += 1
                if ownership["uncovered_types"]:
                    census_unknown.append({"seed": seed, "role": role, "case": row["case"],
                                           "point": row["point"], "types": ownership["uncovered_types"]})
        assert checkpoints["B"].keys() == checkpoints["I"].keys()
        for key, b in checkpoints["B"].items():
            i = checkpoints["I"][key]
            case, point = key
            bo, io = b["ownership"], i["ownership"]
            row = {"seed": seed, "case": case, "point": point,
                   "B_current_bytes": b["current_bytes"], "I_current_bytes": i["current_bytes"],
                   "current_I_minus_B_bytes": i["current_bytes"] - b["current_bytes"],
                   "B_peak_since_reset_bytes": b["peak_since_latest_reset_bytes"],
                   "I_peak_since_reset_bytes": i["peak_since_latest_reset_bytes"],
                   "checkpoint_peak_I_minus_B_bytes": i["peak_since_latest_reset_bytes"] - b["peak_since_latest_reset_bytes"],
                   "normal_hot_current_gate": point in HOT,
                   "numeric_current_exceeds_262144": i["current_bytes"] - b["current_bytes"] > 262144,
                   "B_uncovered": bool(bo["uncovered_types"]), "I_uncovered": bool(io["uncovered_types"]),
                   "numpy_backing_I_minus_B_bytes": io["deduplicated_numpy"]["backing_bytes"] - bo["deduplicated_numpy"]["backing_bytes"],
                   "public_bytes_I_minus_B_bytes": io["deduplicated_public_bytes_roots"]["bytes"] - bo["deduplicated_public_bytes_roots"]["bytes"],
                   "attribution_groups_equal": bo["attribution_groups"] == io["attribution_groups"]}
            checkpoint_pairs.append(row)
            assert bo["per_root_numpy"].keys() == io["per_root_numpy"].keys()
            for label in bo["per_root_numpy"]:
                br, ir = bo["per_root_numpy"][label], io["per_root_numpy"][label]
                attribution.append({"seed": seed, "case": case, "point": point, "root": label,
                                    "B_backing_bytes": br["backing_bytes"], "I_backing_bytes": ir["backing_bytes"],
                                    "backing_I_minus_B_bytes": ir["backing_bytes"] - br["backing_bytes"],
                                    "B_unique_backings": br["unique_backings"], "I_unique_backings": ir["unique_backings"]})
        for case, b in cases["B"].items():
            i = cases["I"][case]
            assert b["ordinal"] == i["ordinal"]
            mb, mi = b["managed"], i["managed"]
            for role, model in (("B", mb), ("I", mi)):
                assert model["peak_above_start_bytes"] == model["window_peak_bytes"] - model["current_before_reset_bytes"]
                held = checkpoints[role][(case, "hot_outputs_held")]
                assert model["window_peak_bytes"] == held["peak_since_latest_reset_bytes"]
                for point in HOT:
                    assert model["current_bytes"][point] == checkpoints[role][(case, point)]["current_bytes"]
            windows.append({"seed": seed, "case": case, "ordinal": b["ordinal"],
                            "B_start_current_bytes": mb["current_before_reset_bytes"],
                            "I_start_current_bytes": mi["current_before_reset_bytes"],
                            "start_I_minus_B_bytes": mi["current_before_reset_bytes"] - mb["current_before_reset_bytes"],
                            "B_window_peak_bytes": mb["window_peak_bytes"],
                            "I_window_peak_bytes": mi["window_peak_bytes"],
                            "peak_I_minus_B_bytes": mi["window_peak_bytes"] - mb["window_peak_bytes"],
                            "B_peak_above_start_bytes": mb["peak_above_start_bytes"],
                            "I_peak_above_start_bytes": mi["peak_above_start_bytes"],
                            "numeric_peak_exceeds_1048576": mi["window_peak_bytes"] - mb["window_peak_bytes"] > 1048576,
                            "hot_proof_equal": b["hot_proof"] == i["hot_proof"]})
        for instrument in ("managed", "os"):
            records = {role: {row["case"]: row for row in read_jsonl(
                FORMAL / f"{instrument}-{seed}-{role}" / "result/cases.jsonl")} for role in ("B", "I")}
            for case, b in records["B"].items():
                i = records["I"][case]
                close_ok = {}
                for role, record in (("B", b), ("I", i)):
                    life, gpu = record["lifecycle"], record["logical_gpu"]
                    close_ok[role] = {
                        "normal_close": all(life["close"].values()),
                        "exception_reopen_close": all(life["reopened_close"].values()),
                        "fresh_reopen": life["fresh_reopen"],
                        "new_owner": life["reopened_ticket_owner_is_distinct"],
                        "bytes_after_close": life["closed_public"]["public_bytes_valid"]
                            and life["closed_public"]["unchanged_across_close"],
                        "one_renderer": gpu["renderers"] == 1,
                        "offscreen_exact": gpu["offscreen"] == [{"width": 1024, "height": 512,
                            "requested_format": "RGBA8", "color_texture": {"width": 1024, "height": 512,
                            "format": "RGBA8", "format_source": "texture"}}],
                        "two_ortho_cameras": gpu["cameras"] == [{"type": "ORTHO"}, {"type": "ORTHO"}],
                        "six_batches": len(gpu["batches"]) == 6,
                    }
                logical_pairs.append({"seed": seed, "instrument": instrument, "case": case,
                                      "logical_equal": b["logical_gpu"] == i["logical_gpu"],
                                      "close_public_equal": b["lifecycle"]["closed_public"] == i["lifecycle"]["closed_public"],
                                      "reopen_proof_equal": b["lifecycle"]["reopened_proof"] == i["lifecycle"]["reopened_proof"],
                                      "role_checks": close_ok})
    point_summary = {}
    for point in dict.fromkeys(row["point"] for row in checkpoint_pairs):
        selected = [row for row in checkpoint_pairs if row["point"] == point]
        point_summary[point] = {**summarize(selected, "current_I_minus_B_bytes"),
                                "numeric_over_262144": sum(row["numeric_current_exceeds_262144"] for row in selected),
                                "normal_hot_current_gate": point in HOT,
                                "checkpoint_peak_difference": summarize(selected, "checkpoint_peak_I_minus_B_bytes")}
    numeric_failures = [row for row in checkpoint_pairs if row["normal_hot_current_gate"] and row["numeric_current_exceeds_262144"]]
    summary = {
        "scope": "independent recomputation; original current numeric exceedances retained alongside census gaps",
        "manifest_sha256": sha256((FORMAL / "manifest.json").read_bytes()).hexdigest(),
        "frozen_source_sha256": source_hashes,
        "windows": len(windows), "checkpoint_pairs": len(checkpoint_pairs),
        "censuses": validations["internally_consistent_censuses"],
        "uncovered_censuses": len(census_unknown),
        "uncovered_type_sets": dict(Counter(json.dumps(row["types"], sort_keys=True) for row in census_unknown)),
        "uncovered_points": dict(Counter(row["point"] for row in census_unknown)),
        "normal_hot_numeric_failures": len(numeric_failures),
        "normal_hot_failure_cases": len({(row["seed"], row["case"]) for row in numeric_failures}),
        "normal_hot_failure_count_by_seed": dict(Counter(row["seed"] for row in numeric_failures)),
        "point_summaries": point_summary,
        "window_peak": {**summarize(windows, "peak_I_minus_B_bytes"),
                        "numeric_over_1048576": sum(row["numeric_peak_exceeds_1048576"] for row in windows)},
        "all_attribution_groups_equal": all(row["attribution_groups_equal"] for row in checkpoint_pairs),
        "all_corresponding_numpy_and_public_backing_bytes_equal": all(
            row["numpy_backing_I_minus_B_bytes"] == row["public_bytes_I_minus_B_bytes"] == 0 for row in checkpoint_pairs),
        "hot_proofs_equal": all(row["hot_proof_equal"] for row in windows),
        "logical_pairs": len(logical_pairs),
        "logical_all_checks": all(row["logical_equal"] and row["close_public_equal"] and row["reopen_proof_equal"]
                                  and all(all(values.values()) for values in row["role_checks"].values())
                                  for row in logical_pairs),
    }
    for name, rows in (("resource_checkpoint_deltas.csv", checkpoint_pairs),
                       ("resource_window_deltas.csv", windows), ("resource_root_attribution.csv", attribution)):
        with (OUT / name).open("w", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader(); writer.writerows(rows)
    for name, data in (("resource_summary.json", summary), ("resource_numeric_failures.json", numeric_failures),
                       ("resource_census_gaps.json", census_unknown), ("resource_logical_recheck.json", logical_pairs),
                       ("resource_input_hashes.json", raw_hashes)):
        (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: summary[key] for key in ("windows", "checkpoint_pairs", "censuses", "uncovered_censuses",
                     "normal_hot_numeric_failures", "normal_hot_failure_cases", "normal_hot_failure_count_by_seed",
                     "window_peak", "all_attribution_groups_equal", "logical_pairs", "logical_all_checks")}, indent=2))


if __name__ == "__main__":
    main()
