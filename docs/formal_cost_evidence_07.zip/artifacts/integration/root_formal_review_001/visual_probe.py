"""CPU-only score replay, independent sample checks and formal feedback binding."""
from collections import Counter, defaultdict
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT/'artifacts/integration/formal_cost_001'
PHASES = ('before','after','next')
PUBLIC = ('before.ao.json','transition.ao.json','next.ao.json','before.png','after.png','next.png')
OUT = Path(__file__).with_suffix('.json')

def read(p):
    return json.loads(p.read_bytes())

def sha(p):
    return sha256(p.read_bytes()).hexdigest()

def lines(p):
    with p.open(encoding='utf-8') as f:
        for line in f:
            yield json.loads(line)

def main():
    manifest = read(BASE/'formal/manifest.json')
    for n in ('verification/cf_visual_acceptance.py','verification/test_raycast_saccade_gpu.py','verification/test_cerebellar_flash.py'):
        assert sha(ROOT/n) == manifest['source_superset'][n], n
    sys.path.insert(0,str(ROOT))
    from verification.cf_visual_acceptance import score_png
    helper_path=ROOT/'artifacts/integration/root_production_review_001/visual_probe.py'
    spec=importlib.util.spec_from_file_location('prior_root_visual',helper_path)
    helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    helper.BASE=ROOT
    seeds, all_feedback = [], {}
    for seed in manifest['seeds']:
        sid=seed['seed']; directory=BASE/'qualified_001'/f'qualification-{sid}'
        summary=read(directory/'result/summary.json')
        feedback=read(directory/'result/feedback.json')
        assert feedback == seed['integration_feedback']
        scored=ROOT/summary['scored_path']
        all_feedback[sid]=feedback
        failures=[]; negative_calls=[]; count=Counter()
        for case_id, phases in feedback.items():
            folder=scored/case_id
            for name in PUBLIC:
                assert (folder/'B'/name).read_bytes() == (folder/'I'/name).read_bytes()
                count['B_I_exact_public_pairs']+=1
            bi, ii = [read(folder/role/'record.json') for role in ('B','I')]
            for key in ('model_calls','feedback_state','measured_delta_m','predicted_delta_m','next_prediction_m'):
                assert bi[key] == ii[key]
            calls=[c for c in ii['model_calls'] if c['method']=='learn_view']
            assert len(calls)==2 and all(c['phase']=='feedback' for c in calls)
            for phase, call in zip(PHASES,calls):
                row=phases[phase]
                assert call['args'][:3] == [row['canonical_index'],row['safe'],row['selected_rays']]
                if not call['args'][1]:
                    negative_calls.append({'case':case_id,'phase':phase,'args':call['args'],'kwargs':call['kwargs']})
            for phase,row in phases.items():
                f=folder/'I'/f'{phase}.visual.json'; png=f.with_name(f'{phase}.png')
                b=read(folder/'B'/f.name); i=read(f)
                assert i['evidence'] == b['evidence'] and i['score'] == b['score']
                assert sha(f)==row['visual_sha256'] and sha(png)==row['png_sha256']
                assert row['pixel_success']==i['score']['pixel_success'] and row['safe']==i['score']['safe']
                assert row['strict_passed']==i['score']['passed']
                assert row['safe']==bool(row['pixel_success'] and row['native_stop'])
                if seed['process_index']:
                    replay=score_png(png.read_bytes(),i['evidence'])
                    assert replay == i['score'], (sid,case_id,phase,'full frozen CPU score')
                    sampled=helper.visual(f)
                    count['new_independent_pixel_grids']+=2
                    count['new_independent_owner_samples']+=1250
                    assert sampled['passed']==row['strict_passed']
                    count['new_full_frozen_score_replays']+=1
                count['strict_total']+=1;count['strict_passed']+=row['strict_passed']
                if not row['strict_passed']:
                    failures.append({'case':case_id,'phase':phase,'checks':row['failed_checks'],'safe':row['safe']})
        assert count['strict_total']==72 and count['strict_passed']==69 and len(negative_calls)==2
        external_path=directory/'result/external-consumer.json'
        external=None
        if seed['process_index']:
            rows=read(external_path)['rows']
            assert len(rows)==48 and {(r['case'],r['role']) for r in rows}=={(c,r) for c in feedback for r in ('B','I')}
            runtime=read(directory/'runtime.json')['clock']
            for r in rows:
                t0,t4=r['t0_before_observe'],r['t4_after_next_prediction']
                assert r['full_elapsed_ns']==t4-t0
                assert runtime['start']['monotonic_before_ns']<t0<t4<runtime['end']['monotonic_after_ns']
                a,b,c=[r['score_roundtrips'][p] for p in PHASES]
                assert t0<=a['start_ns']<a['end_ns']<=b['start_ns']<b['end_ns']<=t4<c['start_ns']<c['end_ns']
                assert all(v['elapsed_ns']==v['end_ns']-v['start_ns'] for v in (a,b,c))
                assert r['score_wait_inside_ns']==a['elapsed_ns']+b['elapsed_ns']
            external={'rows':len(rows),'all_timestamp_checks_pass':True,
                      'before_after_wait_ns_range':[min(r['score_wait_inside_ns'] for r in rows),max(r['score_wait_inside_ns'] for r in rows)],
                      'next_score_outside_t4':True,'score_roundtrip_count':len(rows)*3}
        else:
            assert not external_path.exists()
            assert summary['scored_path']=='artifacts/integration/production_functional_001/native_functional_final/result/L'
        seeds.append({'seed':sid,'scored_path':summary['scored_path'],'counts':dict(count),'negative_calls':negative_calls,
                      'strict_failures':failures,'external_consumer':external,'seed0_reuses_previous_L_only':seed['process_index']==0})
    # Check the actual serialized model values, public bytes, and next plans from every timing proof.
    actual=[]; model_cache={}; public_cache={}
    for seed in manifest['seeds']:
        sid=seed['seed'];expected=all_feedback[sid];directory=BASE/'formal'/f'latency-{sid}'/'result'
        proofs={};negative=0;labels=0
        for row in lines(directory/'proofs.jsonl'):
            case,pair,role=row['case_id'],row['pair'],row['role']
            assert (case,pair,role) not in proofs
            proofs[case,pair,role]=row
            assert all(row['checks'].values())
            p=directory/row['model']['file']
            if p not in model_cache:
                with np.load(p,allow_pickle=False) as z:
                    arrays={k:z[k] for k in z.files}
                member_ids={k:{'dtype':v.dtype.str,'shape':list(v.shape),'sha256':sha256(v.tobytes(order='C')).hexdigest()} for k,v in arrays.items()}
                assert member_ids==row['model']['members']
                model_cache[p]=(arrays,member_ids)
            arrays,member_ids=model_cache[p]
            assert member_ids==row['model']['members']
            assert int(arrays['v_writes'])==242
            for off,phase in enumerate(PHASES[:2]):
                e=expected[case][phase];idx=e['canonical_index']
                assert bool(arrays['v_known'][240+off,idx])
                assert arrays['v_values'][240+off,idx].tolist()==[e['safe'],e['selected_rays']]
                labels+=1;negative+=not e['safe']
            for name,member in row['public'].items():
                p=directory/member['file']
                if p not in public_cache:
                    raw=p.read_bytes();public_cache[p]=(sha256(raw).hexdigest(),len(raw))
                assert public_cache[p]==(member['sha256'],member['bytes'])
            for phase in PHASES:
                e=expected[case][phase]
                assert row['public'][phase+'.png']['sha256']==e['png_sha256']
                audit=row['next']['view_audits'][phase]
                for k in ('canonical_index','direction','order','total_rays','native_stop'):
                    assert audit[k]==e[k]
                selected=[p for p in audit['probes'] if p['direction']==audit['direction']]
                assert len(selected)==1 and selected[0]['ray_count']==e['selected_rays']
            ids=manifest['iterations'][pair]
            assert row['next']['observation_id']==ids['next'] and row['next']['action_id']==ids['next_action']
        assert len(proofs)==24*36*2
        for case in expected:
            for pair in range(36):
                b,i=[proofs[case,pair,r] for r in ('B','I')]
                assert b['next']==i['next'] and b['model']['members']==i['model']['members']
                assert {k:v['sha256'] for k,v in b['public'].items()}=={k:v['sha256'] for k,v in i['public'].items()}
        actual.append({'seed':sid,'actual_latency_proofs':len(proofs),'stored_model_labels_verified':labels,
                       'stored_negative_labels_verified':negative,'B_I_exact_pairs_including_warmup':24*36})
    # Resource rows retain hashes/checks, not a second complete output/NPZ store.
    resource_rows=[]
    for seed in manifest['seeds']:
        sid=seed['seed'];expected=all_feedback[sid]
        for instrument in ('managed','os'):
            pairs={}
            for role in ('B','I'):
                rows=list(lines(BASE/'formal'/f'{instrument}-{sid}-{role}'/'result/cases.jsonl'))
                assert len(rows)==24
                for row in rows:
                    case=row['case'];pairs[case,role]=row
                    for proof in (row['hot_proof'],row['lifecycle']['reopened_proof']):
                        assert all(proof['checks'].values())
                        for phase in PHASES:
                            assert proof['public'][phase+'.png']['sha256']==expected[case][phase]['png_sha256']
            for case in expected:
                for key in ('hot_proof',):
                    assert pairs[case,'B'][key]==pairs[case,'I'][key]
                assert pairs[case,'B']['lifecycle']['reopened_proof']==pairs[case,'I']['lifecycle']['reopened_proof']
            resource_rows.append({'seed':sid,'instrument':instrument,'row_count':48,
                                  'PNG_binding_and_recorded_checks':True,'hot_and_reopen_proofs_exact':True,
                                  'limit':'Model/next hash and recorded check receipts, not stored NPZ or full next fields for independent model replay'})
    # Independently reproduce descriptive pooled postprocessing without invoking its writer.
    pooled={}
    saved=read(BASE/'formal/summary.json')
    for segment in ('before','action','feedback','next','continuous_total'):
        rows=[row for seed in manifest['seeds'] for row in read(BASE/'formal'/f"latency-{seed['seed']}"/'result/summary.json')['segments'][segment]['by_case'].values()]
        p95={r:float(np.quantile([row['arms'][r]['median_ns'] for row in rows],.95,method='linear')) for r in ('B','I')}
        pooled[segment]={'case_seed_rows':len(rows),'p95_ns':p95,'I_over_B':p95['I']/p95['B']}
    assert pooled==saved['latency_pooled_descriptive']
    assert saved['status']=='UNVERIFIED' and saved['prior_b_b_next_failure_unchanged']==manifest['prior_b_b_next_failure_unchanged']
    result={'scope':'CPU frozen scorer replay plus independently decoded pixel/grid checks; archived native owners, no fresh native rays',
            'independent_helper_sha256':sha(helper_path),'seeds':seeds,'formal_actual_proofs':actual,
            'unique_model_npz_verified':len(model_cache),'unique_public_blobs_verified':len(public_cache),
            'resource_binding_receipts':resource_rows,'pooled_descriptive_recomputed':pooled,
            'full_cost_acceptance_claimed':False,'all_checks_pass':True}
    OUT.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'all_checks_pass':True,'seeds':[(s['seed'],s['counts']) for s in seeds],
                      'formal_actual_proofs':actual,'unique_model_npz':len(model_cache),'unique_public_blobs':len(public_cache)},indent=2))

if __name__=='__main__':
    main()
