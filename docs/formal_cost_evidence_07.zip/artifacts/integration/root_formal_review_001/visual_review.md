# 正式成本批次的视觉、反馈与外部消费审查

结论：两个新 seed 的真实生产 B/I 图像、固定评分、负反馈及 next 输出与冻结事实一致；没有新增集成退化。seed 20261105 的复用范围明确为此前 L 的 24 场景、三个阶段，不是重新执行旧 90 图全臂测试。严格失败保留，来源与视觉范围可继续接收；不据此宣布资源或整机成本门全部通过。

复核脚本为 `visual_probe.py`，结果为 `visual_probe.json`。本次仅 CPU 读取原 PNG、矩阵和归档 native owner/depth 证据，没有原生重渲染、新几何射线或性能重测。固定评分源码先核对正式 source_superset SHA，再执行其 score_png；独立像素/相机计算复用此前主干自写 CPU helper，身份也保存于 JSON。相机/剖切旧原因不重复开启优化。

## 新评分与复用范围

| seed | 证据来源 | 本次核对 B/I 公共字节对 | 每臂严格通过 |
| --- | --- | --- | --- |
| 20261105 | production_functional_001/native_functional_final/result/L | 144 | 69/72 |
| 79463 | qualified_001 新运行的 24 场景 × B/I × before/after/next | 144 | 69/72 |
| 310519 | qualified_001 新运行的 24 场景 × B/I × before/after/next | 144 | 69/72 |

每个字节对包括 before/transition/next 的三个 AO 文件和三张 PNG。全部 432 对 B/I 字节完全相同，三 seed 的 216 组 B/I evidence/score 也逐对象相同。两新 seed 共 144 张 I PNG 完整重算固定评分，结果逐字段等于原 score；B PNG 完全相同。另独立解码这些 PNG，核对两视图矩阵/投影、剖切和方向门、支持点/间隙，以及 288 组格网共 **180,000 个归档 native owner 采样**，均与像素相符。格网 oracle 使用归档原生射线结果，不能称为本次新建原生几何真值。

每个 seed 均保留相同三个严格失败：nested-drums-1 before 的 section_declaration；carried-screen-0 after/next 的 directions。其 safe/pixel_success/strict_passed 未被改成正例。像素子项可用与严格声明失败同时成立，沿用既有负样本定义，不改容差、不换输入、不强制修正已冻结 B。

实际 record.json 的 model_calls 和 feedback_state 跨 B/I 完全一致。每条链 before/after 各有一次 learn_view；nested before 和 carried after 两次传入 false。next 只有观察/预测，不产生第三次负反馈写入。因此每 seed 每臂为三个负观察、两次负反馈，不能把两种计数混用。

## 真实评分先于正式测量，且正式输出实际绑定

qualified_001 三个进程在 03:45:11 UTC 前完成，正式第一进程于 03:48:23 UTC 开始。feedback.json 原值逐项等于正式 manifest 中 integration_feedback，PNG/visual 文件 SHA 也在每个正式相关 job 的输入列表中固定。seed 0 使用前阶段原图和原 score；两个新 seed 使用本次真实评分。跨批 scorer/VG 源码完全相同，细节见 provenance_review.md。

不仅复述 binding_checks=true，本次对三个 latency 进程全部 **5,184 条 arm proof** 做了读档核验（含 warmup，对应 2,592 个 B/I 对）：

- 实际公开输出文件 SHA/长度等于 proof；before/after/next PNG 身份等于预先评分输入。
- 三阶段 canonical index、方向、顺序、射线数、native_stop 和 selected rays 与冻结评分逐项相符。
- 实际 next observation/action ID 对应 manifest pair；全部 B/I next 字段、模型成员和公开输出一致。
- 读取 144 份独立路径的实际模型 NPZ，验证 dtype/shape/成员哈希；从存储数组直接核对 10,368 个 before/after 模型写入标签及射线成本。其中 **432 个 false 写入**仍为 false；v_writes 为 242，next 未新增 view 写入。每 seed 144 个负标签，计数包含两臂和 36 次重复，不是新增负场景。
- 实际公开 blob 共 15,840 份路径完成身份核对；相同 PNG 在多轮复用内容不被算成新的独立评分。

managed/os 共 288 条 case 记录的 hot/reopen PNG 身份及记录的 binding checks 与相应 seed 评分一致，两臂 hot/reopen proof 相同。但资源记录只有公开 SHA、active_model_sha256、next_sha256 和运行时布尔检查，未像时延记录一样保存可逐成员重读的模型 NPZ/完整 next 对象。本报告只承认它们是相符的运行时收据，不能冒称做过资源过程的独立模型数组重算；资源 ownership/峰值门交由专门审查。

## 外部等待闭环的证据和边界

新 seed 的 external-consumer.json 各有 48 条链（24 场景 × B/I），共 96 条；三次真实 Pillow 请求各带 start/end/elapsed，共 288 次。全部时间戳重算满足：

`t0 ≤ before score start < end ≤ after score start < end ≤ t4 < next score start < end`

full_elapsed=t4−t0；score_wait_inside 等于 before 和 after 两次实际往返耗时之和；全部链落在本进程 runtime 区间内。79463 的 before+after 等待范围为 9.631–600.3893 ms；310519 为 8.4021–219.4889 ms。所有值保留，包括首次消费初始化开销。next 的评分位于 t4 之后，单独列出，不计入前两次等待或引擎连续服务时延。

这证明新 seed 存在实际出图→外部评分→反馈→next 观察/预测的功能链；其中 native VisualAudit、落盘和功能核对也位于外部工作流。它不是公平的正式性能对比：资格运行 B 后 I、每例一条链并含消费启动/验证/归档；不得将该范围当成正式服务比值。seed 0 没有本次 external-consumer.json，应明确为旧评分复用，不虚构新的外部等待观测。

正式热链刻意使用已固定标签，逐次输出通过实际 PNG/方向/模型写入绑定证明标签仍适用。故正式时延没有包含真实外部评分往返，而外部闭环证据单独保留；这两种证据不能互相替代或混加。

## 报告统计修正和有限结论

CPU 独立从三个 seed 的逐例中位数重算 pooled 的五段 p95 与 I/B，逐字段等于最终 summary。该表只有描述作用；原逐 seed 门及失败未被替换。原 report.py 的 cases/by_case 取键错误与补充控制的 float32 JSON 序列化错误是不同事件，两者原版本和失败均应保留。

本审查没有新增视觉阻塞，支持本范围功能等价。保留三严格负例及 false 反馈；保留 postprocess 来源边界、后补控制的真实时间顺序、资源侧证据精度，以及全局 UNVERIFIED 状态。完整成本、资源 current 和旧 CF 功能范围的最终接收由主干合并其它独立审查决定，无需再重跑本次已核实的视觉集或重开 VG 优化。
