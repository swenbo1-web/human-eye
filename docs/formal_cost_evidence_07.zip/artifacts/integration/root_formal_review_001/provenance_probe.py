"""Read-only independent formal provenance audit. No project imports/native calls."""
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import difflib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'artifacts/integration/formal_cost_001'
OUT = Path(__file__).with_suffix('.json')
CACHE = {}

def read(p):
    return json.loads(p.read_bytes())

def ident(p):
    p = p.resolve()
    if p not in CACHE:
        b = p.read_bytes()
        CACHE[p] = {'sha256': sha256(b).hexdigest(), 'bytes': len(b)}
    return CACHE[p]

def iso(ns):
    return datetime.fromtimestamp(ns / 1e9, timezone.utc).isoformat()

def main():
    errors = []
    def check(ok, label):
        if not ok:
            errors.append(label)
    formal = BASE / 'formal'
    identity = read(formal / 'artifact-identity.json')
    check(identity['file_count'] == len(identity['files']) == 16160, 'formal identity count')
    for n, expected in identity['files'].items():
        check(ident(formal/n) == expected, 'artifact '+n)
    actual = {p.relative_to(formal).as_posix() for p in formal.rglob('*') if p.is_file()}
    check(actual == set(identity['files']) | {'artifact-identity.json'}, 'formal exact file set')
    check(ident(formal/'manifest.json')['sha256'] == '093a0df0ea941eb7cc6bd1206490627ca8196e0951fff18e6601fb513816e8c7', 'manifest expected SHA')
    suites = []
    sources = {}
    all_runs = []
    for name in ('qualified_001', 'qualified_old_001', 'formal', 'control_supplement/run_001', 'control_supplement/run_002'):
        directory = BASE/name
        manifest = read(directory/'manifest.json')
        expected = manifest['source_superset']
        with ZipFile(directory/'sources.zip') as z:
            check(len(z.namelist()) == len(set(z.namelist())), name+' duplicate ZIP members')
            observed = {n: sha256(z.read(n)).hexdigest() for n in z.namelist()}
        check(observed == expected, name+' source ZIP exact match')
        sources[name] = observed
        jobs = manifest['jobs']
        suite_runs = []
        for job in jobs:
            folder = ROOT / job.get('folder', job.get('directory', ''))
            launch = read(folder/'launch.json')
            process = read(folder/'process.json')
            runtime = read(folder/'runtime.json')
            supplement = name.startswith('control_supplement')
            imports = read(folder/('observed-project-imports.json' if supplement else 'project-imports.json'))['paths']
            check(all(expected.get(n) == h for n,h in imports.items()), str(folder)+' observed import hashes')
            if supplement:
                check(launch == job, str(folder)+' launch job exact')
                inputs = launch['input_identities']
                for n, row in inputs.items():
                    check(ident(ROOT/n) == {k: row[k] for k in ('sha256','bytes')}, name+' input '+n)
                reads = [json.loads(line) for line in (folder/'result/reads.jsonl').read_text().splitlines()]
                expected_by_path = {str(Path(v['path']).resolve()):v for v in inputs.values()}
                for r in reads:
                    target = expected_by_path.get(str(Path(r['path']).resolve()))
                    check(target is not None and all(r[k] == target[k] for k in ('sha256','bytes')), name+' actual input read '+r['path'])
                check(runtime['blender_executable'] == manifest['executables']['blender'], name+' executable')
            else:
                check({k:v for k,v in launch.items() if k != 'manifest'} == job, name+' launch '+job['job_id'])
                check({k:launch['manifest'][k] for k in ('bytes','sha256')} == ident(directory/'manifest.json'), name+' registered manifest receipt')
                inputs = job['input_files']
                for n,h in inputs.items():
                    check(ident(ROOT/n)['sha256'] == h, name+' input '+n)
                reads_path = folder/'result/reads.jsonl'
                if reads_path.exists():
                    for row in (json.loads(line) for line in reads_path.read_text().splitlines()):
                        path = Path(row['path']).resolve()
                        relative = path.relative_to(ROOT).as_posix()
                        check(inputs.get(relative) == row['sha256'], name+' actual input read '+relative)
                        check(ident(path) == {k:row[k] for k in ('sha256','bytes')}, name+' actual input read bytes '+relative)
                check(runtime['blender_executable'] == manifest['runtime_registration']['blender_executable'], name+' executable')
                for k,v in manifest['runtime_registration'].get('native_expected',{}).items():
                    check(runtime[k] == v, name+' expected native '+k)
            check(runtime['environment'] == launch['environment_effective'], name+' effective environment')
            check(runtime['gpu']['backend'] == 'OPENGL' and runtime['gpu']['renderer'] == 'NVIDIA GeForce RTX 3060/PCIe/SSE2', name+' GPU')
            check(process['stable_sources'] and process['stable_inputs'], name+' recorded source/input stability')
            stamp = runtime['clock']
            a,b = stamp['start']['monotonic_before_ns'], stamp['end']['monotonic_after_ns']
            check(a < b, name+' valid runtime interval')
            run = {'suite':name, 'job':job.get('job_id',str(job.get('seed'))), 'exit_code':process['exit_code'],
                   'recorded_stable_sources':process['stable_sources'], 'recorded_stable_inputs':process['stable_inputs'],
                   'imports_verified':len(imports),'inputs_current_hash_verified':len(inputs),
                   'start_monotonic_ns':a,'end_monotonic_ns':b,
                   'start_utc':iso(stamp['start']['utc_ns']),'end_utc':iso(stamp['end']['utc_ns']),
                   'runtime':{k:runtime[k] for k in ('platform','blender_version','python_version','python_executable','python_dll','numpy','pillow','gpu')},
                   'directory':folder.relative_to(ROOT).as_posix()}
            suite_runs.append(run); all_runs.append(run)
        check(all(a['end_monotonic_ns'] < b['start_monotonic_ns'] for a,b in zip(suite_runs,suite_runs[1:])), name+' serial order')
        summary = read(directory/('summary.json' if name.startswith('control_supplement') else 'batch-processes.json'))
        check([r['exit_code'] for r in suite_runs] == [r['exit_code'] for r in summary['processes']], name+' process summary exits')
        suites.append({'suite':name,'manifest':ident(directory/'manifest.json'),'source_zip':ident(directory/'sources.zip'),
                       'source_members':len(expected),'jobs':suite_runs})
    check(all(a['end_monotonic_ns'] < b['start_monotonic_ns'] for a,b in zip(all_runs,all_runs[1:])), 'global suite/runtime serial order')
    for run in all_runs:
        check(run['runtime'] == all_runs[0]['runtime'], run['suite']+' all-suite actual native fingerprint')
    formal_sources = sources['formal']
    frozen = read(ROOT/'artifacts/integration/production_functional_001/source-identity.json')['production_and_verification_sources']
    shared = {n:row['sha256'] for n,row in frozen.items() if n in formal_sources}
    check(all(formal_sources[n] == h for n,h in shared.items()), 'frozen production/verification source equality')
    scorer_paths = ('verification/cf_visual_acceptance.py','verification/test_raycast_saccade_gpu.py','human_eye_fast/raycast_saccade_gpu.py')
    scorer_ids = {n:formal_sources[n] for n in scorer_paths}
    for n,h in scorer_ids.items():
        check(all(s[n] == h for s in sources.values()), 'all source archive fixed scorer '+n)
    source_diffs = {name:{n:{'formal':formal_sources.get(n),'this':h} for n,h in s.items() if formal_sources.get(n) != h}
                    for name,s in sources.items()}
    a,b = [sources['control_supplement/'+n] for n in ('run_001','run_002')]
    check([n for n in a if a[n] != b[n]] == ['artifacts/integration/formal_cost_001/control_supplement/worker.py'], 'supplement only serialization source changed')
    with ZipFile(BASE/'control_supplement/run_001/sources.zip') as z1, ZipFile(BASE/'control_supplement/run_002/sources.zip') as z2:
        n='artifacts/integration/formal_cost_001/control_supplement/worker.py'
        diff=''.join(difflib.unified_diff(z1.read(n).decode().splitlines(True),z2.read(n).decode().splitlines(True)))
    report_path='artifacts/integration/formal_cost_001/report.py'
    check(ident(ROOT/report_path)['sha256'] == formal_sources[report_path], 'original buggy report unchanged')
    result = {'scope':'CPU read-only provenance audit; fresh hashes and archived receipts, not historical process rerun',
              'artifact_identity':ident(formal/'artifact-identity.json'),'registered_artifact_files':len(identity['files']),
              'errors':errors,'all_checks_pass':not errors,'suites':suites,'frozen_shared_final_sources':shared,
              'fixed_scorer_and_VG':scorer_ids,'archive_source_differences_from_formal':source_diffs,
              'supplement_serialization_only_diff':diff,
              'postprocess_script':ident(BASE/'postprocess/report_frozen.py'),
              'original_report_script':ident(ROOT/report_path),
              'current_head_context_only':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
              'identity_scope_limit':'16160 files cover formal/ only; qualified/control archives independently verified here; no standalone original report failure exit/log file located in these archived suites'}
    OUT.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'all_checks_pass':not errors,'errors':errors,'artifacts':len(identity['files']),
                      'suites':[(s['suite'],s['source_members'],len(s['jobs'])) for s in suites]},indent=2))

if __name__ == '__main__':
    main()
