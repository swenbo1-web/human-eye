# N 通用对照可执行准备审查

**结论：可冻结为 N 对照的可执行准备候选；没有发现必须先重写算法才能进入原生资格的主线错误。** 当前不能称实际 Blender N worker、真实 world setter、双臂写入审计、终态视觉或成本对照已验收。无需为了“更强基线”继续展开一轮优化；下一步应补一次限定原生接线资格。

本次只读交付/CPU 记录和源，复跑既有 8 项 CPU 测试，并核算一个既有剪枝 fixture 的候选工作量。没有启动 Blender、GUI、GPU、模型、网络或 IPC，没有改作者源、证据、Git 或共享文档。复核程序和结果为本目录 `native_preparation_probe.py/json`；根侧另负责完整交付身份核查，本报告不重复扩大该任务。

## 冻结来源与 CPU 证据

交付 manifest SHA 为 `d8e2ef4d743397d881f1d0a5f4976faa052194307f8d994d1491355b6f3f6fd0`，源 ZIP 为 `8eb961f8f9464a39becb4fc3c73c4189584c5df990c0afa2f5035ca9b58c6395`。以下行号绑定该交付；本次读取的工作区四文件与 ZIP 字节一致：

| 文件 | SHA-256 |
|---|---|
| native_geometry.py | `740dc7aa668d5fcde1c5581ba52276651a4a53a04912c067e5bedaab53faaddf` |
| blender_native.py | `90290289331f8369b19cdee0d8d65266ae66a96e15c8e5eafaa46e963c3ee670` |
| native_audit.py | `f2cff4cf2c265209f79623dc191aedc72e74f0312b631200a038baf517566fdd` |
| test_native_prep.py | `90b14c2f625dadedf6424440a984ff6ad61e8c8a4d07347c4b84cb07f6276b21` |

`cpu_001` 与 `cpu_002` 均保留登记、exit 0、原日志的 8/8 和相符 SHA。第一批 adapter/test 版本与最终版不同，不能合计为最终源“16 项测试”；其旧源码没有独立 ZIP，证据范围是登记与原日志。第二批 ZIP 的全部七项 source hashes 已核对，四个交付文件与它完全一致；借用 evaluated mesh、把临时 to_mesh 留给独立审计的最后修订有对应最终版本证据。

本次复跑最终 **8/8 通过**，测试仍仅使用 RNA doubles。包括 vertex-face 和 edge-edge 内部见证、穿面/共面相交、空面、三个种子的六个多叶 refit 状态与独立 oracle、剪枝、单位和真实 setter 形状的 double、setter 异常。没有追加随机大矩阵或正式 D/V 任务跑分。

128×128 既有合成剪枝例中，实际进入窄相的配对为 **64 / 16384**，一次 batch，返回 0.02 m。这证明这例确实进行了空间剪枝，既不是全笛卡尔积调用慢 oracle，也不是注释中的空宣称；不构成正式 D02/D03 性能、硬件时间或 I/N 收益结论。

## 算法是否是合理通用对照

`native_geometry.py:109–172` 根据实际输入三角形中心构建中位划分的 AABB 树，叶大小 8，维护原三角行号；固定拓扑后只更新实际世界三角形和自底向上的包围盒。`surface_pair:174–215` 对节点对按 AABB 距离下界最佳优先搜索，已有可行见证提供上界，未达到上界的子节点才入队。叶对最多 8×8，局部向量化，并没有预先建立整个两网格的全部三角配对数组。

`_closest_batch:41–99` 检查双向顶点到面内部投影、顶点到边界线段、边到边内部最近点，以及边穿过面内部的零距交点。前两类覆盖边界与退化线段；额外的穿面检查避免仅凭 vertex/edge 距离漏掉横穿三角形。各有效候选给出实际可行点，返回最小候选距离和来源三角行号。多叶随机/refit 结果已与独立凸支持最小二乘 oracle 比较，见证还核对了三角形内的重心可行性。没有把低效 oracle 留在运行时，也未发现遗漏当前主线最近特征的窄相分支。

三 runtime 文件仅导入标准库、NumPy、自身 geometry，以及实际调用时的 bpy；没有 HE 内核、BC/AO 输出、recipe、预知轴/顶点索引、评分答案或 LLM prompt 硬编码。测试对独立 oracle 的导入留在测试层，不污染 N 的运行时依赖。

缩隙公式在这个任务定义下成立：若当前真实最短距离为 d、目标为 g≤d，将 moving 整体沿最近见证方向平移 d−g，原见证对给出距离 g 的上界；刚体平移对距离的变化至多为平移长度，因此全局表面距离同时不小于 g。平移长度 d−g 也是达到 g 所需的下界。这里不涉及碰撞路径规划、旋转或形变，不要求额外迭代/回退链。最终仍重新读取实际 Blender 几何验证浮点和 setter 结果。

可信域应保持 README 所写的固定拓扑、独立固定 reference、moving 刚体平移、串行场景编辑和正常数值范围。相同顶点数但改变面索引不属于有效 refit 输入；应由 host 重绑定，不因本次审查新增通用拓扑扫描。当前实现可作为合理起点，不能仅凭存在 heap/NumPy 开销就要求进一步性能优化，也不能据此断言它已代表所有可能最快 N。

## 实际 Blender 接线及审计覆盖

`blender_native.py:24–36` 在 solver 侧读取 `evaluated.data` 的实际坐标，按 evaluated world matrix 和 scale 转为米；首次读三角行，后续固定拓扑 refit。采集到的 NumPy 几何供独立 N 树，不借 HE 驻留数组。`NativePair` 将状态限定为当前绑定的两个索引和最新可测读回，可常驻调用，不强迫每任务重载 helper。

`translate_world_m:46–65` 先读取 evaluated world matrix，将米增量除以场景单位，仅改 translation，然后只有一行实际 `moving.matrix_world = matrix`。prepare 失败为 not_written、setter 抛错为 unknown；`close_gap:144–197` 写后重新请求 depsgraph、读取实际目标与参考，返回实测间隙及世界原点位移。已达标零写；未达或错误不会锁死未来明确请求，也不自动重试。父变换条件下实际 Blender 对 world matrix assignment 的行为仍须原生资格确认，RNA double 不能替代。

`native_audit.capture_scene_rna:92–127` 与 solver 分开读取：在指定 scene/view_layer 获取 evaluated depsgraph，对全 scene 对象记录 object/data 身份、矩阵，对 mesh 用 `to_mesh/calc_loop_triangles` 得到局部与世界顶点，并在 finally 清临时 mesh。它不使用 N result/witness 来构造快照，可核对新增/删除/替换和参考、父、context 不变。README 的调用者 finally 接线负责保存 after 并关闭 pair；**现在只是示例，还没有实际 native runner 证明错误时也已落盘**。

`SetterTrace:29–89` 找冻结 callable 中单行 `moving.matrix_world` 赋值，记录该行 entered，下一 line/return 标 completed，exception 标 raised。N 的 setter 和第二个模拟 setter 均有 CPU 记录。实际 I 的 `BlenderControl.execute` 源存在唯一适配赋值位点（当前 control.py:175，SHA `85025e57aeac604243f0ff207886621b30674e5c643dc1451522e5ea7351506b`），因此静态可定位，但本次没有运行真实 I trace。

该 trace 的必要边界已明确：它观测指定 Python 写入位点，不是所有 Blender 写操作的全局拦截器，不能发现其他脚本先改后还原的越界行为。正式 N dispatch 必须保存并审查实际可写脚本，使实际写入走指定 adapter，before/after 再独立核对作用范围。不要把这点误报为已有全局写审计，也不需要为了本次准备新增防御框架。两臂用同一 trace 机制不代表两臂调用数量与函数长度相同；正式窗内实际审计开销应按协议原样计入，不能替某臂扣除。

## 可冻结项、具体剩余项与最小下一步

可冻结：上述三 runtime 的算法/接口身份，现有八项 portable 检查，以及 `SetterTrace`/独立 scene snapshot 的对称审计接口，作为进入原生接线资格的候选。没有本轮必须先修改的明确数学或正常流程 bug，**不要求再优化 N 才允许推进**。

正式 N 资格的具体缺项仍是：实际 host/tool dispatch 与允许写入脚本未冻结；借用 evaluated mesh、父级和单位下的实际 setter/fresh RNA 未跑；真正 I/N 单行 setter trace 和错误 finally 原件尚无；N 终态 renderer 与对应 PNG/camera 接线尚无。原文协议仍允许换掉慢起点 helper，因此采用本候选不违约，但正式比较前应绑定本候选的实际加载路径/hash，不能继续把旧慢 oracle 描述当执行源。

后续建议**一次限定 background 原生资格**，无需模型或外发：同一 worker 中用 D02、D03 检查真实 edge-edge/vertex-face 主线，T01 检查固定非均匀父级和米/BU，C02 检查零写。保存每次 before/after 实际 RNA、结果、setter trace、源身份和关闭；在同批 T01/C02 对 I 也启用同一 trace，确认一次写/零写与独立终态。该建议只是待根侧登记的范围，当前未执行，不自行追加进程。

若上述接线通过，可把 N 数值资格往前推进。V 的真实 PNG/camera/标签、实际宿主和模型、完整时间/token 仍由对应阶段处理，不为 N 数学资格额外开启 GUI、四视觉场景或大性能批次。若一次资格失败，保留具体失败再定点处理，不由新聊天重启算法优化循环。
