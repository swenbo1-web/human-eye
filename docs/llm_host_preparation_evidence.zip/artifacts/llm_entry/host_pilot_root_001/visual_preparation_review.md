# V 准备独立复核

结论：**可接收为离线采集与评分准备；四个真实 V 案的视觉资格仍未完成。** 本轮未发现需要退回的主要同源绑定或分类算法退化。无需扩合成矩阵或再开优化。可推进既定的一个数值、一个图像真实宿主 pilot；pilot 的图理解或 usage 可测不代表正式 V 资格、14 案/臂验收或收益 PASS。

范围为本次 `host_pilot_001/visual_prep` 五个源文件、登记/执行记录、草案及现有 VG 对应代码。交付 manifest 为 `d8e2ef4d743397d881f1d0a5f4976faa052194307f8d994d1491355b6f3f6fd0`，总 source ZIP 为 `8eb961f8f9464a39becb4fc3c73c4189584c5df990c0afa2f5035ca9b58c6395`；完整身份核对采用同目录根侧 `check_delivery.py/json`，本报告不另称完成一轮全量身份审计。未运行 Blender、GPU、模型或网络，未修改交付/生产文件。

## 代码与草案对应

| 项目 | 实际实现与判断 |
| --- | --- |
| 同一次绘制 | `visual_capture.py:48–100` 在 prepare 前复制 world-meter 顶点为 float32，保存有序三角形和实际材质色；observe 必须消费同一个 prepared，原参数及 audit 不变，返回 PNG 与 metadata 同次留存。与 VG `raycast_saccade_gpu.py:96–105,240–264` 的材质索引、绘制转换吻合；当前 session `blender_radical_session.py:288–289` 确实逐次 prepare 后 observe。 |
| 公共图与相机绑定 | `visual_capture.py:119–153` 比较 PNG 原字节、任务/观察/frame/image ID、对象、单位、mode、section、panels 和完整 views；解析真正 1024×512 不透明 PNG。`:156–196` 归档五个原件并在重读时复验哈希及绑定。此链成立于 evaluator 确实从该次 draw 采集；`actual_render` 字符串本身不是执行证明。 |
| 投影及切面 | `visual_score.py:32–58,144–176,237–253` 使用记录 GPU VP 的逆矩阵、真实 near/far 和 PNG 顶左像素中心；仅 witness 面板应用有符号切面，scene_context 保持原几何。对应 VG `:118–157,350–374,390–398` 的世界米矩阵、半像素约定及 shader `:89` 的正侧 discard。切面数值带内保留 unknown，没有把未裁剪第一 hit 冒充切后第一 hit。 |
| 独立标签 | `visual_score.py:64–107,155–204` 对归档三角形独立求交，不调用 VG 选视、BVH 或候选可见性结论；保留首 hit、原首 hit、目标邻域 retained/discarded hit 和 PNG RGB。visible 需要目标邻域首 hit 及可区分色标；occluded 需要确认前景及其后的 retained 目标；cut_away 需要未切时局部目标先出现且被实际切面去除。像素不符、色标歧义、深度 tie、HUD 等均不转成正标签。 |
| 五点及覆盖 | `visual_score.py:207–211,245–279` 固定中心与上下左右 2 px，3/5 同票才有标签，unknown 不从分母删去；实际每案 witness 至少一项确定标签，四案合计有 visible、occluded。合成 provenance 不能满足覆盖。符合草案 `LLM_TASK_PROTOCOL_DRAFT.md:40–44`。 |

这里的独立性是“独立射线/像素判定”，不是独立重新证明 BC 最近点：见证点仍来自同次 renderer metadata（`:227–234` 仅检查有限坐标、面索引范围）。实际终态距离、最短位移及作用范围继续由既定 evaluated-RNA 数值 oracle 检查，不能用此视觉分数替代。8 像素世界深度邻域、RGB 容差 2 和 float32 数值带是当前明确配置；最终标签描述邻域可辨认性，不应宣传为精确单点或任意材质场景的通用视觉真值。

## 合成证据的实际范围

作者 `execution_001.json` 记录 smoke 与空输入 CLI 均 exit 0，10 项检查通过，真实 V bundle 数为 **0**。`smoke.py:32–89` 的解析平面和单位 VP 能检查分类逻辑，`:114–172` 另检查相机/PNG 错配、归档篡改、复制及多数票；它们没有执行真正 GPU draw、真实非平凡相机、N 渲染适配或四案图像。

本审查用已有 Python、`-B`，在内存中调用现有 fixture 和评分入口（仅替换 bundle 的磁盘读取，不改变分类），独立得到：NATURAL moving 5 visible/reference 5 occluded；SECTION reference 在 scene_context 为 5 visible、在 witness 为 5 cut_away；单像素冲突为 4 visible + 1 unknown；HUD 为 5 unknown；合成覆盖仍缺 V01–V04。另执行现有 fake-renderer 复制检查。全部断言通过，没有写临时 bundle。这是对既有合成输入的独立执行，**不是十项完整归档负例重跑或真实渲染复验**。

因此“准备完成”可以限定为：数据结构、同源采集接口、独立离线射线/像素评分及待测状态可用。README 的 `call_terminal_run_once`/`call_current_camera_once` 是未来 worker 接线例程；当前 `pilot_worker.py` 另有旧图缓存记录，尚未调用本次 capture。不能把模块可导入或该例程当作实际 I/N 已贯通。

## 唯一后续资格批次的最小合同

1. 保持既定 pilot 范围；在需要正式 V 资格时统一安排 V01–V04 的 I/N 真实采集。使用冻结 fixture/目标终态及 render profile，采集器在实际 prepare 前安装，每次同一缓存仍有效时取得公开 camera。原 wire、来源及 bundle 一次留全，禁止事后重渲染补旧 PNG。
2. I 实际接通本 capture，N 从自己的真实 draw 提供等价 RenderSource；冻结两臂观察条件或证明遮挡难度等价。当前仅支持平涂 RGB、正交双面板，不能未经验证直接套用其他原生着色/投影。这是 N 接线待完成项，不是新增模型样本或要求优化 N 到极限。
3. 用当前独立评分保存全部五点、两面板和 unknown/mixed 负反馈；逐案核对同源矩阵/切面/像素，满足既定确定标签与正负覆盖后冻结实际标签。若某案不满足，则该案资格保留未通过，不降门或剔除难票。评分的 `ready_for_independent_review` 仍只表示可供人工独立验收，不自动证明两臂等价。
4. 实际发布给模型的图片与冻结图绑定，回答按该图标签验收；宿主图片消费/实际 usage、正式质量、成本收益分别报告。当前真实四 V 缺测是明确待办，不妨碍离线准备接收，也不能算通过。

无须本轮再增加算法修订或边界矩阵；余项是上述实际接线及一次统一资格取证。
