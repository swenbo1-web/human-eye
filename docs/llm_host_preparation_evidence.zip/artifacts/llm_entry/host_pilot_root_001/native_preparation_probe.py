"""Bounded offline identity, existing CPU qualification and setter-site audit."""
from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import ast
import io
import json
import os
import sys
import unittest

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "artifacts/llm_entry/host_pilot_001"
OUT = Path(__file__).with_suffix(".json")
PREFIX = "artifacts/llm_entry/host_pilot_001/native_prep/"


def digest(raw):
    return sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def main():
    manifest_path = BASE / "delivery_001/manifest.json"
    manifest = read(manifest_path)
    assert digest(manifest_path.read_bytes()) == "d8e2ef4d743397d881f1d0a5f4976faa052194307f8d994d1491355b6f3f6fd0"
    zip_path = BASE / "delivery_001/sources.zip"
    assert digest(zip_path.read_bytes()) == manifest["sources_zip_sha256"] == "8eb961f8f9464a39becb4fc3c73c4189584c5df990c0afa2f5035ca9b58c6395"
    imports, snapshots = {}, {}
    with ZipFile(zip_path) as archive:
        for path, expected in manifest["sources"].items():
            assert digest(archive.read(path)) == expected, path
        for name in ("native_geometry.py", "blender_native.py", "native_audit.py", "test_native_prep.py"):
            path = PREFIX + name
            raw = archive.read(path)
            assert (ROOT / path).read_bytes() == raw
            snapshots[name] = {"sha256": digest(raw), "bytes": len(raw), "lines": len(raw.splitlines())}
            if name != "test_native_prep.py":
                imports[name] = [ast.unparse(n) for n in ast.walk(ast.parse(raw)) if isinstance(n, (ast.Import, ast.ImportFrom))]
                assert "human_eye" not in "\n".join(imports[name])
                assert "verification" not in "\n".join(imports[name])
        records = []
        for label in ("cpu_001", "cpu_002"):
            folder = BASE / "native_prep" / label
            cpu, result = read(folder / "manifest.json"), read(folder / "summary.json")
            assert digest((folder / "manifest.json").read_bytes()) == result["manifest_sha256"]
            log = (folder / "worker.log").read_bytes()
            assert digest(log) == result["log_sha256"] and result["exit_code"] == 0
            assert b"Ran 8 tests" in log and log.rstrip().endswith(b"OK")
            zip_verified = None
            if label == "cpu_002":
                assert digest((folder / "sources.zip").read_bytes()) == cpu["sources_zip_sha256"]
                with ZipFile(folder / "sources.zip") as frozen:
                    for item in cpu["hashes"]:
                        assert digest(frozen.read(Path(item["path"]).name)) == item["sha256"]
                    for name in snapshots:
                        assert frozen.read(name) == archive.read(PREFIX + name)
                    zip_verified = len(cpu["hashes"])
            records.append({"label": label, "recorded_tests": 8, "exit_code": result["exit_code"],
                            "manifest_sha256": result["manifest_sha256"], "log_sha256": result["log_sha256"],
                            "frozen_zip_sources_verified": zip_verified})
    # No native imports or Blender execution: locate actual I source assignment by AST.
    control_path = ROOT / "human_eye_fast/control.py"
    control = ast.parse(control_path.read_bytes())
    cls = next(n for n in control.body if isinstance(n, ast.ClassDef) and n.name == "BlenderControl")
    function = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == "execute")
    setters = [n for n in ast.walk(function) if isinstance(n, ast.Assign)
               and any(isinstance(t, ast.Attribute) and t.attr == "matrix_world"
                       and isinstance(t.value, ast.Name) and t.value.id == "moving" for t in n.targets)]
    assert len(setters) == 1 and setters[0].lineno == setters[0].end_lineno
    # Re-run only the delivered eight small tests, with the recorded numeric settings.
    sys.path.insert(0, str(ROOT))
    for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "BLIS_NUM_THREADS",
                "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"):
        os.environ[key] = "1"
    suite = unittest.defaultTestLoader.loadTestsFromName("artifacts.llm_entry.host_pilot_001.native_prep.test_native_prep")
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    assert result.wasSuccessful() and result.testsRun == 8
    assert "bpy" not in sys.modules, "RNA double was not removed after tests"
    # This records work count of the existing pruning fixture; no wall-time comparison.
    from unittest.mock import patch
    import numpy as np
    from artifacts.llm_entry.host_pilot_001.native_prep import native_geometry as geometry
    count = 128
    offsets = np.column_stack((2. * np.arange(count), np.zeros((count, 2))))
    triangle = np.array(((0., 0., 0.), (.25, 0., 0.), (0., .25, 0.)))
    a = (triangle[None] + offsets[:, None]).reshape(-1, 3)
    b = a + np.repeat(np.column_stack((np.zeros((count, 2)), np.linspace(.5, .02, count))), 3, axis=0)
    faces = np.arange(3 * count).reshape(-1, 3)
    with patch.object(geometry, "_closest_batch", wraps=geometry._closest_batch) as narrow:
        pair = geometry.surface_pair(geometry.TriangleIndex(a, faces), geometry.TriangleIndex(b, faces))
    work = sum(len(call.args[0]) for call in narrow.call_args_list)
    assert work < count * count // 16
    report = {"scope": "offline source/record audit plus the delivered CPU doubles and one existing pruning-count fixture",
              "native_processes_launched": 0, "network_or_model_calls": 0,
              "delivery_sources_verified": len(manifest["sources"]), "reviewed_sources": snapshots,
              "runtime_imports": imports, "prior_cpu_records": records,
              "independent_cpu_rerun": {"tests": result.testsRun, "passed": True, "raw_log": stream.getvalue()},
              "I_source_setter": {"path": str(control_path), "sha256": digest(control_path.read_bytes()), "line": setters[0].lineno,
                                  "qualification": "AST locatable; not native execution or trace proof"},
              "pruning_count": {"triangles_per_surface": count, "cartesian_pairs": count * count,
                                "narrow_pairs": work, "batch_count": narrow.call_count, "distance": pair.distance_m,
                                "qualification": "synthetic work count; not hardware or formal-task speed"},
              "preparation_result": "acceptable executable candidate; native/visual/host/benefit qualification remains pending"}
    OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(OUT), "cpu_tests": result.testsRun, "pruning_narrow_pairs": work, "native_runs": 0}))


if __name__ == "__main__":
    main()
