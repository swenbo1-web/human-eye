"""Read-only identity check of offline preparation; never starts the pilot."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
AUTHOR = ROOT / "artifacts/llm_entry/host_pilot_001"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_zip(path, entries):
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        for name, digest in entries.items():
            assert hashlib.sha256(archive.read(name)).hexdigest() == digest, name


def main():
    delivery_path = AUTHOR / "delivery_001/manifest.json"
    assert sha(delivery_path) == "d8e2ef4d743397d881f1d0a5f4976faa052194307f8d994d1491355b6f3f6fd0"
    delivery = json.loads(delivery_path.read_bytes())
    for group in ("sources", "evidence"):
        for name, digest in delivery[group].items():
            assert sha(ROOT / name) == digest, name
    delivery_zip = AUTHOR / "delivery_001/sources.zip"
    assert sha(delivery_zip) == delivery["sources_zip_sha256"]
    check_zip(delivery_zip, delivery["sources"])
    plan_path = AUTHOR / "run_001/manifest.json"
    plan = json.loads(plan_path.read_bytes())
    assert sha(plan_path) == delivery["offline_plan"]["sha256"]
    for name, digest in plan["sources"].items():
        assert sha(ROOT / name) == digest, name
    check_zip(AUTHOR / "run_001/sources.zip", plan["sources"])
    assert not (AUTHOR / "run_001/launch.json").exists()
    jobs = {}
    for case, job in plan["jobs"].items():
        argv = job["argv"]
        assert "--approve-for-me" not in argv
        assert "--dangerously-bypass-approvals-and-sandbox" not in argv
        assert argv[argv.index("--sandbox") + 1] == "read-only"
        assert argv[-1] == (AUTHOR / f"run_001/{case}-public-prompt.txt").read_text(encoding="utf-8")
        consumer = Path(job["consumer"])
        assert consumer.is_dir() and not list(consumer.iterdir())
        assert not any((p / ".git").exists() for p in (consumer, *consumer.parents))
        jobs[case] = {"read_only": True, "consumer_empty_outside_git": True,
                      "public_prompt_sha256": hashlib.sha256(argv[-1].encode()).hexdigest()}
    accepted = json.loads((ROOT / "docs/radical_acceptance_engine_v1.json").read_bytes())
    for name, item in accepted["production_sources"].items():
        assert sha(ROOT / name) == item["sha256"], name
    denied = json.loads((AUTHOR / "launch_denied_001/review.json").read_bytes())
    assert denied["status"] == "rejected_before_process_creation"
    assert denied["runner_sha256"] == sha(AUTHOR / "launch_denied_001/run_pilot.py")
    result = {
        "delivery_manifest_sha256": sha(delivery_path),
        "delivery_sources": len(delivery["sources"]), "evidence_references": len(delivery["evidence"]),
        "pilot_manifest_sha256": sha(plan_path), "pilot_sources": len(plan["sources"]),
        "frozen_engine_sources_unchanged": len(accepted["production_sources"]),
        "current_sources_and_zip_members_verified": True, "jobs": jobs,
        "launch_marker_exists": False, "original_rejection_preserved": True,
        "rejected_launch_counts": {k: denied[k] for k in ("blender_launches", "codex_model_contexts", "outbound_pilot_payloads")},
        "root_started_blender_or_model": False,
        "host_or_benefit_acceptance": False,
        "note": "Read-only shell plus task prompt is not an absolute filesystem-read prohibition; inspect actual model tool activity if authorized.",
    }
    (HERE / "identity_review.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
