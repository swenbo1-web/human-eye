"""Archive the offline preparation and preserved launch rejection once."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
AUTHOR = ROOT / "artifacts/llm_entry/host_pilot_001"
ARCHIVE = ROOT / "docs/llm_host_preparation_evidence.zip"
DECISION = ROOT / "docs/radical_acceptance_llm_host_preparation.json"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert not ARCHIVE.exists() and not DECISION.exists()
    assert not (AUTHOR / "run_001/launch.json").exists()
    assert sha(ROOT / "docs/RADICAL_V1_SPEC_REVIEW.md") == "30b921d6a8f24863b6a1be7aaf9e5ad1e580988db2fc55ea161f0300a8cd50ec"
    for name in ("native_preparation_review.md", "visual_preparation_review.md"):
        assert (HERE / name).is_file()
    paths = sorted(p for p in AUTHOR.rglob("*") if p.is_file())
    assert len(paths) == 43
    paths += sorted(p for p in HERE.iterdir() if p.is_file())
    paths.append(ROOT / "docs/LLM_HOST_PREPARATION_REVIEW.md")
    manifest = {p.relative_to(ROOT).as_posix(): {"sha256": sha(p), "bytes": p.stat().st_size}
                for p in sorted(paths)}
    assert len(manifest) == len(paths)
    with zipfile.ZipFile(ARCHIVE, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in manifest:
            archive.write(ROOT / name, name)
        archive.writestr("MANIFEST.json", json.dumps(manifest, ensure_ascii=False, indent=2))
    with zipfile.ZipFile(ARCHIVE) as archive:
        assert archive.testzip() is None
        for name, item in manifest.items():
            payload = archive.read(name)
            assert len(payload) == item["bytes"]
            assert hashlib.sha256(payload).hexdigest() == item["sha256"]
    identity = json.loads((HERE / "identity_review.json").read_bytes())
    decision = {
        "decision": "ACCEPT_OFFLINE_PREPARATION_HOST_BLOCKED", "review_number": 26, "date": "2026-11-06",
        "accepted_entry_commit": "165adf80619bf412a00d1910719665d9d20a8093",
        "source_identity": identity,
        "native_preparation": {"accepted": True, "final_cpu_tests_root_rerun_passed": 8,
                               "earlier_different_source_batch_preserved": True,
                               "reasonable_generic_algorithm": True, "further_optimization_required": False,
                               "real_blender_setter_rna_and_I_N_audit_qualified": False},
        "visual_preparation": {"accepted": True, "author_synthetic_checks_passed": 10,
                               "independent_cpu_paths_checked": True, "actual_bundles": 0,
                               "actual_I_N_capture_connected": False, "four_V_qualified": False,
                               "further_optimization_required": False},
        "pilot": {"blender_launches": 0, "model_contexts": 0, "outbound_payloads": 0,
                  "original_auto_review_rejection_retained": True,
                  "rejection_reason": "specific external payload consent absent; original command contained auto-approval option",
                  "revised_shell_sandbox": "read-only", "auto_approve_flag_removed": True,
                  "explicit_outbound_consent": "pending", "normal_approval_review_still_required": True,
                  "launch_command": "D:/human eye/venv/Scripts/python.exe -B artifacts/llm_entry/host_pilot_001/run_pilot.py launch",
                  "frozen_plan_sha256": "22445e963fb685d73611b5670a2504d132ec00ec6cb8fdc9ed5f201158ad879b",
                  "previous_plan_and_two_prepare_failures_retained": True},
        "host_accepted": False, "task_benefit_accepted": False, "advance_E2": False,
        "root_reports_sha256": {name: sha(HERE / name) for name in
                                ("native_preparation_review.md", "visual_preparation_review.md")},
        "review": "docs/LLM_HOST_PREPARATION_REVIEW.md",
        "evidence_archive": {"path": ARCHIVE.relative_to(ROOT).as_posix(), "sha256": sha(ARCHIVE),
                             "bytes": ARCHIVE.stat().st_size, "file_count_excluding_manifest": len(manifest),
                             "all_members_readback_verified": True},
    }
    DECISION.write_text(json.dumps(decision, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(decision["evidence_archive"]))


if __name__ == "__main__":
    main()
