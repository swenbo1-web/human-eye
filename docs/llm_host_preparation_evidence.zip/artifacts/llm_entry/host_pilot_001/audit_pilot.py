"""Audit the captured MCP exchange independently of the model and scene worker."""

import base64
from hashlib import sha256
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT))

from verification.test_raycast_saccade_gpu import decode_png


def _load(path):
    return json.loads(path.read_bytes()) if path.is_file() else None


def _messages(path):
    if not path.is_file():
        return [], {"present": False, "bytes": 0, "invalid_frames": 0}
    raw = path.read_bytes()
    frames, invalid = [], 0
    for line in raw.splitlines():
        try:
            message = json.loads(line)
        except (UnicodeError, ValueError):
            invalid += 1
            continue
        if isinstance(message, dict):
            frames.append(message)
        else:
            invalid += 1
    return frames, {"present": True, "bytes": len(raw), "sha256": sha256(raw).hexdigest(),
                    "json_frames": len(frames), "invalid_frames": invalid, "ended_in_lf": raw.endswith(b"\n")}


def audit_case(folder, expected):
    requests, upstream = _messages(folder / "wire/requests.bin")
    replies, downstream = _messages(folder / "wire/responses.bin")
    native = _load(folder / "native.json") or {}
    cli = _load(folder / "cli-result.json") or {}
    by_id = {reply["id"]: reply for reply in replies if "id" in reply}
    initialize, discovery, calls = [], [], []
    pngs, text_bytes, errors = [], 0, []
    for request in requests:
        params = request.get("params", {})
        reply = by_id.get(request.get("id"), {})
        result = reply.get("result") or {}
        if "error" in reply:
            errors.append({"method": request.get("method"), "error": reply["error"]})
        method = request.get("method")
        if method == "initialize":
            initialize.append({"offered": params.get("protocolVersion"), "negotiated": result.get("protocolVersion"),
                               "client_info": params.get("clientInfo"), "server_info": result.get("serverInfo")})
        elif method == "tools/list":
            discovery.append([tool.get("name") for tool in result.get("tools", [])])
        elif method == "tools/call":
            blocks = result.get("content", [])
            call = {"name": params.get("name"), "arguments": params.get("arguments"), "error": result.get("isError"),
                    "content_types": [block.get("type") for block in blocks], "text": None}
            calls.append(call)
            for block in blocks:
                if block.get("type") == "text":
                    content = block["text"]
                    text_bytes += len(content.encode("utf-8"))
                    try:
                        call["text"] = json.loads(content)
                    except ValueError:
                        call["text"] = content
                elif block.get("type") == "image" and block.get("mimeType") == "image/png":
                    try:
                        data = base64.b64decode(block["data"], validate=True)
                        pixels = decode_png(data)
                        checksum = sha256(data).hexdigest()
                        camera = next((record for record in native.get("images", []) if record["png_sha256"] == checksum), None)
                        path = folder / f"wire-image-{len(pngs) + 1:02d}.png"
                        with path.open("xb") as output:
                            output.write(data)
                        pngs.append({"bytes": len(data), "sha256": checksum, "shape": list(pixels.shape),
                                     "file": path.name, "worker_camera": camera})
                    except (ValueError, OSError, KeyError) as exc:
                        errors.append({"method": "decode_wire_png", "error": str(exc)})
    run = [call for call in calls if call["name"] == "eye_run"]
    exact_task = len(run) == 1 and run[0]["arguments"] == expected
    return {"case": folder.name, "wire": {"client_to_server": upstream, "server_to_client": downstream},
            "initialize": initialize, "initialized_notifications": sum(
                message.get("method") == "notifications/initialized" and "id" not in message for message in requests),
            "tools_discovery": discovery, "calls": calls, "rpc_or_image_errors": errors, "tool_text_utf8_bytes": text_bytes,
            "pngs": pngs, "exact_registered_eye_run": exact_task,
            "native_status": native.get("status"), "native_executions": native.get("executions"),
            "native_confirmed_writes": native.get("confirmed_writes"),
            "independent_rna_present": all((folder / path).is_file() for path in ("before-rna.json", "after-rna.json")),
            "cli_exit_code": cli.get("exit_code"), "turn_completed_s": cli.get("turn_completed_s"),
            "observed_usage": cli.get("observed_usage", []), "other_public_item_types": cli.get("other_item_types", []),
            "visible_text_tokens": "unreported", "image_tokens": "unreported",
            "model_answer_check": "manual; assess using final.txt and actual wire image only"}


def main():
    out = HERE / "run_001"
    manifest = _load(out / "manifest.json")
    result = {case: audit_case(out / case, job["arguments"])
              for case, job in manifest["jobs"].items() if (out / case).is_dir()}
    with (out / "wire-audit.json").open("x", encoding="utf-8") as log:
        json.dump(result, log, ensure_ascii=False, indent=2, allow_nan=False)
        log.write("\n")
    print(out / "wire-audit.json")


if __name__ == "__main__":
    main()
