"""Serve two frozen pilot scenes in one owned factory GUI Blender process."""

from argparse import ArgumentParser
from base64 import b64decode
from copy import deepcopy
from hashlib import sha256
import json
from math import isfinite
import os
from pathlib import Path
import sys
from threading import get_ident, main_thread
from time import monotonic
import traceback
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[3]
CASES = (("nonconvex", None), ("occluded", "SECTION"))
INTERVAL = 0.005
EOF_GRACE_S = 5.0


def _publish(path, value):
    staging = path.with_name(path.name + ".tmp")
    if path.exists():
        raise FileExistsError(path)
    with staging.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write("\n")
    staging.replace(path)


class _ObservedSocket:
    """Forward the actual socket and distinguish FIN from forced stop or reset."""

    def __init__(self, connection, transport):
        self.connection = connection
        self.transport = transport

    def __getattr__(self, name):
        return getattr(self.connection, name)

    def recv(self, size):
        try:
            data = self.connection.recv(size)
        except BlockingIOError:
            raise
        except OSError as error:
            self.transport["receive_error"] = str(error)
            raise
        if not data:
            self.transport["peer_eof"] += 1
        return data


def _start_observed(factory, transport):
    from human_eye_fast.blender_llm_bridge import start

    bridge = start(factory)
    accept = bridge._accept

    def observed_accept():
        accept()
        if bridge._connection is not None:
            bridge._connection = _ObservedSocket(bridge._connection, transport)

    bridge._accept = observed_accept
    return bridge


def _archive_images(folder, cached_images, vg_events):
    if not cached_images:
        return []
    destination = folder / "images"
    destination.mkdir()
    images = []
    for index, (identity, compact, block, camera) in enumerate(cached_images, 1):
        png = b64decode(block["data"], validate=True)
        digest = sha256(png).hexdigest()
        filename = f"{index:03d}.png"
        with (destination / filename).open("xb") as output:
            output.write(png)
        matching = [event for event in vg_events if event.get("png_sha256") == digest
                    and event["metadata"]["frame_id"] == identity["frame_id"]
                    and event["metadata"]["mode"] == compact["mode"]]
        source = matching[0]["metadata"] if len(matching) == 1 else None
        same_render = source is not None and (
            source["views"] == camera["views"]
            and source["meters_per_blender_unit"] == camera["meters_per_blender_unit"]
            and source["section"] == compact["section"]
            and source["mesh_ids"] == compact["scene_object_ids"]
        )
        images.append({**identity, **compact, **camera, "png_sha256": digest, "png_bytes": len(png),
                       "path": f"images/{filename}", "provenance": {
                           "source": "local LLMEntry image cache captured before the original reply was sent",
                           "matched_actual_vg_observation": same_render,
                           "extra_mcp_calls": 0,
                           "extra_renders": 0,
                       }})
    return images


def _serve(folder, report, binding, run_replies, cached_images, timeout):
    import bpy
    from human_eye_fast.llm_entry import LLMEntry

    owner = main_thread().ident
    transport = report["transport"]

    class PilotEntry(LLMEntry):
        def __init__(self):
            assert get_ident() == owner
            transport["connections"] += 1
            if transport["connections"] != 1:
                raise RuntimeError("The pilot case is bound to one host connection")
            super().__init__(binding)

        def handle_line(self, line):
            assert get_ident() == owner
            transport["dispatch_thread_id"] = get_ident()
            transport["frames"] += 1
            previous_run, previous_image = self._receipt, self._image
            response = super().handle_line(line)
            if self._receipt is not None and self._receipt is not previous_run:
                run_replies.append(response)
            if self._image is not None and self._image is not previous_image:
                _, compact, block, camera = self._image
                if block is not None and camera is not None:
                    identity = {"task_id": self._task_id, "frame_id": self._readback.frame_id,
                                "observation_id": self._readback.observation_id}
                    cached_images.append((identity, deepcopy(compact), block, deepcopy(camera)))
            return response

        def close(self):
            assert get_ident() == owner
            event = {"thread_id": get_ident(), "during_stop": transport["stop_requested"], "completed": False}
            transport["closes"].append(event)
            super().close()
            event["completed"] = True

    bridge = _start_observed(PilotEntry, transport)
    callback, listener = bridge._timer_callback, bridge._listener
    try:
        transport["timer_registered"] = bpy.app.timers.is_registered(callback)
        assert transport["timer_registered"]
        host, port = bridge.address
        transport["address"] = bridge.address
        _publish(folder / "ready.json", {"case": report["case"], "pid": os.getpid(), "host": host, "port": port})
        deadline = monotonic() + timeout
        close_deadline = None
        done_path = folder / "client_done.json"
        while True:
            now = monotonic()
            if close_deadline is None and done_path.is_file():
                report["client_done"] = json.loads(done_path.read_bytes())
                assert isinstance(report["client_done"], dict), "Expected a client completion record"
                close_deadline = min(deadline, now + EOF_GRACE_S)
            if close_deadline is not None:
                if not transport["connections"] or transport["closes"]:
                    break
                if now >= close_deadline:
                    raise TimeoutError("Client exited but the relay connection did not close")
            if now >= deadline:
                raise TimeoutError("The host case did not signal completion before the worker deadline")
            yield INTERVAL
    finally:
        transport["stop_requested"] = True
        try:
            bridge.stop()
        finally:
            transport["listener_closed"] = listener.fileno() == -1
            transport["timer_unregistered"] = not bpy.app.timers.is_registered(callback)


def _record_replies(report, run_replies):
    from artifacts.llm_entry.preflight_001.revision_003.task_native_worker import _tool_fields

    replies = [json.loads(raw)["result"] for raw in run_replies]
    report["run_receipts"] = [{"fields": _tool_fields(result), "is_error": result["isError"],
                               "content_types": [block["type"] for block in result["content"]]}
                              for result in replies]
    if report["run_receipts"]:
        report["run"] = report["run_receipts"][0]["fields"]
    return replies


def _check_case(spec, image_mode, report, before, after, replies):
    from verification.llm_entry_fixtures import MOVING, REFERENCE, validate, validate_image

    assert len(replies) == 1, "Expected exactly one host eye_run receipt"
    fields = report["run"]
    assert not replies[0]["isError"], fields
    assert (fields["unit"], fields["moving_id"], fields["reference_id"]) == ("m", MOVING, REFERENCE), fields
    report["checks"] = validate(spec, fields, before, after)
    assert len(report["executions"]) == report["confirmed_writes"] == 1, report["executions"]
    assert report["executions"][0]["target_matches_fixture"], report["executions"]

    transport = report["transport"]
    assert transport["connections"] == transport["peer_eof"] == len(transport["closes"]) == 1, transport
    assert transport["dispatch_thread_id"] == transport["main_thread_id"], transport
    assert transport["closes"][0] == {"thread_id": transport["main_thread_id"], "during_stop": False,
                                      "completed": True}, transport
    assert transport["listener_closed"] and transport["timer_unregistered"], transport

    events, images = report["vg_events"], report["images"]
    content_types = report["run_receipts"][0]["content_types"]
    if image_mode is None:
        assert content_types == ["text"] and "image" not in fields and not events and not images
    else:
        assert content_types == ["text", "image"] and len(images) == 1, fields
        assert [event["operation"] for event in events] == ["init", "render", "close"], events
        assert all(event["completed"] for event in events) and len({event["renderer_id"] for event in events}) == 1
        image = validate_image(spec, replies[0], fields, after, mode=image_mode)
        assert images[0]["png_sha256"] == image["png_sha256"]
        assert images[0]["image_id"] == fields["image"]["image_id"]
        assert images[0]["provenance"]["matched_actual_vg_observation"]
        report["checks"]["image"] = image


def _case(folder, report, name, image_mode, timeout):
    from artifacts.llm_entry.preflight_001.revision_003.task_native_worker import _renderer_probe
    from examples.blender_llm_entry import binding_for
    from human_eye_fast.control import ActionStageError, BlenderControl
    from verification.llm_entry_fixtures import EPISODES, MOVING, REFERENCE, case

    spec = EPISODES[name]
    original_execute = BlenderControl.execute
    run_replies, cached_images = [], []
    with case(spec) as fixture:
        before = fixture.snapshot()
        _publish(folder / "before-rna.json", before)

        def counted_execute(control, action, *args, **kwargs):
            moving = control._objects[0]
            event = {"object_name": moving.name, "moving_id": control._goal.moving_id,
                     "target_matches_fixture": moving == fixture.objects[MOVING],
                     "command": type(action.command).__name__, "write_status": "unknown"}
            report["executions"].append(event)
            try:
                outcome = original_execute(control, action, *args, **kwargs)
            except ActionStageError as error:
                event.update(write_status=error.write_status, stage=error.stage)
                raise
            event["write_status"] = "written" if outcome is not None else "not_written"
            return outcome

        failure = None
        try:
            binding = binding_for(fixture.scene, fixture.view_layer, fixture.objects, MOVING, REFERENCE,
                                  image_mode=image_mode, context_objects=fixture.context)
            with patch.object(BlenderControl, "execute", counted_execute), _renderer_probe(report["vg_events"]):
                yield from _serve(folder, report, binding, run_replies, cached_images, timeout)
        except Exception as error:
            failure = error
            raise
        finally:
            report["confirmed_writes"] = sum(event["write_status"] == "written" for event in report["executions"])
            try:
                try:
                    after = fixture.snapshot()
                    _publish(folder / "after-rna.json", after)
                finally:
                    try:
                        report["images"] = _archive_images(folder, cached_images, report["vg_events"])
                    finally:
                        replies = _record_replies(report, run_replies)
            except Exception as evidence_error:
                if failure is None:
                    raise
                failure.add_note(f"Recording native evidence also failed: {evidence_error!r}")
        _check_case(spec, image_mode, report, before, after, replies)


def _cases(opts, summary):
    from artifacts.llm_entry.preflight_001.revision_003.task_native_worker import _owned_windows, _require_hidden

    for name, mode in CASES:
        folder = opts.out / name
        folder.mkdir(exist_ok=True)
        report = {"case": name, "pid": os.getpid(), "status": "failed", "windows_before": None,
                  "windows_after": None, "client_done": None, "executions": [], "confirmed_writes": 0,
                  "vg_events": [], "images": [], "run": None, "checks": None, "error": None,
                  "transport": {"main_thread_id": main_thread().ident, "dispatch_thread_id": None,
                                "connections": 0, "frames": 0, "peer_eof": 0, "closes": [],
                                "stop_requested": False}}
        summary["cases"].append(report)
        try:
            report["windows_before"] = _owned_windows(hide=False)
            _require_hidden(report["windows_before"])
            yield from _case(folder, report, name, mode, opts.case_timeout)
            report["status"] = "passed"
        except Exception:
            report["error"] = traceback.format_exc()
        finally:
            try:
                report["windows_after"] = _owned_windows(hide=False)
                _require_hidden(report["windows_after"])
            except Exception:
                report["status"] = "failed"
                report["window_error"] = traceback.format_exc()
            _publish(folder / "native.json", report)
        yield INTERVAL


def main(opts):
    import bpy
    from artifacts.llm_entry.preflight_001.revision_003.task_native_worker import _owned_windows, _require_hidden

    assert get_ident() == main_thread().ident and not bpy.app.background
    windows = _owned_windows(hide=True)
    opts.out = opts.out.resolve()
    opts.out.mkdir(parents=True, exist_ok=True)
    summary = {"pid": os.getpid(), "blender_version": bpy.app.version_string, "blender_binary": bpy.app.binary_path,
               "scope": "native observation of the pilot; external CLI and model checks are separate",
               "windows_at_script_initialization": windows, "cases": []}
    jobs = _cases(opts, summary)

    def finish():
        try:
            summary["windows_at_end"] = _owned_windows(hide=False)
            _require_hidden(summary["windows_at_end"])
        except Exception:
            summary["window_error"] = traceback.format_exc()
        passed = (len(summary["cases"]) == len(CASES)
                  and all(case["status"] == "passed" for case in summary["cases"])
                  and "error" not in summary and "window_error" not in summary)
        summary["status"] = "passed" if passed else "failed"
        try:
            _publish(opts.out / "summary.json", summary)
        finally:
            bpy.ops.wm.quit_blender()

    def tick():
        try:
            window = next(iter(bpy.context.window_manager.windows), None)
            assert window is not None, "The factory GUI has no Blender window"
            with bpy.context.temp_override(window=window):
                return next(jobs)
        except StopIteration:
            pass
        except Exception:
            summary["error"] = traceback.format_exc()
            jobs.close()
        finish()
        return None

    startup_deadline = monotonic() + 5

    def start_cases():
        try:
            observed = _owned_windows(hide=True)
            if not observed and monotonic() < startup_deadline:
                return INTERVAL
            summary["windows_before_cases"] = observed
            _require_hidden(observed)
            bpy.app.timers.register(tick, first_interval=0.0)
        except Exception:
            summary["error"] = traceback.format_exc()
            finish()
        return None

    bpy.app.timers.register(start_cases, first_interval=0.0)


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--case-timeout", type=float, default=210.0)
    arguments = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else sys.argv[1:]
    options = parser.parse_args(arguments)
    if not isfinite(options.case_timeout) or options.case_timeout <= 0:
        parser.error("--case-timeout must be positive and finite")
    sys.path.insert(0, str(ROOT))
    main(options)
