"""Register and run one owned Blender worker and at most two actual Codex contexts."""

from dataclasses import asdict
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import mkdtemp
from threading import Thread
from time import monotonic, sleep
from zipfile import ZIP_DEFLATED, ZipFile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
REVISION = "165adf80619bf412a00d1910719665d9d20a8093"
PYTHON = Path(r"D:\human eye\venv\Scripts\python.exe")
BLENDER = Path(r"C:\Program Files\Blender Foundation\Blender 5.2\blender.exe")
CODEX = Path(r"C:\Users\v_wbobosun\AppData\Local\OpenAI\Codex\bin\14b838c1d074ff01\codex.exe")
CODEX_SHA = "40ecc3d8b6899afd8f935a8cccb7d53ba41ffd7c199f679e186d30ddd0d0bf39"
USER_SPEC_SHA = "30b921d6a8f24863b6a1be7aaf9e5ad1e580988db2fc55ea161f0300a8cd50ec"
MODEL = "gpt-6.1-sol"
SERVER = "human_eye_v1"
STARTUP_S, CONTEXT_S, WORKER_CASE_S = 35, 180, 210
PILOT_CASES = ("nonconvex", "occluded")
THREAD_ENV = dict.fromkeys(("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "BLIS_NUM_THREADS",
                            "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS", "PYTHONDONTWRITEBYTECODE"), "1")
NO_WINDOW = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0

sys.path.insert(0, str(ROOT))

from artifacts.integration.method_diagnostic_001.runtime_identity import identity
from verification.llm_entry_fixtures import EPISODES, request_arguments


def _dump(path, value):
    data = (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")
    temporary = path.with_suffix(".tmp")
    with temporary.open("xb") as out:
        out.write(data)
    temporary.replace(path)


def _load(path):
    return json.loads(path.read_bytes())


def _git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()


def _sources():
    engine = tuple(name for name in _git("ls-tree", "-r", "--name-only", REVISION, "human_eye_fast").splitlines()
                   if name.endswith(".py"))
    tracked = (*engine, "human_eye_llm_stdio.py", "examples/blender_llm_entry.py",
               "docs/LLM_HOST_PILOT_PROTOCOL.md", "docs/LLM_ENTRY_FUNCTIONAL_REVIEW.md",
               "verification/llm_entry_fixtures.py", "verification/test_bc_acceptance.py",
               "verification/test_raycast_saccade_gpu.py")
    subprocess.run(["git", "diff", "--exit-code", REVISION, "--", *tracked], cwd=ROOT, check=True)
    extra = (HERE / "run_pilot.py", HERE / "pilot_worker.py", HERE / "tap_stdio.py", HERE / "audit_pilot.py",
             HERE.parent / "preflight_001/revision_003/task_native_worker.py",
             ROOT / "artifacts/integration/method_diagnostic_001/runtime_identity.py")
    paths = sorted([*(ROOT / name for name in tracked), *extra])
    return {path.relative_to(ROOT).as_posix(): path.read_bytes() for path in paths}


def _prompt(case):
    task = request_arguments(EPISODES[case])
    target = f"{task['target_gap_m']:.6f}"
    tolerance = f"{task['tolerance_m']:.9f}"
    instruction = (
        "你正在操作一个隔离的 Blender 场景。仅使用 human_eye_v1 的工具，不读文件、不运行命令、"
        "不用其他工具。将已绑定的移动对象 moving 朝固定参考对象 reference 平移，"
        f"把两个表面的全局最小间距缩至 {target} 米，容差 {tolerance} 米。"
        "用一次 eye_run 调用 close_gap。"
        "根据实际回包简洁报告是否达标、实测终态间距和实际世界米制位移向量。"
        "如果工具失败或缺少实测，请据实说明，不重复执行。"
    )
    if case == "nonconvex":
        return instruction + "这次只要数值结果，不请求图像。"
    return instruction + (
        "这次需要终态图，在同一次 eye_run 里指定 image_mode 为 SECTION。"
        "根据你实际收到的图，说清左、右面板分别显示什么，并指出图中至少一个物体的可见颜色"
        "及相对位置或遮挡关系。只描述确实能看见的细节；没收到图或看不清就直接说明。"
    )


def _codex_args(folder, consumer, prompt):
    prefix = f"mcp_servers.{SERVER}"
    config = {
        "model_reasoning_effort": "ultra",
        "web_search": "disabled",
        f"{prefix}.command": str(PYTHON),
        f"{prefix}.args": ["-B", str(HERE / "tap_stdio.py"), "--ready", str(folder / "ready.json"),
                           "--audit-dir", str(folder / "wire")],
        f"{prefix}.required": True,
        f"{prefix}.startup_timeout_sec": 20,
        f"{prefix}.tool_timeout_sec": 40,
        f"{prefix}.enabled_tools": ["eye_run", "eye_inspect"],
    }
    argv = [str(CODEX), "exec", "--ignore-user-config", "--ephemeral", "--json", "--approve-for-me",
            "--skip-git-repo-check", "--cd", str(consumer), "--model", MODEL,
            "--output-last-message", str(folder / "final.txt")]
    for key, value in config.items():
        argv.extend(("-c", f"{key}={json.dumps(value, ensure_ascii=False)}"))
    return [*argv, prompt]


def _wait_file(path, process, seconds):
    until = monotonic() + seconds
    while not path.is_file():
        if process.poll() is not None or monotonic() >= until:
            break
        sleep(.04)
    return _load(path) if path.is_file() else None


def _kill_owned_tree(process):
    if process is None or process.poll() is not None:
        return
    if os.name == "nt":
        taskkill = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32/taskkill.exe"
        try:
            subprocess.run([str(taskkill), "/PID", str(process.pid), "/T", "/F"], timeout=8,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=NO_WINDOW)
        except (OSError, subprocess.TimeoutExpired):
            pass
    if process.poll() is None:
        process.kill()
    process.wait(timeout=10)


def _public_events(stream, folder, started, receipt):
    """Keep documented public events, omitting reasoning item streams."""
    with (folder / "events.public.jsonl").open("xb") as log, (folder / "event-timing.jsonl").open("xb") as timing:
        for raw in stream:
            elapsed = monotonic() - started
            try:
                event = json.loads(raw)
            except (UnicodeError, ValueError):
                receipt["invalid_event_lines"] += 1
                continue
            if not isinstance(event, dict) or not isinstance(event.get("type"), str):
                receipt["invalid_event_lines"] += 1
                continue
            kind = event["type"]
            item = event.get("item")
            category = item.get("type", "") if isinstance(item, dict) else ""
            if "reasoning" in kind or category == "reasoning":
                receipt["omitted_reasoning_events"] += 1
                continue
            log.write(raw if raw.endswith(b"\n") else raw + b"\n")
            timing.write((json.dumps({"kind": kind, "item_type": category, "elapsed_s": elapsed}) + "\n").encode())
            if kind == "turn.completed":
                receipt["turn_completed_s"] = elapsed
            if isinstance(event.get("usage"), dict):
                receipt["observed_usage"].append(event["usage"])
            if category == "mcp_tool_call" and kind == "item.completed":
                receipt["mcp_events"].append({key: item.get(key) for key in ("server", "tool", "status")})
            if kind.startswith("item.") and category not in ("agent_message", "mcp_tool_call", ""):
                receipt["other_item_types"].append(category)


def _stderr(stream, folder):
    with (folder / "cli.stderr").open("xb") as log:
        for line in stream:
            log.write(line)


def _run_codex(folder, case, job):
    env = dict(os.environ)
    env.update(THREAD_ENV, RUST_LOG="warn")
    # The registered route uses the existing ChatGPT session, without key auth.
    for name in ("OPENAI_API_KEY", "CODEX_API_KEY"):
        env.pop(name, None)
    receipt = {"case": case, "model_requested": MODEL, "reasoning_requested": "ultra", "launch_pid": None,
               "exit_code": None, "timed_out": False, "launch_error": None, "observed_usage": [],
               "mcp_events": [], "other_item_types": [], "omitted_reasoning_events": 0,
               "invalid_event_lines": 0, "turn_completed_s": None,
               "visible_text_token_breakdown": "unreported", "image_token_breakdown": "unreported"}
    started = monotonic()
    child = None
    readers = []
    try:
        child = subprocess.Popen(job["argv"], cwd=job["consumer"], env=env, stdin=subprocess.DEVNULL,
                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=NO_WINDOW)
        receipt["launch_pid"] = child.pid
        readers = [Thread(target=_public_events, args=(child.stdout, folder, started, receipt), daemon=True),
                   Thread(target=_stderr, args=(child.stderr, folder), daemon=True)]
        for reader in readers:
            reader.start()
        child.wait(timeout=max(0, CONTEXT_S - (monotonic() - started)))
    except subprocess.TimeoutExpired:
        receipt["timed_out"] = True
        _kill_owned_tree(child)
    except OSError as exc:
        receipt["launch_error"] = str(exc)
    finally:
        if child is not None:
            receipt["exit_code"] = child.poll()
        receipt["elapsed_until_cli_exit_s"] = monotonic() - started
        for reader in readers:
            reader.join(timeout=6)
        receipt["collector_stopped"] = not any(reader.is_alive() for reader in readers)
        receipt["final_message_saved"] = (folder / "final.txt").is_file()
        _dump(folder / "cli-result.json", receipt)
        _dump(folder / "client_done.json", receipt)
    return receipt


def run():
    out = HERE / "run_001"
    if out.exists():
        raise FileExistsError("The registered pilot can only be launched once")
    if identity(CODEX)["sha256"] != CODEX_SHA or identity(ROOT / "docs/RADICAL_V1_SPEC_REVIEW.md")["sha256"] != USER_SPEC_SHA:
        raise RuntimeError("Installed CLI or protected user specification differs from registration")
    original = _sources()
    # Outside both workspace Git roots. Only the public prompt is sent to each consumer.
    consumers = Path(mkdtemp(prefix="human-eye-codex-pilot-"))
    out.mkdir()
    jobs = {}
    for case in PILOT_CASES:
        consumer = consumers / case
        consumer.mkdir()
        prompt = _prompt(case)
        (out / f"{case}-public-prompt.txt").write_bytes(prompt.encode("utf-8"))
        jobs[case] = {"consumer": str(consumer), "argv": _codex_args(out / case, consumer, prompt),
                      "scene": asdict(EPISODES[case]), "arguments": request_arguments(EPISODES[case])}
    blender_args = [str(BLENDER), "--factory-startup", "--disable-autoexec", "--threads", "1",
                    "--python-exit-code", "1", "--python", str(HERE / "pilot_worker.py"), "--",
                    "--out", str(out), "--case-timeout", str(WORKER_CASE_S)]
    with ZipFile(out / "sources.zip", "x", ZIP_DEFLATED) as archive:
        for name, contents in original.items():
            archive.writestr(name, contents)
    manifest = {
        "revision": REVISION, "head_at_registration": _git("rev-parse", "HEAD"),
        "sources": {name: sha256(raw).hexdigest() for name, raw in original.items()},
        "source_zip": identity(out / "sources.zip"), "executables": {
            "blender": identity(BLENDER), "codex": identity(CODEX), "tap_python": identity(PYTHON),
            "runner_python": identity(sys.executable)},
        "user_spec_sha256": USER_SPEC_SHA,
        "budget": {"owned_blender": 1, "new_codex_contexts": 2, "context_timeout_s": CONTEXT_S,
                   "startup_wait_s": STARTUP_S, "native_case_timeout_s": WORKER_CASE_S},
        "blender_argv": blender_args, "jobs": jobs, "environment_overrides": {**THREAD_ENV, "RUST_LOG": "warn"},
        "source_policy": ["Use existing ChatGPT auth and no API-key env in model process",
                          "Management rules and automatic approval remain enabled",
                          "No profile, project repo, input image attachment, or secret in prompts",
                          "Start timer just before spawning Codex with prompt, after worker readiness",
                          "Record first public turn completion and CLI exit separately",
                          "Transparent stdio byte tap and independent RNA scoring add instrumentation cost",
                          "No baseline, no formal 14-case task or provider-token inference"],
    }
    _dump(out / "manifest.json", manifest)
    print(f"Registered pilot: {identity(out / 'manifest.json')['sha256']}", flush=True)
    assert _sources() == original
    startup = subprocess.STARTUPINFO()
    startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow = subprocess.SW_HIDE
    worker = None
    state = {"cases": {}, "blender_pid": None, "blender_exit_code": None, "runner_error": None}
    try:
        start = monotonic()
        with (out / "blender.log").open("xb") as log:
            worker = subprocess.Popen(blender_args, cwd=ROOT, env={**os.environ, **THREAD_ENV}, stdin=subprocess.DEVNULL,
                                      stdout=log, stderr=subprocess.STDOUT, startupinfo=startup)
        state["blender_pid"] = worker.pid
        for case in PILOT_CASES:
            folder = out / case
            ready = _wait_file(folder / "ready.json", worker, STARTUP_S)
            if ready is None:
                state["cases"][case] = {"status": "worker_not_ready"}
                break
            assert ready["case"] == case and ready["pid"] == worker.pid and ready["host"] == "127.0.0.1"
            state["cases"][case] = {"startup_elapsed_s": monotonic() - start}
            assert _sources() == original and identity(CODEX) == manifest["executables"]["codex"]
            print(f"Starting actual Codex case: {case}", flush=True)
            receipt = _run_codex(folder, case, jobs[case])
            print(f"Completed Codex case {case}: {receipt['exit_code']}, {receipt['elapsed_until_cli_exit_s']:.2f}s",
                  flush=True)
            native = _wait_file(folder / "native.json", worker, STARTUP_S)
            state["cases"][case].update(cli=receipt, native_status=None if native is None else native["status"])
            if native is None:
                break
            start = monotonic()
        worker.wait(timeout=15)
    except (OSError, ValueError, subprocess.TimeoutExpired, AssertionError) as exc:
        state["runner_error"] = f"{type(exc).__name__}: {exc}"
    finally:
        _kill_owned_tree(worker)
        state["blender_exit_code"] = None if worker is None else worker.poll()
        state["sources_stable"] = _sources() == original
        state["worker_summary_present"] = (out / "summary.json").is_file()
        _dump(out / "process-summary.json", state)
    return 0 if (state["sources_stable"] and len(state["cases"]) == 2
                 and all(case.get("native_status") == "passed" and case["cli"]["exit_code"] == 0
                         for case in state["cases"].values()) and state["blender_exit_code"] == 0) else 1


if __name__ == "__main__":
    sys.exit(run())
