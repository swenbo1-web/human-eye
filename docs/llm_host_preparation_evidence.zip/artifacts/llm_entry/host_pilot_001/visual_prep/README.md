# Four-case visual evidence preparation

The registered cases are V01–V04 in `visual_cases.json`. Their actual labels are pending. The portable smoke exercises synthetic planar geometry and does not create formal labels, start Blender, open a host, or call a model.

## Capture the same render

In the later authorized I worker, import `capture_vg_render` and `save_bundle` from `visual_capture.py`. Enter the capture context around the accepted renderer class before the terminal image request. The wrapper copies `prepare` inputs as the actual float32 world-meter draw geometry, with ordered triangles and flat material RGB. It retains the PNG and metadata returned by that same `observe` call. It leaves the production renderer call and its audit setting intact.

```python
with capture_vg_render(VGRenderer) as capture:
    image_message = call_terminal_run_once()
    camera_message = call_current_camera_once()
    save_bundle(case_folder, case_id="V01", arm="I", provenance="actual_render",
                image_message=image_message, camera_message=camera_message,
                source=capture["source"])
```

Here `call_terminal_run_once` uses the frozen fixture and requested image mode. `call_current_camera_once` asks the same connection for `eye_inspect` with `evidence="camera"` and the returned task ID, before another image or task replaces the cache. Obtain the raw MCP results at the evaluator seam. A complete JSON-RPC response object or its `result` is accepted. Retain the original wire frames separately when the runner records transport. This collector never issues a tool call or initiates rendering on its own.

For arm N, the eventual authorized worker supplies `RenderSource(png, metadata, meshes)` from its actual draw and adapts its evidence to the same receipt keys. Freeze an equivalent flat RGB orthographic render and actual camera/section first. The candidate capture path uses the accepted renderer, while the ray and pixel scorer uses only archived numeric inputs. A native shading, panel layout, or camera convention outside this profile requires its own agreed calibration before comparison. Independent terminal evaluated RNA and native write audits remain separate evidence.

Each new bundle preserves the public PNG, actual draw arrays, actual witness, signed cut and camera matrices, the two MCP result objects, and a per-file SHA-256 manifest. Ingestion checks exact PNG byte equality with standard ImageContent, `task_id`, `observation_id`, `frame_id`, `image_id`, target IDs, ordered draw IDs, mode, units, planes, view matrices, layout and image format. Geometry and metadata come from the source render, not a later redraw. Repeated scoring validates all file hashes and the same cross-binding. `provenance="synthetic"` is reserved for non-real data and cannot satisfy case coverage.

## Score the public image

Run from this directory with the existing environment's Python, NumPy and Pillow.

```powershell
& 'D:/human eye/venv/Scripts/python.exe' -B visual_score.py --arm I
& 'D:/human eye/venv/Scripts/python.exe' -B visual_score.py --arm I <V01-dir> <V02-dir> <V03-dir> <V04-dir> --output score-I.json
```

For both panels, project each actual terminal witness to the original image pixel convention and take the nearest center plus four offsets of two pixels. Top-left PNG index `(x,y)` addresses the geometric center `(x+0.5,y+0.5)`. Inverse recorded GPU view-projection supplies the ray segment inside the actual orthographic clip range. A CPU all-triangle ray test obtains ordered hits independently of VG selection or its BVH. The scene panel uses uncut geometry. The witness panel in SECTION discards intersections on the actual signed positive side of the recorded plane. The configured numerical band leaves ambiguous plane/depth ties unknown.

A visible vote needs the actual first hit to be the target near the witness depth and its distinct frozen draw color to match the actual PNG pixel. An occluded vote needs a distinguishable matched foreground with retained target geometry behind it in the witness depth neighborhood. A cut-away vote needs the uncut first local target to be removed by the same signed plane, with the resulting foreground or background pixel matching. Missing local target, ambiguous depth/palette, color disagreements and points outside the panel or within the HUD stay unknown. The local depth band is eight orthographic pixels in world meters. A single label requires at least three of five votes, including unknown in the denominator. Otherwise the result is mixed. Every vote retains its supporting hit and pixel data.

Each case needs a determinate label in the witness panel. Each arm's four-case set must contain visible and occluded labels. Coverage can only become ready for independent review using actual bundles. That status does not certify equivalent views across arms or qualify model consumption. V01–V04 have no actual bundles or frozen visual labels in this preparation.

## Files proposed for promotion after review

| Current file | Proposed destination |
| --- | --- |
| `visual_capture.py` | `verification/llm_visual_capture.py` |
| `visual_score.py` | `verification/llm_visual_score.py` |
| `visual_cases.json` | `verification/fixtures/llm_visual_cases.json` |
| `smoke.py` | `verification/test_llm_visual_score.py` with repository test discovery conventions |

Promotion would update import and config paths. This preparation does not modify shared files.
