"""Only synthetic pixels and triangles. No Blender, GPU, host, or model."""

import base64
from copy import deepcopy
from io import BytesIO
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace

import numpy as np
from PIL import Image

from visual_capture import DrawMesh, RenderSource, capture_vg_render, read_json, save_bundle
from visual_score import CONFIG, coverage, majority, score_bundle


def tool_reply(fields, png=None):
    content = [{"type": "text", "text": json.dumps(fields)}]
    if png is not None:
        content.append({"type": "image", "mimeType": "image/png", "data": base64.b64encode(png).decode("ascii")})
    return {"jsonrpc": "2.0", "id": "synthetic", "result": {"isError": False, "content": content}}


def quad(name, bounds, z, rgb):
    l, t, r, b = bounds
    vertices = np.array(((l, b, z), (r, b, z), (r, t, z), (l, t, z)), dtype=np.float32)
    return DrawMesh(name, vertices, np.array(((0, 1, 2), (0, 2, 3)), dtype=np.int32),
                    np.array((rgb, rgb), dtype=np.uint8))


def fixture(config, case_id, *, mismatched_pixel=False, edge=False):
    section = None
    role_y = .95 if edge else .19
    moving_bounds = (-.54, role_y + .10, -.24, role_y - .10)
    reference_bounds = (.23, .29, .55, .08)
    meshes = [quad("moving", moving_bounds, -.2, (209, 61, 38)),
              quad("reference", reference_bounds, .25, (41, 153, 230))]
    mode = config["cases"][case_id]["mode"]
    if mode == "SECTION":
        section = {"point_m": [0., 0., .10], "normal": [0., 0., 1.], "kept_side": "<=0"}
        meshes.append(quad("panel", (.7, .76, .85, .63), -.50, (92, 102, 115)))
    else:
        meshes.extend((quad("first-wing", reference_bounds, .05, (92, 102, 115)),
                       quad("second-wing", (.7, .76, .85, .63), -.50, (92, 102, 115))))
    # Independent planar raster, from analytically known orthographic pixel centers.
    x = (np.arange(512)[None, :] + .5) / 256 - 1
    y = 1 - (np.arange(512)[:, None] + .5) / 256
    image = np.empty((512, 1024, 3), dtype=np.uint8)
    image[:] = config["rules"]["background_rgb"]
    for left in (0, 512):
        canvas = image[:, left:left + 512]
        for mesh in sorted(meshes, key=lambda item: -float(item.vertices_m[0, 2])):
            lo, hi = mesh.vertices_m.min(axis=0), mesh.vertices_m.max(axis=0)
            if section is not None and left == 512 and lo[2] > .10:
                continue
            mask = (lo[0] < x) & (x < hi[0]) & (lo[1] < y) & (y < hi[1])
            canvas[mask] = mesh.face_rgb[0]
    if mismatched_pixel:
        image[207, 668] = (243, 242, 8)
    output = BytesIO()
    Image.fromarray(image).save(output, format="PNG")
    png = output.getvalue()
    views = {role: {"viewport": [left, 0, 512, 512], "rna": {"type": "ORTHO"},
                    "gpu": {"view_projection": np.eye(4).tolist()}}
             for role, left in (("global", 0), ("local", 512))}
    compact = {"image_id": "synthetic-image-1", "status": "available", "mode": mode, "section": section,
               "panels": ["scene_context", "witness"], "scene_object_ids": [item.object_id for item in meshes]}
    common = {"task_id": "synthetic-task", "observation_id": "synthetic-observation", "frame_id": 17,
              "moving_id": "moving", "reference_id": "reference", "unit": "m"}
    source = RenderSource(png, {"frame_id": 17, "target_ids": ["moving", "reference"], "section": section,
                                "mode": mode, "mesh_ids": compact["scene_object_ids"], "views": views,
                                "meters_per_blender_unit": 1.,
                                "witness": {"point_a": [-.39, role_y, -.2], "point_b": [.39, .19, .25],
                                            "face_a": 0, "face_b": 0}}, tuple(meshes))
    image_reply = tool_reply({**common, "image": compact}, png)
    camera_reply = tool_reply({**common, **compact, "evidence": "camera", "views": views,
                               "meters_per_blender_unit": 1.})
    return source, image_reply, camera_reply


def expect_value_error(call, snippet):
    try:
        call()
    except ValueError as error:
        assert snippet in str(error), error
    else:
        raise AssertionError(f"Expected a rejection mentioning {snippet}")


def wrapper_smoke(source):
    class FakeRenderer:
        def prepare(self, meshes):
            return object()

        def observe(self, prepared, *, audit=False):
            assert audit is False
            return SimpleNamespace(png=source.png, metadata=source.metadata)

    mesh = SimpleNamespace(world_m=np.array(((0.1, 0., 0.), (0., 1., 0.), (0., 0., 1.))),
                           triangles=np.array(((0, 1, 2),), dtype=np.int32),
                           appearance=SimpleNamespace(object_color=(.82, .24, .15, 1.), material_slots=()))
    with capture_vg_render(FakeRenderer) as captured:
        renderer = FakeRenderer()
        observed = renderer.observe(renderer.prepare({"moving": mesh}))
        mesh.world_m[:] = 0
        assert captured["source"].png == observed.png
        assert captured["source"].meshes[0].vertices_m.dtype == np.float32
        assert captured["source"].meshes[0].vertices_m[1, 1] == 1.
        assert captured["source"].meshes[0].face_rgb[0].tolist() == [209, 61, 38]


def main():
    config = read_json(CONFIG)
    cases = {}
    with TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
        root = Path(directory)

        def save(label, case_id, **kwargs):
            source, image_reply, camera_reply = fixture(config, case_id, **kwargs)
            folder = root / label
            save_bundle(folder, case_id=case_id, arm="I", provenance="synthetic", image_message=image_reply,
                        camera_message=camera_reply, source=source)
            return score_bundle(folder, config)

        natural = save("natural", "V02")
        assert natural["panels"]["witness"]["moving"]["label"] == "visible"
        assert natural["panels"]["witness"]["reference"]["label"] == "occluded"
        cases["natural_visible_and_occluded"] = True

        section = save("section", "V01")
        assert section["panels"]["scene_context"]["reference"]["label"] == "visible"
        assert section["panels"]["witness"]["reference"]["label"] == "cut_away"
        cases["section_applies_to_witness_panel_only"] = True

        mismatched = save("pixel", "V02", mismatched_pixel=True)
        votes = mismatched["panels"]["witness"]["moving"]["votes"]
        assert votes == {"visible": 4, "unknown": 1}, votes
        cases["pixel_disagreement_keeps_unknown_in_denominator"] = True

        edge = save("edge", "V02", edge=True)
        assert edge["panels"]["witness"]["moving"]["votes"] == {"unknown": 5}
        cases["hud_pixels_do_not_vote_visible"] = True

        coverage_result = coverage([section, natural], config, "I")
        assert coverage_result["status"] == "pending_actual_evidence"
        assert coverage_result["missing_or_inconclusive"] == ["V01", "V02", "V03", "V04"]
        cases["synthetic_scores_do_not_qualify_any_case"] = True

        source, img, camera = fixture(config, "V02")
        camera_fields = json.loads(camera["result"]["content"][0]["text"])
        changed_camera = tool_reply({**camera_fields, "image_id": "another-image"})
        expect_value_error(lambda: save_bundle(root / "camera", case_id="V02", arm="I", provenance="synthetic",
                           image_message=img, camera_message=changed_camera, source=source), "different image")
        cases["mismatched_cached_camera_rejected"] = True

        changed_image = deepcopy(img)
        changed_image["result"]["content"][1]["data"] = base64.b64encode(b"not the rendered PNG").decode("ascii")
        expect_value_error(lambda: save_bundle(root / "bad-image", case_id="V02", arm="I", provenance="synthetic",
                           image_message=changed_image, camera_message=camera, source=source), "PNG bytes differ")
        cases["different_wire_png_rejected"] = True

        image_path = root / "natural" / "image.png"
        image_path.write_bytes(image_path.read_bytes() + b"invalid tampering")
        expect_value_error(lambda: score_bundle(root / "natural", config), "Evidence hash differs")
        cases["tampered_archive_rejected"] = True

        wrapper_smoke(source)
        cases["capture_retains_actual_detached_float32_geometry"] = True

    assert majority([{"label": label} for label in ("visible", "occluded", "unknown", "visible", "occluded")])[0] == "mixed"
    assert majority([{"label": label} for label in ("visible", "occluded", "unknown", "unknown", "unknown")])[0] == "unknown"
    cases["five_point_majority_and_mixed"] = True
    print(json.dumps({"scope": "synthetic_only", "checks": cases, "actual_v_coverage": coverage_result}, indent=2))


if __name__ == "__main__":
    main()
