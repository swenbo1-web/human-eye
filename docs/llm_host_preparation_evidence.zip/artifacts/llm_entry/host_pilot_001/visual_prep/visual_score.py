"""Independent CPU first-hit and public-PNG assessment for frozen V cases."""

import argparse
from collections import Counter
from dataclasses import asdict, dataclass
from io import BytesIO
import json
from math import floor
from pathlib import Path

import numpy as np
from PIL import Image

from visual_capture import load_bundle, read_json, write_json


CONFIG = Path(__file__).with_name("visual_cases.json")
PANELS = {"scene_context": "global", "witness": "local"}
LABELS = ("visible", "occluded", "cut_away", "unknown")
DETERMINATE = frozenset(LABELS[:3])


@dataclass(frozen=True)
class Hit:
    object_id: str
    face: int
    depth_m: float
    rgb: tuple
    point_m: tuple


class Camera:
    def __init__(self, view, image_size):
        x, y_bottom, self.width, self.height = view["viewport"]
        self.left = x
        self.top = image_size[1] - y_bottom - self.height
        if self.width <= 0 or self.height <= 0 or not (0 <= self.left <= image_size[0] - self.width
                and 0 <= self.top <= image_size[1] - self.height):
            raise ValueError("Invalid source viewport")
        if view["rna"]["type"] != "ORTHO":
            raise ValueError("This profile requires an orthographic camera")
        self.matrix = np.asarray(view["gpu"]["view_projection"], dtype=float)
        if self.matrix.shape != (4, 4) or not np.isfinite(self.matrix).all():
            raise ValueError("Invalid GPU camera matrix")
        self.inverse = np.linalg.inv(self.matrix)
        if not np.allclose(self.matrix[3], (0, 0, 0, 1), atol=1e-8, rtol=0):
            raise ValueError("Expected affine clip coordinates for this profile")

    def project(self, point):
        x, y, _, w = self.matrix @ np.r_[point, 1.]
        return self.left + (1 + x / w) * self.width / 2 - .5, self.top + (1 - y / w) * self.height / 2 - .5

    def segment(self, x, y):
        ndc_x = 2 * (x + .5 - self.left) / self.width - 1
        ndc_y = 1 - 2 * (y + .5 - self.top) / self.height
        near = self.inverse @ (ndc_x, ndc_y, -1., 1.)
        far = self.inverse @ (ndc_x, ndc_y, 1., 1.)
        return near[:3] / near[3], far[:3] / far[3]

    def contains(self, x, y):
        return self.left <= x < self.left + self.width and self.top <= y < self.top + self.height


class DrawGeometry:
    def __init__(self, meshes):
        triangles, labels, ids, colors = [], [], [], []
        self.palettes = {}
        for mesh in meshes:
            vertices, faces = np.asarray(mesh.vertices_m, dtype=float), np.asarray(mesh.triangles)
            if vertices.ndim != 2 or vertices.shape[1] != 3 or not len(vertices) or not np.isfinite(vertices).all():
                raise ValueError(f"Invalid world-meter vertices for {mesh.object_id}")
            if faces.ndim != 2 or faces.shape[1] != 3 or not np.issubdtype(faces.dtype, np.integer):
                raise ValueError(f"Invalid triangle array for {mesh.object_id}")
            if faces.size and (faces.min() < 0 or faces.max() >= len(vertices)):
                raise ValueError(f"Triangle index out of bounds for {mesh.object_id}")
            if mesh.face_rgb.shape != (len(faces), 3) or mesh.face_rgb.dtype != np.uint8:
                raise ValueError(f"Invalid draw colors for {mesh.object_id}")
            triangles.append(vertices[faces])
            colors.append(mesh.face_rgb)
            ids.extend(range(len(faces)))
            labels.extend([mesh.object_id] * len(faces))
            self.palettes[mesh.object_id] = np.unique(mesh.face_rgb.astype(int), axis=0)
        faces = np.concatenate(triangles)
        self.anchor = faces[:, 0]
        self.edge_ab, self.edge_ac = faces[:, 1] - self.anchor, faces[:, 2] - self.anchor
        self.scale = max(float(np.max(np.abs(faces))), float(np.max(np.ptp(faces.reshape(-1, 3), axis=0))))
        self.triangle_error = 64 * np.finfo(float).eps * (
            np.linalg.norm(self.edge_ab, axis=1) * np.linalg.norm(self.edge_ac, axis=1)
        )
        self.labels, self.ids = tuple(labels), tuple(ids)
        self.colors = np.concatenate(colors).astype(int)

    def intersections(self, origin, direction, length):
        crossed = np.cross(direction, self.edge_ac)
        determinant = np.einsum("ij,ij->i", self.edge_ab, crossed)
        valid = np.abs(determinant) > self.triangle_error
        inverse = np.divide(1., determinant, out=np.zeros_like(determinant), where=valid)
        offset = origin - self.anchor
        u = np.einsum("ij,ij->i", offset, crossed) * inverse
        tangent = np.cross(offset, self.edge_ab)
        v = tangent @ direction * inverse
        depth = np.einsum("ij,ij->i", self.edge_ac, tangent) * inverse
        valid &= (u >= -1e-10) & (v >= -1e-10) & (u + v <= 1 + 1e-10) & (depth >= 0) & (depth <= length)
        indices = np.flatnonzero(valid)
        return [Hit(self.labels[index], self.ids[index], float(depth[index]), tuple(self.colors[index].tolist()),
                    tuple((origin + direction * depth[index]).tolist()))
                for index in indices[np.argsort(depth[indices], kind="stable")]]


def _color_match(pixel, expected, tolerance):
    return bool(np.all(np.abs(np.asarray(pixel, dtype=int) - np.asarray(expected, dtype=int)) <= tolerance))


def _has_color(pixel, palette, tolerance):
    return bool(np.any(np.all(np.abs(np.asarray(pixel, dtype=int) - palette) <= tolerance, axis=1)))


def _top_hit(hits, tie_m):
    if not hits:
        return None, False
    first = hits[0]
    tied = any((hit.object_id, hit.rgb) != (first.object_id, first.rgb)
               for hit in hits[1:] if hit.depth_m - first.depth_m <= tie_m)
    return first, tied


def _overlay(panel, x, y, projected, midpoint, rules):
    if y < rules["header_px"] or y >= rules["footer_start_px"] or x == rules["separator_x"]:
        return True
    if panel == "scene_context":
        cx, cy = midpoint
        rectangles = [(cx + k, cy - 12, cx + k + 1, cy + 13) for k in (-12, 12)]
        rectangles += [(cx - 12, cy + k, cx + 13, cy + k + 1) for k in (-12, 12)]
    else:
        rectangles = []
        for (cx, cy), sign in zip(projected, (-1, 1)):
            rectangles.extend(((cx - 1, cy - 14, cx + 1, cy - 7), (cx - 1, cy + 7, cx + 1, cy + 14),
                               (cx + min(0, sign * 8), cy + 13, cx + max(1, sign * 8), cy + 15)))
    # Draw rectangles use framebuffer edges, while (x,y) denotes the pixel index.
    px, py, pad = x + .5, y + .5, rules["edge_padding_px"]
    return any(l - pad <= px <= r + pad and t - pad <= py <= b + pad for l, t, r, b in rectangles)


def _cut(section):
    if section is None:
        return None
    normal = np.asarray(section["normal"], dtype=float)
    point = np.asarray(section["point_m"], dtype=float)
    if (normal.shape != (3,) or point.shape != (3,) or not np.isfinite(point).all()
            or not np.isclose(np.linalg.norm(normal), 1., atol=2e-6, rtol=0) or section["kept_side"] != "<=0"):
        raise ValueError("Invalid actual signed section plane")
    return point, normal


def _sample(camera, geometry, pixel, x, y, role, point, section, rules):
    origin, far = camera.segment(x, y)
    segment = far - origin
    length = float(np.linalg.norm(segment))
    direction = segment / length
    span = max(float(np.linalg.norm(camera.segment(x + 1, y)[0] - origin)),
               float(np.linalg.norm(camera.segment(x, y + 1)[0] - origin)))
    point_depth = float((point - origin) @ direction)
    depth_band = rules["target_depth_band_pixels"] * span
    tie_m = rules["float32_epsilon_multiplier"] * np.finfo(np.float32).eps * geometry.scale
    hits = geometry.intersections(origin, direction, length)
    retained, discarded, boundary = hits, [], []
    if section is not None:
        retained = []
        for hit in hits:
            signed = float((np.asarray(hit.point_m) - section[0]) @ section[1])
            if signed < -tie_m:
                retained.append(hit)
            elif signed > tie_m:
                discarded.append(hit)
            else:
                boundary.append(hit)
    front, tied = _top_hit(retained, tie_m)
    original, original_tie = _top_hit(hits, tie_m)
    expected = rules["background_rgb"] if front is None else front.rgb
    tolerance = rules["rgb_tolerance"]

    def target(hit):
        return hit.object_id == role and abs(hit.depth_m - point_depth) <= depth_band

    record = {"pixel": [x, y], "actual_rgb": pixel.tolist(), "expected_rgb": list(expected),
              "front": None if front is None else asdict(front),
              "uncut_front": None if original is None else asdict(original),
              "target_depth_m": point_depth, "target_band_m": depth_band,
              "retained_target": [asdict(hit) for hit in retained if target(hit)],
              "discarded_target": [asdict(hit) for hit in discarded if target(hit)]}
    if tied or any(front is None or hit.depth_m <= front.depth_m + tie_m or target(hit) for hit in boundary):
        return {**record, "label": "unknown", "reason": "depth_tie_or_section_boundary"}
    if not _color_match(pixel, expected, tolerance):
        return {**record, "label": "unknown", "reason": "pixel_does_not_confirm_first_hit"}
    if front is not None and target(front):
        other_color = any(_has_color(pixel, colors, tolerance) for key, colors in geometry.palettes.items() if key != role)
        if not other_color and not _color_match(pixel, rules["background_rgb"], tolerance):
            return {**record, "label": "visible", "reason": "local_target_is_first_and_pixel_confirms"}
    elif not _has_color(pixel, geometry.palettes[role], tolerance):
        if front is not None and front.object_id != role and record["retained_target"]:
            return {**record, "label": "occluded", "reason": "confirmed_foreground_before_retained_local_target"}
        if original is not None and not original_tie and target(original) and record["discarded_target"] and not record["retained_target"]:
            return {**record, "label": "cut_away", "reason": "first_local_target_removed_by_actual_section"}
    return {**record, "label": "unknown", "reason": "no_distinct_local_target_pixel_evidence"}


def majority(samples):
    counts = Counter(item["label"] for item in samples)
    if len(samples) != 5 or not set(counts) <= set(LABELS):
        raise ValueError("Expected five valid sample labels")
    return next((label for label in LABELS if counts[label] >= 3), "mixed"), dict(counts)


def score_bundle(path, config):
    manifest, source = load_bundle(path)
    case = config["cases"][manifest["case_id"]]
    meta = source.metadata
    if (manifest["arm"] not in ("I", "N") or manifest["provenance"] not in ("actual_render", "synthetic")
            or meta["mode"] != case["mode"] or set(meta["mesh_ids"]) != set(case["objects"])
            or meta["target_ids"] != config["target_ids"]):
        raise ValueError("Bundle does not match the registered case, mode or object pair")
    rules = config["rules"]
    with Image.open(BytesIO(source.png)) as image:
        size = image.size
        pixels = np.asarray(image.convert("RGB"))
    geometry = DrawGeometry(source.meshes)
    a, b = (np.asarray(meta["witness"][key], dtype=float) for key in ("point_a", "point_b"))
    if any(point.shape != (3,) or not np.isfinite(point).all() for point in (a, b)):
        raise ValueError("Invalid actual terminal witness points")
    for role, key in zip(meta["target_ids"], ("face_a", "face_b")):
        face_id = meta["witness"][key]
        mesh = next(mesh for mesh in source.meshes if mesh.object_id == role)
        if type(face_id) is not int or not 0 <= face_id < len(mesh.triangles):
            raise ValueError("Witness face is outside the actual drawn mesh")
    section = _cut(meta["section"])
    output = {}
    for panel, key in PANELS.items():
        camera = Camera(meta["views"][key], size)
        if (camera.left, camera.top, camera.width, camera.height) != ((0 if key == "global" else 512), 0, 512, 512):
            raise ValueError("Unexpected source panel layout")
        projected = [camera.project(point) for point in (a, b)]
        midpoint = camera.project((a + b) / 2)
        panel_section = section if key == "local" else None
        output[panel] = {}
        for role, point, (u, v) in zip(meta["target_ids"], (a, b), projected):
            x0, y0 = floor(u + .5), floor(v + .5)
            samples = []
            for dx, dy in rules["offsets"]:
                x, y = x0 + dx, y0 + dy
                if not camera.contains(x, y) or _overlay(panel, x, y, projected, midpoint, rules["hud"]):
                    samples.append({"pixel": [x, y], "label": "unknown", "reason": "outside_panel_or_overlay"})
                else:
                    samples.append(_sample(camera, geometry, pixels[y, x], x, y, role, point, panel_section, rules))
            label, votes = majority(samples)
            output[panel][role] = {"projected_px": [u, v], "label": label, "votes": votes, "samples": samples}
    return {"case_id": manifest["case_id"], "arm": manifest["arm"], "provenance": manifest["provenance"],
            "binding": manifest["binding"], "evidence_sha256": manifest["sha256"], "panels": output}


def coverage(scores, config, arm):
    by_case = {}
    for score in scores:
        if score["arm"] != arm or score["case_id"] in by_case:
            raise ValueError("Mismatched arm or repeated visual case")
        by_case[score["case_id"]] = score
    complete, kinds = [], set()
    for key in config["cases"]:
        result = by_case.get(key)
        if result is None or result["provenance"] != "actual_render":
            continue
        labels = {role["label"] for role in result["panels"]["witness"].values()}
        if labels & DETERMINATE:
            complete.append(key)
            kinds.update(labels & DETERMINATE)
    ready = len(complete) == len(config["cases"]) and {"visible", "occluded"} <= kinds
    return {"arm": arm, "status": "ready_for_independent_review" if ready else "pending_actual_evidence",
            "cases_with_determinate_actual_witness": complete,
            "missing_or_inconclusive": [key for key in config["cases"] if key not in complete],
            "actual_witness_labels_observed": sorted(kinds)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("bundle", nargs="*", type=Path)
    parser.add_argument("--config", type=Path, default=CONFIG)
    parser.add_argument("--arm", choices=("I", "N"), required=True)
    parser.add_argument("--output", type=Path)
    options = parser.parse_args()
    config = read_json(options.config)
    scores = [score_bundle(bundle, config) for bundle in options.bundle]
    result = {"coverage": coverage(scores, config, options.arm), "scores": scores}
    if options.output is None:
        print(json.dumps(result, indent=2, allow_nan=False))
    else:
        if options.output.exists():
            raise FileExistsError(options.output)
        write_json(options.output, result)


if __name__ == "__main__":
    main()
