"""Capture and bind exactly one rendered image to MCP and draw geometry."""

from contextlib import contextmanager
from dataclasses import dataclass
from hashlib import sha256
from io import BytesIO
import base64
import json
from pathlib import Path
from unittest.mock import patch

import numpy as np
from PIL import Image


PROFILE = "vg-flat-rgb8-orthographic-v1"
FILES = ("image.png", "source.json", "geometry.npz", "mcp-image.json", "mcp-camera.json")


def digest(data):
    return sha256(data).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


@dataclass(frozen=True)
class DrawMesh:
    object_id: str
    vertices_m: np.ndarray
    triangles: np.ndarray
    face_rgb: np.ndarray


@dataclass(frozen=True)
class RenderSource:
    png: bytes
    metadata: dict
    meshes: tuple
    profile: str = PROFILE


def capture_draw_meshes(meshes):
    """Copy the geometry and material colors that actually enter the VG draw."""
    result = []
    for object_id, mesh in meshes.items():
        appearance = mesh.appearance
        if appearance is None:
            raise ValueError(f"Missing actual draw appearance for {object_id}")
        slots = [appearance.object_color] + [
            appearance.object_color if material is None else material[1]
            for material in appearance.material_slots
        ]
        palette = np.asarray(slots, dtype=np.float32)[:, :3]
        triangles = np.array(mesh.triangles, dtype=np.int32, copy=True)
        if len(slots) == 1:
            colors = np.broadcast_to(palette[0], (len(triangles), 3))
        else:
            material_ids = appearance.polygon_material_indices[appearance.triangle_polygon_indices]
            colors = palette[material_ids + 1]
        face_rgb = np.rint(np.clip(colors, 0., 1.) * 255).astype(np.uint8)
        result.append(DrawMesh(object_id, np.array(mesh.world_m, dtype=np.float32, copy=True), triangles, face_rgb))
    return tuple(result)


@contextmanager
def capture_vg_render(renderer_class):
    """Wrap the accepted prepare/observe calls without changing render arguments.

    Use only in an evaluator-controlled worker. The single current source is
    cleared before every observation and contains copies, not live Blender data.
    """
    current = {}
    prepare, observe = renderer_class.prepare, renderer_class.observe

    def prepare_with_source(renderer, meshes):
        drawn = capture_draw_meshes(meshes)
        prepared = prepare(renderer, meshes)
        current["prepared"] = (prepared, drawn)
        return prepared

    def observe_with_source(renderer, prepared, *args, **kwargs):
        current.pop("source", None)
        actual, drawn = current.pop("prepared", (None, None))
        if actual is not prepared:
            raise ValueError("No draw capture from the same preparation")
        observed = observe(renderer, prepared, *args, **kwargs)
        metadata = json.loads(json.dumps(observed.metadata, allow_nan=False))
        current["source"] = RenderSource(bytes(observed.png), metadata, drawn)
        return observed

    with patch.object(renderer_class, "prepare", prepare_with_source), patch.object(
        renderer_class, "observe", observe_with_source
    ):
        yield current


def unpack_result(message, *, image=False):
    result = message.get("result", message)
    if result.get("isError") is not False or "structuredContent" in result:
        raise ValueError("Expected the one-text result contract without a tool error")
    content = result["content"]
    if len(content) != 1 + image or content[0]["type"] != "text":
        raise ValueError("Expected one JSON TextContent and exactly the requested image count")
    fields = json.loads(content[0]["text"])
    if not image:
        return fields
    block = content[1]
    if block["type"] != "image" or block["mimeType"] != "image/png":
        raise ValueError("Expected a standard PNG ImageContent")
    return fields, base64.b64decode(block["data"], validate=True)


def _bound_fields(image_message, camera_message, source):
    fields, png = unpack_result(image_message, image=True)
    compact = fields.get("image", fields)
    camera = unpack_result(camera_message)
    meta = source.metadata
    if not png or png != source.png:
        raise ValueError("Public and renderer PNG bytes differ")
    if camera.get("evidence") != "camera" or fields.get("unit") != "m":
        raise ValueError("Missing current camera evidence or world-meter unit")
    if any(fields[key] != camera[key] for key in ("task_id", "observation_id", "frame_id", "moving_id", "reference_id", "unit")):
        raise ValueError("PNG and camera refer to different task observations")
    if any(compact[key] != camera[key] for key in ("status", "mode", "image_id", "scene_object_ids", "section", "panels")):
        raise ValueError("Camera belongs to a different image")
    if compact["status"] != "available" or compact["panels"] != ["scene_context", "witness"]:
        raise ValueError("Invalid panel identity or image availability")
    if meta["frame_id"] != fields["frame_id"] or meta["target_ids"] != [fields["moving_id"], fields["reference_id"]]:
        raise ValueError("Renderer used a different frame or target pair")
    pairs = (("mode", "mode"), ("mesh_ids", "scene_object_ids"), ("section", "section"),
             ("meters_per_blender_unit", "meters_per_blender_unit"), ("views", "views"))
    if any(meta[source_key] != camera[public_key] for source_key, public_key in pairs):
        raise ValueError("Camera, units, section or ordered draw objects differ from the actual render")
    ids = [mesh.object_id for mesh in source.meshes]
    if ids != meta["mesh_ids"] or len(set(ids)) != len(ids) or not set(meta["target_ids"]) <= set(ids):
        raise ValueError("Invalid ordered draw mesh identity")
    if source.profile != PROFILE or meta["mode"] not in ("NATURAL", "SECTION"):
        raise ValueError("Unsupported render profile or image mode")
    if (meta["section"] is None) != (meta["mode"] == "NATURAL"):
        raise ValueError("Image mode does not match actual section evidence")
    with Image.open(BytesIO(png)) as image:
        if image.format != "PNG" or image.size != (1024, 512) or image.mode not in ("RGB", "RGBA"):
            raise ValueError("Unexpected PNG format, size or pixel mode")
        image.load()
        if image.mode == "RGBA" and image.getchannel("A").getextrema() != (255, 255):
            raise ValueError("Expected an opaque framebuffer")
    return {key: camera[key] for key in ("task_id", "observation_id", "frame_id", "image_id", "mode")}


def save_bundle(folder, *, case_id, arm, provenance, image_message, camera_message, source):
    """Save immutable evidence after image and cached camera refer to one render."""
    if arm not in ("I", "N") or provenance not in ("actual_render", "synthetic"):
        raise ValueError("Unknown arm or render provenance")
    identity = _bound_fields(image_message, camera_message, source)
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=False)
    (folder / "image.png").write_bytes(source.png)
    write_json(folder / "source.json", {"profile": source.profile, "metadata": source.metadata})
    write_json(folder / "mcp-image.json", image_message)
    write_json(folder / "mcp-camera.json", camera_message)
    arrays = {}
    for index, mesh in enumerate(source.meshes):
        arrays[f"vertices_{index}"] = mesh.vertices_m
        arrays[f"triangles_{index}"] = mesh.triangles
        arrays[f"rgb_{index}"] = mesh.face_rgb
    np.savez(folder / "geometry.npz", **arrays)
    manifest = {"schema": 1, "case_id": case_id, "arm": arm, "provenance": provenance, "binding": identity,
                "sha256": {name: digest((folder / name).read_bytes()) for name in FILES}}
    write_json(folder / "bundle.json", manifest)
    return manifest


def load_bundle(folder):
    folder = Path(folder)
    manifest = read_json(folder / "bundle.json")
    if manifest["schema"] != 1 or set(manifest["sha256"]) != set(FILES):
        raise ValueError("Unknown bundle schema or missing evidence files")
    for name in FILES:
        if digest((folder / name).read_bytes()) != manifest["sha256"][name]:
            raise ValueError(f"Evidence hash differs for {name}")
    document = read_json(folder / "source.json")
    metadata = document["metadata"]
    with np.load(folder / "geometry.npz", allow_pickle=False) as arrays:
        meshes = tuple(DrawMesh(key, arrays[f"vertices_{i}"], arrays[f"triangles_{i}"], arrays[f"rgb_{i}"])
                       for i, key in enumerate(metadata["mesh_ids"]))
    source = RenderSource((folder / "image.png").read_bytes(), metadata, meshes, document["profile"])
    binding = _bound_fields(read_json(folder / "mcp-image.json"), read_json(folder / "mcp-camera.json"), source)
    if binding != manifest["binding"]:
        raise ValueError("Manifest binding differs from the source receipt")
    return manifest, source
