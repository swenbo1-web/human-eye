"""Record raw host stdio while forwarding it to the production relay."""

from argparse import ArgumentParser
import json
import os
from pathlib import Path
import subprocess
import sys
from threading import Event, Lock, Thread


ROOT = Path(__file__).resolve().parents[3]
CHUNK = 64 * 1024
NO_WINDOW = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0


def _binary(*fds):
    if os.name == "nt":
        import msvcrt

        for fd in fds:
            msvcrt.setmode(fd, os.O_BINARY)


def _write(fd, data, audit, key):
    remaining = memoryview(data)
    while remaining:
        count = os.write(fd, remaining)
        if not count:
            raise OSError("Zero-byte pipe or audit write")
        audit[key] += count
        remaining = remaining[count:]


def _forward(relay, request_fd, response_fd, audit):
    source_fd, sink_fd = sys.stdin.fileno(), sys.stdout.fileno()
    relay_input, relay_output = relay.stdin.fileno(), relay.stdout.fileno()
    _binary(source_fd, sink_fd, relay_input, relay_output)
    stop = Event()
    request_log = Lock()

    def upload():
        try:
            while not stop.is_set():
                data = os.read(source_fd, CHUNK)
                if not data:
                    audit["stdin_eof"] = True
                    break
                with request_log:
                    if stop.is_set():
                        break
                    _write(request_fd, data, audit, "request_bytes")
                _write(relay_input, data, audit, "forwarded_request_bytes")
        except OSError as error:
            audit["upload_error"] = str(error)
        finally:
            relay.stdin.close()

    # The relay can exit while the host keeps its input pipe open. A daemon
    # reading the raw descriptor allows stdout EOF to propagate immediately.
    uploader = Thread(target=upload, daemon=True)
    uploader.start()
    try:
        while data := os.read(relay_output, CHUNK):
            _write(response_fd, data, audit, "response_bytes")
            _write(sink_fd, data, audit, "forwarded_response_bytes")
        audit["relay_stdout_eof"] = True
    except OSError as error:
        audit["download_error"] = str(error)
        if relay.poll() is None:
            relay.kill()
    finally:
        stop.set()
        # Synchronize with any in-progress request log write before its file closes.
        with request_log:
            pass
        try:
            relay.wait(timeout=5)
        except subprocess.TimeoutExpired:
            audit["relay_wait_timeout"] = True
            relay.kill()
            relay.wait(timeout=5)
        uploader.join(timeout=0.1)
        audit["upload_thread_finished"] = not uploader.is_alive()


def _port(opts):
    port = opts.port
    if opts.ready is not None:
        ready = json.loads(opts.ready.read_bytes())
        if not isinstance(ready, dict) or ready.get("host") != "127.0.0.1":
            raise ValueError("Ready file does not identify IPv4 loopback")
        port = ready.get("port")
    if type(port) is not int or not 1 <= port <= 65535:
        raise ValueError("Expected a relay port from 1 through 65535")
    return port


def _run(port, folder):
    folder.mkdir(parents=True, exist_ok=True)
    summary_path = folder / "tap.json"
    staging = folder / "tap.json.tmp"
    if summary_path.exists():
        raise FileExistsError(summary_path)
    argv = [sys.executable, "-B", str(ROOT / "human_eye_llm_stdio.py"), "--port", str(port)]
    audit = {"tap_pid": os.getpid(), "tap_parent_pid": os.getppid(), "relay_argv": argv,
             "relay_pid": None, "relay_exit_code": None, "stdin_eof": False, "relay_stdout_eof": False,
             "request_bytes": 0, "forwarded_request_bytes": 0, "response_bytes": 0,
             "forwarded_response_bytes": 0}
    with (
        staging.open("x", encoding="utf-8") as summary,
        (folder / "requests.bin").open("xb", buffering=0) as requests,
        (folder / "responses.bin").open("xb", buffering=0) as responses,
        (folder / "relay.stderr").open("xb", buffering=0) as stderr,
    ):
        try:
            with subprocess.Popen(argv, cwd=ROOT, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr,
                                  bufsize=0, creationflags=NO_WINDOW) as relay:
                audit["relay_pid"] = relay.pid
                try:
                    _forward(relay, requests.fileno(), responses.fileno(), audit)
                finally:
                    if relay.poll() is None:
                        relay.kill()
                    audit["relay_exit_code"] = relay.wait()
        except (OSError, subprocess.TimeoutExpired) as error:
            audit["relay_error"] = str(error)
        finally:
            json.dump(audit, summary, indent=2)
            summary.write("\n")
    staging.replace(summary_path)

    errors = [audit[key] for key in ("relay_error", "upload_error", "download_error") if key in audit]
    for error in errors:
        print(f"stdio tap: {error}", file=sys.stderr)
    return 0 if audit["relay_exit_code"] == 0 and not errors and not audit.get("relay_wait_timeout") else 1


def main():
    parser = ArgumentParser(description=__doc__)
    endpoint = parser.add_mutually_exclusive_group(required=True)
    endpoint.add_argument("--port", type=int)
    endpoint.add_argument("--ready", type=Path)
    parser.add_argument("--audit-dir", type=Path, required=True)
    opts = parser.parse_args()
    try:
        return _run(_port(opts), opts.audit_dir.resolve())
    except (OSError, ValueError) as error:
        print(f"stdio tap: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
