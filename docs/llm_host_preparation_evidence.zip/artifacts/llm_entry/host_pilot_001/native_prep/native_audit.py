"""Symmetric setter tracing and independent Blender RNA snapshots for I and N."""

import ast
from dataclasses import dataclass
import inspect
import sys
from textwrap import dedent
from threading import current_thread, main_thread

import numpy as np


def _main_thread():
    if current_thread() is not main_thread():
        raise RuntimeError("Use the Blender main thread")


def _object_key(obj):
    return obj.as_pointer()


@dataclass(frozen=True, slots=True)
class SetterSite:
    file: str
    line: int
    operation: str


class SetterTrace:
    """Trace one explicit RNA assignment using the same contract in each arm.

    Pass the frozen callable that directly assigns `moving.matrix_world`.
    This traces that Python site. Only a separately restricted dispatch surface
    can enforce that no other code performs scene writes.
    """

    def __init__(self, function, objects):
        lines, start = inspect.getsourcelines(function)
        tree = ast.parse(dedent("".join(lines)))
        setters = [
            node for node in ast.walk(tree)
            if isinstance(node, ast.Assign) and any(
                isinstance(target, ast.Attribute) and target.attr == "matrix_world"
                and isinstance(target.value, ast.Name) and target.value.id == "moving"
                for target in node.targets
            )
        ]
        if len(setters) != 1 or setters[0].lineno != setters[0].end_lineno:
            raise ValueError("Expected one single-line moving.matrix_world assignment")
        self.site = SetterSite(inspect.getsourcefile(function), start + setters[0].lineno - 1, "matrix_world")
        self._code = function.__code__
        self._objects = {_object_key(obj): key for key, obj in objects.items()}
        if len(self._objects) != len(objects):
            raise ValueError("Audit object IDs must bind distinct objects")
        self.events = []

    def _global(self, frame, event, _arg):
        if event != "call" or frame.f_code is not self._code:
            return None
        pending = None

        def local(frame, event, arg):
            nonlocal pending
            if pending is not None:
                if event == "exception":
                    pending.update(status="raised", exception=arg[0].__name__)
                    pending = None
                elif event in ("line", "return"):
                    pending["status"] = "completed"
                    pending = None
            if event == "line" and frame.f_lineno == self.site.line:
                moving = frame.f_locals["moving"]
                pointer = _object_key(moving)
                pending = {"sequence": len(self.events) + 1, "object_id": self._objects.get(pointer),
                           "object_pointer": pointer, "operation": self.site.operation, "status": "entered"}
                self.events.append(pending)
            return local

        return local

    def __enter__(self):
        _main_thread()
        if sys.gettrace() is not None:
            raise RuntimeError("A Python trace is already installed on the Blender thread")
        sys.settrace(self._global)
        return self

    def __exit__(self, exc_type, exc, traceback):
        sys.settrace(None)


def capture_scene_rna(scene, view_layer, objects):
    """Independently read identity, evaluated world matrices and mesh rows."""
    import bpy

    _main_thread()
    scale = float(scene.unit_settings.scale_length)
    known = {_object_key(obj): key for key, obj in objects.items()}
    if len(known) != len(objects):
        raise ValueError("Snapshot object IDs must bind distinct objects")
    snapshot = {"frame_id": scene.frame_current, "subframe": scene.frame_subframe,
                "meters_per_blender_unit": scale, "objects": []}
    with bpy.context.temp_override(scene=scene, view_layer=view_layer):
        graph = bpy.context.evaluated_depsgraph_get()
        for obj in sorted(scene.objects, key=lambda candidate: (candidate.name, _object_key(candidate))):
            evaluated = obj.evaluated_get(graph)
            matrix = np.asarray(evaluated.matrix_world, dtype=np.float64)
            pointer = _object_key(obj)
            data = obj.data
            record = {"id": known.get(pointer), "name": obj.name, "type": obj.type,
                      "object_pointer": pointer, "data_pointer": None if data is None else data.as_pointer(),
                      "matrix_world_bu": matrix.tolist()}
            if obj.type == "MESH":
                mesh = evaluated.to_mesh()
                try:
                    local = np.asarray([tuple(v.co) for v in mesh.vertices], dtype=float).reshape(-1, 3)
                    mesh.calc_loop_triangles()
                    record.update(
                        local_vertices_bu=local.tolist(),
                        world_vertices_m=((local @ matrix[:3, :3].T + matrix[:3, 3]) * scale).tolist(),
                        triangles=[list(row.vertices) for row in mesh.loop_triangles],
                    )
                finally:
                    evaluated.to_mesh_clear()
            snapshot["objects"].append(record)
    return snapshot
