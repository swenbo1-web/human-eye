"""Small portable qualification. No Blender, model, recipe, or timing claim."""

from contextlib import nullcontext
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import numpy as np

from verification.test_bc_acceptance import exhaustive_convex_oracle

from . import native_geometry
from .blender_native import NativePair, translate_world_m
from .native_audit import SetterTrace, capture_scene_rna
from .native_geometry import TriangleIndex, surface_pair


_FACE = ((0, 1, 2),)


class GeometryTests(unittest.TestCase):
    def _check(self, a, b, distance, pa=None, pb=None):
        result = surface_pair(TriangleIndex(a, _FACE), TriangleIndex(b, _FACE))
        self.assertAlmostEqual(result.distance_m, distance, places=13)
        self.assertAlmostEqual(np.linalg.norm(np.subtract(result.point_b_m, result.point_a_m)), distance, places=13)
        if pa is not None:
            np.testing.assert_allclose(result.point_a_m, pa, rtol=0, atol=1e-13)
        if pb is not None:
            np.testing.assert_allclose(result.point_b_m, pb, rtol=0, atol=1e-13)

    def test_vertex_projects_to_face_interior(self):
        self._check([(0., 0., 2.)] * 3, [(-1., -1., 0.), (2., -1., 0.), (0., 2., 0.)],
                    2., (0., 0., 2.), (0., 0., 0.))

    def test_two_edge_interiors(self):
        self._check([(-1., 0., 0.), (1., 0., 0.), (1., 0., 0.)],
                    [(0., -1., 2.), (0., 1., 2.), (0., 1., 2.)], 2., (0., 0., 0.), (0., 0., 2.))

    def test_segment_through_face_without_vertex_or_edge_hit(self):
        self._check([(0., -.25, -1.), (0., -.25, 1.), (0., .25, 1.)],
                    [(-1., -1., 0.), (2., -1., 0.), (0., 2., 0.)], 0.)

    def test_coplanar_intersection_and_empty(self):
        self._check([(-2., -1., 0.), (2., -1., 0.), (0., 2., 0.)],
                    [(-2., 1., 0.), (2., 1., 0.), (0., -2., 0.)], 0.)
        empty = TriangleIndex(np.empty((0, 3)), [])
        self.assertIsNone(surface_pair(empty, empty))

    def test_independent_oracle_on_multiple_leaves_and_refit(self):
        faces_a = np.arange(33).reshape(-1, 3)
        faces_b = np.arange(39).reshape(-1, 3)
        for seed in (27, 902, 5101):
            with self.subTest(seed=seed):
                rng = np.random.default_rng(seed)
                a = rng.uniform(-1., 1., size=(33, 3))
                b = rng.uniform(-1., 1., size=(39, 3)) + (3., .15, -.25)
                ia, ib = TriangleIndex(a, faces_a), TriangleIndex(b, faces_b)
                trees = ia._nodes, ib._nodes
                for shift in (0., -.15):
                    shifted = b + (shift, 0., 0.)
                    ib.refit(shifted)
                    actual = surface_pair(ia, ib)
                    expected = exhaustive_convex_oracle(a, faces_a, shifted, faces_b)[0]
                    self.assertAlmostEqual(actual.distance_m, expected, places=13)
                    self.assertIs(ia._nodes, trees[0])
                    self.assertIs(ib._nodes, trees[1])
                    for points, faces, idx, witness in (
                        (a, faces_a, actual.face_a, actual.point_a_m),
                        (shifted, faces_b, actual.face_b, actual.point_b_m),
                    ):
                        tri = points[faces[idx]]
                        weight = np.linalg.lstsq((tri[1:] - tri[0]).T, witness - tri[0], rcond=None)[0]
                        self.assertGreaterEqual(float(min(*weight, 1 - weight.sum())), -1e-12)
                        np.testing.assert_allclose(tri[0] + weight @ (tri[1:] - tri[0]), witness, rtol=0, atol=1e-12)

    def test_spatial_pruning_avoids_dense_cartesian_narrow_phase(self):
        count = 128
        offsets = np.column_stack((2. * np.arange(count), np.zeros((count, 2))))
        triangle = np.asarray(((0., 0., 0.), (.25, 0., 0.), (0., .25, 0.)))
        a = (triangle[None] + offsets[:, None]).reshape(-1, 3)
        heights = np.linspace(.5, .02, count)
        b = a + np.repeat(np.column_stack((np.zeros((count, 2)), heights)), 3, axis=0)
        faces = np.arange(3 * count).reshape(-1, 3)
        original = native_geometry._closest_batch
        with patch.object(native_geometry, "_closest_batch", wraps=original) as narrow:
            result = surface_pair(TriangleIndex(a, faces), TriangleIndex(b, faces))
        evaluated_pairs = sum(len(call.args[0]) for call in narrow.call_args_list)
        self.assertAlmostEqual(result.distance_m, .02, places=14)
        self.assertGreater(evaluated_pairs, 0)
        self.assertLess(evaluated_pairs, count * count // 16)


class Matrix:
    def __init__(self, origin=(0., 0., 0.)):
        self.values = np.eye(4)
        self.translation = origin

    def __array__(self, dtype=None, copy=None):
        return np.asarray(self.values, dtype=dtype)

    @property
    def translation(self):
        return tuple(self.values[:3, 3])

    @translation.setter
    def translation(self, origin):
        self.values[:3, 3] = origin

    def copy(self):
        other = Matrix()
        other.values = self.values.copy()
        return other


class RNAList(list):
    def foreach_get(self, attr, values):
        values[:] = np.asarray([getattr(row, attr) for row in self]).reshape(-1)


class Object:
    def __init__(self, name, origin, *, kind="MESH"):
        self.name, self.type = name, kind
        self._matrix = Matrix(origin)
        self.calls = []
        self.raise_on_set = False
        self.mesh = SimpleNamespace(
            vertices=RNAList(SimpleNamespace(co=co) for co in ((0., 0., 0.), (1., 0., 0.), (0., 1., 0.))),
            loop_triangles=RNAList([SimpleNamespace(vertices=(0, 1, 2))]),
            calc_loop_triangles=lambda: self.calls.append("triangulate"),
            as_pointer=lambda: id(self.calls),
        )
        self.data = self.mesh if kind == "MESH" else None

    @property
    def matrix_world(self):
        return self._matrix

    @matrix_world.setter
    def matrix_world(self, matrix):
        self.calls.append("setter")
        if self.raise_on_set:
            raise RuntimeError("simulated RNA assignment failure")
        self._matrix = matrix

    def as_pointer(self):
        return id(self)

    def evaluated_get(self, graph):
        self.calls.append("evaluate")
        return self

    def to_mesh(self):
        self.calls.append("to_mesh")
        return self.mesh

    def to_mesh_clear(self):
        self.calls.append("clear")


def _alternate_setter(moving, matrix):
    moving.matrix_world = matrix


class AdapterTests(unittest.TestCase):
    def setUp(self):
        self.moving = Object("moving", (0., 0., 2.))
        self.reference = Object("reference", (0., 0., 0.))
        self.parent = Object("parent", (0., 0., 4.), kind="EMPTY")
        self.objects = {"moving": self.moving, "reference": self.reference, "parent": self.parent}
        self.layer = SimpleNamespace(name="View")
        self.scene = SimpleNamespace(objects=list(self.objects.values()), view_layers={"View": self.layer},
                                     frame_current=17, frame_subframe=0.,
                                     unit_settings=SimpleNamespace(scale_length=.001))
        self.context = Mock()
        self.context.temp_override.side_effect = lambda **kwargs: nullcontext()
        self.graph = object()
        self.context.evaluated_depsgraph_get.return_value = self.graph
        fake = patch.dict(sys.modules, {"bpy": SimpleNamespace(context=self.context)})
        fake.start()
        self.addCleanup(fake.stop)
        self.pair = NativePair(self.scene, self.layer, self.objects, "moving", "reference")
        self.addCleanup(self.pair.close)

    def test_native_task_and_independent_rna_snapshot(self):
        before = capture_scene_rna(self.scene, self.layer, self.objects)
        self.moving.calls.clear()
        self.reference.calls.clear()
        with SetterTrace(translate_world_m, self.objects) as audit:
            result = self.pair.close_gap(.00125, 1e-12)
        after = capture_scene_rna(self.scene, self.layer, self.objects)
        self.assertEqual((result["status"], result["write_status"]), ("reached", "written"))
        self.assertAlmostEqual(result["before_gap_m"], .002, places=14)
        self.assertAlmostEqual(result["after_gap_m"], .00125, places=14)
        np.testing.assert_allclose(result["actual_delta_world_m"], (0., 0., -.00075), rtol=0, atol=1e-14)
        self.assertEqual(len(audit.events), 1)
        self.assertEqual((audit.events[0]["object_id"], audit.events[0]["status"]), ("moving", "completed"))
        self.assertEqual(self.moving.calls.count("setter"), 1)
        self.assertEqual(self.reference.calls.count("setter"), 0)
        self.assertEqual(self.moving.calls.count("triangulate"), 2)  # first solver capture + audit snapshot
        self.assertEqual((self.moving.calls.count("to_mesh"), self.moving.calls.count("clear")), (1, 1))
        a = {row["id"]: row for row in before["objects"]}
        b = {row["id"]: row for row in after["objects"]}
        self.assertEqual((a["reference"], a["parent"]), (b["reference"], b["parent"]))
        self.assertEqual(a["moving"]["triangles"], b["moving"]["triangles"])
        np.testing.assert_allclose(np.asarray(b["moving"]["world_vertices_m"]) - a["moving"]["world_vertices_m"],
                                   np.broadcast_to((0., 0., -.00075), (3, 3)), rtol=0, atol=1e-14)
        self.assertEqual(self.pair.last_readback.gap_m, result["after_gap_m"])
        with SetterTrace(translate_world_m, self.objects) as audit:
            self.assertEqual(self.pair.close_gap(.00125, 1e-12)["reason"], "already_reached")
        self.assertEqual(audit.events, [])
        self.assertIsNone(sys.gettrace())

    def test_same_trace_contract_for_another_setter_and_raised_assignment(self):
        with SetterTrace(_alternate_setter, self.objects) as audit:
            _alternate_setter(self.moving, self.moving.matrix_world.copy())
        self.assertEqual((audit.events[0]["object_id"], audit.events[0]["status"]), ("moving", "completed"))
        self.moving.raise_on_set = True
        with SetterTrace(translate_world_m, self.objects) as audit:
            result = self.pair.close_gap(.00125, 1e-12)
        self.assertEqual((result["stage"], result["write_status"]), ("setter", "unknown"))
        self.assertEqual((audit.events[0]["object_id"], audit.events[0]["status"], audit.events[0]["exception"]),
                         ("moving", "raised", "RuntimeError"))
        self.assertIsNone(self.pair.last_readback)
        self.moving.raise_on_set = False
        self.assertEqual(self.pair.close_gap(.00125, 1e-12)["status"], "reached")


if __name__ == "__main__":
    unittest.main()
