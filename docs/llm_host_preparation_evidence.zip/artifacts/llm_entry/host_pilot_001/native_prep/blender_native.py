"""Independent world-meter task adapter. Importing this file does not import bpy."""

from dataclasses import dataclass
from math import isfinite
from threading import current_thread, main_thread

import numpy as np

from .native_geometry import SurfacePair, TriangleIndex, surface_pair


def _main_thread():
    if current_thread() is not main_thread():
        raise RuntimeError("Use the Blender main thread")


def _scale(scene):
    scale = float(scene.unit_settings.scale_length)
    if not isfinite(scale) or scale <= 0:
        raise ValueError("The Blender scene must have a positive finite unit scale")
    return scale


def _read_mesh(evaluated, scale, *, topology):
    mesh = evaluated.data
    local = np.empty(3 * len(mesh.vertices), dtype=np.float32)
    mesh.vertices.foreach_get("co", local)
    matrix = np.asarray(evaluated.matrix_world, dtype=np.float64)
    world = (local.astype(np.float64).reshape(-1, 3) @ matrix[:3, :3].T + matrix[:3, 3]) * scale
    triangles = None
    if topology:
        mesh.calc_loop_triangles()
        rows = np.empty(3 * len(mesh.loop_triangles), dtype=np.int32)
        mesh.loop_triangles.foreach_get("vertices", rows)
        triangles = rows.reshape(-1, 3)
    return world, triangles, matrix


class NativeWriteError(RuntimeError):
    def __init__(self, stage, write_status):
        super().__init__(f"Native world translation failed at {stage}")
        self.stage = stage
        self.write_status = write_status


def translate_world_m(moving, delta_world_m, scale_length, graph):
    """Assign world translation once; the caller owns context and fresh readback."""
    _main_thread()
    try:
        if not isfinite(scale_length) or scale_length <= 0:
            raise ValueError("Expected a positive finite Blender unit scale")
        delta = tuple(delta_world_m)
        if len(delta) != 3 or not all(map(isfinite, delta)):
            raise ValueError("Expected three finite world-meter translation components")
        matrix = moving.evaluated_get(graph).matrix_world.copy()
        position = tuple(value + change / scale_length for value, change in zip(matrix.translation, delta))
        if not all(map(isfinite, position)):
            raise ValueError("The destination world position is not finite")
        matrix.translation = position
    except Exception as error:
        raise NativeWriteError("prepare", "not_written") from error
    try:
        moving.matrix_world = matrix
    except Exception as error:
        raise NativeWriteError("setter", "unknown") from error


@dataclass(frozen=True, slots=True)
class PairReadback:
    frame_id: int
    scale_length: float
    world_origin_m: tuple[float, float, float]
    witness: SurfacePair | None

    @property
    def gap_m(self):
        return None if self.witness is None else self.witness.distance_m


def _value(number):
    if type(number) not in (int, float):
        raise ValueError("Target and tolerance must be finite nonnegative meters")
    try:
        result = float(number)
    except OverflowError as error:
        raise ValueError("Target and tolerance must be finite nonnegative meters") from error
    if not isfinite(result) or result < 0:
        raise ValueError("Target and tolerance must be finite nonnegative meters")
    return result


class NativePair:
    """Main-thread native task helper over two explicitly bound mesh objects.

    The host keeps topology stable and the reference independent and fixed.
    The helper rebuilds its AABB indexes on a new binding and refits during
    measurement. The caller owns scene lifetime and optional terminal images.
    """

    def __init__(self, scene, view_layer, objects, moving_id, reference_id):
        _main_thread()
        if moving_id == reference_id or objects[moving_id] == objects[reference_id]:
            raise ValueError("Bind two distinct mesh objects")
        if any(objects[key].type != "MESH" for key in (moving_id, reference_id)):
            raise ValueError("Both bound objects must be meshes")
        if view_layer is None or scene.view_layers.get(view_layer.name) != view_layer:
            raise ValueError("Bind an explicit scene view layer")
        self.scene = scene
        self.view_layer = view_layer
        self.ids = moving_id, reference_id
        self.moving, self.reference = (objects[key] for key in self.ids)
        self._indexes = None
        self._vertex_counts = None
        self.last_readback = None
        self._closed = False

    def _measure(self, graph, scale):
        fresh = self._indexes is None
        meshes = [_read_mesh(obj.evaluated_get(graph), scale, topology=fresh)
                  for obj in (self.moving, self.reference)]
        if fresh:
            self._indexes = tuple(TriangleIndex(world, faces) for world, faces, _ in meshes)
            self._vertex_counts = tuple(len(world) for world, _, _ in meshes)
        else:
            if tuple(len(world) for world, _, _ in meshes) != self._vertex_counts:
                raise ValueError("Rebind after a target topology change")
            for index, (world, _, _) in zip(self._indexes, meshes):
                index.refit(world)
        return PairReadback(self.scene.frame_current, scale,
                            tuple(map(float, meshes[0][2][:3, 3] * scale)),
                            surface_pair(*self._indexes))

    def measure(self):
        import bpy

        _main_thread()
        if self._closed:
            raise RuntimeError("The native pair is closed")
        self.last_readback = None
        with bpy.context.temp_override(scene=self.scene, view_layer=self.view_layer):
            self.last_readback = self._measure(bpy.context.evaluated_depsgraph_get(), _scale(self.scene))
            return self.last_readback

    def close_gap(self, target_gap_m, tolerance_m):
        """Complete one local task with at most one actual world-space write."""
        import bpy

        _main_thread()
        if self._closed:
            raise RuntimeError("The native pair is closed")
        target, tolerance = _value(target_gap_m), _value(tolerance_m)
        self.last_readback = None
        fields = {"moving_id": self.ids[0], "reference_id": self.ids[1], "unit": "m",
                  "target_gap_m": target, "tolerance_m": tolerance, "write_status": "not_written",
                  "goal_reached": False, "before_gap_m": None, "after_gap_m": None,
                  "error_m": None, "delta_world_m": None, "actual_delta_world_m": None}
        with bpy.context.temp_override(scene=self.scene, view_layer=self.view_layer):
            try:
                scale = _scale(self.scene)
                graph = bpy.context.evaluated_depsgraph_get()
                before = self._measure(graph, scale)
            except Exception:
                return {**fields, "status": "error", "reason": "observation_failed"}
            distance = before.gap_m
            fields.update(frame_id=before.frame_id, before_gap_m=distance)
            if distance is None:
                return {**fields, "status": "no_action", "reason": "empty_surface"}
            fields["error_m"] = abs(distance - target)
            if fields["error_m"] <= tolerance:
                self.last_readback = before
                return {**fields, "status": "no_action", "reason": "already_reached", "goal_reached": True}
            if target > distance:
                self.last_readback = before
                return {**fields, "status": "rejected", "reason": "would_increase_gap"}
            fraction = (distance - target) / distance
            delta = tuple(fraction * (b - a) for a, b in zip(before.witness.point_a_m, before.witness.point_b_m))
            fields["delta_world_m"] = delta
            try:
                translate_world_m(self.moving, delta, scale, graph)
            except NativeWriteError as error:
                return {**fields, "status": "error", "reason": "write_failed",
                        "stage": error.stage, "write_status": error.write_status}
            fields.update(write_status="written", error_m=None)
            try:
                after = self._measure(bpy.context.evaluated_depsgraph_get(), _scale(self.scene))
            except Exception:
                return {**fields, "status": "error", "reason": "readback_failed"}
        fields["actual_delta_world_m"] = tuple(b - a for a, b in zip(before.world_origin_m, after.world_origin_m))
        fields.update(after_gap_m=after.gap_m, frame_id=after.frame_id)
        if after.gap_m is None:
            return {**fields, "status": "error", "reason": "unmeasured_after"}
        self.last_readback = after
        error = abs(after.gap_m - target)
        fields.update(error_m=error, goal_reached=error <= tolerance)
        if not fields["goal_reached"]:
            return {**fields, "status": "not_reached", "reason": "outside_tolerance"}
        return {**fields, "status": "reached"}

    def close(self):
        _main_thread()
        self._indexes = None
        self.last_readback = None
        self.scene = self.view_layer = self.moving = self.reference = None
        self._closed = True
