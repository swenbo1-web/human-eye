"""Generic NumPy triangle-surface proximity for a native Blender comparator."""

from dataclasses import dataclass
from heapq import heappop, heappush
from math import inf, sqrt

import numpy as np


_NEXT = (1, 2, 0)
_LEAF_SIZE = 8
_LOWER_ROUNDING = 1 - 16 * np.finfo(float).eps


@dataclass(frozen=True, slots=True)
class SurfacePair:
    distance_m: float
    face_a: int
    face_b: int
    point_a_m: tuple[float, float, float]
    point_b_m: tuple[float, float, float]


def _dot(a, b):
    return np.einsum("...i,...i->...", a, b)


def _ratio(numerator, denominator):
    return np.divide(numerator, denominator, out=np.zeros_like(numerator), where=denominator != 0)


def _inside(points, triangles, normals, area_sq):
    e0 = triangles[:, 1, :] - triangles[:, 0, :]
    e1 = triangles[:, 2, :] - triangles[:, 0, :]
    offset = points - triangles[:, :1, :]
    u = _ratio(_dot(np.cross(offset, e1[:, None]), normals[:, None]), area_sq[:, None])
    v = _ratio(_dot(np.cross(e0[:, None], offset), normals[:, None]), area_sq[:, None])
    return (area_sq[:, None] > 0) & (u >= 0) & (v >= 0) & (u + v <= 1)


def _closest_batch(a, b):
    """Closest witness among a small batch of aligned triangle pairs."""
    origin = a[:, :1, :]
    a, b = a - origin, b - origin
    ae, be = a[:, _NEXT] - a, b[:, _NEXT] - b
    best = None
    best_sq = inf

    def offer(left, right, valid=True):
        nonlocal best_sq, best
        residual = left - right
        squared = _dot(residual, residual)
        squared = np.where(valid, squared, inf)
        index = np.unravel_index(int(squared.argmin()), squared.shape)
        if squared[index] < best_sq:
            best_sq = float(squared[index])
            row = index[0]
            shape = residual.shape
            offset = origin[row, 0]
            best = row, np.broadcast_to(left, shape)[index] + offset, np.broadcast_to(right, shape)[index] + offset

    def against(source, source_edges, target, target_edges, *, reverse):
        def candidate(left, right, valid=True):
            if reverse:
                offer(right, left, valid)
            else:
                offer(left, right, valid)

        normal = np.cross(target_edges[:, 0], target_edges[:, 1])
        area_sq = _dot(normal, normal)
        plane = _dot(source - target[:, :1], normal[:, None])
        projected = source - _ratio(plane, area_sq[:, None])[..., None] * normal[:, None]
        candidate(source, projected, _inside(projected, target, normal, area_sq))

        # Boundary cases, including parallel and zero-length segments.
        offset = source[:, :, None] - target[:, None, :]
        edges = target_edges[:, None, :]
        t = np.clip(_ratio(_dot(offset, edges), _dot(edges, edges)), 0, 1)
        candidate(source[:, :, None], target[:, None, :] + t[..., None] * edges)

        # An edge can pass through a face interior without an edge-edge hit.
        direction = _dot(source_edges, normal[:, None])
        t = _ratio(-plane, direction)
        hit = source + t[..., None] * source_edges
        valid = (direction != 0) & (t >= 0) & (t <= 1) & _inside(hit, target, normal, area_sq)
        candidate(hit, hit, valid)

    against(a, ae, b, be, reverse=False)
    against(b, be, a, ae, reverse=True)

    u, v = ae[:, :, None], be[:, None, :]
    normal = np.cross(u, v)
    denom = _dot(normal, normal)
    between = b[:, None, :] - a[:, :, None]
    s = _ratio(_dot(np.cross(between, v), normal), denom)
    t = _ratio(_dot(np.cross(between, u), normal), denom)
    valid = (denom > 0) & (s >= 0) & (s <= 1) & (t >= 0) & (t <= 1)
    offer(a[:, :, None] + s[..., None] * u, b[:, None, :] + t[..., None] * v, valid)
    return best_sq, best


def _world_triangles(vertices, faces):
    vertices = np.asarray(vertices, dtype=np.float64)
    if vertices.ndim != 2 or vertices.shape[1] != 3 or not np.isfinite(vertices).all():
        raise ValueError("Expected finite world-meter vertex triples")
    return vertices[faces]


class TriangleIndex:
    """Build one median AABB tree, then refit the same topology as geometry moves."""

    def __init__(self, vertices, triangles):
        raw = np.asarray(triangles)
        if raw.size and raw.dtype.kind not in "iu":
            raise ValueError("Expected integer triangle vertex rows")
        self.faces = np.asarray(raw, dtype=np.intp).reshape(-1, 3).copy()
        if self.faces.size and (self.faces.min() < 0 or self.faces.max() >= len(vertices)):
            raise ValueError("Triangle vertex row is outside the mesh")
        world = _world_triangles(vertices, self.faces)
        self.triangle_count = len(self.faces)
        self.world = world
        if not self.triangle_count:
            return

        centers = world.mean(axis=1)
        nodes, levels, leaves, order = [], [], [], []

        def build(rows, depth):
            node = len(nodes)
            nodes.append(None)
            if depth == len(levels):
                levels.append([])
            if len(rows) <= _LEAF_SIZE:
                start = len(order)
                order.extend(rows.tolist())
                leaves.append((node, start))
                nodes[node] = (-1, -1, start, len(order))
            else:
                axis = int(np.ptp(centers[rows], axis=0).argmax())
                middle = len(rows) // 2
                rows = rows[np.argpartition(centers[rows, axis], middle)]
                left, right = build(rows[:middle], depth + 1), build(rows[middle:], depth + 1)
                nodes[node] = (left, right, -1, -1)
                levels[depth].append(node)
            return node

        build(np.arange(self.triangle_count), 0)
        self._nodes = nodes
        self._order = np.asarray(order)
        self._leaf_nodes, self._starts = np.asarray(leaves).T
        self._levels = []
        for level in reversed(levels):
            if level:
                left, right = zip(*(nodes[node][:2] for node in level))
                self._levels.append(tuple(np.asarray(part) for part in (level, left, right)))
        self._low = np.empty((len(nodes), 3))
        self._high = np.empty_like(self._low)
        self._bounds()

    def _bounds(self):
        low, high = self.world.min(axis=1)[self._order], self.world.max(axis=1)[self._order]
        self._low[self._leaf_nodes] = np.minimum.reduceat(low, self._starts, axis=0)
        self._high[self._leaf_nodes] = np.maximum.reduceat(high, self._starts, axis=0)
        for nodes, left, right in self._levels:
            self._low[nodes] = np.minimum(self._low[left], self._low[right])
            self._high[nodes] = np.maximum(self._high[left], self._high[right])

    def refit(self, vertices):
        self.world = _world_triangles(vertices, self.faces)
        if self.triangle_count:
            self._bounds()


def surface_pair(a, b):
    """Return the minimum unsigned surface distance and source-triangle witnesses."""
    if not a.triangle_count or not b.triangle_count:
        return None

    def bound(i, j):
        gap = np.maximum(np.maximum(a._low[i] - b._high[j], b._low[j] - a._high[i]), 0.)
        return float(gap @ gap) * _LOWER_ROUNDING

    queue = [(bound(0, 0), 0, 0)]
    best_sq, best = inf, None
    while queue:
        lower, i, j = heappop(queue)
        if lower >= best_sq:
            break
        left_a, right_a, start_a, stop_a = a._nodes[i]
        left_b, right_b, start_b, stop_b = b._nodes[j]
        if left_a < 0 and left_b < 0:
            rows_a, rows_b = a._order[start_a:stop_a], b._order[start_b:stop_b]
            ia, ib = np.repeat(rows_a, len(rows_b)), np.tile(rows_b, len(rows_a))
            squared, witness = _closest_batch(a.world[ia], b.world[ib])
            if squared < best_sq:
                row, pa, pb = witness
                best_sq = squared
                best = SurfacePair(sqrt(squared), int(ia[row]), int(ib[row]), tuple(map(float, pa)), tuple(map(float, pb)))
                if squared == 0:
                    break
            continue
        span_a = float((a._high[i] - a._low[i]).max())
        span_b = float((b._high[j] - b._low[j]).max())
        if left_b < 0 or (left_a >= 0 and span_a >= span_b):
            children = ((left_a, j), (right_a, j))
        else:
            children = ((i, left_b), (i, right_b))
        for p, q in children:
            lower = bound(p, q)
            if lower < best_sq:
                heappush(queue, (lower, p, q))
    if best is None:
        raise ArithmeticError("Surface distance exceeds the numeric range")
    return best
