# Native comparator preparation

This candidate is a reusable NumPy and Blender adapter for the N arm. The
runtime modules do not import Human Eye, the evaluator, or fixture recipes.
The portable checks use an independent geometry oracle and a Blender RNA
double.

## Runtime modules

- `native_geometry.py` builds a median AABB hierarchy for each triangle
  surface. It refits the same hierarchy for fresh world geometry and traverses
  node pairs best first. Only leaf pairs surviving the distance bound reach
  the bounded, vectorized narrow phase. The narrow phase considers vertex-face,
  vertex-edge, edge-edge and segment-through-face witnesses. It returns the
  unsigned gap and original triangle row IDs in world meters.
- `blender_native.py` supplies `NativePair`. It borrows the evaluated mesh
  datablocks and bulk-reads coordinates through Blender RNA. It reads triangle
  rows on the initial binding and reuses the topology during refits. Its
  `translate_world_m` function performs one explicit world-matrix setter.
  The returned task result separates the planned and measured translations.
  `last_readback` holds the measurable result for optional witness or visual
  evidence without another gap query.
- `native_audit.py` supplies the same `SetterTrace` for both arms and an
  independent scene snapshot using `to_mesh` and `to_mesh_clear`. It records
  object/data identities, evaluated transforms, local/world coordinates and
  triangle rows. The runner should retain the after snapshot and any actual
  setter failure when a task fails.

## Host integration

Import from Blender's main thread after explicitly binding the scene, view
layer and IDs. Keep the two evaluated target meshes at fixed topology. The
reference must stay fixed, the moving surface must translate rigidly, and the
host must serialize scene edits. Rebind on topology change. The writable
object pair and units come from the host. The math operates on finite Blender
scene coordinates in the normal float64 range for its squared-distance
arithmetic.

```python
from artifacts.llm_entry.host_pilot_001.native_prep.blender_native import NativePair, translate_world_m
from artifacts.llm_entry.host_pilot_001.native_prep.native_audit import SetterTrace, capture_scene_rna

pair = NativePair(scene, view_layer, objects, moving_id, reference_id)
before = capture_scene_rna(scene, view_layer, objects)
try:
    with SetterTrace(translate_world_m, objects) as writes:
        result = pair.close_gap(target_gap_m, tolerance_m)
finally:
    try:
        after = capture_scene_rna(scene, view_layer, objects)
    finally:
        pair.close()
```

The native solver can be called as one task, and a trusted native script may
also use `measure` and the explicit setter separately. For I the evaluator
passes `BlenderControl.execute` into the same trace class. Each trace records
entry, completion or exception at the source-located `moving.matrix_world`
assignment. A trace on one callable cannot detect arbitrary writes from other
Python, so the runner must restrict or review actual writable dispatch and
independently verify both snapshots. Object pointers are process-local and
must only be compared within the same Blender worker.

## Recorded CPU checks

Both preregistered batches passed 8/8. The first batch checked the same
geometry and task boundary with a temporary mesh capture in the solver. The
final revision borrows evaluated meshes for solving, so a temporary mesh is
allocated only by the independent audit.

- `cpu_001/` retains the first registration, result and raw log.
- `cpu_002/` retains the final preregistration, source ZIP, result and raw
  log. Its manifest SHA-256 is
  `15a4a5345c771be36f06d048af522b1bf03217449edce7428bb363f88cfa3264`.

Both batches ran from the repository root with the six recorded numerical
thread settings at 1.

```powershell
& 'D:/human eye/venv/Scripts/python.exe' -B -m unittest -v artifacts.llm_entry.host_pilot_001.native_prep.test_native_prep
```

The tests cover vertex-face and edge-edge interiors, transverse and coplanar
intersection, empty input, six seeded oracle states, a synthetic pruning
check, RNA unit conversion and readback with a double, and symmetric trace
completion/failure. The test source uses an exhaustive oracle for small
correctness cases only. The runtime has no Cartesian triangle-pair array or
per-pair least-squares solver.

## Before formal use

The promotion candidates are the three runtime modules and
`test_native_prep.py`. Freeze the actual native tool and host registration,
world RNA snapshots and setter traces for D02/D03 and the other real scenes,
and the N terminal renderer and its paired PNG/camera evidence. Bind both
arms to the same eligibility, task, scene and measurement window, including
any in-window audit cost. No Blender or model process was started in this
preparation. Actual geometry performance, native execution, visual parity and
comparative outcomes remain to be measured.
