# 托管常驻限定归因诊断

原正式轮保留 33 个超门点，最大 I−B 488,751 B。
下面的单次诊断单列，整机结论交主干复审。

## Ordinal 7 阶段

| 观测点 | B current (B) | I current (B) | I−B (B) |
| --- | ---: | ---: | ---: |
| t4_original | 9,699,001 | 9,548,595 | -150,406 |
| held_census_complete | 9,072,624 | 9,558,815 | 486,191 |
| proof_summary_complete | 9,072,353 | 9,558,760 | 486,407 |
| released_original | 8,982,320 | 9,469,567 | 487,247 |

## 终点分配栈

按最靠近分配点的已记录栈帧分栏。栈记录可用于定位分配，存活持有链另行核证。

| 分栏 | B (B) | I (B) | I−B (B) |
| --- | ---: | ---: | ---: |
| production | 6,784,612 | 7,133,112 | 348,500 |
| verification_reporting | 349,939 | 316,693 | -33,246 |
| numpy | 547,530 | 733,675 | 186,145 |
| host_runtime | 1,299,167 | 1,285,015 | -14,152 |
| unattributed | 1,128 | 1,128 | 0 |

GC 关系按各进程自己的 QPC 计算。单次快照及 GC 时间重合只作归因线索。
[阶段全表](phase-comparison.json) · [GC 明细](gc-relationship.json) · [原正式读数](formal-current-unchanged.json) · [完整诊断摘要](summary.json)
