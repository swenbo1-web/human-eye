"""One registered managed-current role, with the frozen resource workload underneath."""

from array import array
from collections import Counter
from contextlib import ExitStack, contextmanager
import gc
import json
import os
from pathlib import Path
import time
import traceback
import tracemalloc

from artifacts.integration.formal_cost_001 import resources


SEED = 310519
PROCESS_INDEX = 2
ENDPOINT = 7
GC_CAPACITY = 32_768
GC_COLUMNS = 7
POINT_COLUMNS = 5
POINT_NAMES = {
    2: "t4_original",
    3: "held_census_complete",
    5: "proof_summary_complete",
    7: "released_original",
}
GC_STAGE_NAMES = (
    "setup_and_warmup",
    "hot_chain",
    "held_census",
    "held_checkpoint_reporting",
    "hot_proof",
    "proof_to_release",
    "released_census_and_reporting",
    "lifecycle_and_case_reporting",
    "endpoint_snapshot_and_cleanup",
)
POINT_CAPACITY = (ENDPOINT + 1) * len(POINT_NAMES)


def instrumentation_config():
    return {
        "seed": SEED, "process_index": PROCESS_INDEX, "ordinals": list(range(ENDPOINT + 1)),
        "terminal_ordinal": ENDPOINT, "traceback_limit": 1,
        "gc_capacity": GC_CAPACITY, "gc_columns": GC_COLUMNS, "gc_stage_names": list(GC_STAGE_NAMES),
        "phase_capacity": POINT_CAPACITY, "phase_columns": POINT_COLUMNS,
        "phase_names": POINT_NAMES, "numeric_cell_bits": array("q").itemsize * 8,
    }


class _EndpointReached(Exception):
    """Unwind the fixed terminal case through the original lane cleanup."""


class _Recorder:
    def __init__(self):
        self.gc_rows = array("q", [0]) * (GC_CAPACITY * GC_COLUMNS)
        self.points = array("q", [0]) * (POINT_CAPACITY * POINT_COLUMNS)
        self.counters = array("q", [0]) * 5
        self.ordinal = -1
        self.stage = 0
        self.first_callback_error = None
        self.snapshot = None
        self.camera_ownership = None

    def on_gc(self, event, info):
        try:
            timestamp = time.perf_counter_ns()
            used = self.counters[0]
            if used >= GC_CAPACITY:
                self.counters[1] += 1
                return
            if event not in ("start", "stop"):
                raise ValueError("Unexpected GC event")
            offset = used * GC_COLUMNS
            self.gc_rows[offset] = self.ordinal
            self.gc_rows[offset + 1] = self.stage
            self.gc_rows[offset + 2] = timestamp
            self.gc_rows[offset + 3] = int(event == "stop")
            self.gc_rows[offset + 4] = info["generation"]
            self.gc_rows[offset + 5] = info.get("collected", 0)
            self.gc_rows[offset + 6] = info.get("uncollectable", 0)
            self.counters[0] += 1
        except Exception as error:
            self.counters[2] += 1
            if self.first_callback_error is None:
                self.first_callback_error = type(error).__name__

    def point(self, name, qpc_ns, reading):
        used = self.counters[3]
        if used >= POINT_CAPACITY:
            self.counters[4] += 1
            return
        offset = used * POINT_COLUMNS
        self.points[offset] = self.ordinal
        self.points[offset + 1] = name
        self.points[offset + 2] = qpc_ns
        self.points[offset + 3] = reading[0]
        self.points[offset + 4] = reading[1]
        self.counters[3] += 1


def _class_identity(cls):
    return {
        "module": cls.__module__,
        "qualname": cls.__qualname__,
        "mro": [f"{parent.__module__}.{parent.__qualname__}" for parent in cls.__mro__],
    }


def _camera_ownership(lane):
    import bpy

    renderer = lane.renderer
    if lane.role == "I":
        renderer_owned = lane._session._renderer is renderer
        owner = "lane._session._renderer"
    else:
        renderer_owned = lane._b_renderer is renderer and lane._b_control._renderer is renderer
        owner = "lane._b_renderer / lane._b_control._renderer"
    cameras = []
    for camera in renderer.cameras:
        data = camera.data
        registered_object = bpy.data.objects.get(camera.name)
        registered_data = bpy.data.cameras.get(data.name)
        cameras.append({
            "name": camera.name,
            "data_name": data.name,
            "object_type": _class_identity(type(camera)),
            "data_type": _class_identity(type(data)),
            "is_bpy_types_object": isinstance(camera, bpy.types.Object),
            "is_bpy_types_camera_data": isinstance(data, bpy.types.Camera),
            "object_kind": camera.type,
            "camera_kind": data.type,
            "camera_points_to_registered_object": registered_object is not None
            and camera.as_pointer() == registered_object.as_pointer(),
            "object_data_points_to_registered_camera": registered_data is not None
            and data.as_pointer() == registered_data.as_pointer(),
        })
    return {
        "when": "after terminal allocation snapshot, before original lane cleanup",
        "renderer_owner_path": owner,
        "renderer_owned_by_lane": renderer_owned,
        "renderer_class": _class_identity(type(renderer)),
        "camera_relation": "renderer.cameras",
        "cameras": cameras,
        "native_allocation_bytes": None,
        "native_sizes_added_to_traced_current": False,
    }


@contextmanager
def _observations(observer):
    original_managed_hot = resources._managed_hot
    original_record_hot_point = resources._record_hot_point
    original_current_point = resources._current_point
    original_proof_summary = resources._proof_summary
    original_census = resources.backing_census
    original_trace_read = tracemalloc.get_traced_memory

    def managed_hot(lane, result, checkpoints):
        observer.stage = 1
        return original_managed_hot(lane, result, checkpoints)

    def record_hot_point(result, checkpoints, name, roots, *, reading=None):
        if name == "hot_outputs_held":
            observer.point(2, result["stamps_qpc_ns"]["t4"], reading)
            observer.stage = 2
        return original_record_hot_point(result, checkpoints, name, roots, reading=reading)

    def census(roots):
        result = original_census(roots)
        observer.point(3, time.perf_counter_ns(), original_trace_read())
        observer.stage = 3
        return result

    def release_read():
        reading = original_trace_read()
        observer.point(7, time.perf_counter_ns(), reading)
        if observer.ordinal == ENDPOINT:
            observer.stage = 8
            observer.snapshot = tracemalloc.take_snapshot()
            raise _EndpointReached
        observer.stage = 6
        return reading

    def current_point(stream, case_id, name, roots, reading=None):
        if name == "hot_outputs_held":
            resources.backing_census = census
            try:
                return original_current_point(stream, case_id, name, roots, reading)
            finally:
                resources.backing_census = original_census
        if name != "hot_outputs_released":
            return original_current_point(stream, case_id, name, roots, reading)
        tracemalloc.get_traced_memory = release_read
        try:
            try:
                result = original_current_point(stream, case_id, name, roots, reading)
            finally:
                tracemalloc.get_traced_memory = original_trace_read
        except _EndpointReached:
            try:
                observer.camera_ownership = _camera_ownership(roots.__self__)
            except Exception:
                observer.camera_ownership = {"error": traceback.format_exc()}
            raise
        observer.stage = 7
        return result

    def proof_summary(lane, outputs):
        if observer.stage != 3:
            return original_proof_summary(lane, outputs)
        observer.stage = 4
        result = original_proof_summary(lane, outputs)
        observer.point(5, time.perf_counter_ns(), original_trace_read())
        observer.stage = 5
        return result

    resources._managed_hot = managed_hot
    resources._record_hot_point = record_hot_point
    resources._current_point = current_point
    resources._proof_summary = proof_summary
    try:
        yield
    finally:
        resources._managed_hot = original_managed_hot
        resources._record_hot_point = original_record_hot_point
        resources._current_point = original_current_point
        resources._proof_summary = original_proof_summary


def _save_observations(out_dir, observer):
    with (out_dir / "phase_observations.jsonl").open("x", encoding="utf-8", newline="\n") as stream:
        for idx in range(observer.counters[3]):
            offset = idx * POINT_COLUMNS
            ordinal, name, stamp, current, peak = observer.points[offset:offset + POINT_COLUMNS]
            resources._write(stream, {"ordinal": ordinal, "phase": POINT_NAMES[name], "phase_id": name,
                                      "qpc_ns": stamp, "current_bytes": current, "peak_bytes": peak})
    with (out_dir / "gc_events.jsonl").open("x", encoding="utf-8", newline="\n") as stream:
        for idx in range(observer.counters[0]):
            offset = idx * GC_COLUMNS
            ordinal, stage, stamp, event, generation, collected, uncollectable = (
                observer.gc_rows[offset:offset + GC_COLUMNS]
            )
            resources._write(stream, {"ordinal": ordinal, "phase": GC_STAGE_NAMES[stage], "phase_id": stage,
                                      "qpc_ns": stamp, "event": "stop" if event else "start",
                                      "generation": generation, "collected": collected,
                                      "uncollectable": uncollectable})


def _save_json(path, data):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(data, stream, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write("\n")


def _save_snapshot(out_dir, snapshot):
    snapshot.dump(str(out_dir / "endpoint.snapshot"))
    stats = {"traceback_limit": snapshot.traceback_limit}
    for group in ("traceback", "filename", "lineno"):
        stats[group] = [
            {"size_bytes": row.size, "count": row.count,
             "traceback": [{"filename": frame.filename, "lineno": frame.lineno} for frame in row.traceback]}
            for row in snapshot.statistics(group)
        ]
    stats["trace_count"] = len(snapshot.traces)
    stats["total_size_bytes"] = sum(row["size_bytes"] for row in stats["traceback"])
    _save_json(out_dir / "snapshot_statistics.json", stats)
    return {key: stats[key] for key in ("traceback_limit", "trace_count", "total_size_bytes")}


def run(formal_manifest_path, out_dir, role):
    import bpy
    import gpu
    from human_eye_fast import raycast_saccade_gpu

    if not bpy.app.background or role not in ("B", "I"):
        raise RuntimeError("Expected one registered B or I background Blender process")
    if not gc.isenabled() or tracemalloc.is_tracing():
        raise RuntimeError("Expected GC enabled and no tracing before the registered diagnostic")
    formal_manifest_path, out_dir = Path(formal_manifest_path), Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=False)
    manifest_data = formal_manifest_path.read_bytes()
    manifest = json.loads(manifest_data)
    config = manifest["resource"]
    if manifest["seeds"][PROCESS_INDEX]["seed"] != SEED or config["interval_ns"] != 2_000_000:
        raise ValueError("The formal seed or resource configuration has changed")
    observer = _Recorder()
    callback = observer.on_gc
    thresholds = gc.get_threshold()
    statuses = Counter()
    visited = 0
    loaded = 0
    errors = 0
    trace_depth = None
    run_error = None
    try:
        with ExitStack() as stack:
            records = stack.enter_context((out_dir / "cases.jsonl").open("x", encoding="utf-8", newline="\n"))
            checkpoints = stack.enter_context((out_dir / "checkpoints.jsonl").open("x", encoding="utf-8", newline="\n"))
            stack.enter_context(_observations(observer))
            gc.callbacks.append(callback)
            stack.callback(gc.callbacks.remove, callback)
            tracemalloc.start()
            stack.callback(tracemalloc.stop)
            trace_depth = tracemalloc.get_traceback_limit()
            resources._current_point(checkpoints, None, "cold_before_workload_load", dict)
            cases = resources.load_workload(formal_manifest_path, PROCESS_INDEX)
            loaded = len(cases)
            if loaded != 24:
                raise RuntimeError("Expected the original complete 24-case workload")
            resources._current_point(checkpoints, None, "cold_after_workload_load",
                                     lambda: {"immutable_deployment_parameters": cases[0].deployment})
            for case in cases:
                if case.ordinal != visited or case.ordinal > ENDPOINT:
                    raise RuntimeError("Unexpected registered prefix order")
                observer.ordinal = case.ordinal
                observer.stage = 0
                result = {"case": case.case_id, "ordinal": case.ordinal, "family": case.family,
                          "role": role, "instrument": "managed"}
                try:
                    resources._case_work(case, role, "managed", result, checkpoints, None, None, None, config)
                except _EndpointReached:
                    if case.ordinal != ENDPOINT or observer.snapshot is None:
                        raise
                    result["status"] = "DIAGNOSTIC_ENDPOINT"
                    result["managed"]["current_bytes"]["hot_outputs_released"] = (
                        observer.points[(observer.counters[3] - 1) * POINT_COLUMNS + 3]
                    )
                    result["terminal_census_omitted"] = True
                except Exception:
                    result["status"] = "UNVERIFIED"
                    result["error"] = traceback.format_exc()
                    errors += 1
                statuses[result["status"]] += 1
                resources._write(records, result)
                del result
                visited += 1
                if case.ordinal == ENDPOINT:
                    break
    except Exception:
        run_error = traceback.format_exc()

    snapshot_meta = _save_snapshot(out_dir, observer.snapshot) if observer.snapshot is not None else None
    if observer.camera_ownership is not None:
        _save_json(out_dir / "camera_ownership.json", observer.camera_ownership)
    _save_observations(out_dir, observer)
    point_order = [
        (observer.points[index * POINT_COLUMNS], observer.points[index * POINT_COLUMNS + 1])
        for index in range(observer.counters[3])
    ]
    complete = (
        run_error is None and errors == 0 and statuses["FAIL"] == 0 and visited == ENDPOINT + 1
        and snapshot_meta is not None and observer.counters[1] == observer.counters[2] == observer.counters[4] == 0
        and point_order == [(ordinal, name) for ordinal in range(ENDPOINT + 1) for name in POINT_NAMES]
        and trace_depth == 1 and gc.isenabled() and gc.get_threshold() == thresholds
    )
    try:
        gpu_identity = {"gpu_backend": gpu.platform.backend_type_get(), "gpu_renderer": gpu.platform.renderer_get()}
    except SystemError as error:
        gpu_identity = {"gpu_backend": None, "gpu_renderer": None, "gpu_identity_error": repr(error)}
    summary = {
        "scope": "fixed-prefix attribution diagnostic; no formal gate is recomputed",
        "status": "COMPLETE" if complete else "INCOMPLETE",
        "role": role,
        "seed": SEED,
        "process_index": PROCESS_INDEX,
        "pid": os.getpid(),
        "formal_manifest_sha256": resources._identity(manifest_data)["sha256"],
        "loaded_case_count": loaded,
        "visited_cases": visited,
        "original_warm_pairs": list(resources.WARM_PAIRS),
        "original_hot_pair": resources.HOT_PAIR,
        "untimed_lifecycle_pairs": [resources.CLOSE_LIFECYCLE_PAIR, resources.REOPEN_LIFECYCLE_PAIR],
        "terminal_ordinal": ENDPOINT,
        "terminal_boundary": "after original hot_outputs_released trace read; before terminal census, report, and reference replacement",
        "case_status_counts": dict(statuses),
        "case_errors": errors,
        "run_error": run_error,
        "clock": vars(time.get_clock_info("perf_counter")),
        "gc": {"enabled_after": gc.isenabled(), "threshold_before": thresholds, "threshold_after": gc.get_threshold(),
               "capacity": GC_CAPACITY, "recorded": observer.counters[0], "overflow": observer.counters[1],
               "callback_errors": observer.counters[2], "first_error_type": observer.first_callback_error,
               "stage_names": GC_STAGE_NAMES, "allocation": "preallocated seven-column signed 64-bit numeric buffer"},
        "observations": {"capacity": POINT_CAPACITY, "recorded": observer.counters[3],
                         "overflow": observer.counters[4], "phase_ids": POINT_NAMES},
        "traceback_limit": trace_depth,
        "snapshot": snapshot_meta,
        "camera_ownership_available": bool(observer.camera_ownership and "error" not in observer.camera_ownership),
        "renderer_module": raycast_saccade_gpu.__name__,
        **gpu_identity,
        "instrumentation": [
            "Additional wrappers, QPC calls and integer buffer writes can perturb allocation and GC scheduling.",
            "t4 and released bytes come from the original tracemalloc reads; the held and proof observations are immediately after their computation and before their original reporting assignments.",
            "The endpoint snapshot is taken once after the original released read and before camera inspection or terminal reporting.",
            "Snapshot statistics retain the original one-frame tracing depth and cannot establish historical allocation ownership or a GC cause by themselves.",
        ],
    }
    _save_json(out_dir / "summary.json", summary)
    if not complete:
        raise RuntimeError("Diagnostic prefix did not complete. Partial evidence was retained.")
    return summary
