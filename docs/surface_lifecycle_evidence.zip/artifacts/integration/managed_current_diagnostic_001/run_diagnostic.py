"""Register and execute the fixed two-process managed-current diagnostic once."""

from argparse import ArgumentParser
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback
from zipfile import ZIP_DEFLATED, ZipFile


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
FORMAL = HERE.parent / "formal_cost_001" / "formal"
PROTOCOL = ROOT / "docs/MANAGED_CURRENT_DIAGNOSTIC_PROTOCOL.md"
FORMAL_MANIFEST = FORMAL / "manifest.json"
FORMAL_MANIFEST_SHA = "093a0df0ea941eb7cc6bd1206490627ca8196e0951fff18e6601fb513816e8c7"
FORMAL_INDEX_SHA = "05d93ebe31677cef58a1d722e8833abbfd3a9a60ec46c34f09bccf8ed493c91a"
PRODUCTION_BASE = "79f8bcc"
ROLES = ("B", "I")
sys.path.insert(0, str(ROOT))

from artifacts.integration.method_diagnostic_001.runtime_identity import (
    clock_anchor, effective_environment, identity, native_fingerprint, write_json,
)


def _read(path):
    return json.loads(path.read_bytes())


def _relative(path):
    return path.resolve().relative_to(ROOT).as_posix()


def _digest(data):
    return sha256(data).hexdigest()


def _sources(formal):
    archived = formal["source_superset"]
    files = {name: (ROOT / name).read_bytes() for name in archived}
    for name, data in files.items():
        if _digest(data) != archived[name]:
            raise RuntimeError(f"Frozen formal source changed: {name}")
    for path in [PROTOCOL, *HERE.glob("*.py")]:
        files[_relative(path)] = path.read_bytes()
    return files


def _verify_inputs(files):
    for name, expected in files.items():
        if identity(ROOT / name)["sha256"] != expected:
            raise RuntimeError(f"Registered input changed: {name}")


def _original_roles(formal):
    return {row["role"]: row for row in formal["jobs"]
            if row["kind"] == "managed" and row["seed"] == 310519}


def _reference_inputs():
    files = {}
    index = _read(FORMAL / "artifact-identity.json")["files"]
    assert identity(FORMAL / "artifact-identity.json")["sha256"] == FORMAL_INDEX_SHA
    for seed in (20261105, 79463, 310519):
        for role in ROLES:
            for suffix in ("cases.jsonl", "checkpoints.jsonl"):
                name = f"managed-{seed}-{role}/result/{suffix}"
                files[_relative(FORMAL / name)] = index[name]["sha256"]
    return {_relative(FORMAL / "artifact-identity.json"): FORMAL_INDEX_SHA, **files}


def register():
    from artifacts.integration.managed_current_diagnostic_001 import worker

    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    if not head.startswith(PRODUCTION_BASE):
        raise RuntimeError(f"Expected the frozen production base {PRODUCTION_BASE}, got {head}")
    assert identity(FORMAL_MANIFEST)["sha256"] == FORMAL_MANIFEST_SHA
    formal = _read(FORMAL_MANIFEST)
    executable = formal["runtime_registration"]["blender_executable"]
    assert identity(executable["path"]) == executable
    source_bytes = _sources(formal)
    source_ids = {name: _digest(payload) for name, payload in source_bytes.items()}
    original = _original_roles(formal)
    assert tuple(original) == ROLES
    inputs = _reference_inputs()
    inputs[_relative(FORMAL_MANIFEST)] = FORMAL_MANIFEST_SHA
    inputs[_relative(PROTOCOL)] = source_ids[_relative(PROTOCOL)]
    _verify_inputs(inputs)
    path = HERE / "manifest.json"
    jobs = []
    for role in ROLES:
        folder = HERE / role
        if folder.exists():
            raise FileExistsError(folder)
        prior = original[role]
        overrides = {**prior["environment_overrides"],
                     "PYTHONPYCACHEPREFIX": str(folder / "isolated-pycache")}
        effective = effective_environment({**os.environ, **overrides})
        old_effective = dict(prior["environment_effective"])
        old_effective["PYTHONPYCACHEPREFIX"] = overrides["PYTHONPYCACHEPREFIX"]
        if effective != old_effective:
            raise RuntimeError(f"Effective environment differs from frozen managed job for {role}")
        files = {**prior["input_files"], **inputs}
        _verify_inputs(files)
        argv = [executable["path"], "--background", "--factory-startup", "--disable-autoexec",
                "--threads", "1", "--python-exit-code", "1", "--python", str(Path(__file__).resolve()),
                "--", "--worker", str(path), role]
        jobs.append({"role": role, "argv": argv, "input_files": files,
                     "environment_overrides": overrides, "environment_effective": effective})
    manifest = {
        "scope": "fixed seed 310519 managed current attribution only, no formal gate rerun",
        "protocol": identity(PROTOCOL), "production_head": head,
        "formal_manifest": _relative(FORMAL_MANIFEST), "formal_manifest_sha256": FORMAL_MANIFEST_SHA,
        "source_superset": source_ids, "jobs": jobs,
        "runtime_registration": {"blender_executable": executable,
                                 "native_expected": formal["runtime_registration"]["native_expected"],
                                 "launcher_python": identity(sys.executable), "launcher_python_version": sys.version},
        "execution": {"seed": 310519, "load_case_count": 24, "case_ordinals": list(range(8)),
                      "warm_pairs": formal["resource"]["warm_pairs"], "hot_pair": formal["resource"]["hot_pair"],
                      "full_lifecycle_ordinals": list(range(7)),
                      "lifecycle_pairs": formal["resource"]["lifecycle_pairs"],
                      "endpoint": "ordinal 7 hot_outputs_released current read, before census and reference replacement",
                      "snapshots_per_process": 1, "active_gc_collect_calls": 0, "traceback_limit": 1,
                      "gc_buffer": {"capacity": worker.GC_CAPACITY, "columns": worker.GC_COLUMNS,
                                    "storage": "signed 64-bit array", "stage_names": worker.GC_STAGE_NAMES},
                      "phase_buffer": {"capacity": worker.POINT_CAPACITY, "columns": worker.POINT_COLUMNS,
                                       "storage": "signed 64-bit array", "phase_names": worker.POINT_NAMES}},
        "original_managed_over_gate_points_unchanged": 33,
    }
    with ZipFile(HERE / "sources.zip", "x", compression=ZIP_DEFLATED) as archive:
        for name, data in source_bytes.items():
            archive.writestr(name, data)
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(manifest, stream, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write("\n")
    print(f"Registered two diagnostic processes: {identity(path)['sha256']}", flush=True)
    return path


def _observed_project():
    files = {Path(raw).resolve() for module in tuple(sys.modules.values())
             if (raw := getattr(module, "__file__", None))}
    files.add(Path(__file__).resolve())
    return {_relative(path): identity(path)["sha256"] for path in sorted(files)
            if path.is_relative_to(ROOT) and path.is_file()}


def _worker(manifest_path, role):
    manifest = _read(manifest_path)
    sys.dont_write_bytecode = True
    sys.pycache_prefix = os.environ["PYTHONPYCACHEPREFIX"]
    out = HERE / role
    anchor = clock_anchor()
    try:
        from artifacts.integration.managed_current_diagnostic_001.worker import run

        run(ROOT / manifest["formal_manifest"], out / "result", role)
    finally:
        write_json(out / "project-imports.json", {"scope": "observed project imports at exit",
                                                "paths": _observed_project()})
        try:
            write_json(out / "runtime.json", native_fingerprint(anchor))
        except Exception:
            (out / "runtime-error.txt").write_text(traceback.format_exc(), encoding="utf-8")


def _same_sources(manifest):
    try:
        return all(identity(ROOT / name)["sha256"] == sha for name, sha in manifest["source_superset"].items())
    except OSError:
        return False


def _execute_job(job, manifest_path, manifest, registered):
    role = job["role"]
    if identity(manifest_path) != registered or not _same_sources(manifest):
        raise RuntimeError("Diagnostic source or preregistration changed before worker launch")
    _verify_inputs(job["input_files"])
    env = {**os.environ, **job["environment_overrides"]}
    if effective_environment(env) != job["environment_effective"]:
        raise RuntimeError("Diagnostic environment changed after registration")
    out = HERE / role
    out.mkdir()
    write_json(out / "launch.json", {**job, "manifest": registered})
    print(f"Starting fixed 310519 role {role}", flush=True)
    with (out / "worker.log").open("wb") as stream:
        process = subprocess.run(job["argv"], cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT,
                                 check=False)
    runtime_path, imports_path = out / "runtime.json", out / "project-imports.json"
    runtime = _read(runtime_path) if runtime_path.is_file() else {}
    observed = _read(imports_path)["paths"] if imports_path.is_file() else {}
    mismatches = [name for name, sha in observed.items() if manifest["source_superset"].get(name) != sha]
    try:
        _verify_inputs(job["input_files"])
        stable_inputs = identity(manifest_path) == registered
    except (OSError, RuntimeError):
        stable_inputs = False
    expected = manifest["runtime_registration"]["native_expected"]
    result = {"role": role, "exit_code": process.returncode, "stable_sources": _same_sources(manifest),
              "stable_inputs": stable_inputs, "observed_project_imports": len(observed),
              "import_discrepancies": mismatches,
              "runtime_matches": bool(runtime and runtime["environment"] == job["environment_effective"]
                                      and all(runtime[key] == value for key, value in expected.items()))}
    result["verified_process"] = bool(result["exit_code"] == 0 and result["stable_sources"] and stable_inputs
                                      and observed and not mismatches and result["runtime_matches"])
    write_json(out / "process.json", result)
    print(json.dumps(result), flush=True)
    return result


def execute(manifest_path):
    manifest = _read(manifest_path)
    registered = identity(manifest_path)
    assert tuple(job["role"] for job in manifest["jobs"]) == ROLES
    with (HERE / "batch-started.json").open("x", encoding="utf-8") as stream:
        json.dump({"manifest": registered, "start": clock_anchor()}, stream)
    results = [_execute_job(job, manifest_path, manifest, registered) for job in manifest["jobs"]]
    passed = all(result["verified_process"] for result in results)
    write_json(HERE / "batch-processes.json", {"verified_processes": passed, "processes": results,
                                              "end": clock_anchor()})
    return 0 if passed else 1


def main():
    if "--worker" in sys.argv:
        start = sys.argv.index("--worker")
        _worker(Path(sys.argv[start + 1]), sys.argv[start + 2])
        return 0
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=("register", "execute"))
    args = parser.parse_args()
    if args.operation == "register":
        register()
        return 0
    return execute(HERE / "manifest.json")


if __name__ == "__main__":
    status = main()
    if status:
        raise SystemExit(status)
