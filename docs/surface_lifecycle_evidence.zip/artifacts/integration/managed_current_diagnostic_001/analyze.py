"""Compare the two bounded managed-current observations offline."""

from argparse import ArgumentParser
from collections import Counter
from hashlib import file_digest
import json
import linecache
from pathlib import Path
from pickle import UnpicklingError
import tracemalloc


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
FORMAL = HERE.parent / "formal_cost_001" / "formal"
ROLES = ("B", "I")
SEEDS = (20261105, 79463, 310519)
CURRENT_LIMIT = 262_144
PEAK_LIMIT = 1_048_576
FORMAL_POINTS = ("hot_outputs_held", "hot_outputs_released", "hot_reference_replaced")
PHASES = ("t4_original", "held_census_complete", "proof_summary_complete", "released_original")
GROUPS = ("production", "verification_reporting", "numpy", "host_runtime", "unattributed")
MEASURES = ("B_bytes", "I_bytes", "I_minus_B_bytes", "B_blocks", "I_blocks", "I_minus_B_blocks")


def _read(path):
    return json.loads(path.read_bytes())


def _lines(path):
    with path.open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream if line.strip()]


def _write(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write("\n")


def _identity(path):
    with path.open("rb") as stream:
        return {"path": str(path), "bytes": path.stat().st_size,
                "sha256": file_digest(stream, "sha256").hexdigest()}


def _cases(rows):
    result = {row["ordinal"]: row for row in rows}
    if len(result) != len(rows):
        raise ValueError("Duplicate case ordinal")
    return result


def _formal(out):
    values, peaks, inputs = [], [], []
    for seed in SEEDS:
        arms = {}
        for role in ROLES:
            path = FORMAL / f"managed-{seed}-{role}" / "result/cases.jsonl"
            inputs.append(_identity(path))
            arms[role] = _cases(_lines(path))
            if set(arms[role]) != set(range(24)):
                raise ValueError(f"Incomplete formal case set: {path}")
        for ordinal in range(24):
            b, i = (arms[role][ordinal] for role in ROLES)
            if b["case"] != i["case"]:
                raise ValueError(f"Formal case identity differs for {seed} ordinal {ordinal}")
            key = {"seed": seed, "ordinal": ordinal, "case": b["case"]}
            for point in FORMAL_POINTS:
                b_bytes, i_bytes = (row["managed"]["current_bytes"][point] for row in (b, i))
                delta = i_bytes - b_bytes
                values.append({**key, "point": point, "B_bytes": b_bytes, "I_bytes": i_bytes,
                               "I_minus_B_bytes": delta, "above_original_limit": delta > CURRENT_LIMIT})
            b_peak, i_peak = (row["managed"]["window_peak_bytes"] for row in (b, i))
            peaks.append({**key, "B_bytes": b_peak, "I_bytes": i_peak, "I_minus_B_bytes": i_peak - b_peak})
    exceedances = [row for row in values if row["above_original_limit"]]
    counts = Counter(row["point"] for row in exceedances)
    worst = max(values, key=lambda row: row["I_minus_B_bytes"])
    peak = max(peaks, key=lambda row: row["I_minus_B_bytes"])
    original = {
        "source_inputs": inputs, "current_limit_bytes": CURRENT_LIMIT, "peak_limit_bytes": PEAK_LIMIT,
        "matching_windows": len(peaks), "current_points": len(values),
        "original_current_exceedances": len(exceedances),
        "exceedance_counts": {point: counts[point] for point in FORMAL_POINTS},
        "largest_original_current_delta": worst, "largest_original_window_peak_delta": peak,
        "case_7_current": [row for row in values if (row["seed"], row["ordinal"]) == (310519, 7)],
    }
    _write(out / "formal-current-unchanged.json", {
        **original, "current_rows": values, "window_peak_rows": peaks, "exceedances": exceedances,
    })
    return original


def _try_read(path, reader, errors):
    try:
        return reader(path)
    except (OSError, ValueError, EOFError, UnpicklingError) as error:
        errors.append({"file": str(path), "error": repr(error)})
        return None


def _read_role(path):
    errors, data = [], {}
    for key, filename, reader in (
        ("summary", "summary.json", _read),
        ("phases", "phase_observations.jsonl", _lines),
        ("gc", "gc_events.jsonl", _lines),
        ("cases", "cases.jsonl", _lines),
        ("camera", "camera_ownership.json", _read),
        ("snapshot", "endpoint.snapshot", tracemalloc.Snapshot.load),
    ):
        data[key] = _try_read(path / filename, reader, errors)
    data["errors"] = errors
    data["path"] = str(path)
    return data


def _paired_phases(arms):
    indices = {}
    anomalies = {}
    for role in ROLES:
        rows = arms[role]["phases"] or []
        indices[role] = {(row["ordinal"], row["phase"]): row for row in rows}
        expected = {(ordinal, phase) for ordinal in range(8) for phase in PHASES}
        anomalies[role] = {
            "duplicates": len(rows) - len(indices[role]),
            "missing": sorted(expected - indices[role].keys()),
            "unexpected": sorted(indices[role].keys() - expected),
        }
    result = []
    for ordinal in range(8):
        prior = {role: None for role in ROLES}
        for phase in PHASES:
            sides = {}
            for role in ROLES:
                row = indices[role].get((ordinal, phase))
                previous = prior[role]
                sides[role] = None if row is None else {
                    **row, "change_since_previous_phase_bytes": (
                        row["current_bytes"] - previous["current_bytes"] if previous else None),
                    "elapsed_since_previous_phase_ns": row["qpc_ns"] - previous["qpc_ns"] if previous else None,
                }
                prior[role] = row
            b, i = (sides[role] for role in ROLES)
            delta = i["current_bytes"] - b["current_bytes"] if b and i else None
            b_change, i_change = (sides[role]["change_since_previous_phase_bytes"]
                                  if sides[role] else None for role in ROLES)
            result.append({"ordinal": ordinal, "phase": phase, **sides, "I_minus_B_bytes": delta,
                           "I_minus_B_phase_change_bytes": (i_change - b_change
                                                            if None not in (b_change, i_change) else None)})
    return result, anomalies, indices


def _gc_timeline(rows, phases, case_rows):
    active, collections, unpaired = {}, [], []
    for index, row in enumerate(rows):
        event, generation = row["event"], row["generation"]
        if event == "start":
            if generation in active:
                unpaired.append({"index": active[generation][0], "reason": "replaced_start"})
            active[generation] = index, row
        elif event == "stop" and generation in active:
            start_index, start = active.pop(generation)
            collections.append({
                "generation": generation, "start_index": start_index, "stop_index": index,
                "start_qpc_ns": start["qpc_ns"], "stop_qpc_ns": row["qpc_ns"],
                "elapsed_ns": row["qpc_ns"] - start["qpc_ns"],
                "start_ordinal": start["ordinal"], "stop_ordinal": row["ordinal"],
                "start_phase": start["phase"], "stop_phase": row["phase"],
                "collected": row["collected"], "uncollectable": row["uncollectable"],
            })
        else:
            unpaired.append({"index": index, "reason": "stop_without_start_or_unknown_event"})
    unpaired.extend({"index": item[0], "reason": "start_without_stop"} for item in active.values())
    cases = _cases(case_rows)
    windows = []
    for ordinal in range(8):
        t0 = cases.get(ordinal, {}).get("stamps_qpc_ns", {}).get("t0")
        points = [("t0", t0), *((phase, phases.get((ordinal, phase), {}).get("qpc_ns"))
                               for phase in PHASES)]
        for (left, start), (right, end) in zip(points, points[1:]):
            if None in (start, end):
                continue
            overlaps = []
            for collection in collections:
                elapsed = min(end, collection["stop_qpc_ns"]) - max(start, collection["start_qpc_ns"])
                if elapsed > 0:
                    overlaps.append({"start_event_index": collection["start_index"],
                                     "stop_event_index": collection["stop_index"], "overlap_ns": elapsed})
            windows.append({"ordinal": ordinal, "from": left, "to": right, "start_qpc_ns": start,
                            "end_qpc_ns": end, "overlapping_collections": overlaps})
    return {"raw_event_count": len(rows), "paired_collection_count": len(collections),
            "unpaired_events": unpaired, "collections": collections, "phase_windows": windows}


def _source_group(filename):
    path = filename.replace("\\", "/").casefold()
    root = ROOT.as_posix().casefold() + "/"
    if path.startswith(root):
        path = path[len(root):]
    if path.startswith("human_eye_fast/"):
        return "production"
    if path.startswith(("verification/", "artifacts/integration/")):
        return "verification_reporting"
    if path.startswith("numpy/") or "/numpy/" in path:
        return "numpy"
    if ("blender foundation/" in path or "/blender/" in path or
            path.startswith(("<frozen ", "_bpy", "bpy/", "mathutils/"))):
        return "host_runtime"
    return "unattributed"


def _source_line(filename, lineno):
    if _source_group(filename) not in ("production", "verification_reporting"):
        return None
    path = ROOT / filename
    if path.resolve().is_relative_to(ROOT):
        return linecache.getline(str(path), lineno).strip() or None
    return None


def _stats(snapshot, key_type):
    return {tuple((frame.filename, frame.lineno) for frame in item.traceback): (item.size, item.count)
            for item in snapshot.statistics(key_type)}


def _sizes(b_bytes, i_bytes, b_count, i_count):
    return dict(zip(MEASURES, (b_bytes, i_bytes, i_bytes - b_bytes,
                               b_count, i_count, i_count - b_count), strict=True))


def _domains(arms):
    sizes, counts = {}, {}
    for role in ROLES:
        sizes[role], counts[role] = Counter(), Counter()
        for trace in arms[role]["snapshot"].traces:
            sizes[role][trace.domain] += trace.size
            counts[role][trace.domain] += 1
    return {str(key): _sizes(sizes["B"][key], sizes["I"][key], counts["B"][key], counts["I"][key])
            for key in sorted(counts["B"].keys() | counts["I"].keys())}


def _diff_snapshots(arms, out):
    if any(arms[role]["snapshot"] is None for role in ROLES):
        return {"comparable": False, "reason": "At least one raw snapshot is missing or unreadable"}
    result = {"comparable": True, "traceback_frame_limit": {
        role: arms[role]["snapshot"].traceback_limit for role in ROLES},
        "attribution_rule": "Most recent recorded allocation frame only. Categories do not identify who retained a live object.",
        "tracemalloc_domains": _domains(arms),
        "snapshot_inputs": {role: _identity(Path(arms[role]["path"]) / "endpoint.snapshot") for role in ROLES},
        "statistics": {},
    }
    for key_type in ("traceback", "filename", "lineno"):
        b, i = (_stats(arms[role]["snapshot"], key_type) for role in ROLES)
        grouped = {key: Counter(dict.fromkeys(MEASURES, 0)) for key in GROUPS}
        rows = []
        for traceback in b.keys() | i.keys():
            b_bytes, b_count = b.get(traceback, (0, 0))
            i_bytes, i_count = i.get(traceback, (0, 0))
            filename, lineno = traceback[-1]
            group = _source_group(filename)
            size = _sizes(b_bytes, i_bytes, b_count, i_count)
            grouped[group].update(size)
            rows.append({"frames_oldest_to_most_recent": traceback, "group": group,
                         "allocation_line": _source_line(filename, lineno), **size})
        rows.sort(key=lambda row: (-abs(row["I_minus_B_bytes"]), row["frames_oldest_to_most_recent"]))
        name = f"snapshot-diff-{key_type}.jsonl"
        with (out / name).open("x", encoding="utf-8", newline="\n") as stream:
            for row in rows:
                stream.write(json.dumps(row, ensure_ascii=False, allow_nan=False, separators=(",", ":")) + "\n")
        totals = Counter()
        for sizes in grouped.values():
            totals.update(sizes)
        result["statistics"][key_type] = {
            "details": name, "union_rows": len(rows), "totals": dict(totals),
            "allocation_groups": {key: dict(grouped[key]) for key in GROUPS},
        }
    return result


def _readme(path, summary):
    original, endpoint = summary["original_formal"], summary["diagnostic_endpoint"]
    lines = [
        "# 托管常驻限定归因诊断", "",
        f"原正式轮保留 {original['original_current_exceedances']} 个超门点，最大 I−B "
        f"{original['largest_original_current_delta']['I_minus_B_bytes']:,} B。",
        "下面的单次诊断单列，整机结论交主干复审。", "",
        "## Ordinal 7 阶段", "",
        "| 观测点 | B current (B) | I current (B) | I−B (B) |",
        "| --- | ---: | ---: | ---: |",
    ]
    for row in endpoint["phases"]:
        entries = [side["current_bytes"] if side else None for side in (row["B"], row["I"])]
        entries.append(row["I_minus_B_bytes"])
        lines.append(f"| {row['phase']} | " + " | ".join(
            "缺测" if item is None else f"{item:,}" for item in entries) + " |")
    snapshot = summary["snapshot"]
    lines.extend(("", "## 终点分配栈", ""))
    if snapshot["comparable"]:
        lines.extend(("按最靠近分配点的已记录栈帧分栏。栈记录可用于定位分配，存活持有链另行核证。",
                      "", "| 分栏 | B (B) | I (B) | I−B (B) |", "| --- | ---: | ---: | ---: |"))
        for group, row in snapshot["statistics"]["traceback"]["allocation_groups"].items():
            lines.append(f"| {group} | {row.get('B_bytes', 0):,} | {row.get('I_bytes', 0):,} | "
                         f"{row.get('I_minus_B_bytes', 0):,} |")
    else:
        lines.append("至少一侧快照缺失或无法读取。")
    lines.extend(("", "GC 关系按各进程自己的 QPC 计算。单次快照及 GC 时间重合只作归因线索。",
                  "[阶段全表](phase-comparison.json) · [GC 明细](gc-relationship.json) · "
                  "[原正式读数](formal-current-unchanged.json) · [完整诊断摘要](summary.json)", ""))
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write("\n".join(lines))


def run(b_dir, i_dir, out_dir):
    """Write a complete comparison without modifying either worker's output."""
    out = Path(out_dir).resolve()
    out.mkdir(parents=True)
    original = _formal(out)
    arms = {role: _read_role(Path(directory).resolve()) for role, directory in zip(ROLES, (b_dir, i_dir), strict=True)}
    phases, anomalies, indices = _paired_phases(arms)
    _write(out / "phase-comparison.json", {"rows": phases, "coverage": anomalies})
    timelines = {role: _gc_timeline(arms[role]["gc"] or [], indices[role], arms[role]["cases"] or [])
                 for role in ROLES}
    _write(out / "gc-relationship.json", timelines)
    snapshot = _diff_snapshots(arms, out)
    endpoint = [row for row in phases if row["ordinal"] == 7]
    released = endpoint[-1]["I_minus_B_bytes"]
    held = endpoint[0]["I_minus_B_bytes"]
    summary = {
        "scope": "Attribution diagnostic only. Retains every original formal current and peak result.",
        "seed": 310519, "original_formal": original, "phase_coverage": anomalies,
        "diagnostic_endpoint": {"phases": endpoint,
                                "released_delta_above_original_limit": (released > CURRENT_LIMIT if released is not None else None),
                                "held_to_released_delta_shift_bytes": (released - held if None not in (held, released) else None)},
        "arms": {role: {key: arms[role][key] for key in ("path", "summary", "camera", "errors")} for role in ROLES},
        "gc": {role: {key: timelines[role][key] for key in ("raw_event_count", "paired_collection_count",
                                                           "unpaired_events")} for role in ROLES},
        "snapshot": snapshot,
        "limits_of_evidence": ["One execution per role with additional fixed-buffer instrumentation.",
                               "Raw current and the subsequent snapshot are distinct observations.",
                               "GC overlap and an allocation frame do not establish the holder or the original cause.",
                               "No diagnostics are substituted for the original formal measurements."],
    }
    if snapshot["comparable"]:
        totals = snapshot["statistics"]["traceback"]["totals"]
        summary["diagnostic_endpoint"]["snapshot_minus_released_current_bytes"] = {
            role: totals[f"{role}_bytes"] - endpoint[-1][role]["current_bytes"]
            for role in ROLES if endpoint[-1][role] is not None}
    _write(out / "summary.json", summary)
    _readme(out / "README.md", summary)
    return summary


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--B", dest="b_dir", type=Path, default=HERE / "B/result")
    parser.add_argument("--I", dest="i_dir", type=Path, default=HERE / "I/result")
    parser.add_argument("--out", type=Path, default=HERE / "analysis")
    args = parser.parse_args()
    result = run(args.b_dir, args.i_dir, args.out)
    print(json.dumps({"summary": str(args.out / "summary.json"),
                      "released_I_minus_B_bytes": result["diagnostic_endpoint"]["phases"][-1]["I_minus_B_bytes"],
                      "snapshot_comparable": result["snapshot"]["comparable"]}))


if __name__ == "__main__":
    main()
