"""Preregister and run the three untimed production-F qualification workers."""

from argparse import ArgumentParser
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback
from zipfile import ZIP_DEFLATED, ZipFile


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT))

from artifacts.integration.method_diagnostic_001 import runtime_identity as runtime


BLENDER = Path(r"C:\Program Files\Blender Foundation\Blender 5.2\blender.exe")
SEEDS = (20261105, 79463, 310519)
ENTRY = Path(__file__).resolve()
HISTORICAL = ROOT / "artifacts/cf/formal_001"
DEPLOYMENTS = HERE.parent / "production_functional_001/deployments"
FORMAL = HERE.parent / "formal_cost_001"
LEGACY = FORMAL / "qualified_old_001"


def _relative(path):
    return Path(path).resolve().relative_to(ROOT).as_posix()


def _digest(data):
    return sha256(data).hexdigest()


def _source_bytes():
    paths = {
        *ROOT.glob("human_eye_fast/**/*.py"), *ROOT.glob("verification/**/*.py"), *HERE.glob("*.py"),
        FORMAL / "old_cf.py", Path(runtime.__file__),
        *(ROOT / "docs" / name for name in ("FORMAL_COST_REVIEW.md", "ENGINE_INTEGRATION_API.md",
                                            "CF_ACCEPTANCE_PROTOCOL.md", "INTEGRATION_COST_PROTOCOL.md")),
    }
    return {_relative(path): path.read_bytes() for path in sorted(paths)}


def _observed():
    paths = {Path(raw).resolve() for module in tuple(sys.modules.values())
             if (raw := getattr(module, "__file__", None))}
    paths.add(ENTRY)
    return {_relative(path): runtime.identity(path)["sha256"] for path in sorted(paths)
            if path.is_relative_to(ROOT) and path.is_file()}


def _run_worker(launch_path):
    sys.dont_write_bytecode = True
    sys.pycache_prefix = os.environ["PYTHONPYCACHEPREFIX"]
    from artifacts.integration.production_f_qualification_001 import worker
    import bpy

    assert bpy.app.background
    folder = launch_path.parent
    job = json.loads(launch_path.read_bytes())
    anchor = runtime.clock_anchor()
    try:
        worker.run(job, folder / "result")
    finally:
        runtime.write_json(folder / "observed-project-imports.json", {
            "scope": "Project imports observed at exit and explicit worker entry",
            "paths": _observed(),
        })
        try:
            runtime.write_json(folder / "runtime.json", runtime.native_fingerprint(anchor))
        except Exception:
            (folder / "runtime-error.txt").write_text(traceback.format_exc(), encoding="utf-8")


def _job(out, seed):
    historical = HISTORICAL / str(seed)
    legacy = LEGACY / f"old-qualification-{seed}"
    quality = "evaluation-completion" if seed == 20261105 else "evaluation"
    inputs = {
        "deployment": _relative(DEPLOYMENTS / f"{seed}.npz"),
        "evaluation_manifest": _relative(historical / "specs/manifest-evaluation.json"),
        "historical_summary": _relative(historical / quality / "summary.json"),
        "historical_records": _relative(historical / "evaluation/records.jsonl.gz"),
        "historical_media": _relative(historical / "evaluation/media.zip"),
        "legacy_f_ao_media": _relative(legacy / "result/public_proof.zip"),
    }
    legacy_summary = legacy / "result/summary.json"
    legacy_receipt = json.loads(legacy_summary.read_bytes())
    assert legacy_receipt["status"] == "PASS" and not legacy_receipt["timings_collected"]
    legacy_process = legacy / "process.json"
    assert json.loads(legacy_process.read_bytes())["verified_process"]
    deployed_summary = DEPLOYMENTS / "summary.json"
    deployed_record = json.loads(deployed_summary.read_bytes())["seeds"][str(seed)]["deployment_file"]
    deployed_identity = runtime.identity(ROOT / inputs["deployment"])
    assert inputs["deployment"] == deployed_record["path"]
    assert all(deployed_identity[key] == deployed_record[key] for key in ("sha256", "bytes"))
    directory = out / str(seed)
    launch_path = directory / "launch.json"
    overrides = {**runtime.THREAD_ENV, "PYTHONDONTWRITEBYTECODE": "1",
                 "PYTHONPYCACHEPREFIX": str(directory / "isolated-pycache")}
    environment = {**os.environ, **overrides}
    argv = [str(BLENDER), "--background", "--factory-startup", "--disable-autoexec",
            "--threads", "1", "--python-exit-code", "1", "--python", str(ENTRY), "--",
            "--registered-worker", str(launch_path)]
    old_source_archive = Path(legacy_receipt["original_executed_members"]["archive"])
    with ZipFile(old_source_archive) as baseline:
        assert all(_digest(baseline.read(name)) == expected
                   for name, expected in legacy_receipt["original_executed_members"]["member_sha256"].items())
    provenance = (LEGACY / "manifest.json", legacy_summary, legacy_process, old_source_archive, deployed_summary)
    return {"seed": seed, "argv": argv, "directory": _relative(directory), "inputs": inputs,
            "input_identities": {path: runtime.identity(ROOT / path) for path in inputs.values()},
            "provenance_identities": {_relative(path): runtime.identity(path) for path in provenance},
            "environment_overrides": overrides,
            "environment_effective": runtime.effective_environment(environment)}


def _verify_identities(records):
    return all(runtime.identity(ROOT / path) == identity for path, identity in records.items())


def _run_job(job, sources):
    folder = ROOT / job["directory"]
    folder.mkdir()
    runtime.write_json(folder / "launch.json", job)
    assert _source_bytes() == sources
    environment = {**os.environ, **job["environment_overrides"]}
    assert runtime.effective_environment(environment) == job["environment_effective"]
    assert _verify_identities(job["input_identities"]) and _verify_identities(job["provenance_identities"])
    print(f"Untimed production F seed {job['seed']} starting", flush=True)
    with (folder / "worker.log").open("wb") as log:
        proc = subprocess.run(job["argv"], cwd=ROOT, env=environment, stdout=log, stderr=subprocess.STDOUT,
                              check=False)
    reads_path = folder / "result/reads.jsonl"
    reads = [json.loads(line) for line in reads_path.read_bytes().splitlines()] if reads_path.exists() else []
    read_identities = {_relative(item["path"]): item for item in reads}
    observed_path = folder / "observed-project-imports.json"
    observed = json.loads(observed_path.read_bytes())["paths"] if observed_path.exists() else {}
    mismatches = [path for path, value in observed.items() if path not in sources or _digest(sources[path]) != value]
    runtime_path = folder / "runtime.json"
    runtime_record = json.loads(runtime_path.read_bytes()) if runtime_path.exists() else None
    stable_environment = bool(runtime_record and runtime_record["environment"] == job["environment_effective"])
    result_path = folder / "result/summary.json"
    result = json.loads(result_path.read_bytes()) if result_path.exists() else None
    checks = {"actual_input_reads_match": read_identities == job["input_identities"],
              "stable_sources": sources == _source_bytes(), "stable_inputs": _verify_identities(job["input_identities"]),
              "stable_provenance": _verify_identities(job["provenance_identities"]),
              "observed_import_identity": bool(observed and not mismatches),
              "runtime_environment_stable": stable_environment}
    passed = bool(proc.returncode == 0 and all(checks.values()) and result and result["passed"])
    record = {"seed": job["seed"], "exit_code": proc.returncode, "passed": passed, **checks,
              "observed_project_imports": len(observed), "import_discrepancies": mismatches,
              "cases": result["cases"] if result else None, "passed_cases": result["passed_cases"] if result else None}
    runtime.write_json(folder / "process.json", record)
    print(json.dumps(record), flush=True)
    return record


def launch(out):
    out = Path(out).resolve()
    if not out.is_relative_to(HERE) or out == HERE:
        raise ValueError("Use a fresh output directory inside production_f_qualification_001")
    subprocess.run(["git", "diff", "--exit-code", "79f8bcc", "--", "human_eye_fast"], cwd=ROOT, check=True)
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    out.mkdir()
    sources = _source_bytes()
    with ZipFile(out / "sources.zip", "x", compression=ZIP_DEFLATED) as archive:
        for name, value in sources.items():
            archive.writestr(name, value)
    jobs = [_job(out, seed) for seed in SEEDS]
    manifest = {
        "scope": "Original CF V-F 180 production observations, untimed and serial",
        "git_head_at_registration": head, "production_source_commit": "79f8bcc",
        "seed_order": list(SEEDS), "cases_per_seed": 60, "public_ao_alignment": ["observation_id", "image.path"],
        "legacy_ao": "Saved full F public AO from actual untimed old_qualification runner at 42ddcf2 path",
        "historical_png_and_audit": "Original held-out F archives and original independently scored ray proof",
        "geometry": "Current bridge checked against independent evaluated RNA and archived witness/face bindings",
        "learning": "No view ticket, no detected learning call, identical active bank/head arrays and writes",
        "executables": {"blender": runtime.identity(BLENDER), "launcher_python": runtime.identity(sys.executable)},
        "source_superset": {path: _digest(data) for path, data in sources.items()}, "jobs": jobs,
    }
    runtime.write_json(out / "manifest.json", manifest)
    results = [_run_job(job, sources) for job in jobs]
    passed = all(item["passed"] for item in results)
    runtime.write_json(out / "summary.json", {"passed": passed, "scope": manifest["scope"], "timings_collected": False,
                                             "processes": results})
    return 0 if passed else 1


def main():
    if "--registered-worker" in sys.argv:
        _run_worker(Path(sys.argv[sys.argv.index("--registered-worker") + 1]))
        return 0
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=HERE / "run_001")
    return launch(parser.parse_args().out)


if __name__ == "__main__":
    status = main()
    if status:
        raise SystemExit(status)
