"""Prove all original CF V-F cases through production, with no service clocks."""

from collections import Counter
from contextlib import ExitStack
import gzip
from io import BytesIO
import json
from pathlib import Path
import sys
import traceback
from types import SimpleNamespace
from zipfile import ZIP_STORED, ZipFile

import numpy as np

from artifacts.integration.formal_cost_001 import old_cf
from human_eye_fast import CaptureChange, MeshChange, ObservationRequest, load_cf_deployment
from human_eye_fast.cerebellar_flash import CerebellarFlash, ExperienceBank, LinearHead
from human_eye_fast.fast_affordance_out import ImageFact, _image, _row


ROOT = old_cf.ROOT
SCHEMA = old_cf.SCHEMA
COLUMNS = old_cf.COLUMNS
CHANGES = MeshChange.VERTICES | MeshChange.TRANSFORM | MeshChange.UNITS


def _snapshot(model):
    """Hash all active model arrays with dtype, shape and state metadata."""
    arrays = {"retrieval_scale": model.retrieval_scale}
    metadata = {}
    for name, head, bank in (("V", model.view_head, model.views), ("A", model.action_head, model.actions)):
        assert bank.writes == len(bank) == 240
        metadata[name] = {"writes": bank.writes, "capacity": bank.capacity, "quadratic": head.quadratic,
                          "regularization": head.regularization, "view": head.view}
        for field in ("mean", "scale", "weights"):
            arrays[f"{name}_head_{field}"] = getattr(head, field)
        for i, products in enumerate(head._products or ()):
            arrays[f"{name}_head_products_{i}"] = products
        for field in ("keys", "values", "known"):
            arrays[f"{name}_bank_{field}"] = getattr(bank, field)[:bank.writes]
    metadata["arrays"] = {name: {"dtype": value.dtype.str, "shape": value.shape,
                                 "sha256": old_cf._digest(value.tobytes())}
                          for name, value in arrays.items()}
    return metadata


def _observe_f(session, spec, changes):
    """Collect actual observed behavior and detect any learning call in the F request."""
    monitored = {method.__code__: method.__qualname__ for method in (
        CerebellarFlash.learn_view, CerebellarFlash.learn_action, ExperienceBank.append_view,
        ExperienceBank.append, LinearHead.learn_view, LinearHead.learn_action,
    )}
    calls = []

    def profile(frame, event, arg):
        if event == "call" and frame.f_code in monitored:
            calls.append(monitored[frame.f_code])

    previous = sys.getprofile()
    sys.setprofile(profile)
    try:
        result = session.observe(ObservationRequest(spec.episode_id, spec.mode, "F"), changes=changes)
    finally:
        sys.setprofile(previous)
    return result, calls


def _canonical(view):
    from mathutils import Vector
    from human_eye_fast.raycast_saccade_gpu import _EPS32, _FIXED, _ORBIT, _transverse

    axis = (Vector(view.point_b) - Vector(view.point_a)).normalized()
    u = _transverse(_FIXED, axis)
    u = u.normalized() if u.length_squared > _EPS32**2 else axis.orthogonal().normalized()
    v = axis.cross(u).normalized()
    return [tuple((c * u + s * v).normalized()) for c, s in _ORBIT]


def _audit(observed, archive, native, session):
    expected, score = archive["audit"], archive["score"]
    public = observed.view_audit
    assert public.canonical_index is None and public.order is None
    selection = expected["metadata"]["selection"]
    actual_direction = tuple(public.direction)
    assert actual_direction == tuple(selection["direction"])
    assert public.total_rays == expected["ray_count"] == archive["rays"] == len(expected["trace"])
    assert public.native_stop == expected["native_stop"] == archive["native_stop"]
    assert len(public.probes) == len(selection["probes"])
    for actual, archived in zip(public.probes, selection["probes"], strict=True):
        assert (actual.direction, actual.ray_count, actual.aperture_taps, actual.target_support) == (
            tuple(archived["direction"]), archived["ray_count"], archived["aperture_taps"],
            archived["target_support"],
        )
    readback = session._current.readback
    witness = readback.surface
    assert observed.frame_id == archive["frame_id"] == readback.frame_id == native.scene.frame_current
    assert list(native.targets) == archive["targets"] == list(readback.target_ids)
    assert (witness.distance_m, witness.triangle_a, witness.triangle_b,
            list(witness.point_a), list(witness.point_b)) == (
        archive["witness"]["distance_m"], archive["witness"]["face_a"], archive["witness"]["face_b"],
        archive["witness"]["point_a"], archive["witness"]["point_b"],
    )
    canonical = _canonical(witness)
    visited = [canonical.index(probe.direction) for probe in public.probes]
    assert expected["order"] == list(range(len(canonical))) and visited == expected["order"][:len(visited)]
    counts = Counter(ray["candidate"] for ray in expected["trace"])
    assert [(candidate, counts[candidate]) for candidate in counts] == [
        (index, probe.ray_count) for index, probe in zip(visited, public.probes, strict=True)
    ]
    selected = canonical.index(actual_direction)
    assert selected == expected["candidate"] == archive["candidate"]
    assert counts[selected] == expected["selected_rays"] == archive["selected_rays"]
    assert score["passed"] == archive["success"] and score["safe"] == archive["safe"]
    return {"visited_indices": visited, "selected_candidate": selected, "direction": actual_direction,
            "selected_rays": counts[selected], "total_rays": public.total_rays,
            "native_stop": public.native_stop, "pixel_pass": score["pixel_success"],
            "strict_pass": score["passed"], "safe": score["safe"]}


def _geometry(native, session, archived):
    """Check the production bridge and witness against independently evaluated RNA."""
    from verification.cf_native import mesh_pair
    from verification.test_bc_acceptance import surface_tolerance
    from verification.test_blender_control import _assert_witness

    snapshot = native.snapshot()
    observed = {key: session._controller.bridge.get(key) for key in native.objects}
    assert tuple(snapshot) == tuple(observed) == tuple(archived["mesh_ids"][1:])
    rows = {}
    counts = [0]
    for key, (vertices, triangles) in snapshot.items():
        mesh = observed[key]
        np.testing.assert_array_equal(mesh.world_m, vertices)
        np.testing.assert_array_equal(mesh.triangles, triangles)
        counts.append(len(triangles))
        rows[key] = {"world_vertices_m": vertices, "triangles": triangles}
    assert counts == archived["face_counts"]
    a, b = mesh_pair(observed, native.targets)
    budget = surface_tolerance(*a, *b)
    readback = session._current.readback
    _assert_witness(readback, rows, archived["expected"]["witness"]["distance_m"], budget)
    return {"object_ids": list(observed), "face_counts": counts,
            "evaluated_vertex_counts": [len(data[0]) for data in snapshot.values()],
            "world_rows_match_independent_RNA": True, "witness_geometry_budget_m": budget}


def _prove_case(spec, native, deployed, archived, original_png, legacy_ao, legacy_png, proof, record, stack):
    session, _ = old_cf._make_session(native, deployed, stack, old_cf._untimed)
    initial = _snapshot(session._model)
    original_model = old_cf._ModelReset(session._model, deployed)
    changes = dict.fromkeys(native.objects, CaptureChange(CHANGES))
    observed, learning_calls = _observe_f(session, spec, changes)
    prefix = spec.episode_id
    proof.writestr(f"{prefix}/production.ao.json", observed.ao_bytes)
    proof.writestr(f"{prefix}/reference.f.ao.json", legacy_ao)
    assert observed.observation_id == prefix and observed.image_status == "rendered"
    assert observed.view_ticket is None and not learning_calls
    assert set(observed.attachments) == {f"{prefix}.png"}
    png = observed.attachments[f"{prefix}.png"]
    proof.writestr(f"{prefix}/production.png", png)
    assert png == original_png == legacy_png
    assert old_cf._digest(png) == archived["png_sha256"] == archived["score"]["png_sha256"]
    actual = old_cf._normalize(observed.ao_bytes, ("view",), (prefix,))
    reference = old_cf._normalize(legacy_ao, ("view",), ("view",))
    assert old_cf._compact(actual) == old_cf._compact(reference)
    row, = old_cf._rows(actual)
    indices = {key: index for index, key in enumerate(actual[COLUMNS["package"]["object_ids"]])}
    metadata = archived["audit"]["metadata"]
    image = _image(_row, ImageFact("view.png", SimpleNamespace(metadata=metadata)), indices)
    assert old_cf._compact(row[COLUMNS["observation"]["image"]]) == old_cf._compact(image)
    record.update({"ao_production_sha256": old_cf._digest(observed.ao_bytes),
                   "ao_legacy_qualification_sha256": old_cf._digest(legacy_ao),
                   "ao_role_aligned_sha256": old_cf._digest(old_cf._compact(actual)),
                   "png_original_sha256": old_cf._digest(original_png),
                   "audit": _audit(observed, archived, native, session),
                   "geometry": _geometry(native, session, archived["audit"]),
                   "view_ticket": None, "learning_calls": learning_calls})
    final = _snapshot(session._model)
    assert initial == final
    original_model.verify_action(None, None, None, False)
    record.update({"model_arrays_initial": initial, "model_arrays_final": final})


def run(job, out_dir):
    from verification.cf_experiment import Inputs
    from verification.cf_fixtures import EpisodeSpec, build_fixture
    from verification.cf_native import materialize

    out = Path(out_dir)
    out.mkdir()
    inputs = Inputs(out)
    registered = job["inputs"]
    seed = job["seed"]
    deployment = load_cf_deployment(BytesIO(inputs.track(ROOT / registered["deployment"])))
    manifest = json.loads(inputs.track(ROOT / registered["evaluation_manifest"]))
    specs = [EpisodeSpec(**row) for row in manifest["episodes"] if row["head"] == "V"]
    assert len(specs) == 60 and all((s.seed, s.split, s.command) == (seed, "evaluation", None) for s in specs)
    ids = [s.episode_id for s in specs]
    quality = json.loads(inputs.track(ROOT / registered["historical_summary"]))["views"]["F"]
    assert [row["id"] for row in quality] == ids
    archives = {}
    with gzip.GzipFile(fileobj=BytesIO(inputs.track(ROOT / registered["historical_records"]))) as stream:
        for line in stream:
            row = json.loads(line)
            if row["id"] in ids and row.get("arm") == "F":
                archives[row["id"]] = row
    assert list(archives) == ids
    assert all(archives[row["id"]][key] == row[key] for row in quality for key in (
        "png_sha256", "rays", "candidate", "witness", "native_stop", "success", "safe",
    ))
    records = []
    with (ZipFile(BytesIO(inputs.track(ROOT / registered["historical_media"]))) as original,
          ZipFile(BytesIO(inputs.track(ROOT / registered["legacy_f_ao_media"]))) as legacy,
          ZipFile(out / "public_outputs.zip", "w", compression=ZIP_STORED) as proof,
          (out / "observations.jsonl").open("w", encoding="utf-8", newline="\n") as raw):
        canonical_schema = json.loads(old_cf._compact(SCHEMA))
        assert all(json.loads(z.read("ao-schema.json")) == canonical_schema for z in (original, legacy))
        proof.writestr("ao-schema.json", old_cf._compact(SCHEMA))
        for ordinal, spec in enumerate(specs):
            record = {"ordinal": ordinal, "case_id": spec.episode_id, "mode": spec.mode, "arm": "F"}
            try:
                with ExitStack() as stack:
                    native = stack.enter_context(materialize(build_fixture(spec)))
                    source = f"{ordinal:02d}/00/F"
                    _prove_case(spec, native, deployment, archives[spec.episode_id],
                                original.read(f"{spec.episode_id}/F.png"), legacy.read(f"{source}/view.ao.json"),
                                legacy.read(f"{source}/view.png"), proof, record, stack)
                record["passed"] = True
            except Exception:
                record.update({"passed": False, "error": traceback.format_exc()})
            records.append(record)
            raw.write(old_cf._compact(record).decode() + "\n")
            raw.flush()
    result = {"seed": seed, "passed": all(row["passed"] for row in records), "cases": len(records),
              "passed_cases": sum(row["passed"] for row in records), "timings_collected": False,
              "production_F_only": True, "ao_comparator": "Saved full legacy F AO from qualified_old_001",
              "png_audit_comparator": "Original held-out F PNG and independent scored audit",
              "case_records": "observations.jsonl", "outputs": "public_outputs.zip"}
    old_cf._write(out / "summary.json", result)
    return result
