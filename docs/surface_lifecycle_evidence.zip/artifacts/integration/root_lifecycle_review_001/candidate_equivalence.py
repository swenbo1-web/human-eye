"""Compare a one-line constructor-lifetime candidate to the frozen kernel."""
import ast
from dataclasses import fields, is_dataclass
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from types import ModuleType
import numpy as np

ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT))
PATH='human_eye_fast/fast_bvh_clearance.py'
original=subprocess.check_output(['git','show','79f8bcc:'+PATH],cwd=ROOT)
needle=b'            split(0, count, depth)\r\n'
assert original.count(needle)==1
candidate=original.replace(needle,needle+b'            del split\r\n')
old_ast=ast.parse(original);new_ast=ast.parse(candidate)
removed=[]
class RemoveLifetimeDelete(ast.NodeTransformer):
    def visit_Delete(self,node):
        assert len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id=='split'
        removed.append(node.lineno)
        return None
assert ast.dump(old_ast,include_attributes=False)==ast.dump(RemoveLifetimeDelete().visit(new_ast),include_attributes=False)
assert len(removed)==1

def load(name,data):
    module=ModuleType(name);sys.modules[name]=module
    exec(compile(data,str(ROOT/PATH),'exec'),module.__dict__)
    return module
old=load('root_bc_original',original);new=load('root_bc_lifetime_candidate',candidate)

def same(a,b):
    if isinstance(a,np.ndarray):
        assert isinstance(b,np.ndarray) and a.dtype==b.dtype and a.shape==b.shape
        assert a.tobytes()==b.tobytes()
    elif is_dataclass(a):
        assert [f.name for f in fields(a)]==[f.name for f in fields(b)]
        for f in fields(a):same(getattr(a,f.name),getattr(b,f.name))
    elif isinstance(a,dict):
        assert a.keys()==b.keys()
        for key in a:same(a[key],b[key])
    elif isinstance(a,(list,tuple)):
        assert len(a)==len(b)
        for x,y in zip(a,b,strict=True):same(x,y)
    else:assert a==b,(a,b)

from verification.benchmark_fast_bvh_clearance import _grid_case,_dense_case
cases=[]
for seed in (20261105,79463,314159,271828):
    for cells in (8,16):
        for gap in (.5,.05):cases.append((f'{seed}/{cells}/{gap}',_grid_case(cells,gap,seed)))
cases.append(('dense512',_dense_case()))
records=[]
for name,case in cases:
    old_indexes=[old.SurfaceIndex(vertices,faces) for vertices,faces in zip(case.states[0],(case.faces_a,case.faces_b),strict=True)]
    new_indexes=[new.SurfaceIndex(vertices,faces) for vertices,faces in zip(case.states[0],(case.faces_a,case.faces_b),strict=True)]
    for phase,vertices in enumerate(case.states):
        if phase:
            for api_indexes in (old_indexes,new_indexes):
                for index,value in zip(api_indexes,vertices,strict=True):index.update(value)
        for a,b in zip(old_indexes,new_indexes,strict=True):same(vars(a),vars(b))
        result_old=old.surface_distance(*old_indexes);result_new=new.surface_distance(*new_indexes)
        same(result_old,result_new)
        records.append({'case':name,'phase':phase,'triangles':[len(case.faces_a),len(case.faces_b)],
                        'distance_m':result_new.distance_m,'tree_packed_bounds_query_exact':True})
rng=np.random.default_rng(71109)
for n in (0,1,2,4,5,8,33,256):
    vertices=rng.normal(size=(n*3,3));faces=np.arange(n*3).reshape(n,3)
    same(vars(old.SurfaceIndex(vertices,faces)),vars(new.SurfaceIndex(vertices,faces)))
result={'scope':'CPU exact construction/refit/query equivalence, no timing or native resource result',
        'original_sha256':sha256(original).hexdigest(),'candidate_sha256':sha256(candidate).hexdigest(),
        'AST_only_change':'Delete split after successful recursive build',
        'case_states':len(records),'tree_size_cases':[0,1,2,4,5,8,33,256],'states':records}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='states'}))
