# 原 V-F 生产功能补齐：独立验收

**决定：关闭原 V-F 60 × 3 功能余项。** `production_f_qualification_001/run_001` 完成了此前明确缺少的 180 个原 V 留出场景，经真实 `BlenderRadicalSession + load_cf_deployment` 的 F 观察。它没有替换旧成本实验中的历史 F 分母，也不把补齐时间倒写为正式前资格。无须扩大测试或重开算法优化。

本次只读 CPU 核验，未启动 Blender/GPU、训练或新计量。仅新增本目录的 `f_recompute.py`、`f_recompute.json` 和本报告；没有改作者源码、输出、生产代码或旧报告。

## 身份与真实执行路径

- `artifact-identity.json` 的 **32 项**均重新读取真实文件，长度与 SHA-256 一致；目录中除身份表本身外，没有未列入身份表的额外文件。
- frozen ZIP **581 个成员**与 manifest 逐项一致；其中 **17 个生产源文件**全部与 `79f8bcc` 对应 Git 内容逐字节相同，也与旧正式归档相同。两个新测试脚本与归档内容一致。
- 每个进程实际输入读取收据为 6 项，恰等登记输入；另外登记的旧资格/历史源/部署 provenance 文件也按内容重算。每进程 30 项观察到的项目导入与冻结源一致，三个独立进程均退出 0。
- 冻结 `worker.py:195` 从真实 v1 NPZ 加载 deployment；`:197–198` 只筛原 evaluation 清单的 V、每 seed 60 例、无 command；`:224–228` 真实 materialize 原场景并调用 `_prove_case`。
- `_prove_case:149` 调用冻结 `old_cf._make_session`，该 helper `old_cf.py:198–201` 直接构造生产 `BlenderRadicalSession(..., deployment=deployed)`。`worker.py:63` 直接执行 `session.observe(ObservationRequest(spec.episode_id, spec.mode, "F"), changes=...)`，并非历史 ViewEpisode、引用旧输出或仅靠导入模块声称走新入口。
- `MeshChange.VERTICES|TRANSFORM|UNITS` 对实际所有对象显式声明；原 scene/frame、模式、目标、代号和参考经相同冻结构造保持。没有注入备用 renderer 或重写生产方法。

## 180 例原文件核验

| seed | 原例数 | NATURAL / SECTION | 三个家族 | 记录总射线 | 访问候选数 |
|---|---:|---:|---|---:|---:|
| 20261105 | 60 | 30 / 30 | curved-slot / pleated-baffle / interleaved-channel 各 20 | 3,185 | 395 |
| 79463 | 60 | 30 / 30 | 同上，各 20 | 3,743 | 426 |
| 310519 | 60 | 30 / 30 | 同上，各 20 | 3,935 | 419 |

每个 ID 和 ordinal 均与对应 seed 的原 manifest 顺序一致，没有删例、重复例或新场景替代。三个输出 ZIP 各 181 个成员：schema 加每例 3 份文件。共 **540 份内容核对**，其中 360 份是本次实际生产 AO/PNG，180 份是保存的旧 F AO 对照副本。

独立脚本对每例原始 JSON 递归比较，真实 AO 与旧 F AO **只有两处不同**：`observations[0].observation_id` 和 `observations[0].image.path`。仅对齐这两处后重新序列化，完整字节等于原旧资格 F AO；未删除 outcome、TD、对象、witness、投影或其他字段。保存的对照 AO 也逐字节等于旧资格归档的同 ordinal F 原件。

每张生产 PNG 同时逐字节等于原 CF 留出 F PNG、旧资格 F PNG，并与原独立评分记录的 PNG hash 相同。公开 image 字段另从历史 raw audit 的相机/投影/SECTION metadata 重建比较。原严格评分 60/60 × 3 保持；这是对相同实际图像及绑定证据的已验证评分引用，没有声称重新执行了 Pillow/射线评分。

完整 AO 中目标顺序、frame、原面 ID、距离与两个 witness 点均与原记录匹配。保存的实际 `audit` 方向、访问候选顺序、选中候选、选中射线数、总射线数、native stop 与原完整 trace 核对：合计 **10,863 条射线、1,240 个访问候选**。原 trace 的逐候选计数与 metadata 的每个 probe ray_count 一致。

## RNA 几何和逐候选证明的证据层次

冻结 `_geometry` 通过 `native.snapshot → _native_meshes` 在真实 evaluated depsgraph 上重新读取 RNA 顶点、matrix_world、loop triangles；该函数不从生产 bridge 复制数据。随后与生产 bridge 的全部 world rows/triangle rows 精确数组比较，并按原面、目标和距离预算验证 witness，核对原 face counts。180 条记录都达到该断言后的成功点；保存的对象顺序、face counts 及几何结果逐条与原审计和完整 AO 对账。

冻结 `_audit` 对**实际** `observed.view_audit.probes` 的方向、ray_count、aperture_taps、target_support 逐项比较原 probe；从实际 witness 重建候选索引，并按原完整 trace 计数检查每个实际访问候选。每例完成这些断言后才写 `passed=true`。

边界需要准确表达：本次没有将全部实际 RNA 数组和完整实际 probe 元组再存一份；它们由冻结程序在真实进程中直接比较。离线直接复算的对象是已保存完整 AO/PNG、实际方向/visited/selected/total、原 trace 和来源一致的执行断言，不能宣传为“主干离线重新读取了当时 RNA”或“主干重新发射了原生射线”。这不妨碍本次有界功能资格判定，也不据此新增补测要求。

## F 无学习和状态保持

180 例都保存 `view_ticket=null` 和 `learning_calls=[]`。冻结 `_observe_f` 在实际 `session.observe` 周围用 Python profiler 监控 CF 两个 learn 方法、两种经验库 append、两个 LinearHead learn 方法的 code object；不替换这些函数，也不提交虚假 F feedback。

每例观察前后保存完整活跃状态的 dtype/shape/SHA、writes 和 head 配置，涵盖 retrieval_scale、两头 mean/scale/weights、V 二次项索引、两库全部 240 活跃行 keys/values/known。离线直接从原 v1 NPZ 读取数组，独立重建二次项索引及 15 项期望数组摘要，**180 × 2 × 15 = 5,400 项**全部匹配；前后 metadata 也相同，V/A writes 均为 240，capacity 均为 4096。

此外冻结 `_ModelReset` 在原进程中将实际 weights 和两库活跃数组与部署数据按 dtype/shape/原始 bytes 比较，没有执行 restore。这里调用的 `verify_action(..., learned=False)` 只是状态核验 helper，不执行 A 动作。生产 `_frame` 的 F 分支不做学习排序，实际调用记录和状态双重支持 F 不学习结论。

## 串行顺序与范围

实际 runtime 的 UTC 和 QPC 两种时钟均严格有序，五个 PID 不同，无交叠：

| 进程 | PID | UTC 开始—结束（2026-11-06） |
|---|---:|---|
| managed diagnostic B | 38320 | 04:29:00.260671—04:29:12.598372 |
| managed diagnostic I | 4676 | 04:29:15.762315—04:29:26.408651 |
| F 20261105 | 24620 | 04:32:57.418531—04:33:04.941460 |
| F 79463 | 38884 | 04:33:08.973801—04:33:18.217681 |
| F 310519 | 16936 | 04:33:22.284675—04:33:28.667372 |

冻结 launcher 使用串行 `subprocess.run`；三个 worker 只遍历原 V 主集，只有一次 F observe，没有 A execute、R/L 请求、控制清单、训练、性能重复或服务时延段。进程总生命周期锚点是来源证明，不是新增性能成绩。

本次可关闭 `79f8bcc:docs/PRODUCTION_FUNCTIONAL_REVIEW.md:46` 中先前遗漏的“原三 seed V-F 经新生产入口”子项。旧 R/L 和 A 已有证据不重跑；九项历史成本通过、原 R 射线失败、正式前资格时间线偏差以及其他资源门的状态均保持原判定。本报告不替代主端的整机最终验收。
