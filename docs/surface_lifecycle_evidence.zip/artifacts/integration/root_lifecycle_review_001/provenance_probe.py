"""CPU read-only identity/registration audit for the bounded current diagnostic."""
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import json

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'artifacts/integration/managed_current_diagnostic_001'
FORMAL=ROOT/'artifacts/integration/formal_cost_001/formal'
OUT=Path(__file__).with_suffix('.json')

def read(p): return json.loads(p.read_bytes())
def ident(p):
    b=p.read_bytes();return {'sha256':sha256(b).hexdigest(),'bytes':len(b)}

def main():
    index=read(BASE/'artifact-identity.json');m=read(BASE/'manifest.json');fm=read(FORMAL/'manifest.json')
    assert index['file_count']==len(index['files'])==41
    for n,v in index['files'].items(): assert ident(BASE/n)==v,n
    assert {p.relative_to(BASE).as_posix() for p in BASE.rglob('*') if p.is_file()}==set(index['files'])|{'artifact-identity.json'}
    with ZipFile(BASE/'sources.zip') as z:
        assert len(z.namelist())==len(set(z.namelist()))==599
        source_ids={n:sha256(z.read(n)).hexdigest() for n in z.namelist()}
    assert source_ids==m['source_superset']
    assert all(source_ids[n]==v for n,v in fm['source_superset'].items())
    assert m['formal_manifest_sha256']==ident(FORMAL/'manifest.json')['sha256']=='093a0df0ea941eb7cc6bd1206490627ca8196e0951fff18e6601fb513816e8c7'
    assert ident(FORMAL/'artifact-identity.json')['sha256']=='05d93ebe31677cef58a1d722e8833abbfd3a9a60ec46c34f09bccf8ed493c91a'
    assert m['production_head']=='79f8bcc8ea4d9bf881d2f3d555310fc5b5ec998b'
    assert ident(Path(m['protocol']['path']))=={k:m['protocol'][k] for k in ('sha256','bytes')}
    assert source_ids['docs/MANAGED_CURRENT_DIAGNOSTIC_PROTOCOL.md']==m['protocol']['sha256']
    cfg=m['execution']
    assert cfg['seed']==310519 and cfg['load_case_count']==24 and cfg['case_ordinals']==list(range(8))
    assert cfg['warm_pairs']==list(range(5)) and cfg['hot_pair']==5 and cfg['lifecycle_pairs']==[36,37]
    assert cfg['full_lifecycle_ordinals']==list(range(7)) and cfg['snapshots_per_process']==1 and cfg['active_gc_collect_calls']==0 and cfg['traceback_limit']==1
    assert cfg['gc_buffer']['capacity']==32768 and cfg['gc_buffer']['columns']==7
    assert cfg['phase_buffer']['capacity']==32 and cfg['phase_buffer']['columns']==5
    assert [j['role'] for j in m['jobs']]==['B','I']
    runs=[]
    for j in m['jobs']:
        role=j['role'];d=BASE/role;launch=read(d/'launch.json');p=read(d/'process.json');r=read(d/'runtime.json')
        assert {k:v for k,v in launch.items() if k!='manifest'}==j
        assert {k:launch['manifest'][k] for k in ('sha256','bytes')}==ident(BASE/'manifest.json')
        assert '--background' in j['argv'] and '--factory-startup' in j['argv'] and j['argv'][-1]==role
        for n,h in j['input_files'].items(): assert ident(ROOT/n)['sha256']==h,n
        imports=read(d/'project-imports.json')['paths']
        assert len(imports)==p['observed_project_imports']==30
        assert all(source_ids[n]==h for n,h in imports.items())
        assert p['exit_code']==0 and p['verified_process'] and p['stable_sources'] and p['stable_inputs'] and p['runtime_matches'] and not p['import_discrepancies']
        assert r['environment']==j['environment_effective']
        assert r['blender_executable']==m['runtime_registration']['blender_executable']
        assert all(r[k]==v for k,v in m['runtime_registration']['native_expected'].items())
        old=next(x for x in fm['jobs'] if x['kind']=='managed' and x['role']==role and x['seed']==310519)
        expected=dict(old['environment_effective']);expected['PYTHONPYCACHEPREFIX']=j['environment_effective']['PYTHONPYCACHEPREFIX']
        assert expected==j['environment_effective']
        runs.append({'role':role,'input_files_verified':len(j['input_files']),'observed_imports_verified':len(imports),
                     'process':p,'clock':r['clock'],'pid':r['pid'],'gpu':r['gpu']})
    assert runs[0]['clock']['end']['monotonic_after_ns']<runs[1]['clock']['start']['monotonic_before_ns']
    batch=read(BASE/'batch-processes.json');assert batch['verified_processes'] and batch['processes']==[r['process'] for r in runs]
    start=read(BASE/'batch-started.json')
    assert {k:start['manifest'][k] for k in ('sha256','bytes')}==ident(BASE/'manifest.json')
    assert start['start']['monotonic_after_ns']<runs[0]['clock']['start']['monotonic_before_ns']
    assert runs[-1]['clock']['end']['monotonic_after_ns']<batch['end']['monotonic_before_ns']
    result={'all_checks_pass':True,'scope':'fresh CPU archive hashes plus retained launch/source/input/runtime receipts; no native rerun',
            'artifact_count':41,'artifact_identity':ident(BASE/'artifact-identity.json'),'manifest':ident(BASE/'manifest.json'),
            'sources_zip':ident(BASE/'sources.zip'),'source_members':599,'formal_sources_unchanged':len(fm['source_superset']),
            'protocol':m['protocol'],'production_head_registered':m['production_head'],'execution':cfg,'runs':runs,
            'recorded_stability_not_fresh_execution_observation':True}
    OUT.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('execution','runs')},indent=2))

if __name__=='__main__':main()
