# SurfaceIndex 闭包生命周期独立审查

结论：**支持当前仅增加 `del split` 的修复，允许进入一次限定资源和同场景时延复核。** 已独立证明旧构造器存在真实循环引用，也证明一行修复在正常可信构建路径消除此环。未发现需要重新优化 BC 算法、加入运行时 GC 策略或新增防御链的问题。整机当前仍未通过；历史 33 个 current 超限点和归属缺口不因本结论消失。

本审查只运行独立 CPU 探针，没有运行 Blender/GPU，没有改生产、正式数据或作者交付源。产物为 `state_probe.py`、`state_probe.json` 与本文。探针使用工作区 venv Python，自动 GC 仅在短命测试进程中暂时禁用以区分引用计数释放与循环收集，结束时恢复；这不是部署建议。

## 源码与可复现证据

- 历史原始源从同目录 `bc_before.py` 读取，SHA256 `ffc494bf309bb9010854d88007edb54533c9fa9d7fad68905fe0d75663692aeb`。它对应诊断所用旧 BC，而非后来已修改的生产文件。
- 在内存生成“原始”“调用后单行 del”“try/finally del”三个模块。单行候选的完整原始字节**等于当前生产文件**，SHA256 `76b25ff24cbde8433bcf700f8b45e3dfe8fefa8737425ef992ff7d1f3b8bebc1`；测试前后生产 hash 一致。
- 9 个正常生命周期案例（3 版本 × 0/1/64 面）、6 个异常边界案例、42 条构树/更新/查询比较均通过。异常候选仅在内存存在，没有落地。
- 独立命令：`D:/human eye/venv/Scripts/python.exe artifacts/integration/root_lifecycle_review_001/state_probe.py`。原始 weakref 状态、闭包边、版本、hash 和逐项断言均在 JSON。

## 真实持有链及探针自身引用控制

`split.__code__.co_freevars` 为 `centers, self, split, starts`。实际结构为：

```text
split function → __closure__ tuple → split cell → 同一个 split function
                                  → self cell → SurfaceIndex → packed/topology/order/bounds
                                  → centers cell → ndarray
                                  → starts cell → list
```

删除外部 index 之后，旧版 1 面和 64 面案例的 index、order、topology、packed.vertices、split function 和 centers 的弱引用均仍存活。`gc.get_referrers` 精确验证 index 的实际 referrer 包含那个 self cell，function 的实际 referrer 包含那个 split cell，closure tuple 的实际 referrer 包含那个 function。它不是仅根据源码猜测的环。

即使 1 面直接进入递归基例，也使用同一编译后闭包，仍保留全部四个 freevars；空拓扑不创建函数，所以立即释放。

显式一次 full GC 后，上述弱引用全部失效。输入 vertices/faces 在外部 helper 返回时已经失效，排除了探针持有源数组导致 index 存活的解释。单行候选在相同 1/64 面正常案例中，无需显式 GC，全部弱引用立即失效；64 面在函数执行期间捕获了 split/centers 弱引用，所以其消失也经过实际观测。

`gc.get_objects()` 的列表、闭包字典、被检对象和 `get_referrers` 临时引用均只存在于独立 helper 内；helper 返回的只有弱引用和标量描述。**collect 在所有检查 helper 返回之后执行。** 不保留 exception、traceback 或 frame，也不访问 `frame.f_locals`。starts 是不可弱引用的内置 list，因此报告只直接证明其闭包持有边，不伪造 list 的弱引用销毁证据。进程级 `gc.collect()` 返回的收集数不被当作此索引独占数量。

## 修复含义和异常覆盖范围

`del split` 清空递归引用所在 cell；构建返回后，构造器临时 centers/starts 随局部状态释放，索引自身由真实 owner 正常持有，owner 释放后可立即销毁。不改变排序、分割、索引结构、距离公式或查询遍历。

独立几何探针对 0/1/4/5/8/33/64 面分别比较构造后和 update 后的 order/topology/starts/leaves、全部 packed 字段、全部 BVH bounds 的 shape/dtype/原始 bytes，以及最终 distance/triangle IDs/witness points，三版本均一致。该证据补充主端更广的独立数值 oracle，不冒称本探针遍历所有几何情形。

| 情况 | 原始源 | 调用后单行 del | 内存 try/finally del |
|---|---|---|---|
| 正常非空构建后释放 owner | 留到循环 GC | 立即释放 | 立即释放 |
| split 内部注入异常，调用方已丢弃 traceback | 留到循环 GC | 留到循环 GC | 立即释放 |
| split 成功，后面的 update 注入异常 | 留到循环 GC | 立即释放 | 立即释放 |
| 空拓扑正常构建 | 立即释放 | 立即释放 | 立即释放 |

建议保留**一行 del**。当前实证缺陷和正式正常链针对成功构建的可信拓扑；没有发现真实 split 中断用例或要求所有失败构造均在 GC 前立即释放的冻结门。try/finally 是若未来明确扩大失败构造生命周期承诺时可用的最小清理，但本轮不据人工注入异常要求添加它，也不把该边界列为本次接线阻塞。不得引入 gc.collect、阈值修改、禁用生产 GC、重试或兜底算法。

## 与诊断及原 33 点的关系

限定诊断 seed310519/case7 的 held census 期间，B current 减少 626,377 B，I 增加 10,220 B；t4 至 released 的 I−B 差移为 637,653 B。终点实际差为 487,247 B；这是新诊断的读数，不替换原正式 released 487,784 B 或 reference_replaced 488,751 B。

闭包机制说明：历史 session owner 根已经移除的旧索引仍可能由不可达函数环保留，其 arrays 不在当前 session owner/backing 清单，却仍计入 traced current。这与“对应当前根 NumPy 字节相同、全进程 traced current 不同”的现象相容，也给出可修复的生产持有缺陷。

但是，单次 GC 时刻、分配快照及本 CPU 弱引用证明**不能确定当时回收的所有对象，也不能证明三 seed 的全部 33 点只有这一根因**。原分配快照还含验证/报告、NumPy、宿主等类别；不得按推测从原 current 扣除某块字节、把原 FAIL 改为 PASS，或认为删除闭包必然使下一轮每个差值更小。

## 最小后续复核范围和承接边界

支持主端提出的 **6 个 managed 进程 + 3 个 same-scene latency 进程**。它是对生命周期变更的限定复核，不重开模块算法优化。

1. **6 managed 必要。** 原三 seed、B/I 独立进程、同 24 例顺序、每例 5 warm + 1 hot，保留全部 72 对应窗口、216 个原热态 current 点和原 peak 门；不能只跑 case7、只复测 33 点，或改变每案例起点/终点来消掉跨例状态。current 门仍 262,144 B，完整窗口 peak 门仍 1,048,576 B。其他冷点/close/reopen/异常记录仍单列，不能新增事后门，也不能删原记录。
2. 两臂使用**同一个修复后的公共 BC 实现**，B 直接编排职责和其他组件保持冻结；不能让 B 留旧环、I 清环来获得偏置比较。保留正常 GC、旧场景/部署/反馈/顺序及原证据。验证侧只对已证实的 `_bpy_types.Object` 作显式 opaque native 归属，记录对象身份/所属相机及释放依据；不把整类宿主对象推成 0 字节。
3. 新 managed 原热链和重开 proof 对照旧档；所有对应 AO/PNG/Outcome/活动状态/绑定不变才可接受。重新核对真实 session owner 引用移除、native close 和保留 bytes 仍可消费，不能以空 root 推断全进程无内存。
4. **3 同场景时延有必要。** 一行 del 不改变 update/query，但改变构造后对象寿命、跨例垃圾存量及 GC 调度；GC 可能落在任意热段，不能用逐字节语义等价断言新 hash 的热时延相等。沿原三进程 × 24 例 × 31 pairs、五段各 p95 I/B ≤1.05、原 GC 事件和物理执行顺序复核，不删除 GC 样本、不改预算。managed 的追踪时间不能代替它。
5. **不要求本轮重跑旧 CF 九项时延、全部 OS 或全功能/训练。** 冻结 `old_cf.py` 每例先建立两个长期会话及原 View/ActionEpisode，首次 capture 的构树位于五次预热内；其后正常重复仅 update/query，未改 CF 学习/推理、评分、调度器接口或原生 renderer 分配。已核旧真实 F/R/L/A 输出、数值/状态证据可承接；新 managed proof 再核当前热链和重开。禁止为了本修复重训或重新选模。
6. 承接不是新测量：旧 CF 九门和 RSS/DXGI sampled maximum 仍是旧冻结源码的历史实测，可作为本次有界变更未触及项保留；**不得改写为在新 hash 下重新实测通过**。本 CPU 证明也不证明所有旧 CF 场景 GC 调度或 allocator/RSS 绝对不变。无额外数组、算法或 native GPU 创建变更及新 managed/latency 的直接复核，足以支持这次限定范围；若新读数/输出/生命周期出现反证，再由主端指定受影响项，不自动扩大或加跑直到通过。

新轮无论是否通过，都完整保留原正式失败。当前判定是“最小生命周期修复成立，准入限定复核”，不是提前授予资源或整机 PASS。
