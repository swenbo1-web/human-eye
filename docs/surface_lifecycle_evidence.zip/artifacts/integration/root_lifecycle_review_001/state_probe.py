"""Independent CPU-only lifecycle probe; never modifies production sources.

Automatic GC is disabled only inside this short-lived probe to distinguish
refcount release from cyclic collection. No production GC policy is proposed.
Only weakrefs and scalar descriptions survive inspection helpers; no frames or
tracebacks are retained. Run with the workspace venv Python.
"""
from __future__ import annotations

import dataclasses
import gc
import hashlib
import json
from pathlib import Path
import sys
import types
import weakref
from unittest.mock import patch

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT / "human_eye_fast/fast_bvh_clearance.py"
FROZEN_SOURCE = Path(__file__).with_name("bc_before.py")
OUT = Path(__file__).with_suffix(".json")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def module_from_source(source, label):
    name = "_independent_surface_lifecycle_" + label
    module = types.ModuleType(name)
    sys.modules[name] = module
    exec(compile(source, str(SOURCE) + "::" + label, "exec"), module.__dict__)
    return module


def mesh(count):
    rng = np.random.default_rng(6713 + count)
    offsets = rng.normal(size=(count, 1, 3))
    shape = np.array([[0., 0., 0.], [.4, 0., 0.], [0., .3, .1]])
    vertices = (offsets + shape).reshape(-1, 3)
    faces = np.arange(3 * count, dtype=np.int64).reshape(-1, 3)
    return vertices, faces


def cells_of(fn):
    return dict(zip(fn.__code__.co_freevars, fn.__closure__))


def capture_split(module, refs, descriptions, index=None):
    """The gc.get_objects list and every referent die when this helper returns."""
    for obj in gc.get_objects():
        if not isinstance(obj, types.FunctionType):
            continue
        if obj.__module__ != module.__name__:
            continue
        if obj.__qualname__ != "SurfaceIndex.__init__.<locals>.split":
            continue
        cells = cells_of(obj)
        current = cells["self"].cell_contents
        if index is not None and current is not index:
            continue
        refs["split"] = weakref.ref(obj)
        refs["index"] = weakref.ref(current)
        refs["centers"] = weakref.ref(cells["centers"].cell_contents)
        refs["order"] = weakref.ref(current._order)
        descriptions["captured_freevars"] = list(obj.__code__.co_freevars)
        descriptions["starts_list_length_at_capture"] = len(cells["starts"].cell_contents)
        return True
    return False


def cycle_edges(refs):
    """Temporary strong inspection references do not escape this helper."""
    index = refs["index"]()
    fn = refs.get("split", lambda: None)()
    if index is None or fn is None:
        return None
    cells = cells_of(fn)
    split_cell = cells["split"]
    self_cell = cells["self"]
    centers = cells["centers"].cell_contents
    starts = cells["starts"].cell_contents
    return {
        "function_closure_contains_split_cell": any(c is split_cell for c in fn.__closure__),
        "split_cell_contains_same_function": split_cell.cell_contents is fn,
        "self_cell_contains_index": self_cell.cell_contents is index,
        "gc_referrers_index_includes_self_cell": any(r is self_cell for r in gc.get_referrers(index)),
        "gc_referrers_function_includes_split_cell": any(r is split_cell for r in gc.get_referrers(fn)),
        "gc_referrers_closure_tuple_includes_function": any(r is fn for r in gc.get_referrers(fn.__closure__)),
        "centers_shape": list(centers.shape),
        "centers_nbytes": centers.nbytes,
        "starts_type": type(starts).__name__,
        "starts_count": len(starts),
        "starts_list_id": id(starts),
        "note": "starts is not weakrefable; this is a directly observed closure edge, not a weakref claim",
    }


def alive(refs):
    return {key: ref() is not None for key, ref in refs.items()}


def construction(module, count, failure):
    refs, descriptions = {}, {}
    vertices, faces = mesh(count)
    refs["input_vertices"] = weakref.ref(vertices)
    refs["input_faces"] = weakref.ref(faces)
    original_argpartition = np.argpartition

    def intercept_argpartition(*args, **kwargs):
        if "split" not in refs:
            assert capture_split(module, refs, descriptions)
        if failure == "inside_split":
            raise RuntimeError("injected only by CPU lifecycle probe")
        return original_argpartition(*args, **kwargs)

    def intercept_update(index, _vertices):
        refs["index"] = weakref.ref(index)
        refs["order"] = weakref.ref(index._order)
        capture_split(module, refs, descriptions, index)
        raise RuntimeError("injected after split completed")

    caught = False
    with patch.object(np, "argpartition", intercept_argpartition):
        try:
            if failure == "after_split":
                with patch.object(module.SurfaceIndex, "update", intercept_update):
                    module.SurfaceIndex(vertices, faces)
            else:
                index = module.SurfaceIndex(vertices, faces)
                refs["index"] = weakref.ref(index)
                refs["order"] = weakref.ref(index._order)
                refs["topology"] = weakref.ref(index._topology)
                refs["packed_vertices"] = weakref.ref(index._packed.vertices)
                if "split" not in refs:
                    capture_split(module, refs, descriptions, index)
                del index
        except RuntimeError:
            # No bound exception variable, sys.exc_info value, traceback, or frame escapes.
            caught = True
    assert caught == (failure is not None)
    return refs, descriptions


def one_lifecycle(module, count, failure=None):
    gc.collect()
    refs, descriptions = construction(module, count, failure)
    before = alive(refs)
    edges = cycle_edges(refs)
    collected = gc.collect()
    after = alive(refs)
    return {
        "variant": module.__name__.rsplit("_", 1)[1],
        "triangle_count": count,
        "failure": failure,
        "immediately_after_constructor_helper_return": before,
        "cycle_after_external_index_release": edges,
        "explicit_full_gc_collected_objects_processwide": collected,
        "after_explicit_full_gc": after,
        **descriptions,
    }


def array_equal(a, b):
    return a.shape == b.shape and a.dtype == b.dtype and a.tobytes() == b.tobytes()


def tree_equal(a, b):
    for name in ("_order", "_topology", "_starts", "_leaves"):
        if hasattr(a, name) != hasattr(b, name):
            return False
        if hasattr(a, name) and not array_equal(getattr(a, name), getattr(b, name)):
            return False
    for field in dataclasses.fields(a._packed):
        if not array_equal(getattr(a._packed, field.name), getattr(b._packed, field.name)):
            return False
    return len(a._bounds) == len(b._bounds) and all(
        array_equal(aa, bb)
        for pair_a, pair_b in zip(a._bounds, b._bounds)
        for aa, bb in zip(pair_a, pair_b)
    )


def equivalence(modules):
    results = []
    for count in (0, 1, 4, 5, 8, 33, 64):
        vertices, faces = mesh(count)
        target = vertices + [0., 0., 3.]
        indexes = {key: module.SurfaceIndex(vertices, faces) for key, module in modules.items()}
        targets = {key: module.SurfaceIndex(target, faces) for key, module in modules.items()}
        for phase in ("constructed", "updated"):
            if phase == "updated":
                for index in indexes.values():
                    index.update(vertices + [.05, -.02, .12])
            expected = dataclasses.astuple(modules["original"].surface_distance(indexes["original"], targets["original"]))
            for key, index in indexes.items():
                result = dataclasses.astuple(modules[key].surface_distance(index, targets[key]))
                results.append({
                    "triangle_count": count, "phase": phase, "variant": key,
                    "tree_packed_bounds_bytes_equal": tree_equal(indexes["original"], index),
                    "distance_ids_points_equal": result == expected,
                })
    return results


def main():
    production_before = SOURCE.read_bytes()
    raw_before = FROZEN_SOURCE.read_bytes()
    source = raw_before.decode("utf-8")
    newline = "\r\n" if "\r\n" in source else "\n"
    needle = "            split(0, count, depth)"
    assert source.count(needle) == 1
    texts = {
        "original": source,
        "delete": source.replace(needle, needle + newline + "            del split"),
        "finally": source.replace(needle, newline.join(("            try:", "                split(0, count, depth)", "            finally:", "                del split"))),
    }
    assert texts["delete"].encode("utf-8") == production_before
    modules = {label: module_from_source(text, label) for label, text in texts.items()}
    was_enabled = gc.isenabled()
    gc.disable()
    try:
        lifecycle = [one_lifecycle(module, count) for module in modules.values() for count in (0, 1, 64)]
        exceptional = [one_lifecycle(module, 64, stage) for module in modules.values() for stage in ("inside_split", "after_split")]
        numeric = equivalence(modules)
        assert all(row["tree_packed_bounds_bytes_equal"] and row["distance_ids_points_equal"] for row in numeric)
        for row in lifecycle + exceptional:
            assert not any(row["after_explicit_full_gc"].values()), row
        expected_retention = {
            ("original", None): True,
            ("delete", None): False,
            ("finally", None): False,
            ("original", "inside_split"): True,
            ("original", "after_split"): True,
            ("delete", "inside_split"): True,
            ("delete", "after_split"): False,
            ("finally", "inside_split"): False,
            ("finally", "after_split"): False,
        }
        for row in lifecycle + exceptional:
            expected = row["triangle_count"] != 0 and expected_retention[(row["variant"], row["failure"])]
            assert row["immediately_after_constructor_helper_return"]["index"] == expected, row
        report = {
            "scope": "CPU-only independent in-memory source probe, no Blender/GPU and no production edits",
            "python": sys.version,
            "numpy": np.__version__,
            "frozen_original_source": str(FROZEN_SOURCE),
            "frozen_original_sha256": digest(raw_before),
            "production_sha256_before": digest(production_before),
            "production_sha256_after": digest(SOURCE.read_bytes()),
            "in_memory_text_sha256": {key: digest(value.encode()) for key, value in texts.items()},
            "probe_gc": {"automatic_gc_originally_enabled": was_enabled, "temporarily_disabled": True, "explicit_collect_is_probe_only": True},
            "success_cases": lifecycle,
            "exception_domain_cases": exceptional,
            "equivalence": numeric,
            "all_assertions_pass": True,
            "limits": [
                "Does not measure native Blender/GPU memory or formal resource/time budgets.",
                "Does not prove that all 33 historical formal current failures had this sole cause.",
                "Injected exceptions expose coverage boundaries; they do not require expanding the trusted-input contract.",
                "Process-wide gc.collect return counts are not assigned to this index; weakrefs establish referent disappearance.",
            ],
        }
        assert report["production_sha256_before"] == report["production_sha256_after"]
        OUT.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    finally:
        gc.collect()
        if was_enabled:
            gc.enable()
    print(json.dumps({"output": str(OUT), "success_cases": len(lifecycle), "exception_cases": len(exceptional), "equivalence_cases": len(numeric), "all_assertions_pass": True}))


if __name__ == "__main__":
    main()
