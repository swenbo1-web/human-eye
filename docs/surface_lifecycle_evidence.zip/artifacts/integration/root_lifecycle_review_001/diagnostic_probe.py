"""Recompute diagnostic snapshots/phases from original data; no native execution."""
from collections import Counter, defaultdict
from hashlib import sha256
from pathlib import Path
from types import CodeType
from zipfile import ZipFile
import ast
import json
import tracemalloc

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'artifacts/integration/managed_current_diagnostic_001'
FORMAL=ROOT/'artifacts/integration/formal_cost_001/formal'
OUT=Path(__file__).with_suffix('.json')
PHASES=('t4_original','held_census_complete','proof_summary_complete','released_original')
GROUPS=('production','verification_reporting','numpy','host_runtime','unattributed')
FIELDS=('B_bytes','I_bytes','I_minus_B_bytes','B_blocks','I_blocks','I_minus_B_blocks')

def read(p):return json.loads(p.read_bytes())
def rows(p):return [json.loads(line) for line in p.read_text(encoding='utf-8').splitlines()]
def source_group(filename):
    p=filename.replace('\\','/').casefold();root=ROOT.as_posix().casefold()+'/'
    if p.startswith(root):p=p[len(root):]
    if p.startswith('human_eye_fast/'):return 'production'
    if p.startswith(('verification/','artifacts/integration/')):return 'verification_reporting'
    if p.startswith('numpy/') or '/numpy/' in p:return 'numpy'
    if 'blender foundation/' in p or '/blender/' in p or p.startswith(('<frozen ','_bpy','bpy/','mathutils/')):return 'host_runtime'
    return 'unattributed'
def values(b,i):return dict(zip(FIELDS,(b[0],i[0],i[0]-b[0],b[1],i[1],i[1]-b[1])))
def walk_codes(code):
    yield code
    for c in code.co_consts:
        if isinstance(c,CodeType):yield from walk_codes(c)

def main():
    author=read(BASE/'analysis/summary.json');phases={};gc_records={};snapshots={};case_rows={};arms={}
    for role in ('B','I'):
        d=BASE/role/'result';summary=read(d/'summary.json');r=rows(d/'phase_observations.jsonl');cases=rows(d/'cases.jsonl')
        assert len(r)==32 and [(x['ordinal'],x['phase']) for x in r]==[(n,p) for n in range(8) for p in PHASES]
        assert all(a['qpc_ns']<b['qpc_ns'] for a,b in zip(r,r[1:]))
        assert summary['status']=='COMPLETE' and summary['loaded_case_count']==24 and summary['visited_cases']==8
        assert summary['original_warm_pairs']==list(range(5)) and summary['original_hot_pair']==5 and summary['untimed_lifecycle_pairs']==[36,37]
        assert summary['gc']['enabled_after'] and summary['gc']['threshold_before']==summary['gc']['threshold_after']==[2000,10,10]
        assert summary['gc']['overflow']==summary['gc']['callback_errors']==summary['observations']['overflow']==0
        assert summary['observations']['recorded']==summary['observations']['capacity']==32
        assert len(cases)==8 and [x['ordinal'] for x in cases]==list(range(8))
        phases[role]={(x['ordinal'],x['phase']):x for x in r};case_rows[role]=cases
        cp=rows(d/'checkpoints.jsonl');assert len(cp)==106
        cps={(x['case'],x['point']):x for x in cp};assert len(cps)==len(cp)
        for n,case in enumerate(cases):
            assert all(case['hot_proof']['checks'].values())
            assert case['stamps_qpc_ns']['t4']==phases[role][n,'t4_original']['qpc_ns']
            assert case['managed']['current_bytes']['hot_outputs_held']==phases[role][n,'t4_original']['current_bytes']
            assert cps[case['case'],'hot_outputs_held']['current_bytes']==phases[role][n,'t4_original']['current_bytes']
            assert case['managed']['current_bytes']['hot_outputs_released']==phases[role][n,'released_original']['current_bytes']
            if n<7:
                assert case['status']=='UNVERIFIED'
                life=case['lifecycle']
                assert all(life['close'].values()) and all(life['reopened_close'].values())
                assert life['fresh_reopen'] and life['reopened_ticket_owner_is_distinct'] and all(life['reopened_proof']['checks'].values())
                assert cps[case['case'],'hot_outputs_released']['current_bytes']==phases[role][n,'released_original']['current_bytes']
                assert (case['case'],'hot_reference_replaced') in cps and (case['case'],'reopened_released') in cps
            else:
                assert case['status']=='DIAGNOSTIC_ENDPOINT' and case['terminal_census_omitted']
                assert 'lifecycle' not in case and 'hot_reference_replaced' not in case['managed']['current_bytes']
                assert (case['case'],'hot_outputs_released') not in cps
        camera=read(d/'camera_ownership.json')
        assert camera['renderer_owned_by_lane'] and camera['native_allocation_bytes'] is None and not camera['native_sizes_added_to_traced_current']
        assert len(camera['cameras'])==2
        for c in camera['cameras']:
            assert c['object_type']['module']=='_bpy_types' and c['object_type']['qualname']=='Object'
            assert c['data_type']['module']=='bpy.types' and c['data_type']['qualname']=='Camera'
            assert c['is_bpy_types_object'] and c['is_bpy_types_camera_data'] and c['camera_points_to_registered_object'] and c['object_data_points_to_registered_camera']
            assert c['object_kind']=='CAMERA' and c['camera_kind']=='ORTHO'
        gc=rows(d/'gc_events.jsonl');assert len(gc)==summary['gc']['recorded']
        assert all(a['qpc_ns']<b['qpc_ns'] for a,b in zip(gc,gc[1:]))
        active={};pairs=[]
        for x in gc:
            gen=x['generation']
            if x['event']=='start':assert gen not in active;active[gen]=x
            else:
                start=active.pop(gen)
                pairs.append({'generation':gen,'start':start,'stop':x,'duration_ns':x['qpc_ns']-start['qpc_ns']})
        assert not active
        gc_records[role]=pairs
        snapshots[role]=tracemalloc.Snapshot.load(str(d/'endpoint.snapshot'))
        snap=snapshots[role];assert snap.traceback_limit==1 and all(len(t.traceback)==1 for t in snap.traces)
        stored=read(d/'snapshot_statistics.json')
        for key in ('traceback','filename','lineno'):
            independent={tuple((f.filename,f.lineno) for f in s.traceback):(s.size,s.count) for s in snap.statistics(key)}
            archived={tuple((f['filename'],f['lineno']) for f in s['traceback']):(s['size_bytes'],s['count']) for s in stored[key]}
            assert independent==archived,(role,key)
        total=sum(t.size for t in snap.traces)
        assert total==stored['total_size_bytes']==summary['snapshot']['total_size_bytes'] and len(snap.traces)==stored['trace_count']
        assert total-phases[role][7,'released_original']['current_bytes']==56
        arms[role]={'observations':32,'checkpoints':106,'GC_events':len(gc),'GC_collections':len(pairs),'GC_no_overflow_or_error':True,
                    'snapshot_total_bytes':total,'snapshot_trace_count':len(snap.traces),'snapshot_minus_released_current':56,
                    'snapshot_sha256':sha256((d/'endpoint.snapshot').read_bytes()).hexdigest(),
                    'camera_owner':camera,'full_close_reopen_audits':7,'terminal_postcleanup_audit_present':False}
    comparisons=[]
    for n in range(8):
        prior=None
        for phase in PHASES:
            b,i=[phases[r][n,phase] for r in ('B','I')];delta=i['current_bytes']-b['current_bytes']
            x={'ordinal':n,'phase':phase,'B_current_bytes':b['current_bytes'],'I_current_bytes':i['current_bytes'],'I_minus_B_bytes':delta}
            if prior:
                x.update(B_change=b['current_bytes']-prior[0]['current_bytes'],I_change=i['current_bytes']-prior[1]['current_bytes'],
                         difference_change=delta-prior[2],B_elapsed_ns=b['qpc_ns']-prior[0]['qpc_ns'],I_elapsed_ns=i['qpc_ns']-prior[1]['qpc_ns'])
            comparisons.append(x);prior=(b,i,delta)
    assert [r['I_minus_B_bytes'] for r in comparisons]==[r['I_minus_B_bytes'] for r in read(BASE/'analysis/phase-comparison.json')['rows']]
    for n in range(8):assert case_rows['B'][n]['hot_proof']==case_rows['I'][n]['hot_proof']
    domains={};domain_by_role={}
    for role,snap in snapshots.items():
        d=defaultdict(lambda:[0,0])
        for t in snap.traces:d[t.domain][0]+=t.size;d[t.domain][1]+=1
        domain_by_role[role]=d
    for domain in set(domain_by_role['B'])|set(domain_by_role['I']):domains[str(domain)]=values(domain_by_role['B'][domain],domain_by_role['I'][domain])
    assert domains==author['snapshot']['tracemalloc_domains']
    statistics={}
    with ZipFile(BASE/'sources.zip') as z:
        archived_sources={n:z.read(n) for n in z.namelist()}
    for key in ('traceback','filename','lineno'):
        stats={role:{tuple((f.filename,f.lineno) for f in s.traceback):(s.size,s.count) for s in snap.statistics(key)} for role,snap in snapshots.items()}
        a,b=stats['B'],stats['I'];all_rows=[];groups={g:Counter(dict.fromkeys(FIELDS,0)) for g in GROUPS}
        for frame_key in set(a)|set(b):
            vals=values(a.get(frame_key,(0,0)),b.get(frame_key,(0,0)));group=source_group(frame_key[-1][0]);groups[group].update(vals)
            line=None;filename,lineno=frame_key[-1]
            p=Path(filename)
            if p.is_absolute() and p.is_relative_to(ROOT) and lineno>0:
                name=p.relative_to(ROOT).as_posix()
                if name in archived_sources:line=archived_sources[name].decode('utf-8-sig').splitlines()[lineno-1].strip() or None
            all_rows.append({'frames_oldest_to_most_recent':[list(t) for t in frame_key],'group':group,'allocation_line':line,**vals})
        all_rows.sort(key=lambda r:(-abs(r['I_minus_B_bytes']),r['frames_oldest_to_most_recent']))
        archived=rows(BASE/f'analysis/snapshot-diff-{key}.jsonl')
        assert all_rows==archived,key
        totals=Counter()
        for group in groups.values():totals.update(group)
        assert dict(totals)==author['snapshot']['statistics'][key]['totals']
        assert {k:dict(v) for k,v in groups.items()}==author['snapshot']['statistics'][key]['allocation_groups']
        statistics[key]={'union_rows':len(all_rows),'totals':dict(totals),'allocation_groups':{k:dict(v) for k,v in groups.items()},'all_rows':all_rows}
    # Original numbers remain original failures; do not substitute the diagnostic.
    failures=[];all_original=[];peaks=[]
    for sid in (20261105,79463,310519):
        b,i=[rows(FORMAL/f'managed-{sid}-{r}/result/cases.jsonl') for r in ('B','I')]
        assert len(b)==len(i)==24
        for x,y in zip(b,i):
            assert x['case']==y['case'] and x['ordinal']==y['ordinal']
            for point in ('hot_outputs_held','hot_outputs_released','hot_reference_replaced'):
                delta=y['managed']['current_bytes'][point]-x['managed']['current_bytes'][point]
                rec={'seed':sid,'ordinal':x['ordinal'],'case':x['case'],'point':point,'I_minus_B_bytes':delta}
                all_original.append(rec)
                if delta>262144:failures.append(rec)
            peaks.append(y['managed']['window_peak_bytes']-x['managed']['window_peak_bytes'])
    assert len(failures)==33 and max(r['I_minus_B_bytes'] for r in all_original)==488751 and max(peaks)==513429
    counts=dict(Counter(r['point'] for r in failures));assert counts=={'hot_outputs_held':9,'hot_outputs_released':12,'hot_reference_replaced':12}
    # Static compilation only: obtain the frozen recursive closure's free variables.
    name='human_eye_fast/fast_bvh_clearance.py'
    code=compile(archived_sources[name],name,'exec')
    split=next(c for c in walk_codes(code) if c.co_qualname=='SurfaceIndex.__init__.<locals>.split')
    assert set(split.co_freevars)=={'centers','self','split','starts'}
    src=archived_sources[name].decode();tree=ast.parse(src)
    init=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='__init__')
    assert not any(isinstance(n,ast.Delete) and any(isinstance(t,ast.Name) and t.id=='split' for t in n.targets) for n in ast.walk(init))
    gc_endpoint={}
    for role in ('B','I'):
        t4=phases[role][7,'t4_original']['qpc_ns'];census=phases[role][7,'held_census_complete']['qpc_ns'];end=phases[role][7,'released_original']['qpc_ns']
        selected=[g for g in gc_records[role] if g['start']['ordinal']==7]
        gc_endpoint[role]=[{'generation':g['generation'],'start_qpc_ns':g['start']['qpc_ns'],'stop_qpc_ns':g['stop']['qpc_ns'],
                            'collected':g['stop']['collected'],'uncollectable':g['stop']['uncollectable'],'duration_ns':g['duration_ns'],
                            'within_t4_census':t4<g['start']['qpc_ns']<g['stop']['qpc_ns']<census,
                            'start_minus_released_ns':g['start']['qpc_ns']-end,'stage':g['start']['phase']} for g in selected]
    result={'all_checks_pass':True,'scope':'CPU audit of archived snapshots/records, no new diagnostic execution',
            'arms':arms,'phase_comparisons':comparisons,'endpoint_GC':gc_endpoint,'all_GC_collections':gc_records,
            'domains':domains,'snapshot_statistics':statistics,'original_exceedance_count':33,'original_exceedance_counts':counts,
            'original_failures':failures,'original_maximum_current_difference':488751,'original_maximum_peak_difference':513429,
            'static_lifecycle_candidate':{'source':name,'source_sha256':sha256(archived_sources[name]).hexdigest(),
                'code_name':split.co_qualname,'first_line':split.co_firstlineno,'freevars':list(split.co_freevars),
                'reference_cycle':'split function -> closure cell named split -> same function; another cell retains self SurfaceIndex',
                'missing_explicit_cycle_break_at_constructor_end':True,
                'boundary':'Static retaining path; no runtime referrer inventory. Does not quantify how much of this snapshot delta belongs to this path.'},
            'snapshot_capture_start_end_QPC_available':False,'formal_acceptance_changed':False}
    OUT.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'all_checks_pass':True,'arms':{k:{n:v[n] for n in ('observations','GC_events','snapshot_total_bytes','snapshot_minus_released_current')} for k,v in arms.items()},
                      'endpoint':comparisons[-4:],'domains':domains,'groups':statistics['lineno']['allocation_groups'],
                      'endpoint_GC':gc_endpoint,'original_exceedances':33,'static_split_freevars':list(split.co_freevars)},indent=2))

if __name__=='__main__':main()
