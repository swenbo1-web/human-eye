"""CPU-only audit of the frozen 180-case production F completion. No project imports."""
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
import gzip
import json
from pathlib import Path
import subprocess
from zipfile import ZipFile

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT/'artifacts/integration/production_f_qualification_001'
RUN = BASE/'run_001'
OUT = Path(__file__).parent
SEEDS = (20261105, 79463, 310519)

def read(path):
    return json.loads(Path(path).read_bytes())

def lines(path):
    return [json.loads(line) for line in Path(path).read_bytes().splitlines()]

def digest(raw):
    return sha256(raw).hexdigest()

def compact(value):
    return json.dumps(value,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode()

def check_identity(path, record):
    raw=Path(path).read_bytes()
    assert len(raw)==record['bytes'] and digest(raw)==record['sha256'], str(path)

def expected_state(path):
    with np.load(path,allow_pickle=False) as data:
        assert data['version'].shape==() and int(data['version'])==1
        arrays={'retrieval_scale':data['retrieval_scale']}
        result={}
        for name,prefix in [('V','v'),('A','a')]:
            result[name]={'writes':240,'capacity':4096,'quadratic':bool(data[prefix+'_quadratic']),
                          'regularization':float(data[prefix+'_lambda']),'view':name=='V'}
            for field in ('mean','scale','weights'):
                arrays[f'{name}_head_{field}']=data[f'{prefix}_{field}']
            if result[name]['quadratic']:
                for i,index in enumerate(np.triu_indices(len(data[prefix+'_mean']))):
                    arrays[f'{name}_head_products_{i}']=index
            for field in ('keys','values','known'):
                arrays[f'{name}_bank_{field}']=data[f'{prefix}_{field}']
                assert len(arrays[f'{name}_bank_{field}'])==240
        result['arrays']={name:{'dtype':value.dtype.str,'shape':list(value.shape),'sha256':digest(value.tobytes())}
                          for name,value in arrays.items()}
        return result

def differences(left,right,path=()):
    if type(left) is not type(right):
        return [path]
    if isinstance(left,list):
        if len(left)!=len(right):
            return [path]
        return [d for i,(a,b) in enumerate(zip(left,right)) for d in differences(a,b,path+(i,))]
    if isinstance(left,dict):
        if left.keys()!=right.keys():
            return [path]
        return [d for k in left for d in differences(left[k],right[k],path+(k,))]
    return [] if left==right else [path]

def old_image(metadata,objects):
    def view(v):
        r,g=v['rna'],v['gpu']
        return [v['viewport'],r['type'],r['matrix_world'],r['ortho_scale'],r['clip_start'],r['clip_end'],
                r['shift_x'],r['shift_y'],r['projection'],g['view'],g['projection'],g['view_projection']]
    s=metadata['section']
    return ['view.png',1024,512,metadata['meters_per_blender_unit'],metadata['mode'],
            [objects.index(k) for k in metadata['target_ids']],[objects.index(k) for k in metadata['mesh_ids']],
            [s['point_m'],s['normal'],s['kept_side']] if s else None,
            view(metadata['views']['global']),view(metadata['views']['local'])]

def process_clock(path,label):
    r=read(path);c=r['clock']
    assert c['monotonic']
    return {'label':label,'pid':r['pid'],'start_utc_ns':c['start']['utc_ns'],'end_utc_ns':c['end']['utc_ns'],
            'start_qpc_ns':c['start']['monotonic_before_ns'],'end_qpc_ns':c['end']['monotonic_after_ns'],
            'start_utc':datetime.fromtimestamp(c['start']['utc_ns']/1e9,timezone.utc).isoformat(),
            'end_utc':datetime.fromtimestamp(c['end']['utc_ns']/1e9,timezone.utc).isoformat()}

identity=read(BASE/'artifact-identity.json')
assert identity['file_count']==len(identity['files'])==32
for name,record in identity['files'].items():
    check_identity(BASE/name,record)
actual={p.relative_to(BASE).as_posix() for p in BASE.rglob('*') if p.is_file()}
assert actual==set(identity['files'])|{'artifact-identity.json'}
manifest=read(RUN/'manifest.json')
assert manifest['seed_order']==list(SEEDS) and manifest['cases_per_seed']==60
assert manifest['public_ao_alignment']==['observation_id','image.path']
assert manifest['production_source_commit']=='79f8bcc'
result={'decision':'ACCEPT_AND_CLOSE_ORIGINAL_V_F_FUNCTIONAL_ITEM','identity_files_checked':32,
        'production_source_commit':'79f8bcc','scope':'CPU offline audit; historical timing and prior sequencing unchanged',
        'seeds':{},'evidence_limits':[
            'Saved public bytes independently checked in full; no new render or native ray run.',
            'RNA arrays and actual complete probe tuples were compared in frozen worker assertions, not separately archived in full.',
            'Saved model before/after hashes independently reconstructed from original v1 arrays; no new native state read.',
            'This is post-formal functional completion, not retrospective formal-start qualification or a new cost trial.',
        ]}
with ZipFile(RUN/'sources.zip') as frozen:
    assert len(frozen.namelist())==len(manifest['source_superset'])==581
    for name,expected in manifest['source_superset'].items():
        assert digest(frozen.read(name))==expected
    production=[p for p in frozen.namelist() if p.startswith('human_eye_fast/')]
    for name in production:
        expected=subprocess.run(['git','show','79f8bcc:'+name],cwd=ROOT,capture_output=True,check=True).stdout
        assert expected==frozen.read(name)
    result['frozen_sources_checked']=581
    result['production_files_equal_79f8bcc']=len(production)
    with ZipFile(ROOT/'artifacts/integration/formal_cost_001/formal/sources.zip') as formal:
        assert all(formal.read(name)==frozen.read(name) for name in production)
    for name in ('run_qualification.py','worker.py'):
        assert (BASE/name).read_bytes()==frozen.read('artifacts/integration/production_f_qualification_001/'+name)

    for job,seed in zip(manifest['jobs'],SEEDS,strict=True):
        assert job['seed']==seed
        folder=RUN/str(seed)
        assert job==read(folder/'launch.json')
        for field in ('input_identities','provenance_identities'):
            for name,record in job[field].items():
                check_identity(ROOT/name,record)
        reads=lines(folder/'result/reads.jsonl')
        assert len(reads)==6
        assert {Path(r['path']).relative_to(ROOT).as_posix():r for r in reads}==job['input_identities']
        observed=read(folder/'observed-project-imports.json')['paths']
        assert len(observed)==30
        assert all(name in manifest['source_superset'] and value==digest(frozen.read(name)) for name,value in observed.items())
        runtime=read(folder/'runtime.json')
        assert runtime['environment']==job['environment_effective']
        assert runtime['blender_executable']==manifest['executables']['blender']
        assert job['argv'][job['argv'].index('--threads')+1]=='1'
        assert '--background' in job['argv'] and '--registered-worker' in job['argv']
        receipt=read(folder/'process.json')
        assert receipt['exit_code']==0 and receipt['cases']==receipt['passed_cases']==60
        assert all(receipt[k] for k in ['passed','actual_input_reads_match','stable_sources','stable_inputs','stable_provenance','observed_import_identity','runtime_environment_stable'])
        inp=job['inputs']
        original_manifest=read(ROOT/inp['evaluation_manifest'])
        specs=[r for r in original_manifest['episodes'] if r['head']=='V']
        rows=lines(folder/'result/observations.jsonl')
        assert len(specs)==len(rows)==60
        ids=[r['episode_id'] for r in specs]
        assert len(set(ids))==60 and [r['case_id'] for r in rows]==ids
        assert all(r['seed']==seed and r['split']=='evaluation' and r['command'] is None for r in specs)
        quality=read(ROOT/inp['historical_summary'])['views']['F']
        assert [r['id'] for r in quality]==ids
        with gzip.open(ROOT/inp['historical_records'],'rt',encoding='utf8') as stream:
            archived={r['id']:r for r in map(json.loads,stream) if r['id'] in ids and r.get('arm')=='F'}
        assert list(archived)==ids
        model=expected_state(ROOT/inp['deployment'])
        assert len(model['arrays'])==15
        checked_cases=[]
        with ZipFile(folder/'result/public_outputs.zip') as output,ZipFile(ROOT/inp['historical_media']) as historical,ZipFile(ROOT/inp['legacy_f_ao_media']) as legacy:
            assert len(output.namelist())==181
            assert json.loads(output.read('ao-schema.json'))==json.loads(legacy.read('ao-schema.json'))==json.loads(historical.read('ao-schema.json'))
            for i,(row,spec,score_row) in enumerate(zip(rows,specs,quality,strict=True)):
                case=ids[i];original=archived[case];a=original['audit'];metadata=a['metadata']
                assert row['ordinal']==i and row['arm']=='F' and row['mode']==spec['mode'] and row['passed'] and 'error' not in row
                assert not any(k.startswith('t0') or 'elapsed' in k or 'duration' in k for k in row)
                assert row['view_ticket'] is None and row['learning_calls']==[]
                assert row['model_arrays_initial']==row['model_arrays_final']==model
                prod_raw=output.read(case+'/production.ao.json')
                ref_raw=output.read(case+'/reference.f.ao.json')
                assert ref_raw==legacy.read(f'{i:02d}/00/F/view.ao.json')
                assert digest(prod_raw)==row['ao_production_sha256']
                assert digest(ref_raw)==row['ao_legacy_qualification_sha256']
                prod,ref=json.loads(prod_raw),json.loads(ref_raw)
                assert differences(prod,ref)==[(3,0,0),(3,0,5,0)]
                assert prod[0:2]==['he-ao/1','m'] and len(prod[3])==1 and prod[4] is None
                assert prod[3][0][0]==case and prod[3][0][5][0]==case+'.png'
                prod[3][0][0]='view';prod[3][0][5][0]='view.png'
                assert compact(prod)==compact(ref)==ref_raw
                assert digest(compact(prod))==row['ao_role_aligned_sha256']
                png=output.read(case+'/production.png')
                assert png==historical.read(case+'/F.png')==legacy.read(f'{i:02d}/00/F/view.png')
                assert digest(png)==row['png_original_sha256']==original['png_sha256']==original['score']['png_sha256']==score_row['png_sha256']
                assert prod[3][0][5]==old_image(metadata,prod[2])
                for key in ('png_sha256','rays','candidate','witness','native_stop','success','safe'):
                    assert original[key]==score_row[key]
                observed_audit=row['audit'];trace=a['trace'];counts=Counter(r['candidate'] for r in trace)
                assert a['order']==list(range(16))
                assert observed_audit['visited_indices']==list(counts)==a['order'][:len(counts)]
                assert len(a['metadata']['selection']['probes'])==len(counts)
                assert [p['ray_count'] for p in metadata['selection']['probes']]==list(counts.values())
                assert observed_audit['selected_candidate']==original['candidate']==a['candidate']
                assert observed_audit['selected_rays']==a['selected_rays']==counts[a['candidate']]==original['selected_rays']
                assert observed_audit['total_rays']==len(trace)==a['ray_count']==original['rays']
                assert observed_audit['direction']==metadata['selection']['direction']
                assert observed_audit['native_stop']==a['native_stop']==original['native_stop']
                assert observed_audit['pixel_pass']==original['score']['pixel_success']
                assert observed_audit['strict_pass']==original['score']['passed']==original['success']
                assert observed_audit['safe']==original['score']['safe']==original['safe']
                assert prod[3][0][1]==original['frame_id']==a['expected']['frame_id']
                witness=original['witness'];clearance=prod[3][0][3]
                assert clearance[0]=='positive_gap' and clearance[2]==witness['distance_m']
                assert clearance[3]==[witness['face_a'],witness['point_a']]
                assert clearance[4]==[witness['face_b'],witness['point_b']]
                assert [prod[2][j] for j in clearance[1]]==original['targets']
                geometry=row['geometry']
                assert geometry['world_rows_match_independent_RNA']
                assert geometry['object_ids']==a['mesh_ids'][1:]==prod[2]
                assert geometry['face_counts']==a['face_counts']
                assert len(geometry['evaluated_vertex_counts'])==len(prod[2]) and all(v>0 for v in geometry['evaluated_vertex_counts'])
                assert 0<geometry['witness_geometry_budget_m']<1e-6
                checked_cases.append({'ordinal':i,'case_id':case,'family':spec['family'],'mode':spec['mode'],
                    'actual_ao_difference_paths':[[3,0,0],[3,0,5,0]],'public_content_exact':True,
                    'native_worker_RNA_and_full_probe_assertions_completed':True,
                    'archived_candidate_ray_counts':dict(counts),'selected_candidate':a['candidate'],
                    'total_rays':len(trace),'strict_pass':observed_audit['strict_pass'],
                    'model_hashes_match_deployment_before_and_after':True,'learning_calls':0})
        result['seeds'][str(seed)]={'cases':60,'output_zip_members':181,'public_files_content_checked':180,
            'observed_imports':30,'runtime_pid':runtime['pid'],'actual_reads':6,'model_arrays_per_state':15,
            'mode_counts':dict(Counter(r['mode'] for r in specs)),
            'family_counts':dict(Counter(r['family'] for r in specs)),
            'total_rays':sum(r['total_rays'] for r in checked_cases),'candidate_probe_count':sum(len(r['archived_candidate_ray_counts']) for r in checked_cases),
            'strict_passed':sum(r['strict_pass'] for r in checked_cases),'cases_detail':checked_cases}

clock_paths=[(ROOT/'artifacts/integration/managed_current_diagnostic_001'/role/'runtime.json','diagnostic-'+role) for role in ('B','I')]
clock_paths += [(RUN/str(seed)/'runtime.json','F-'+str(seed)) for seed in SEEDS]
clocks=[process_clock(path,label) for path,label in clock_paths]
assert len({r['pid'] for r in clocks})==5
for before,after in zip(clocks,clocks[1:]):
    assert before['end_utc_ns']<after['start_utc_ns'] and before['end_qpc_ns']<after['start_qpc_ns']
result['process_sequence']=clocks
result['serial_after_two_diagnostics']=True
result['total_cases']=sum(s['cases'] for s in result['seeds'].values())
result['actual_public_files_content_checked']=sum(s['public_files_content_checked'] for s in result['seeds'].values())
result['model_array_hashes_compared_to_original_npz']=180*2*15
result['new_scope_only']='Original V F; no action execution, R/L, controls, model optimization or service cost run in the frozen entry/worker'
(OUT/'f_recompute.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in result.items() if k!='seeds'},indent=2))
for seed,data in result['seeds'].items():
    print(seed,json.dumps({k:v for k,v in data.items() if k!='cases_detail'}))
