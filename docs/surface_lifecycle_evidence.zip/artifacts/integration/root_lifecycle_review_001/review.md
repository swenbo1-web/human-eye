# managed_current_diagnostic_001 独立复核

结论：这次两进程限定诊断符合事前范围，来源、原始阶段数据与快照重算通过；它复现了 ordinal 7 的托管 current 超门和 census 阶段差值摆动。证据支持转入一个有具体源行的生命周期修复评估，不支持整模块重新优化，也不支持宣布原正式轮通过。原 33 个超门点完整保留。

本审查只用 CPU 读取已归档数据、加载原 snapshot、静态编译冻结源码以检查闭包 freevars，没有运行 Blender/GPU、创建新诊断或修改生产、评分、协议和作者文件。可复核入口为 `provenance_probe.py/.json` 与 `diagnostic_probe.py/.json`；两者均运行完成，all_checks_pass=true。后者保存全部三种快照差分明细，未只挑选有利栈。

## 来源和执行范围

- artifact-identity SHA：`48c14b6311e77f5a77172a1196f5309f06da26d9e0b03c515614e2a4c00d4cf0`。清单 41 项 SHA/大小全部相同，实际文件集合也一致（身份文件自身除外）。
- manifest SHA：`5349d437ab44fd37ac0bf906bc8d5ed84202bb901b52b653d8b9ae0cc1b1def1`；sources.zip 含 599 个唯一成员，全部匹配 source_superset。
- 原 formal 的 595 份来源全部逐项相同；新增为本次诊断三个脚本及协议。生产登记 HEAD 为 `79f8bcc8ea4d9bf881d2f3d555310fc5b5ec998b`。原 formal manifest `093a0df0…` 和 identity `05d93ebe…` 未变。
- 事前 `MANAGED_CURRENT_DIAGNOSTIC_PROTOCOL.md` SHA 为 `1d236aa2cf6fe022cb149ac47e6fc93bf4ce1779577265782a3c75fdd7b93b73`，与 manifest、ZIP 和现文件一致。
- 恰好 B、I 两个登记进程，B 后 I 串行，均 exit 0；每进程的 172 项登记输入哈希、30 项实际项目导入回执、manifest launch 绑定、实际 runtime/环境均一致。输入集合是运行前后核验的绑定集合，不等于每一个登记文件都有独立文件读取事件。
- 实际原生版本/设备等于 formal 的 native_expected，独立 pycache 路径是与相应旧资源进程环境的唯一有意差异。运行时 QPC 区间 B 为 `11232716143900…11245053988800`，I 为 `11248217966700…11258864426800`，不存在重叠；batch 起止包住两者。

manifest、worker 和原 resources.py 的调用路径一致：仍加载完整 24 例，只执行 ordinal 0…7；0…6 保留原五预热、复位、热链、reference replacement、close/reopen 轨迹；7 完成五预热和热链后，在原 released current 读取之后终止，尚未进入 released census、报告和 reference replacement。每侧原 records 有 8 例，前七例保持 UNVERIFIED，第八例标为 DIAGNOSTIC_ENDPOINT；每侧 checkpoints 为 106 条，终例只有 hot_outputs_held，没有虚构终例 released census 或 lifecycle 数据。

## 观测方式及其扰动

每侧均有 8×4=32 条阶段观察，顺序和 QPC 单调性正确，无缺项或重复。t4/released 的 current 复用原读取值；额外两点位于 held census 计算完成和 proof_summary 完成后。t4 标签使用原 t4 边界 QPC，released QPC 在读取后立即采样，不能把两者描述成无指令间隙的瞬时同一次操作。

GC 回调仅写预分配七列 int64 缓冲，容量 32,768；阶段缓冲为 32×5，另有五个 int64 计数器。其数值底层容量合计 1,836,328 B，均在 tracemalloc.start 前建立。正常回调无 append 字典或 JSON 写出；B 记录 14 个事件、7 个完整集合，I 为 12 个事件、6 个完整集合，无溢出、异常或未配对事件。GC 正常启用，threshold 前后均为 `(2000,10,10)`；源码没有主动 collect 或 threshold 修改。

这不能称为零扰动：回调的 QPC、整数运算、包装函数和额外观测会改变分配/GC 调度；预分配发生在 tracing 前，也不表示它对进程或 GC 状态无影响。因此本轮只作一次限定归因证据，不能替换正式成本原读数。

## ordinal 7 的实际变化

| 点 | B current (B) | I current (B) | I−B (B) |
| --- | ---: | ---: | ---: |
| 原 t4 | 9,699,001 | 9,548,595 | −150,406 |
| held census 完成 | 9,072,624 | 9,558,815 | +486,191 |
| proof_summary 完成 | 9,072,353 | 9,558,760 | +486,407 |
| 原 released 读取 | 8,982,320 | 9,469,567 | **+487,247** |
| 随后唯一 allocation snapshot | 8,982,376 | 9,469,623 | **+487,247** |

t4→census：B 下降 626,377 B，I 上升 10,220 B，导致差值摆动 **+636,597 B**；对应区间分别 6.0775 ms 和 4.1296 ms。census→proof 只再改变差值 +216 B；proof→released 改变 +840 B。t4→released 总摆幅为 +637,653 B。因此本次大跳变发生在 census 区间，并不是后续删除 outputs 时才出现。

每进程按同一终点条件只调用一次 take_snapshot，且位于 released current 读取之后、相机检查之前。直接读取原 snapshot 总量，B/I 分别为 8,982,376/9,469,623 B，均比其 released 原值多 **56 B**。它们是紧邻但不同的观察，+56 只是一致的净差，不能在没有前后分配事件证据时命名成某个特定对象开销。快照差值仍超原 262,144 B 门，但本轮没有重判正式门。

## GC 时序能证明什么

B 的 ordinal 7 gen1 集合从 `11243077267100` 到 `11243079467500`，历时 2.2004 ms，完整落在 t4→census 内，collected=462、uncollectable=0。I 的对应 gen1 从 `11256738183400` 到 `11256742671000`，collected=218、uncollectable=0；开始比 I released QPC `11256732655000` **晚 5.5284 ms**，当时 stage 为 endpoint_snapshot_and_cleanup。

因此可以确认：本诊断 B 的大幅下降区间包含 GC，而 I 在该区间没有对应集合，I 的 gen1 发生在被比较的 released 读数之后。不能把 collected 的对象数直接换算为释放字节，也不能断言 B 的 626,377 B 下降全部由 GC 造成。

stage8 同时覆盖 take_snapshot、异常展开、相机检查、正常清理和后续报告；没有 snapshot 捕获的起止 QPC。故不能进一步断言 I 的 GC 一定发生在 snapshot 对象构造完成之后，也不能区分它在具体哪一步发生。只可结合 snapshot 总量说明捕获状态与 released 读数接近。原正式资源轮没有 GC 事件，当前时序更不能反向证明原 33 点的确切 GC 时刻。

## 原快照的完整重算

本次直接用原 `endpoint.snapshot` 重算 traceback/lineno/filename 三种统计，逐项等于 snapshot_statistics 和作者全部差分记录。traceback 与 lineno 各有 1,093 个并集位置，filename 有 65 个；B/I 分别 20,594/21,876 个 trace block，净增 1,282。

| 最近分配帧的来源类别 | B (B) | I (B) | I−B (B) |
| --- | ---: | ---: | ---: |
| production | 6,784,612 | 7,133,112 | +348,500 |
| verification/reporting | 349,939 | 316,693 | −33,246 |
| NumPy 文件 | 547,530 | 733,675 | +186,145 |
| host/runtime | 1,299,167 | 1,285,015 | −14,152 |
| 无法按路径归类 | 1,128 | 1,128 | 0 |
| 合计 | 8,982,376 | 9,469,623 | **+487,247** |

trace domain 0 为 B 2,444,047 / I 2,500,566，差 +56,519 B、+969 blocks；domain 389047 为 B 6,538,329 / I 6,969,057，差 +430,728 B、+313 blocks。domain 是分配器追踪域，文件类别是最近记录帧，两种划分不可相加，也不能把路径中出现 NumPy 当成最终拥有者。

主要位置包括 fast_bvh_clearance.py 文件净 +299,776 B；其中行 56 edges +61,920 B、行 60 directions +61,632 B、行 116 packed 输入 +61,632 B。numpy numeric.py:1711 +62,496 B；_methods.py:43/47 分别 +37,568/+37,344 B。许多同尺寸 BC 数组的 I block 数是 B 的约七倍，构成旧实例可能尚被保留的线索，不等于已识别各实例。

分类也会受实现位置影响：I 的 blender_radical_session.py:280 ranking 为 +26,040 B，而 B 的 integration_reference.py:400 对应状态为 −26,040 B，整体抵消，但会分别落入 production 和 verification。因此不能将 production 净 +348,500 B 直接解释成生产根“新增拥有”348,500 B。

traceback_limit 实际为 1。记录的是最近一个分配帧，不含完整调用链、对象地址、引用者、可达性或分配/释放历史。已有 owner census 的 NumPy/bytes 等价也只覆盖显式根；它不能否定待 GC 循环中的旧数组还计入 traced current。上述数据不能单独证明验证者故障、无限泄漏或全部差值的确切持有链。

## 相机类型、绑定与清理证据

终点 snapshot 后的实际原生回执确认，两侧 renderer.cameras 都包含 VG Context、VG Witness 两个 ORTHO 相机；对象真实类为 `_bpy_types.Object`，MRO 为 `_bpy_types.Object → bpy.types.ID → builtins.bpy_struct → object`，`isinstance(..., bpy.types.Object)` 为 true。data 为 `bpy.types.Camera`，对象与 bpy.data.objects 的指针相符，data 与 bpy.data.cameras 的指针也相符。I 的 owner 为 `lane._session._renderer`；B 为 `lane._b_renderer / lane._b_control._renderer`。

这证明当前分类遗漏的是已绑定的原生相机对象类型，不是未识别 Python 数组根。原 native 大小保持 null，未填零，也没有加算到 traced current。相机类型识别不足与实际 current 数值超门是两件事；修正分类不消除原 33 点。

ordinal 0…6 的 close 和 reopen-close 各有逐项运行时回执，均确认一次 offscreen free、两个 camera Object/Data 移除、renderer CPU 缓冲清空和所有者清理。terminal ordinal7 按协议提前异常展开，无终点清理后的逐项审计；源码 with/finally 会调用 lane.close，且进程 exit0，支持正常清理路径完成，但不能把它写成终点所有资源释放已独立测量。此缺项不违反本次固定诊断范围，不需追加一次原生实验。

## 有限修复方向

除了快照线索，冻结源码存在一条可静态证明的保留路径：`SurfaceIndex.__init__` 的局部递归函数 split（fast_bvh_clearance.py:91 起）捕获 `centers, self, split, starts`。本审查只 compile 归档源码、检查 code.co_freevars，没有执行构造器或追加运行诊断。

`split function → closure 中的 split cell → 同一 function` 构成循环；self cell 又保留 SurfaceIndex，而 index 在构造后持有 `_packed`、`_bounds` 等数组。构造器完成前没有断开 split 绑定，因此外部 owner 释放后，该循环仍可让旧 index 等待循环 GC。这个缺陷同时存在于冻结 B/I 共用 BC 组件；调度差异可以让两边在同一比较点保留不同数量的旧实例。此静态事实比单帧分配栈更强，但仍不能把本次全部 487,247 B 定量归到该路径。

建议主干只授权这一递归闭包的生命周期定点修复评估：在递归完成后明确断开本地 split 绑定，或采用同等明确且不改变遍历/排序结果的生命周期处理；保持 BC 算法、输入、结果和评分门。先用针对性 CPU 生命周期/结果检查证明修复，再由主干预定必要资源复核范围。不要以强制 GC、改变阈值/次序、扣掉冷基线、忽略原失败或反复换样本代替修复；也不因此重开 BC 搜索或全引擎优化。

原正式 72 窗口/216 个 current 点已独立重算：held 9、released 12、reference replaced 12，合计 **33** 超门；最大 current 差 **488,751 B**，原 peak 最大差 **513,429 B**。数值、门和失败全部不变。该诊断本身不授予整机 PASS。
