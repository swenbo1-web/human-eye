"""Independent CF raw-data/statistics review; imports no CF implementation/report code."""
from pathlib import Path
from collections import Counter
from hashlib import sha256
import gzip
import json
import os
import statistics
import zipfile

for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[name] = '1'
import numpy as np

ROOT = Path(__file__).resolve().parents[3]
DATA = ROOT / 'artifacts/cf/formal_001'
OUT = Path(__file__).with_name('statistics_review.json')
SEEDS = (20261105, 79463, 310519)
ARMS = ('F', 'R', 'L')
V_ARMS = (*ARMS, 'zero', 'shuffle')
STAGES = ('total_ns', 'V_ns', 'A_ns')
ORDERS = (('F', 'R', 'L'), ('R', 'L', 'F'), ('L', 'F', 'R'),
          ('L', 'R', 'F'), ('F', 'L', 'R'), ('R', 'F', 'L'))

def read(path):
    return json.loads(path.read_bytes())

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def near(actual, expected):
    assert np.isclose(actual, expected, rtol=1e-13, atol=1e-14), (actual, expected)

def percentile(values, p=.95):
    # Explicit linear interpolation, independent of report's np.quantile.
    a = sorted(values)
    index = (len(a)-1)*p
    lo = int(index)
    hi = min(lo+1, len(a)-1)
    return a[lo] + (a[hi]-a[lo])*(index-lo)

summary = read(DATA/'summary.json')
result = {'source_summary_sha256': digest(DATA/'summary.json'), 'per_seed': {},
          'checks': {}, 'scope': 'Raw statistics, source binding of performance, and timing source review. No new native run.'}
view_pool = {arm: [] for arm in V_ARMS}
error_pool = {arm: [] for arm in ('C', 'G', 'L', 'shuffle')}
time_pool = {stage: {arm: [] for arm in ARMS} for stage in STAGES}
source_counts = Counter()
for si, seed in enumerate(SEEDS):
    base = DATA/str(seed)
    quality_dir = base/'evaluation'
    if not (quality_dir/'summary.json').exists():
        quality_dir = base/'evaluation-completion'
    q = read(quality_dir/'summary.json')
    report = summary['per_seed'][str(seed)]
    manifest = read(base/'specs/manifest-evaluation.json')
    ids = {arm: [row['id'] for row in q['views'][arm]] for arm in V_ARMS}
    assert all(len(x)==60 and len(set(x))==60 and x==ids['F'] for x in ids.values())
    action_ids = [row['id'] for row in q['actions']]
    assert len(action_ids)==len(set(action_ids))==60
    assert len(set(ids['F']) & set(action_ids))==0
    # Reconcile all main metric fields against originally emitted raw records,
    # including the interrupted first evaluation (never silently recomputed).
    raw_dir = base/'evaluation'
    with gzip.open(raw_dir/'records.jsonl.gz', 'rt', encoding='utf-8') as stream:
        raw_rows = [json.loads(line) for line in stream]
    raw_v = {(r['id'],r['arm']):r for r in raw_rows if r['id'] in set(ids['F'])}
    raw_a = {r['id']:r for r in raw_rows if r['id'] in set(action_ids)}
    assert len(raw_v)==60*5 and len(raw_a)==60
    for arm in V_ARMS:
        for row in q['views'][arm]:
            raw = raw_v[(row['id'], arm)]
            for key, value in row.items():
                if key != 'solvable': assert value == raw[key], (seed, arm, key)
    for row in q['actions']:
        for key, value in row.items(): assert value == raw_a[row['id']][key], (seed, key)
    if quality_dir.name == 'evaluation-completion':
        continuation = read(quality_dir/'continuation.json')
        assert continuation['sha256'] == digest(raw_dir/'records.jsonl.gz')
        assert continuation['replayed_main_episodes'] == 0
    rays = {arm: np.array([r['rays'] for r in q['views'][arm]]) for arm in V_ARMS}
    view = {}
    families = sorted({r['family'] for r in q['views']['F']})
    assert len(families)==3
    for arm in V_ARMS:
        rows = q['views'][arm]
        med = statistics.median(rays[arm])
        ratio = med / statistics.median(rays['F'])
        losses = [r['id'] for b,r in zip(q['views']['F'],rows) if b['success'] and not r['success']]
        family_success = {fam: sum(r['success'] for r in rows if r['family']==fam) for fam in families}
        assert Counter(r['family'] for r in rows) == {fam:20 for fam in families}
        assert Counter(r['mode'] for r in rows) == {'NATURAL':30,'SECTION':30}
        decline = [fam for fam in families if family_success[fam] < sum(r['success'] for r in q['views']['F'] if r['family']==fam)]
        near(med, report['evaluation']['views'][arm]['rays_median'])
        near(ratio, report['evaluation']['views'][arm]['ray_ratio_to_F'])
        family_ray_ratio = {fam:float(statistics.median(r['rays'] for r in rows if r['family']==fam) /
            statistics.median(r['rays'] for r in q['views']['F'] if r['family']==fam)) for fam in families}
        view[arm] = {'median_rays': float(med), 'ratio':float(ratio), 'success':sum(r['success'] for r in rows),
                     'F_losses':losses, 'family_success':family_success,
                     'family_ray_ratio':family_ray_ratio,
                     'passed':bool(ratio<=.75 and not losses and not decline)}
        view_pool[arm].extend(rays[arm].tolist())
    actual = np.array([r['measured_delta_m'] for r in q['actions']])
    errors = {method: np.abs(np.array([r['comparison'][method] for r in q['actions']])-actual)
              for method in error_pool}
    mae = {method:float(err.mean()) for method,err in errors.items()}
    best = min(('G','C'), key=lambda x:mae[x])
    ratio = mae['L']/mae[best]
    budget = statistics.mean(r['delta_budget_m'] for r in q['actions'])
    for method in mae:
        near(mae[method],report['evaluation']['actions']['metrics'][method]['MAE_m'])
        error_pool[method].extend(errors[method].tolist())
    near(ratio,report['evaluation']['actions']['MAE_ratio_to_strongest'])
    action_family_ratios={}
    for family in sorted({row['family'] for row in q['actions']}):
        idx=[i for i,row in enumerate(q['actions']) if row['family']==family]
        assert len(idx)==20
        action_family_ratios[family]=float(errors['L'][idx].mean() / min(errors['C'][idx].mean(), errors['G'][idx].mean()))
    action = {'MAE_m':mae,'strongest_baseline':best,'L_ratio':ratio,'mean_delta_budget_m':budget,
              'family_L_ratios':action_family_ratios,
              'passed':ratio<=.8 and mae[best]>budget}
    # Every stored timing row, including non-gate warmups, is checked.
    timing = read(base/'performance/timing.json')
    line_rows = [json.loads(line) for line in (base/'performance/timing.jsonl').read_text().splitlines()]
    episodes = timing['episodes']
    assert episodes==line_rows and len(episodes)==60
    assert [r['ordinal'] for r in episodes] == list(range(60))
    durations = {stage:{arm:[] for arm in ARMS} for stage in STAGES}
    schedule = Counter()
    for ordinal, episode in enumerate(episodes):
        assert episode['view_id']==ids['F'][ordinal] and episode['action_id']==action_ids[ordinal]
        assert episode['view_family']==q['views']['F'][ordinal]['family']
        assert episode['action_family']==q['actions'][ordinal]['family']
        assert len(episode['samples'])==10
        for repeat, sample in enumerate(episode['samples']):
            assert sample['repeat']==repeat and sample['warmup']==(repeat<5)
            assert tuple(sample['order'])==ORDERS[(si+ordinal+repeat)%6]
            assert set(sample['arms'])==set(ARMS)
            schedule[tuple(sample['order'])]+=1
            for arm, values in sample['arms'].items():
                assert all(isinstance(values[s],int) and values[s]>0 for s in STAGES)
                assert values['total_ns']==values['V_ns']+values['A_ns']
        for stage in STAGES:
            for arm in ARMS:
                durations[stage][arm].append(statistics.median(s['arms'][arm][stage] for s in episode['samples'][5:]))
    stage_metrics={}
    for stage in STAGES:
        stats={arm:{'p95_ns':percentile(vals),'median_ns':statistics.median(vals)} for arm,vals in durations[stage].items()}
        for arm in ARMS:
            stats[arm]['p95_ratio']=stats[arm]['p95_ns']/stats['F']['p95_ns']
            near(stats[arm]['p95_ns'],report['timing'][stage]['all'][arm]['p95_ns'])
            near(stats[arm]['p95_ratio'],report['timing'][stage]['all'][arm]['p95_ratio_to_F'])
            time_pool[stage][arm].extend(durations[stage][arm])
        stage_metrics[stage]=stats
    # Full performance artifact/source identities bind current reviewed timing code.
    receipt=read(base/'performance/process.json')
    assert receipt['exit_code']==0 and receipt['sources_stable'] and receipt['inputs_stable']
    for name,identity in receipt['outputs'].items():
        p=base/'performance'/name
        assert digest(p)==identity['sha256'] and p.stat().st_size==identity['bytes']
    source=read(base/'performance/source.json')
    with zipfile.ZipFile(base/'performance/source.zip') as archive:
        for name, identity in source.items():
            stored=archive.read(name)
            assert sha256(stored).hexdigest()==identity['sha256']
            if name.startswith(('human_eye_fast/', 'verification/')):
                assert digest(ROOT/name)==identity['sha256'], name
            source_counts[name]+=1
    seal=read(base/'seal/frozen.json')
    assert seal['reference_arm']==min(('G','C'),key=lambda m:seal['action_validation_mae_m'][m])
    controls={label:{'count':len(q[label]),'success':sum(r['success'] for r in q[label])}
              for label in ('controls','diagnostic','prequential')}
    assert controls == {'controls':{'count':24,'success':24},'diagnostic':{'count':7,'success':7},'prequential':{'count':2,'success':2}}
    memory=read(base/'memory/memory.json')['capacity']
    assert memory['capacity']==4096 and memory['session_isolation'] and memory['closed']
    assert memory['occupancy']==[[0,0],[1,1],[4096,4096],[4096,4096]]
    result['per_seed'][str(seed)]={'view':view,'action':action,'timing':stage_metrics,
        'reference_arm':seal['reference_arm'],'controls':controls,
        'schedule_counts':{'/'.join(k):v for k,v in schedule.items()},
        'timed_episodes':60,'warmup_arm_runs':900,'measured_arm_runs':900,
        'V_gate':view['L']['passed'],'A_gate':action['passed'],
        'time_gate':all(stage_metrics[s]['L']['p95_ratio']<=1.1 for s in STAGES)}

# Reproduce the fixed paired, within-seed sampling independently of cf_report.
rng=np.random.Generator(np.random.PCG64(271828))
draws=np.hstack([rng.integers(0,60,(10000,60))+60*i for i in range(3)])
def ci(values): return np.quantile(values,(.025,.975),method='linear').tolist()
pool={'view':{},'action':{},'time':{}}
for arm in ('R','L','zero','shuffle'):
    a,b=np.array(view_pool[arm]),np.array(view_pool['F'])
    interval=ci(np.median(a[draws],axis=1)/np.median(b[draws],axis=1))
    ratio=float(np.median(a)/np.median(b))
    near(ratio,summary['pooled_and_bootstrap']['view'][arm]['pooled_ratio'])
    for x,y in zip(interval,summary['pooled_and_bootstrap']['view'][arm]['interval_95']):near(x,y)
    pool['view'][arm]={'ratio':ratio,'interval_95':interval}
err={a:np.array(v) for a,v in error_pool.items()}
for arm in ('L','shuffle'):
    ratio=float(err[arm].mean()/min(err['C'].mean(),err['G'].mean()))
    interval=ci(err[arm][draws].mean(axis=1)/np.minimum(err['C'][draws].mean(axis=1),err['G'][draws].mean(axis=1)))
    near(ratio,summary['pooled_and_bootstrap']['action'][arm]['pooled_ratio_to_strongest'])
    for x,y in zip(interval,summary['pooled_and_bootstrap']['action'][arm]['interval_95']):near(x,y)
    pool['action'][arm]={'ratio':ratio,'interval_95':interval}
for stage in STAGES:
    arrays={a:np.array(v) for a,v in time_pool[stage].items()}
    stats={arm:{'p95_ns':percentile(values),'median_ns':statistics.median(values)} for arm,values in arrays.items()}
    for arm in ('R','L'):
        stats[arm]['ratio']=stats[arm]['p95_ns']/stats['F']['p95_ns']
        interval=ci(np.quantile(arrays[arm][draws],.95,axis=1,method='linear') / np.quantile(arrays['F'][draws],.95,axis=1,method='linear'))
        stats[arm]['interval_95']=interval
        for x,y in zip(interval,summary['pooled_and_bootstrap']['time'][stage]['ratios'][arm]['interval_95']):near(x,y)
        near(stats[arm]['p95_ns'],summary['pooled_and_bootstrap']['time'][stage]['pooled'][arm]['p95_ns'])
    pool['time'][stage]=stats
result['pooled']=pool
result['checks']={'all_main_metric_records_match_original_raw':True,
  'all_performance_json_equals_incremental_jsonl':True,'all_5400_arm_intervals_structurally_valid':True,
  'all_2700_measured_arm_intervals_used':True,'all_performance_source_snapshots_match_current':True,
  'performance_source_files_per_seed':len(source_counts),'all_10000_bootstrap_CIs_match':True,
  'all_three_L_gates_pass':all(x['V_gate'] and x['A_gate'] and x['time_gate'] for x in result['per_seed'].values())}
result['decision']='METRIC_GATES_PASS'
result['caveats']=[
  'Pooled total p95 and V p95 increase, with bootstrap intervals above one. This is quality/ray efficiency under a <=10% cost allowance, not wall-clock acceleration.',
  'R fails first-seed ray threshold. L is the accepted candidate in the frozen protocol.',
  'First-seed shuffled V supervision has the same ray median as L; not every seed alone establishes the learning mechanism.',
  '310519/pleated-baffle V ray median rises 22.5->24.5 (+8.8889%); protocol gates rays per seed and pixel quality per family. All 9 A family MAEs improve versus each family lower C/G.',
  'Stage timing breakdown is one separate first-episode probe per seed, not distributions for every internal stage.',
  'Summary structure does not itself prove native images or input leakage absence; sibling reviews cover these.'
]
OUT.write_text(json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
print(json.dumps({'decision':result['decision'],'checks':result['checks'],'pooled':pool['time']['total_ns']},indent=2))
