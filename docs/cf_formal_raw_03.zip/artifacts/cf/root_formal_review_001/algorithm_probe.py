"""Independent CF evidence/math checks; no fitting, fixture generation or native calls."""
from pathlib import Path
import gzip
import hashlib
import json
import sys
import zipfile
import numpy as np

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from human_eye_fast.cerebellar_flash import ExperienceBank, LinearHead, CerebellarFlash

FORMAL = ROOT / "artifacts/cf/formal_001"
OUT = Path(__file__).with_suffix(".json")
SEEDS = (20261105, 79463, 310519)
CHECKS = []
DETAIL = {}

def check(name, condition):
    CHECKS.append({"check": name, "passed": bool(condition)})

def load(path):
    return json.loads(path.read_bytes())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def arrays(path):
    with np.load(path, allow_pickle=False) as data:
        return {name: data[name].copy() for name in data.files}

def design(keys, data, prefix, view=False):
    raw = np.array(keys, dtype=np.float64, copy=True)
    if view:
        raw[..., 2:] = np.log1p(raw[..., 2:])
    z = (raw - data[prefix + "_mean"]) / data[prefix + "_scale"]
    cols = [z]
    if data[prefix + "_quadratic"]:
        # Explicit canonical j<=k list, independent of production triu indexing.
        cols.append(np.stack([z[..., j] * z[..., k]
                              for j in range(z.shape[-1])
                              for k in range(j, z.shape[-1])], axis=-1))
    cols.append(np.ones((*z.shape[:-1], 1)))
    return np.concatenate(cols, axis=-1)

def normalized_std(values, axis=0):
    std = values.std(axis=axis)
    return np.where(std == 0, 1., std)

def group_key(row):
    return str(row[0]), int(row[1]), int(row[2])

for seed in SEEDS:
    p = FORMAL / str(seed)
    trained = arrays(p / "fit/candidates.npz")
    frozen = arrays(p / "seal/frozen.npz")
    fit = load(p / "fit/candidates.json")
    sealed = load(p / "seal/frozen.json")
    selection = load(p / "seal/frozen.selection.json")
    train_v = arrays(p / "train/view.npz")
    train_a = arrays(p / "train/action.npz")
    val_a = arrays(p / "validation-labels/action.npz")
    val_v = load(p / "validation-arms/views.json")
    check(f"{seed}: four configs / 200 V updates",
          fit["configs"] == [[False,.001],[False,.01],[True,.001],[True,.01]]
          and fit["view_updates_per_config"] == 200)
    check(f"{seed}: model / selection hashes",
          sha(p / "fit/candidates.npz") == fit["candidate_sha256"]
          and sha(p / "seal/frozen.npz") == sealed["snapshot_sha256"]
          and sha(p / "seal/frozen.selection.json") == sealed["selection_sha256"])
    check(f"{seed}: fit train-only inputs",
          {Path(r["path"]).resolve() for r in fit["actual_reads"]} ==
          {p / "train/view.npz", p / "train/action.npz"})
    check(f"{seed}: seal has no evaluation / diagnostic reads",
          all(not any(x in r["path"].lower() for x in ("evaluation", "diagnostic"))
              for r in sealed["actual_reads"]))
    for label, rows in (("fit",fit["actual_reads"]),("seal",sealed["actual_reads"])):
        check(f"{seed}: {label} input hashes still match",
              all(sha(Path(r["path"])) == r["sha256"] for r in rows))
    manifests = {split: load(p / f"specs/manifest-{split}.json")["episodes"]
                 for split in ("train", "validation", "evaluation", "diagnostic")}
    for head in ("V", "A"):
        groups = [{r["group_id"] for r in manifests[split] if r["head"] == head}
                  for split in ("train", "validation", "evaluation")]
        families = [{r["family"] for r in manifests[split] if r["head"] == head}
                    for split in ("train", "validation", "evaluation")]
        check(f"{seed}: {head} split sizes/group separation",
              list(map(len,groups)) == [240,60,60] and
              all(not(groups[i] & groups[j]) for i in range(3) for j in range(i+1,3)))
        check(f"{seed}: {head} heldout families", not((families[0] | families[1]) & families[2]))
        expected_ids = [r["episode_id"] for r in manifests["train"] if r["head"] == head]
        check(f"{seed}: {head} ring provenance train only",
              sealed["train_bank_rows"]["view" if head == "V" else "action"] == expected_ids)
    check(f"{seed}: train shape / count", train_v["keys"].shape == (240,16,5) and
          train_a["keys"].shape == (240,23))
    for name, raw in (("view_keys",train_v["keys"]),("view_feedback",train_v["feedback"]),
                      ("action_keys",train_a["keys"]),
                      ("action_labels",train_a["labels_m"]/train_a["scales"]-train_a["keys"][:,1])):
        check(f"{seed}: {name} original train bytes/value binding",
              np.array_equal(trained[name],raw) and np.array_equal(frozen[name],raw))
    check(f"{seed}: retrieval normalization train only",
          np.array_equal(trained["retrieval_scale"],normalized_std(train_v["keys"])) and
          np.array_equal(frozen["retrieval_scale"],trained["retrieval_scale"]))
    for h, raw in (("v",train_v["keys"].reshape(-1,5).copy()),("a",train_a["keys"])):
        if h == "v": raw[:,2:] = np.log1p(raw[:,2:])
        for i in range(4):
            pref = f"{h}{i}"
            check(f"{seed}: {pref} train-only standardization / config",
                  np.array_equal(trained[pref+"_mean"],raw.mean(axis=0)) and
                  np.array_equal(trained[pref+"_scale"],normalized_std(raw)) and
                  bool(trained[pref+"_quadratic"]) == (i>=2) and
                  float(trained[pref+"_lambda"]) == (.001 if i%2==0 else .01))
    labels, groups = train_a["labels_m"], list(map(group_key, train_a["groups"]))
    medians = {g: float(np.median([y for y,k in zip(labels,groups) if k==g])) for g in set(groups)}
    check(f"{seed}: C conditional medians train only",
          all(float(m)==medians[group_key(g)] for g,m in zip(trained["c_groups"],trained["c_medians"])))
    mae = {"C": float(np.mean(np.abs([medians[group_key(g)]-y for g,y in
                                    zip(val_a["groups"],val_a["labels_m"])]))),
           "G": float(np.mean(np.abs(val_a["keys"][:,1]*val_a["scales"]-val_a["labels_m"])))}
    for i in range(4):
        pred = val_a["scales"]*(val_a["keys"][:,1]+design(val_a["keys"],trained,f"a{i}") @ trained[f"a{i}_weights"])
        mae[f"L{i}"] = float(np.mean(np.abs(pred-val_a["labels_m"])))
    a_winner = min(range(4),key=lambda i:(mae[f"L{i}"],i))
    reference = "G" if mae["G"] <= mae["C"] else "C"
    check(f"{seed}: independent A validation selection", a_winner == sealed["action_config"]
          and reference == sealed["reference_arm"] and
          all(np.isclose(v,sealed["action_validation_mae_m"][k],rtol=1e-12,atol=1e-18) for k,v in mae.items()))
    scores = {}
    base = val_v["F"]
    for arm in ("R","L0","L1","L2","L3"):
        rows = val_v[arm]
        check(f"{seed}: {arm} validation row binding", [r["id"] for r in rows] == [r["id"] for r in base])
        scores[arm] = (sum(b["success"] and not r["success"] for b,r in zip(base,rows)),
                       sum(sum(r["success"] for r in rows if r["family"]==family) <
                           sum(r["success"] for r in base if r["family"]==family)
                           for family in {r["family"] for r in base}),
                       float(np.median([r["rays"] for r in rows])/np.median([r["rays"] for r in base])),
                       -sum(r["success"] for r in rows))
    v_winner = min(range(4),key=lambda i:(*scores[f"L{i}"],i))
    check(f"{seed}: independent V validation selection", v_winner == sealed["view_config"] and
          all(list(v)==sealed["view_validation_scores"][k] for k,v in scores.items()))
    for final,cand in (("view_head",f"v{v_winner}"),("action_head",f"a{a_winner}")):
        check(f"{seed}: {final} equals selected pre-evaluation candidate",
              all(np.array_equal(frozen[final+"_"+tail],trained[cand+"_"+tail])
                  for tail in ("mean","scale","weights","quadratic","lambda")))
    check(f"{seed}: zero V weights", not np.count_nonzero(frozen["view_zero_weights"]))
    for i,h in enumerate(("view","action")):
        perm=np.random.Generator(np.random.PCG64(np.random.SeedSequence([seed,i,2718]))).permutation(240)
        check(f"{seed}: {h} frozen shuffle permutation", list(map(int,perm))==sealed[f"shuffle_{h}_train_indices"])
    raw = [json.loads(line) for line in gzip.open(p / "evaluation/records.jsonl.gz", "rt")]
    main_a = [r for r in raw if r["id"].startswith(f"A-{seed}-evaluation-")]
    max_error=0.
    for row in main_a:
        x=np.asarray(row["features"]); meters=row["feature_scale_m"]
        for arm,prefix in (("L","action_head"),("shuffle","action_shuffle")):
            prediction=float(meters*(x[1]+design(x,frozen,prefix) @ frozen[prefix+"_weights"]))
            max_error=max(max_error,abs(prediction-row["comparison"][arm]))
        check(f"{seed}: action current G/scale and real outcome {row['id']}",
              x[1]*meters==row["comparison"]["G"] and
              row["distance_after_m"]-row["distance_before_m"]==row["measured_delta_m"])
    check(f"{seed}: all main action predictions reproduce", len(main_a)==60 and max_error<1e-14)
    stages=[x for x in p.iterdir() if (x/"source.json").is_file()]
    stable_files=("human_eye_fast/cerebellar_flash.py","human_eye_fast/_cf_features.py",
                  "verification/cf_training.py","verification/cf_native.py",
                  "verification/cf_fixtures.py","verification/cf_baselines.py","docs/CF_ACCEPTANCE_PROTOCOL.md")
    for name in stable_files:
        hashes={load(x/"source.json")[name]["sha256"] for x in stages}
        check(f"{seed}: frozen stage identity {name}",hashes=={sha(ROOT/name)})
    DETAIL[str(seed)]={"view_config":v_winner,"action_config":a_winner,"reference":reference,
                       "independent_validation_mae_m":mae,"max_prediction_reproduction_error_m":max_error,
                       "seal_mtime_ns":(p/"seal/frozen.npz").stat().st_mtime_ns,
                       "evaluation_manifest_mtime_ns":(p/"specs/manifest-evaluation.json").stat().st_mtime_ns,
                       "diagnostic_manifest_mtime_ns":(p/"specs/manifest-diagnostic.json").stat().st_mtime_ns}

latest_seal=max(d["seal_mtime_ns"] for d in DETAIL.values())
check("all three seeds sealed before any evaluation / diagnostic manifest",
      all(latest_seal<min(d["evaluation_manifest_mtime_ns"],d["diagnostic_manifest_mtime_ns"]) for d in DETAIL.values()))
p=FORMAL / "20261105"
raw=[json.loads(line) for line in gzip.open(p/"evaluation/records.jsonl.gz","rt")]
result=load(p/"evaluation-completion/summary.json")
original=load(p/"evaluation/process.json")
check("original failed run retained/hash bound",original["exit_code"]==1 and
      original["outputs"]["records.jsonl.gz"]["sha256"]==sha(p/"evaluation/records.jsonl.gz"))
view_exclude={"audit","score","media"}
action_exclude={"features","group_key","outcome","native_before","native_after"}
for arm in ("F","R","L","zero","shuffle"):
    rows=[{k:v for k,v in r.items() if k not in view_exclude} for r in raw if r.get("arm")==arm]
    output=[{k:v for k,v in r.items() if k!="solvable"} for r in result["views"][arm]]
    check(f"continuation preserves all 60 original V {arm} rows", len(rows)==60 and rows==output)
actions=[{k:v for k,v in r.items() if k not in action_exclude} for r in raw if r["id"].startswith("A-")]
check("continuation preserves all 60 original A rows",len(actions)==60 and actions==result["actions"])
new_raw=[json.loads(line) for line in gzip.open(p/"evaluation-completion/records.jsonl.gz","rt")]
check("continuation emits no new main evaluation rows",all("-evaluation-" not in r["id"] for r in new_raw))
with zipfile.ZipFile(p/"evaluation/source.zip") as first,zipfile.ZipFile(p/"evaluation-completion/source.zip") as second:
    changed=[n for n in first.namelist() if first.read(n)!=second.read(n)]
DETAIL["continuation_changed_files"]=changed
check("continuation changes only four reviewed verifier files",set(changed)=={
      "verification/benchmark_cerebellar_flash.py","verification/cf_experiment.py",
      "verification/cf_report.py","verification/cf_visual_acceptance.py"})

# Independent equations on tiny synthetic rows, not fitting or evaluation generation.
for view in (False,True):
    mean=np.array([.1,.2,.3]);scale=np.array([.5,.7,.9]);weights=np.arange(10)/10-.3
    head=LinearHead(mean,scale,weights,quadratic=True,regularization=.01,view=view)
    row=np.array([.2,.8,.6]);d=design(row,{"h_mean":mean,"h_scale":scale,"h_quadratic":True},"h",view)
    check(f"tiny {view}: basis ordering",np.allclose(head.design(row),d,rtol=0,atol=1e-15))
    label=.7; old=head.weights.copy(); predicted=float(d@old)
    error=(1/(1+np.exp(-predicted))-label) if view else predicted-label
    regularizer=np.r_[.01*old[:-1],0.]
    expected=old-(.05/(1+float(d@d)))*(error*d+regularizer)
    (head.learn_view if view else head.learn_action)(row,label)
    check(f"tiny {view}: single online gradient",np.allclose(head.weights,expected,rtol=0,atol=2e-16))
bank=ExperienceBank((16,5),(16,2),(16,),capacity=4)
key=np.zeros((16,5));scale=np.ones((16,5))
check("empty ring canonical",bank.rank(key,scale)==tuple(range(16)))
for i in range(5):bank.append_view(key,i,True,i+1)
check("wrapped nearest tie selects oldest live insertion",bank.rank(key,scale)[0]==1 and len(bank)==4 and bank.writes==5)
check("online partial observation only one known",np.count_nonzero(bank.known[0])==1 and bank.known[0,4])
session=CerebellarFlash(None,None,retrieval_scale=scale,capacity=4)
session.views.append_view(key,3,False,9)
ranking=session.rank_view(key,"R")
check("unknown before known unsafe",ranking[-1]==3)
clone=session.clone();clone.views.append_view(key+1,2,True,1)
check("cloned rings independent",session.views.writes==1 and clone.views.writes==2 and not np.shares_memory(session.views.keys,clone.views.keys))
session.close();check("close releases arrays",session.views.keys is None and session.actions.keys is None)

report={"scope":"lightweight independent evidence/math review, no training/native/performance calls",
        "checks":CHECKS,"failed":[r for r in CHECKS if not r["passed"]],"details":DETAIL,
        "chronology_limitation":"mtime is corroborative filesystem evidence, not tamper-proof creation proof; read logs are explicit application-level logs, not OS access enforcement."}
OUT.write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+"\n",encoding="utf-8")
print(json.dumps({"checks":len(CHECKS),"failed":report["failed"],"output":str(OUT)}))
