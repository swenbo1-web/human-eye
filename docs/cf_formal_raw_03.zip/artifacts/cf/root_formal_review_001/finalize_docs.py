from pathlib import Path
import json
from hashlib import sha256

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent


def replace(path, old, new):
    target = ROOT / path
    data = target.read_bytes()
    old, new = old.encode(), new.encode()
    assert data.count(old) == 1, (path, old)
    target.write_bytes(data.replace(old, new))


replace('README.md', '学习与统一整链仍待完成。', 'CF视角与动作学习已验收，S及统一生产编排仍待完成。')
replace('README.md', '[CF协议和场景冻结已通过](docs/CF_PREFLIGHT_REVIEW.md)，当前推进模型、经验库及正式测试；学习收益与全引擎端到端尚未验收。', '[CF V+A学习已独立验收](docs/CF_ROOT_REVIEW.md)：逐seed射线减少43%–48%、动作MAE减少53%–67%；整链p95增加2.19%，在原10%成本门内，局部退化与续做流程偏差均披露。S必要性/协议与统一整引擎验收待完成。')
replace('docs/RADICAL_V1_INTEGRATION_PLAN.md', 'CF协议/夹具冻结已通过，正在推进模型、经验库与正式测试；', 'CF V+A模型/经验库已通过[独立验收](CF_ROOT_REVIEW.md)，S必要性及统一生产编排待验；')
replace('docs/RADICAL_V1_INTEGRATION_PLAN.md', 'VG已验收真实主动视角、剖切与双联PNG，采用主干流式编码 | CF学习与整链编排', 'VG已验收真实主动视角、剖切与双联PNG，CF视角学习已验收 | 统一生产整链编排')
replace('docs/RADICAL_V1_INTEGRATION_PLAN.md', '无学习记忆；`FastSession` 缓存不等于学习 | 特征、经验标签和动作条件；会话内环形库；检索与读出学习；增益消融', 'CF V+A特征、真实标签、两头环形库及学习读出已验收；R首seed门未过 | S必要性/协议与统一会话生命周期')
replace('docs/RADICAL_V1_INTEGRATION_PLAN.md', 'E2：同名文件待实施 | 会话持有检索库/学习读出，以真实观察和动作结果监督，不使用全局隐式单例', 'E2：已实现同名文件及_cf_features.py，V+A已验收 | 会话持有两头经验环/学习读出，S及统一入口待验')
replace('docs/RADICAL_V1_COMPETITION_WORKFLOW.md', 'CF协议/夹具冻结及最小VG排序接线已通过[阶段复核](CF_PREFLIGHT_REVIEW.md)，当前同一实施聊天推进模型、经验库与正式测试，CF学习和整链尚未验收。', 'CF V+A模型/经验库及学习收益已通过[主干独立复核](CF_ROOT_REVIEW.md)，保留整链p95增加2.19%和局部射线退化等边界；该目标收口，同一聊天下一步仅做S必要性/协议，统一生产编排与全引擎最终验收待完成。')
replace('docs/CF_WORK_ORDER.md', '协议/夹具阶段已通过[主干复核](CF_PREFLIGHT_REVIEW.md)，现在在同一聊天继续第二阶段实现与正式测试。当前冻结协议及源码见[冻结JSON](radical_acceptance_cf_preflight.json)；不表示CF学习收益或整链已经通过。', '协议/夹具阶段与第二阶段V+A均已通过主干复核，当前结论见[CF审查](CF_ROOT_REVIEW.md)及[验收JSON](radical_acceptance_cf.json)。V+A目标收口，下一步只按[独立S派工](CF_S_WORK_ORDER.md)做必要性/协议；原第二阶段条款保留为历史执行范围，不重新启动。统一生产编排与全引擎最终验收未通过。')
replace('docs/CF_WORK_ORDER.md', '## 当前第二阶段：实现、训练、自测后回传', '## 第二阶段：已完成并验收，保留执行合同')
replace('docs/CF_WORK_ORDER.md', '当前GPU/性能窗口交给本CF聊天，后台Blender任务串行启动', '第二阶段GPU窗口已释放；未来获派原生测量时，后台Blender任务串行启动')

log = ROOT / 'docs/RADICAL_V1_ACCEPTANCE_LOG.md'
with log.open('ab') as stream:
    stream.write(('\r\n## 主验收013：CF V+A — ACCEPT_VA，目标收口\r\n\r\n'
        '三个seed的L视角射线比.541667/.520000/.565217，540幅F/R/L主PNG独立复核通过；A对较强C/G的MAE比.333992/.465583/.375342。整链及V/A子段每seed p95均低于1.10；整链pooled p95 56.940→58.186ms（+2.19%），不是墙钟提速。310519折纹挡板族射线中位+8.89%保留，R首seed未过；原合同逐seed射线和逐族像素门不变。\r\n\r\n'
        '主干341项算法/隔离探针、25阶段来源身份及全部原始时间重算通过；54视角+18动作真实重放字节/数值一致，72控制/21诊断/6顺序反馈及负例另重放一致，14便携单测通过。首seed零距bool传输失败后的作者续做未事前报告主干固定范围，记录流程偏差；原主数据及模型未变，根端独立复核不替换原统计。所有失败证据保留。\r\n\r\n'
        '采用原实施生产源码7c185a4a及特征130a66f8，未追加主干优化；按用户新收口规则直接结束V+A目标。下一步同CF聊天只做S必要性/协议；统一生产入口/会话及最终整引擎仍待验。见[CF独立审查](CF_ROOT_REVIEW.md)、[验收JSON](radical_acceptance_cf.json)及[证据索引](cf_formal_evidence_index.json.gz)。\r\n').encode())

def read(name):
    return json.loads((HERE / name).read_bytes())

summary = json.loads((ROOT / 'artifacts/cf/formal_001/summary.json').read_bytes())
delivery = json.loads((ROOT / 'artifacts/cf/formal_001/delivery-identity.json').read_bytes())
decision = {'decision': 'ACCEPT_VA', 'date': '2026-11-05',
            'selected': 'Delivered L view ranking + learned finite-action residual, unchanged by root',
            'protocol_sha256': '740662fe75aa1108cd0fc580024fa3ffb813b16677b1300274ad05c111dbdb43',
            'sources': delivery['sources'], 'frozen_snapshots': {k: v['frozen'] for k, v in delivery['seeds'].items()},
            'author_summary': summary, 'independent_statistics': read('statistics_review.json'),
            'independent_algorithm': read('algorithm_probe.json'), 'independent_quality': read('quality_probe.json'),
            'identity_and_native_replay': read('identity_review.json'),
            'portable_tests': {'count': 14, 'passed': 14,
                               'command': 'python -B -m unittest verification.test_cerebellar_flash verification.test_cf_training -v'},
            'limitations': ['Wall-clock total p95 +2.19%, V p95 +3.54%, cost gates passed; no latency speedup claim',
                            'Seed310519 pleated-baffle median rays +8.89%; per-seed gates still pass',
                            'R first seed fails; V shuffled first seed shares L median',
                            'Continuation lacked advance root scope approval; original main data unchanged, root replay passes',
                            'No immutable chronology or OS enforced read sandbox; evidence combines code, logs and identities',
                            'S and unified production orchestration/final engine acceptance pending',
                            'Offline train/validation bulk PNG remain local, exact hashes indexed'],
            'next_work_order': 'docs/CF_S_WORK_ORDER.md'}
(ROOT / 'docs/radical_acceptance_cf.json').write_text(json.dumps(decision, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('Updated CF acceptance and current status documents')
