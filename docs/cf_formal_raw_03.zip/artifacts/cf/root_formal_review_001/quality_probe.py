"""Independent CPU replay of saved CF quality evidence; no Blender or model fitting."""
import base64
from collections import Counter
from copy import deepcopy
import gzip
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import sys
from zipfile import ZipFile

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
# Existing pre-CF independent camera and pixel-coordinate definitions only.
from verification.test_raycast_saccade_gpu import _digital_line, _neighbors

BASE = ROOT / "artifacts/cf/formal_001"
OUT = Path(__file__).with_suffix(".json")
GRID_AXIS = np.linspace(8, 503, 25).astype(np.int32)
GRID = np.column_stack((np.tile(GRID_AXIS, 25), np.repeat(GRID_AXIS, 25)))
STEPS = (0, 1, -1, 2, -2, 3, -3, 4, -4, 5, -5, 6, -6, 7, -7, 8)
COLORS = np.rint(255 * np.array(((.08,.10,.14,1),(.82,.24,.15,1),(.16,.60,.90,1),(.36,.40,.45,1)))).astype(np.int16)


class _Camera:
    """Pure NumPy orthographic reconstruction; never imports/creates Blender cameras."""
    def __init__(self,record,scale):
        rna,gpu=record["rna"],record["gpu"]
        world=np.asarray(rna["matrix_world"],dtype=float).copy();world[:3,3]*=scale
        self.backward=world[:3,2];self.width=rna["ortho_scale"]*scale
        self.view=np.asarray(gpu["view"]);self.vp=np.asarray(gpu["view_projection"])
        w,n,f=rna["ortho_scale"],rna["clip_start"],rna["clip_end"]
        projection=np.array([[2/w,0,0,-2*rna["shift_x"]],[0,2/w,0,-2*rna["shift_y"]],
                             [0,0,-2/(f-n),-(f+n)/(f-n)],[0,0,0,1.]])
        recorded=np.asarray(rna["projection"])
        same=lambda a,b:bool(np.allclose(a,b,rtol=8*np.finfo(np.float32).eps,atol=8*np.finfo(np.float32).eps))
        self.agreement={"orthographic":rna["type"]=="ORTHO" and 0<n<f and w>0,
            "rotation":same(world[:3,:3].T@world[:3,:3],np.eye(3)) and np.linalg.det(world[:3,:3])>0,
            "analytic_rna_projection":same(recorded,projection),
            "gpu_view":same(self.view,np.linalg.inv(world)),
            "gpu_projection":same(gpu["projection"],recorded@np.diag((1/scale,1/scale,1/scale,1))),
            "gpu_view_projection":same(self.vp,np.asarray(gpu["projection"])@self.view)}

    def project(self,points):
        points=np.column_stack((points,np.ones(len(points))))
        clip=points@self.vp.T
        pixels=((clip[:,:2]/clip[:,3,None])*(1,-1)+1)*256-.5
        return pixels,-(points@self.view[2])


def read(path):
    return json.loads(path.read_bytes())


def digest(data):
    return sha256(data).hexdigest()


def unpack(s, dtype, shape):
    return np.frombuffer(base64.b64decode(s), dtype=dtype).reshape(shape)


def close(a, b, atol=2e-6):
    return np.allclose(a, b, rtol=0, atol=atol)


def palette(audit):
    targets = audit["expected"]["target_ids"]
    return np.asarray([COLORS[0]] + [COLORS[1+targets.index(k)] if k in targets else COLORS[3]
                                   for k in audit["mesh_ids"][1:]])


def matches(a, b):
    return (np.abs(np.asarray(a, dtype=np.int16) - b) <= 1).all(axis=-1)


def longest(bits):
    best = run = 0
    for bit in bits:
        run = run + 1 if bit else 0
        best = max(best, run)
    return best


def ray_check(audit):
    meta = audit["metadata"]
    trace = audit["trace"]
    probes = meta["selection"]["probes"]
    order = audit["order"]
    if audit["expected"]["witness"]["distance_m"] == 0:
        return not trace and not order and not probes and meta["selection"]["ray_count"] == 0
    assert sorted(order) == list(range(16)) or len(order) == 1
    # Use float32 elementary operations to match the native vector inputs;
    # never trust the recorded candidate index without a geometric check.
    witness = audit["expected"]["witness"]
    pa, pb = np.asarray((witness["point_a"], witness["point_b"]), dtype=np.float32)
    axis = pb-pa
    axis /= np.linalg.norm(axis)
    fixed = np.array((1,-1,1), dtype=np.float32); fixed /= np.linalg.norm(fixed)
    u = fixed - (fixed @ axis)*axis
    assert u @ u > np.finfo(np.float32).eps**2, "axial case needs native orthogonal convention"
    u /= np.linalg.norm(u)
    v = np.cross(axis,u); v /= np.linalg.norm(v)
    directions = []
    for k in STEPS:
        d = np.float32(np.cos(k*np.pi/8))*u + np.float32(np.sin(k*np.pi/8))*v
        directions.append(d/np.linalg.norm(d))
    offset = 0
    scores = []
    counts = np.cumsum(audit["face_counts"])
    for candidate, probe in zip(order, probes):
        calls = trace[offset:offset+probe["ray_count"]]
        assert calls
        offset += len(calls)
        assert close(probe["direction"], directions[candidate], 4e-6)
        for call in calls:
            assert call["candidate"] == candidate and close(call["direction"], -directions[candidate], 4e-6)
            tri = call["triangle"]
            if tri is None:
                assert call["owner"] is None and call["depth_m"] is None
            else:
                owner_code = int(np.searchsorted(counts, tri, side="right"))
                assert 0 < owner_code < len(audit["mesh_ids"])
                assert call["owner"] == audit["mesh_ids"][owner_code] and call["depth_m"] >= 0
        aperture = [r for r in calls if r["purpose"] == "aperture"]
        support = [r for r in calls if r["purpose"] != "aperture"]
        opened = probe["aperture_taps"]
        assert len(aperture) == (9 if opened == 9 else opened+1)
        assert calls == aperture + support
        targets = audit["expected"]["target_ids"]
        supported = 0
        for label,target in zip(("support_a","support_b"), targets):
            part = [r for r in support if r["purpose"] == label]
            if opened == 9:
                assert 2 <= len(part) <= 6
                hits = sum(r["owner"] == target for r in part)
                assert hits <= 2 and (len(part) == 6 or (hits == 2 and part[-1]["owner"] == target))
                supported += hits == 2
            else:
                assert not part
        assert supported == probe["target_support"]
        scores.append((supported,opened))
    assert offset == len(trace) == audit["ray_count"] == meta["selection"]["ray_count"]
    assert all(s[0] < 2 for s in scores[:-1])
    stopped = scores[-1][0] == 2
    assert stopped == audit["native_stop"] and (stopped or len(probes) == len(order))
    selected = len(scores)-1 if stopped else max(range(len(scores)),key=scores.__getitem__)
    assert audit["candidate"] == order[selected]
    assert close(meta["selection"]["direction"], directions[audit["candidate"]], 4e-6)
    return True


def visual_check(png, audit):
    # This function does not import CF's scorer or use its PASS/native_checks.
    with Image.open(BytesIO(png)) as image:
        actual = np.asarray(image.convert("RGBA"))
    assert actual.shape == (512,1024,4)
    expected,meta = audit["expected"],audit["metadata"]
    assert meta["target_ids"] == expected["target_ids"]
    assert meta["frame_id"] == expected["frame_id"] and meta["mode"] == expected["mode"]
    assert meta["witness"] == {**expected["witness"],"status":expected["status"]}
    assert meta["meters_per_blender_unit"] == expected["scale_length"]
    assert sorted(meta["mesh_ids"]) == sorted(audit["mesh_ids"][1:])
    p = palette(audit)
    cameras = {side:_Camera(meta["views"][side],expected["scale_length"]) for side in ("global","local")}
    for camera in cameras.values():
        assert all(camera.agreement.values()), camera.agreement
    points = np.asarray((expected["witness"]["point_a"],expected["witness"]["point_b"]))
    gap = expected["witness"]["distance_m"]
    px,depths = cameras["local"].project(points)
    assert close(cameras["global"].backward,np.array((1,-1,1))/np.sqrt(3))
    assert close(cameras["local"].backward,meta["selection"]["direction"])
    assert close(cameras["local"].project(points.mean(axis=0)[None])[0][0],(255.5,255.5),.005)
    if gap:
        assert abs(cameras["local"].width-32*gap) <= audit["depth_tolerance_m"]
    if expected["mode"] == "SECTION":
        sec = meta["section"]
        assert close(sec["point_m"],points.mean(axis=0),audit["depth_tolerance_m"])
        assert close(sec["normal"],meta["selection"]["direction"]) and sec["kept_side"] == "<=0"
    else:
        assert meta["section"] is None
    grid_failures = []
    for panel,side in enumerate(("global","local")):
        raw = audit["grid"][side]
        owner = unpack(raw["owners_i32le"],"<i4",(625,))
        assert ((owner>=0)&(owner<len(p))).all()
        bottom = unpack(raw["bottom_rgba"],"u1",(625,4))
        mismatch = set(np.flatnonzero(~matches(bottom,p[owner])).tolist())
        for i,near in raw["edge_owners"]:
            assert len(near) == 4 and all(0<=code<len(p) for code in near)
            if i in mismatch and matches(bottom[i],p[near]).any():mismatch.remove(i)
        projected,_=cameras[side].project(points)
        assert close(projected,audit["witness_pixels"][side],.005)
        outside = (GRID[:,1]>=64)&(GRID[:,1]<=447)
        outside &= GRID[:,0]<511 if panel==0 else GRID[:,0]>0
        for point in projected:outside &= ((GRID-point)**2).sum(axis=1)>32**2
        public=actual[GRID[:,1],GRID[:,0]+512*panel]
        drift=np.count_nonzero(outside & (public!=bottom).any(axis=1))
        if mismatch or drift:grid_failures.append((side,len(mismatch),int(drift)))
    assert not grid_failures, grid_failures
    ray_check(audit)
    if not gap:
        assert np.linalg.norm(px[1]-px[0])<=.005
        return {"gap":None,"support":None}
    separation=np.linalg.norm(px[1]-px[0]); assert separation>=4 and (px>=-.5).all() and (px<511.5).all()
    assert abs(separation-meta["selection"]["gap_pixels"])<=.005
    codes=[audit["mesh_ids"].index(t) for t in expected["target_ids"]]
    def sample(raw,expected_xy):
        xy=np.asarray(raw["pixels"],dtype=int).reshape(-1,2)
        assert np.array_equal(xy,np.asarray(expected_xy).reshape(-1,2))
        owner=np.asarray(raw["owners"],dtype=int);face=np.asarray(raw["faces"],dtype=int)
        assert ((owner>=0)&(owner<len(p))).all()
        depth=np.asarray([np.inf if x is None else x for x in raw["depth_m"]])
        count=np.asarray(audit["face_counts"])
        assert (((owner==0)&(face==-1)&np.isinf(depth))|((owner>0)&(face>=0)&(face<count[owner])&np.isfinite(depth)&(depth>0))).all()
        bottom=unpack(raw["bottom_rgba"],"u1",(len(xy),4))
        public=actual[xy[:,1],xy[:,0]+512]
        return xy,owner,depth,matches(bottom,p[owner])&matches(public,p[owner])
    support=[]
    for point,code,raw in zip(px,codes,audit["samples"]["supports"]):
        _,owner,_,ok=sample(raw,list(_neighbors(point)))
        support.append(int(np.count_nonzero((owner==code)&ok)))
    if min(support)<2:raise ValueError("TARGET_SUPPORT",support)
    xy,owner,depth,ok=sample(audit["samples"]["interior"],_digital_line(*px)[1:-1])
    frac=np.clip((xy-px[0])@(px[1]-px[0])/separation**2,0,1)
    clear=~np.isin(owner,codes)&(depth>depths[0]+frac*(depths[1]-depths[0])+audit["depth_tolerance_m"])
    run=longest(clear&ok)
    if run<3:raise ValueError("GAP_RUN",run)
    return {"gap":run,"support":support}


def decode(raw,schema,kind):
    if raw is None:return None
    fields=schema[kind];assert len(raw)==len(fields)
    row=dict(zip(fields,raw))
    singular={"package":{"outcome":"outcome"},"observation":{"clearance":"clearance","deformation":"deformation","image":"image"},"clearance":{"witness_a":"witness","witness_b":"witness"},"image":{"section":"section","global_view":"view","local_view":"view"},"outcome":{"goal":"goal","command":"command"}}
    plural={"package":{"observations":"observation"},"observation":{"objects":"object"},"deformation":{"faces":"face"}}
    for k,t in singular.get(kind,{}).items():row[k]=decode(row[k],schema,t)
    for k,t in plural.get(kind,{}).items():row[k]=[decode(v,schema,t) for v in row[k]]
    return row


def action_check(row,z,schema):
    before=decode(json.loads(z.read(row["id"]+"/before.json")),schema,"package")
    after=decode(json.loads(z.read(row["id"]+"/after.json")),schema,"package")
    assert before["length_unit"]==after["length_unit"]=="m"
    assert before["object_ids"]==after["object_ids"]==["moving","reference"]
    assert before["observations"]==after["observations"][:1]
    out=after["outcome"];native=row["outcome"]
    assert out["before_observation_id"]=="before" and out["after_observation_id"]=="after"
    assert out["measured_delta_m"]==row["measured_delta_m"]==native["measured_delta_m"]
    assert out["predicted_delta_m"]==native["action"]["predicted_delta_m"]
    assert out["control_before"]==native["control_before"] and out["control_after"]==native["control_after"]
    assert out["measured_delta_m"]==out["distance_after_m"]-out["distance_before_m"]
    for phase,obs in zip(("before","after"),after["observations"]):
        facts=native[phase];snap=row["native_"+phase]
        assert obs["observation_id"]==facts["observation_id"] and obs["frame_id"]==facts["frame_id"]
        surf=facts["surface"];cl=obs["clearance"]
        assert cl["distance_m"]==surf["distance_m"]
        points=[]
        for target,which in zip(("moving","reference"),("a","b")):
            witness=cl["witness_"+which];face=surf["triangle_"+which];point=np.asarray(surf["point_"+which])
            assert witness["original_face_id"]==face and witness["point_m"]==point.tolist()
            vertices,faces=map(np.asarray,snap[target]); tri=vertices[faces[face]]
            q=np.linalg.lstsq((tri[1:]-tri[0]).T,point-tri[0],rcond=None)[0]
            scale=max(np.ptp(vertices,axis=0).max(),np.finfo(float).tiny)
            tol=1e-9*scale+64*np.finfo(float).eps*np.abs(vertices).max()
            assert np.linalg.norm(tri[0]+q@(tri[1:]-tri[0])-point)<=tol
            assert q.min()>=-1e-7 and q.sum()<=1+1e-7
            points.append(point)
        assert abs(np.linalg.norm(points[1]-points[0])-cl["distance_m"])<=row["delta_budget_m"]
        for obj in obs["objects"]:
            vertices=np.asarray(snap[after["object_ids"][obj["object_index"]]][0])
            assert close(obj["center_m"],vertices.mean(axis=0),1e-12)
        td=obs["deformation"];assert td["sample_frames"]==[obs["frame_id"]] and td["position_frame"]==obs["frame_id"]
        vertices,faces=map(np.asarray,snap[after["object_ids"][td["object_index"]]])
        assert td["reduced_face_count"]==len(faces)
        for f in td["faces"]:assert close(f["position_m"],vertices[faces[f["original_face_id"]]].mean(axis=0),1e-12)
        image=obs["image"];assert image is not None and image["path"]==phase+".png"
        with Image.open(BytesIO(z.read(row["id"]+"/"+image["path"]))) as im:
            assert im.size==(image["width_px"],image["height_px"])==(1024,512); im.load()
        for name in ("global_view","local_view"):
            v=image[name]
            r={"viewport":v["viewport"],"rna":{"name":"public","type":v["camera_type"],"matrix_world":v["matrix_world_blender"],"ortho_scale":v["ortho_scale_blender"],"clip_start":v["clip_start_blender"],"clip_end":v["clip_end_blender"],"shift_x":v["shift_x"],"shift_y":v["shift_y"],"projection":v["projection_blender"]},"gpu":{"view":v["gpu_view_m"],"projection":v["gpu_projection_m"],"view_projection":v["gpu_view_projection_m"]}}
            assert all(_Camera(r,image["meters_per_blender_unit"]).agreement.values())
    return True


failures=[];counts=Counter();summaries={};bindings=[];positive_examples={}
for seed in (20261105,79463,310519):
    for stage in ("evaluation","evaluation-completion"):
        d=BASE/str(seed)/stage
        if not d.exists():continue
        process=read(d/"process.json")
        for name,info in process["outputs"].items():
            raw=(d/name).read_bytes()
            assert digest(raw)==info["sha256"] and len(raw)==info["bytes"],(d,name)
        with ZipFile(d/"source.zip") as source:
            for name,info in read(d/"source.json").items():
                raw=source.read(name);assert digest(raw)==info["sha256"] and len(raw)==info["bytes"]
        bindings.append({"seed":seed,"stage":stage,"outputs_and_source_archive":True,"exit":process["exit_code"],"input_stable":process["inputs_stable"],"source_stable":process["sources_stable"]})
        primary={}
        with ZipFile(d/"media.zip") as z,gzip.open(d/"records.jsonl.gz","rt",encoding="utf-8") as stream:
            schema=json.loads(z.read("ao-schema.json"))["columns"]
            for member in z.namelist():
                if "/empty.json" not in member:continue
                empty=decode(json.loads(z.read(member)),schema,"package")
                for obs in empty["observations"]:
                    cl=obs["clearance"]
                    assert obs["image"] is None and cl["status"]=="empty_surface"
                    assert cl["distance_m"] is None and cl["witness_a"] is None and cl["witness_b"] is None
                counts["V_empty_control"]+=1
            for line in stream:
                row=json.loads(line)
                # Main F/R/L and all available controls. Diagnostics/ablations
                # retain their raw records; no labels or model inputs are made.
                main="-evaluation-" in row["id"]
                try:
                    if "audit" in row and (row["arm"] in ("F","R","L") or not main):
                        png=z.read(row["media"]);assert digest(png)==row["png_sha256"]
                        detail=visual_check(png,row["audit"])
                        if main and row["arm"]=="F" and row["mode"]=="SECTION":
                            positive_examples.setdefault(seed,(png,row["audit"]))
                        counts["V_main" if main else "V_control"]+=1
                        if main:
                            primary.setdefault(row["arm"],[]).append({"id":row["id"],"rays":len(row["audit"]["trace"]),**detail})
                    elif "native_before" in row:
                        action_check(row,z,schema)
                        counts["A_main" if main else "A_control_or_diagnostic"]+=1
                except Exception as exc:
                    # Natural enclosed controls are expected to be invisible.
                    expected_failure=("-control-enclosed-" in row["id"] and not row["success"]
                                      and exc.args and exc.args[0] in ("TARGET_SUPPORT","GAP_RUN"))
                    if expected_failure:counts["expected_enclosed_failure"]+=1
                    else:failures.append({"seed":seed,"stage":stage,"id":row["id"],"arm":row.get("arm"),"error":repr(exc)})
        summaries[f"{seed}/{stage}"]={arm:{"count":len(rows),"median_rays":float(np.median([r["rays"] for r in rows])),"min_gap_run":min((r["gap"] for r in rows if r["gap"] is not None),default=None),"min_target_pixels":min((min(r["support"]) for r in rows if r["support"] is not None),default=None)} for arm,rows in primary.items()}
        print(seed,stage,'checked',dict(counts),'failures',len(failures),flush=True)

negative_checks={}
for seed,(png,audit) in positive_examples.items():
    checks={}
    for kind in ("wrong_frame","wrong_object","wrong_ray_count","wrong_rna_scale","erased_witness"):
        forged=deepcopy(audit);bad_png=png
        if kind=="wrong_frame":forged["metadata"]["frame_id"]+=1
        elif kind=="wrong_object":forged["metadata"]["target_ids"].reverse()
        elif kind=="wrong_ray_count":forged["metadata"]["selection"]["ray_count"]+=1
        elif kind=="wrong_rna_scale":forged["metadata"]["views"]["local"]["rna"]["ortho_scale"]*=1.1
        else:
            with Image.open(BytesIO(png)) as im:
                im=im.convert("RGB");im.paste((0,0,0),(712,200,824,312));buf=BytesIO();im.save(buf,format="PNG");bad_png=buf.getvalue()
        try:visual_check(bad_png,forged)
        except (AssertionError,ValueError):checks[kind]=True
        else:checks[kind]=False
    for stage in ("evaluation","evaluation-completion"):
        d=BASE/str(seed)/stage/"visual-negatives"
        if not d.exists():continue
        for name in ("wrong_global_cut","missing_local_cut"):
            try:visual_check((d/(name+".png")).read_bytes(),read(d/(name+".json")))
            except (AssertionError,ValueError):checks[stage+"/"+name]=True
            else:checks[stage+"/"+name]=False
    negative_checks[str(seed)]=checks
    assert all(checks.values()),checks

resume=BASE/"20261105"
original=[]
with gzip.open(resume/"evaluation/records.jsonl.gz","rt",encoding="utf-8") as stream:
    original=[json.loads(line) for line in stream]
continued=read(resume/"evaluation-completion/summary.json")
continuation=read(resume/"evaluation-completion/continuation.json")
assert continuation["sha256"]==digest((resume/"evaluation/records.jsonl.gz").read_bytes())
assert continuation["replayed_main_episodes"]==0
retained=0
for row in original:
    if not "-evaluation-" in row["id"]:continue
    if row["id"].startswith("V-"):
        matches_rows=[r for r in continued["views"][row["arm"]] if r["id"]==row["id"]]
        keys=set(row)-{"audit","score","media"}
    else:
        matches_rows=[r for r in continued["actions"] if r["id"]==row["id"]]
        keys=set(row)-{"features","group_key","outcome","native_before","native_after"}
    assert len(matches_rows)==1 and all(matches_rows[0][k]==row[k] for k in keys)
    retained+=1
model_bindings={}
for seed in (20261105,79463,310519):
    model=BASE/str(seed)/"seal/frozen.npz";expected=digest(model.read_bytes())
    records=[]
    for stage in ("evaluation","evaluation-completion"):
        d=BASE/str(seed)/stage
        if not d.exists():continue
        launch=read(d/"launch.json")
        records.append(launch["file_whitelist"][str(model.resolve())]["sha256"]==expected)
    model_bindings[str(seed)]=all(records)

result={"counts":dict(counts),"failures":failures,"bindings":bindings,"summary":summaries,
        "negative_checks":negative_checks,"retained_main_summary_rows":retained,"frozen_models_match_initial_evaluation":model_bindings,
        "limits":"No Blender or fresh ray casting. V bottom and independent ray samples are saved evidence; native geometry for V cannot be re-created from these samples. A public PNG dimensions/matrices and native witness/centroid facts rechecked, not arbitrary visual task success. CF scorer PASS/native_checks are not inputs to this probe's decision."}
OUT.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(str(OUT), 'failures',len(failures))
