# CF formal_001 independent architecture, algorithm and isolation review

审查日期：2026-11-05。范围为第二阶段实施层验收；未启动第二轮优化。本文不替代根端的像素、性能原始样本和控制链独立复核。

结论：本次审查未发现需要退回实施方修改的算法错误、未来事实泄漏、评估集选模或假在线更新。独立轻量探针 **341 项全部通过**。首 seed 的原主样本、选模结果和冻结模型未因续跑改变。存在一项必须公开保留的流程偏差：未找到续跑前由根端固定恢复范围的记录，因此不能把作者完成的控制/诊断续跑直接视为严格履行了原审批程序。根端已确认不补造审批，并独立冻结范围复核原定 72 个控制、21 个诊断和 6 个 prequential 步骤；`root_formal_controls_002/result.json` 记录全部通过。该复核与原主集统计分开，不消除历史流程偏差。

本轮无建议追加优化项，也没有修改作者源码、协议或引擎。只新增本报告及 `algorithm_probe.py/.json`；探针没有拟合模型、构造评估场景、调用 Blender/GPU 或进行性能采样。

## 来源及复核方式

冻结协议 `docs/CF_ACCEPTANCE_PROTOCOL.md` SHA256 为 `740662fe75aa1108cd0fc580024fa3ffb813b16677b1300274ad05c111dbdb43`。生产 `cerebellar_flash.py` 为 `7c185a4ac23b897cff5310499a60a087d4cd76d939d2a42b2aeefe79cd09b74c`，`_cf_features.py` 为 `130a66f80dec18f8b83065c71d832c2af5222329a39ec8c6dd3c0a85da59ee39`。探针对三个 seed 各阶段 source.json 中的协议、模型、特征、训练、native、fixture 和冻结基线身份与当前文件作一致性检查；全部相同。完整工件身份和统计由根端另一个独立审计覆盖，本文不重复背书未逐项核验的文件。

阅读了生产两文件、`cf_training.py`、`cf_experiment.py`、`cf_native.py`、`benchmark_cerebellar_flash.py`、`cf_memory.py`、portable tests，以及正式 train/validation/fit/seal/evaluation/completion 证据。独立探针不调用训练实现的选择、标准化、预测或统计辅助函数：用显式二次项顺序重算设计矩阵、验证集 MAE/字典序选择和正式 A 输出；仅在微型构造输入上调用生产在线更新/环库入口，与独立方程比较。

## 当前输入和基线公平性

V 输入由 `ViewEpisode.capture/ranker`（`cf_native.py:103/115`）生成。输入是当前 RB/BC、当前见证点、VG 已有候选方向、当前非目标索引三角网格及显式模式。`view_features`（`_cf_features.py:30`）生成几何方向密度，不发射射线，也不接触评分标签、隐藏参数、族名、seed、文件路径或动作后数据。F 使用原生顺序；R 是 train 库中的精确标准化 1NN；L 仅用模型分数排方向，不调用检索补救。原生 ray/图像决策仍交给 VG，排序本身不伪造成功标签。

A 预测入口 `ActionEpisode._predict`（`cf_native.py:225`）早于控制执行。它只接收当前索引网格、当前全局 witness、从原生 RNA 回读的当前 q、已知命令、静态相对 shape-key basis 和当前世界变换。相对 basis 在物化时从真实 key 与 relative-key 数据读取；当前 q 不是用命令前声明替代。静态已知形变基和动作能用于有限动作预测，不能被等同于动作后全局 BC 真值。

G 是对**当前两片 witness 三角形**施加已知有限动作后的精确窄相距离，再减当前全局距离；不会提前刷新 Blender 或重新全局找最近面。它强于法线一阶投影，但可因最近面切换而与真实 global BC 不同；这正是 A 学习残差仍有意义的原因。三角数学已经在阶段 1 的独立凸距离探针覆盖，本轮生产公式仍与冻结来源一致，未扩大声明到任意非线性 modifier。

A 特征的 support sketch 对已知有限 basis 做几何摘要，属于协议事前允许的当前输入；没有读取 `native_after`。之后执行控制、重新捕获和查询，才产生 `measured_delta_m`。`_verify_action` 用真正前后快照和真实控制回读检查 witness/单位/Outcome，训练标签不是 G 自己的预测。独立复算 180 个主动作的 L 和 shuffle 预测，最大与原记录差为 `2.168404344971009e-18 m`，并逐例核对 G 的归一化关系及 `after-before=measured_delta`。

计时下 G 只算其所需当前三角对，C 只算命令分组；不会强制给它们计入 L 所需的 PCA/support-sketch/23 维特征。L 内 G 只求一次并进入第 1 特征及最终输出，未为公平性人为重复生成。质量收集为了并列 C/G/L/shuffle 会多算比较项，但正式性能调用 `collect=False`，不会把质量插桩当基线成本。

## 训练、选模和留出隔离

每 seed、每 head 的主 train/validation/evaluation 均为 240/60/60；独立检查 group 集合无重叠，evaluation 族与 train/validation 族不同。拟合进程实际声明的读取仅为 `train/view.npz` 和 `train/action.npz`；seal 的读取不包含 evaluation/diagnostic。两层已记录输入哈希在审查时仍匹配。冻结 banks 的 keys、标签、retrieval std 与原 train 数组逐项一致，train provenance 的 240 个 ID 顺序完全匹配，不含验证和评估行。

V 标准化仅由 240×16 个 train 方向行计算，密度列先 log1p；A 标准化只由 240 个 train 行计算。所有 8 个候选头/seed 的 mean、std、quadratic 标志、λ 逐项通过独立检查。二次特征为标准化后所有 j≤k 乘积加 bias。V 的原始代码是 4 个事前配置各 200 次 batch logistic 更新，步长满足冻结 Lipschitz 上界，bias 不正则；A 以 `(真实 delta-G)/L` 做对应 ridge 闭式求解。没有在评估反馈后继续拟合正式主模型的入口。

V 选模只使用 validation 的 F-success 损失、退化族数、ray 中位比、成功数和配置序号；A 按 validation 米制 MAE，序号打破平局；计时参考 G/C 也只按 validation 选择。独立复算得到：

| seed | V 配置 | A 配置 | 计时参考 |
| --- | --- | --- | --- |
| 20261105 | 2：quadratic, λ=.001 | 1：linear, λ=.01 | G |
| 79463 | 2：quadratic, λ=.001 | 1：linear, λ=.01 | G |
| 310519 | 2：quadratic, λ=.001 | 0：linear, λ=.001 | G |

三 seed 的冻结部署权重与所选候选权重完全相同。第三 seed 在 evaluation 上 C 比 G 更强不触发计时参考改选；A 的质量门仍和 evaluation 中较强的 C/G 比，时延仍和事前选定 G 比，符合协议的不同用途。

选择文件先写入并以 hash 绑定，之后只用已选配置做事前规定的 shuffle 消融；独立重算两头 PCG64/SeedSequence permutation 一致。zero-V 权重确为零。没有用 shuffle 结果再次挑模型。第一 seed shuffle-V 的中位收益与 L 相同，只能如实披露为该 seed 消融分辨力不足，不能单凭这一 seed 声称训练标签不可替代；这不改变预定主门。

驱动代码先对全部三 seed 完成 train/validation/fit/seal，再进入任何 evaluation/diagnostic manifest 的生成和读取。当前文件时间也显示最新 seal 早于最早 evaluation/diagnostic manifest，且 frozen JSON/NPZ 哈希贯穿后续阶段保持不变。**限制**：文件 mtime 是佐证，不是不可篡改时间戳；`actual_reads` 是程序显式数据读日志，不是操作系统强制文件访问审计。本结论结合代码数据流、工件绑定和时间顺序，而不是宣称存在硬沙箱隔离。

## 真实更新、库容量和执行边界

`LinearHead._update`（生产行 75）与冻结方程相符：用更新前预测误差，`.05/(1+||x||²)` 步长，非 bias 权重正则。独立微型方程探针对 V/A 各一次真实更新均通过。A 输出保持米制，学习目标保持归一化残差。

真实在线 V 行仅标记实际展示方向，其余 15 个方向是 unknown，不会把没观察到的方向填成失败。R 对已知 safe/unknown/已知 unsafe 的顺序以及同层 ray/canonical tie 均符合协议。环形库用固定容量数组；满容量近邻同距时从最老仍存活的插入开始比较。探针覆盖空库、部分标签、覆盖后的最近邻 tie、未知方向先于已知失败、clone 独立和释放。没有发现读到被覆盖标签或会话串写。

`_prequential`（`cf_experiment.py:369`）使用自己的同一个 deployment 对象：先保存预测，得到原生图/实际动作 Outcome 和消费者反馈，再写经验并改权重，下一步继续用该对象。两个写入计数和非零权重变化会记录。此链只有每 seed 两步，用于证明真实入口发生，不能据此声称长期在线收敛或长期质量保障。

正式质量模型不更新；正式性能查询也始终读取冻结模型，反馈只更新 shadow。每次重复前在计时外恢复 shadow 的占用和权重；本次每头只新增一行，240 个原始 train 槽未被覆盖，恢复 writes=240 后槽 240 的旧内容不再属于 live 区间，因此无需把整库拷贝回去。这个边界测到了真实写库/梯度成本，又没有让评估样本逐轮进入正式预测模型。

性能 V 的反馈来自独立评分记录，但计时后核对同次 PNG hash、frame、targets、witness 和 ray，A 标签直接取该次真实 Outcome。协议允许把外部独立反馈等待单列；不能把这一 frozen-query/shadow-update 计时等同于包含消费者评分等待的在线延迟，后者在 prequential 另列。

整链从当次必需 capture 之前开始，到字节输出和经验/权重更新之后结束，包含 V 当前 PNG/AO 和 A 前后 PNG/AO、宿主写入及后 global BC。fixture 构造、状态 reset、独立像素审计和日志在外，符合冻结边界。V/A 子段分开设门，不能用另一个头抵消退化。实现没有按评估结果回退成 R/G/C 的隐藏链。

## 首 seed serialization 失败及 continuation

原 `20261105/evaluation` 退出码为 1，`process.json` 的 source/input stable 均为 true。trace 显示完成主循环后，在 `_control_view` 的零距图评分返回时，Pillow 子进程 JSON 无法编码 NumPy bool。原 source.zip、media.zip、records.jsonl.gz 和失败日志均保留。

独立读取原 gzip：5 个 V 臂各 60 条主行、60 条 A 主行完整。completion summary 中这些行除 V 的派生 `solvable` 字段外与原记录逐字段相等；原 A 行逐字段相等。completion 自己的主 records 没有重新生成任何 evaluation 主行。其 prequential 子目录按原规定复用首两个 evaluation 场景，仅作单独在线入口证据，不进入主质量数组或选模。

原失败 records SHA256 `017846f33599f34889e7c50c48b45bb32e6a9135c362d5429a67d8c063d1e833` 与原进程收据以及 continuation 绑定相同。代码只接受明确带此控制序列化错误的失败路径，验证原 receipt/records 哈希、五臂完整 ID 和 A 完整 ID，再补 controls/diagnostics/prequential。

两个归档 source.zip 只有四文件变化：

- `cf_visual_acceptance.py`：零距 `coincident_projection` 的 NumPy bool 显式转内建 bool；无像素阈值变化。
- `cf_experiment.py`：增加继承已完成主行的分支和 receipts；把 CONTACT 控制条件收严为还必须真实 `row.success`；原主循环逻辑未改变。
- `benchmark_cerebellar_flash.py`：增加已限定故障的恢复入口和原输入 whitelist。
- `cf_report.py`：首目录缺失 summary 时选择 completion summary。

生产 CF、特征、训练配置、已选权重、fixture、协议都没有变。该续做没有改变主收益数据或重新选模；因此没有证据把原主统计视为按结果挑轮次。不过，**缺少根端事前固定范围的沟通记录仍是流程偏差**，源码约束不能事后替代授权证据。根端随后独立复核相同固定控制/诊断/prequential 范围，保留作者旧工件且不替换主数组。审阅完成前已读取 `root_formal_controls_002/result.json` 和进程收据：退出码 0、source/input stable，每 seed 24 控制、7 诊断、2 prequential、9 视觉负例均报告通过。此处引用根端另行生成的复核证据，本审查者没有另跑 Blender。根端还保留 `root_formal_controls_001` 的测试器负例 schema KeyError 失败，随后修正测试器而未修改实施源码。

## 对收益声明的边界

本轮结构的实际收益是降低 V 射线数量，以及在真实有限动作上降低 A 对强几何/条件基线的误差。它不是整链延迟无条件下降的证据。作者主报告显示整链 p95 约增加 2.2%，仍处于事前允许的 10% 预算内；根端应保留该代价，不能改写为“全链提速”。V、A、整链各 seed 门由独立统计审计决定。

R 首 seed 未达到自己的 ray 收益门，不得将 R 表述为三个 seed 全通过；部署候选是事前选定 L+A。第一版没有引入任何 S 头能力，不能外推未验收范围。只要根端剩余质量/控制复核与原门均成立，当前证据支持按原协议验收本轮实施，**无需启动第二轮优化**。
