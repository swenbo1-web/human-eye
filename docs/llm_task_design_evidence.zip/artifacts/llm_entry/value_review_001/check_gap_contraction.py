"""Design check only: exact witness contraction against an independent hull oracle."""
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from human_eye_fast.fast_bvh_clearance import SurfaceIndex, surface_distance
from verification.test_fast_bvh_clearance import exhaustive_distance

rng = np.random.default_rng(20261106)
rows = []
for case in range(8):
    # Disconnected, arbitrarily oriented triangles exercise the general surface proof.
    va = rng.uniform(-0.5, 0.5, (12, 3))
    vb = rng.uniform(-0.5, 0.5, (15, 3)) + np.array([2.0, 0.3, -0.2])
    fa = np.arange(len(va)).reshape(-1, 3)
    fb = np.arange(len(vb)).reshape(-1, 3)
    original = surface_distance(SurfaceIndex(va, fa), SurfaceIndex(vb, fb))
    oracle_before = exhaustive_distance(va, fa, vb, fb)
    for fraction in (0.0, 0.25, 0.8, 1.0):
        target = original.distance_m * fraction
        delta = (np.asarray(original.point_b) - original.point_a) * (1.0 - fraction)
        shifted = va + delta
        after = surface_distance(SurfaceIndex(shifted, fa), SurfaceIndex(vb, fb))
        oracle_after = exhaustive_distance(shifted, fa, vb, fb)
        error = max(abs(original.distance_m - oracle_before), abs(after.distance_m - target),
                    abs(oracle_after - target))
        rows.append(dict(case=case, target_fraction=fraction, target_m=target,
                         measured_m=after.distance_m, oracle_m=oracle_after,
                         maximum_error_m=error, pass_=error <= 1e-10))
sources = ['human_eye_fast/fast_bvh_clearance.py', 'verification/test_fast_bvh_clearance.py']
result = dict(kind='CPU_DESIGN_CHECK_NOT_BLENDER_OR_LLM_ACCEPTANCE', cases=rows,
              passed=all(row['pass_'] for row in rows),
              maximum_error_m=max(row['maximum_error_m'] for row in rows),
              source_sha256={p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in sources})
path = Path(__file__).with_suffix('.json')
path.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in result.items() if k != 'cases'}))
assert result['passed']
