# 当前接入候选的任务价值复审

## 收尾时检测到整体换版：最新快速结论优先

**阅读期间作者已把逐动作入口替换为任务入口。** 07:28:53 UTC 读取的是407行 `eye_open/eye_step/eye_close` 版；07:37 UTC复核时，`llm_entry.py` 已成为236行、SHA `5d036303d3a735a1b1672a7e0e5b9a2985a7f57fc03161a8ea8ad285e9030b8c` 的 `eye_run(close_gap)/eye_inspect` 版。后面的逐动作问题只属于旧阅读快照，**不能当作新版仍未修复的缺陷**。测试也正在继续写入；没有追逐每次变化重做一轮审计。

新版已经做对的改变：默认 run 只返回实际任务结果，不返回AO/schema/见证/PNG；inspect 才取得可选证据并缓存一张图（新版107–181行）。这直接处理了任务级无用图像/重复AO，不需再照旧建议给它补 act/image_mode 或 pending-V 框架。两工具和限定 rigid close_gap 任务应先保留；不因旧接口有shape/CF/V/A能力就强行全部塞回默认任务。

对这个新版，最小剩余建议是：

1. **裁掉不必要的持久写阻塞。** 新版134–135行把有限、真实已测的 `not_reached` 也写成 Binding._write_blocked；112–113行此后连新的明确目标都拒绝，称为 `unverified_prior_write`，只能由host重绑定。已测未达不是未知写入。若支持域没有事前明确规定“测得未达即永久退出该绑定”，应如实返回未达，下一次明确任务重新读取实际几何；这不是自动重试，也不需要新恢复机制。未知/缺失回读单独诚实报告即可，不由本报告扩写异常恢复协议。新版测试已经开始固定“measured miss blocks next write”的行为；应先确定它是否必要，再决定测试，而非因为测试存在就保留这条防御策略。
2. **同一短结果仍发送两份。** 新版 `_result:73–77` 将完整 fields 序列化为TextContent，同时放入structuredContent。它比旧AO小很多，但与旧工单避免重复完整结果的目标不同。核对选定宿主实际消费哪一份；尽量只让模型收到一份，若其协议确实需要两份，明确计量并在宿主输入侧避免双份上下文。不要扩成多客户端fallback矩阵。
3. **仅在任务预先需要最终视觉时，考虑合并证据请求。** 当前必须 run 后再 inspect(image)，因此有明确“完成并给图”意图的任务仍需两次工具交互。可选的 run附带最终image能合成一轮，默认仍无图；若只是偶发排查，保留独立inspect更简单。不是要求现在无条件新增参数，更不是默认每任务出图。
4. **新版是窄任务能力，不能冒称旧通用会话同责。** 工具描述明确最多一次刚体平移；没有公开shape、TD或V反馈操作。应按相同close_gap任务、相同真实目标与测量责任比较任务完成成本，不能拿它与旧全引擎图像/学习链直接相减宣称全功能提速。`open_task(...).run` 的实际任务算法由相应独立审查核对，本报告没有读取/验收新的local_tasks算法。

新版测试重点保留一条 task→真实结果→可选inspect→同目标再次测量不重复移动，以及一个真实写入错误；不再运行逐动作全套操作组合来证明这个新入口。真实模型看图和任务成功的资格仍未完成。本轮只读，没有执行这些测试。

新版快速阅读记录：`llm_entry.py` 10983 bytes/236行，上述SHA；当时 `test_llm_entry.py` 14943 bytes/307行、SHA `48bbe34035d9353c72e8f04cb8acba79f1f7023828e61eed058e5484eb970a2e`，`test_llm_transport.py` 8942 bytes/235行、SHA `be90dff0488c249bc410aaa92f3a12daddc35798164aede5bcf10aabad02ec04`。随后再次读取测试时内容又在增长，所以不把这些测试行号作为冻结证据。bridge/relay 摘要在07:37检查时未变。

---

## 以下是07:28逐动作版的已完成审查，保留以说明建议来源

**判断：保留现有常驻 relay/pump 和单次 act 编排；下一步先改“每步必须出图”及反馈与当前步的过紧绑定，再用一个完整多步任务看交互量。** 当前实现解决了旧传输外壳与多余方法往返，但尚不能证明“大模型完成任务更高效”。完整联合 AO 的重复事实和相机数据仍在每步输出中；正式草案主要测一个 act 的 wire-entry，缺少任务级收益判断。

这是当前候选的只读源码审查，不是测试执行结果。不运行 Blender、模型、网络或测试，不改生产、已有文档、证据或 Git。以下实现状态与建议严格分开；行号绑定末尾所列阅读摘要，作者继续修改后应以新摘要重新核对，不把本报告当最终冻结版本。

## 最小保留项

| 当前实现 | 位置 | 判断 |
|---|---|---|
| 一个 act 内真实 V→predict→execute→真实 A，无默认 next，无模型审批 | `llm_entry.py:247–305` | 保留。已经避免把每个底层函数变成模型往返。不要再加自动 predict-preview/commit 确认。 |
| 原 AO 文本一次转交，普通动作只发送新图，read 才恢复整包 | `llm_entry.py:179–202,313–317` | 保留正确交付能力；也要承认原 AO 本身有重复 before 事实。read 是恢复操作，不应成为普通动作必经步骤。 |
| 最后一个公开包、固定 V/A/plan 槽 | `llm_entry.py:156–177,229–235,269–305` | 不扩成历史表/TTL。图片已交付不等于消费者判断合格；未提供 V 仍为未知。 |
| relay 双向只复制 bytes，一次连接；主线程非阻塞 pump、部分发送与自然背压 | `human_eye_llm_stdio.py:20–48,64–67`；`blender_llm_bridge.py:94–148` | 保留，不再为了当前“少数据/少模型轮数”问题重写传输层或调低 timer 寻优。 |
| 写入错误保留实际 Outcome、read 说明旧包不可执行、close 释放 | `llm_entry.py:276–302,349–363` | 保留真实结果边界。错误路径不是本轮主要数据浪费，不值得为省几行罕见错误字段扩展重构。 |

模型每次确实需要依据新几何/图像决定下一命令时，一动作一轮可能已经是必要下限；不能把应由模型作出的判断偷偷改成宿主猜测。反过来，一动作一轮也不能自动等同于一个多动作任务已达到最少轮数。

## 优先修改与需要主端明确的输出选择

### 1. 当前 act 没有按步图像策略，不能交替“事实步”和“视觉关键步”

**当前事实：** act/execute 的 schema 没有 image_mode（`llm_entry.py:57–64`）；`_execute` 在第271行始终采用 `binding.image_mode`。如果绑定是 NATURAL/SECTION，每次动作都做 after VG/PNG 并发送新图，即使模型当前只需要真实 control、distance 与 Outcome。`observe(image_mode=null)` 仅影响那次 observe（327–332行），并不会让后面的 act 无图。

这是旧工单默认有图闭环的实现，不是作者偷偷添加了额外 observe；但它没有满足用户新强调的“多轮任务只取必要输出”。目前绕开每步图像要么冷绑定全程无图，要么另做 observe，无法在同一任务里低成本切换。

**最小建议：** 给 act 的 after 请求一个显式 `image_mode` 覆盖，缺省保持绑定模式；传 null 时沿引擎已有 disabled 路径，不做 VG/PNG，不产生该 after 的 V ticket，真实 execute/Outcome/A 仍执行。需要视觉判断时再选择有图 act 或一次明确 observe。显式 execute 若保留同能力，可复用同一个参数，不新建“低质量图”“自动压缩”“失败备用图”机制。

这只减少图像工作和传输，**不会自动减少模型决策轮数**。何时需要图，由明确的任务/模型请求决定；不要用定时抽样、自动阈值或私有 oracle 猜测。真正需要逐步看图的任务仍逐步出图。

### 2. 可用旧图 V 被默认 act 拒绝，可能平白多出一次 feedback 调用

**当前事实：** `_views` 可以保存 before/current 两张票据（289行），响应也列出 v_pending（174–177行）；但 act 在255–256行固定 `current_only=True`，217–220行又要求被评分图 ID 等于当前可执行观察 ID。例：o1 图真实看过、未提交评分；一次 act 到 o2 后，o1 仍列为可反馈。此时 `act(from=o2, view_feedback=o1)` 被拒绝，只能先独立 feedback(o1)，再 act(o2)。工具描述第71行只写“previously seen image”，没有暴露这个限制。

**最小建议：** 命令的 `from` 继续必须是当前观察；V 的 observation_id 则只需是现有固定槽中的真实未消费票据。两种绑定分别校验，不把“下一动作依据哪个状态”与“消费者在评分哪张图”绑成同一个 ID。可以直接复用 `_feedback` 的现有槽/原票据，不加 registry、延长历史或取消一次消费。

该问题在允许无图中间步后更明显：当前观察可能没有图，而模型这次到达的是此前真实已看图的评分。不能逼它先加一轮反馈，也不能伪造无图当前观察的 V。默认按当前图及时反馈的最短路径保持不变。

### 3. 每步的原联合 AO 仍重发 before 全部事实与完整相机标定

**当前事实：** `_publication` 第182行直接发送整个 `result.ao_bytes`。引擎在 `blender_radical_session.py:478` 编码 `(before_fact, after.fact)`；AO view 定义和 `_view`（`fast_affordance_out.py:83–85,161–166`）包含两面板的矩阵与投影参数。before PNG 虽被排除，before 的 objects、clearance、TD、image metadata 仍重复出现。bootstrap schema 没有每步重复，这是已实现的节省。

这是明确遵循旧工单“尽量保留原 bytes”的取舍，不能按当前需求反过来定性为作者违约。其成本应与防止丢事实的收益一起衡量。当前 B/I/L 主成本对照要求最终内容相同，因此这个对照**天然不能证明任务级无用输出减少**。

**建议主端作一个有限选择，而非立即造通用投影层：**

- 本轮仍保留完整 AO：就将它标为交换语义资格，别宣称输出已极致简化；先量一次真实多步任务的 AO/图像/模型输入分账。
- 若该任务确实不需要重复 before/calibration：批准一个明确版本的“当前必要事实 + 实际 Outcome + before 引用”返回契约，完整 AO/双图仍由显式 read 获取。优先在编码时一次产生，或对实际解析/重编码开销与减少模型输入的收益做同责比较；不能为了机械坚持零 parse 而永久把大量无用文本交给模型。不能删几列后仍声称是完整 `he-ao/1`。

必要事实至少包括当前观察/帧、对象与原面/代号、真实距离/见证、任务需要的 TD/Top-K 与参考语义、实际 command/control/测距/预测分离、图像状态/剖切语义。不是所有任务都需要全部相机矩阵；要求精确投影的消费者则必须取得完整记录。不要现在新增任意字段 DSL、动态 schema 协商或兼容 fallback。

### 4. 冷启动缺少部分有用任务信息，热头反而反复发送固定状态

**当前事实：** open 的 defaults 只给 image mode/view arm/predictor（198–201行）；Binding 只有 factory/changes 和这三项（20–28行）。首次 observe AO 没有 Outcome，因此没有 Goal 的 target_distance/tolerance；具体允许使用的 shape key 也仅在宿主配置中（`examples/blender_llm_entry.py:32–54`）。模型若未从任务上文收到这些真实值，只能追问或猜参数。

**最小建议：** 如果上层任务尚未提供，把明确 Goal 和本次配置允许的动作/key 名单一次放入 open/task bootstrap；仅针对已选 key 提供确实必要的控制范围，不扫全场景目录。若上文已明确给齐，就不再重复一份。

热响应中的 `schema:false`、默认 act 成功后的 `a_pending:false` 等是可省的小冗余（174–177、194–195行），但不是首要瓶颈。`images`/before_ref/失败后的 executable=false 与 pending 可用性有真实用途，不应为了短而一并删除。优先处理图像与大块 AO，而非先把几十字节状态改成复杂省略规则。

### 5. 非图操作的信息是否真正送到模型仍需一次实际宿主资格

predict、feedback、NoAction 等主要信息只在 structuredContent，content 可为空（140–141、261–267、324–326行）。现有 CPU 测试直接读取 structuredContent；这不证明所选真实 MCP 宿主把它交给模型，也不证明模型据此少走一轮。若宿主漏掉它，模型可能只看到空结果。

这里先保留为**资格未完成项**，不是静态认定协议错误。只需在选定实际宿主核对一次 predict/NoAction 等短结果可见性；不因假想的所有客户端都加双份文本或多版本兼容层。若所选宿主确有缺口，选一个对该宿主可见的唯一简短表达。

## 多轮任务与测试：收缩重复覆盖，补一条真正主流程

当前 `test_llm_entry.py` 5个测试和 `test_llm_transport.py` 5个测试数量并不庞大，也不是应删除的“防御框架”。分片/partial-send/通知/EOF是实际传输必要性质；没有理由为了任务效率重测几十种 JSON-RPC 边界。

更有价值的调整如下：

1. **把单步默认 act 测试扩成一条3–5步任务轨迹，而非新增一堆独立边界。** 检查一次 open、连续 act、最终判断与close；schema只首发、每步before_ref指向真实前观察、没有隐式predict-only/read/observe、实际A每次最多一次、未评分V没有被当真。累计请求/响应、AO bytes、新/重发PNG、恢复次数与最终Goal。
2. **图像选择与V关系合成一个场景。** 初始有图→明确事实步→最终有图；只对真实交付且有票据的图给V，真实A不依赖有图。若采用上述槽内迟到V放宽，在同一任务里验证它能随下一act提交，而非再加独立评分回合。
3. **显式预测/恢复只测一次，不在每个正常任务里套全套操作。** `llm_entry_fixtures.py:62–67` 当前非终态固定 `open→predict→act→read(schema=true)→observe→close/EOF`，它重复预测、重发schema/双图又多观察，适合覆盖操作，不代表产品最短路径。保留一例覆盖即可；任务效率主例应是 `open→act…→close` 加确实需要的视觉请求。
4. **保留一个已写失败真实Outcome/不可执行旧包，以及close/EOF。** 不展开所有阶段×模式×命令×错误类型的组合矩阵，不重开原六模块全部边界。

Stub 的 AO 是传输保真用文本，PNG 是哨兵 bytes（`test_llm_entry.py:17–23`），不是公开消费者或图像解码资格。它还使用 `image_status="ok"`、NoAction `already_reached` 及 predictor NONE 仍返回 −0.02 的合成值（46、66、67行），不能由这些用例宣称真实契约或模型视觉已通过。可顺手对齐实际枚举/None，**不必把 stub 重写成第二套引擎**；少量真实handler功能预检负责跨到引擎。

## 对模型回合与任务级收益的直接判断

当前新桥缩短每次工具服务路径，但仍由 LLM 每次选择下一动作。若任务确需逐结果适应，一轮一动作合理；若任务本来已明确一串独立命令，当前接口还不能把它作为一次明确有序请求完成。这类已明确命令序列可由主端作为后续窄批请求选择，但不要因此现在新增自动规划器、通用任务DSL、内部猜动作或不受控循环。

按步无图解决图像量，不解决动作/LLM轮数；省掉小头字段解决少量字节，不等于缩短任务；同 pump 的1.05门解决编排不过度，不等于模型真正使用成功。这三者应分别出分。

最小任务价值证据应从**首个模型输入到真实任务完成**统计：模型调用数、工具往返数、引擎动作/观察数、实际发送和模型实际收到的图像数量、重复schema/AO/图像量、完整模型输入/输出token（若可获得）、恢复成本、最终实测目标/变形约束与总耗时。不要只选最快的单次act，也不要拿本地字节推远端token或费用。当前未运行模型，所以这一层仍是未验证，不能用CPU脚本成功代替。

## 本次建议的实施顺序

先保留底层常驻架构；明确并实现 per-act 图像选择与固定槽内V绑定；把已有单步用例改成一条短任务来观察总交换量。然后由主端决定原AO是否需要一个有限的任务返回契约。不要先开更大的边界审计、并行改同一生产文件或调timer追毫秒。输出精简若不改变模型实际输入与任务成功率，就不应宣称任务级收益。

## 阅读版本与行号依据

阅读摘要时间：**2026-11-06 07:28:53 UTC**。本报告只绑定以下候选；没有用 Git 判定其是否跟踪/冻结。主体源码最后写入时间为07:18:24–07:20:48 UTC，测试为07:20:03–07:21:44 UTC，API/成本草案为07:22:35/07:23:50 UTC。继续变更会使行号失效。

| 文件 | bytes / 行数 | SHA256 |
|---|---:|---|
| human_eye_fast/llm_entry.py | 18979 / 407 | d2970d59edf408672d272a77b85d03c0ff20ca820dd1ed7fee75108a46fa5540 |
| human_eye_fast/blender_llm_bridge.py | 6278 / 190 | fe35939e0826756d075af2cb09532948e4201b65ec81c1db75432149c5449274 |
| human_eye_llm_stdio.py | 2269 / 75 | 2932dfecaaaaa28ee9385a83ab58c50f52071b1d19fe015f6468dbe9f3cac33b |
| verification/test_llm_entry.py | 13832 / 283 | 5cfd33cedba68c542e08d5df994bf1dc013d28985492bb16b1b8f22355d75e7e |
| verification/test_llm_transport.py | 8485 / 219 | b75e4b6de0dcb202a586d146170e5acc01fa671ba78f80d40d92016f6e995ce4 |
| verification/llm_entry_reference.py | 3126 / 66 | 53625f205d10814700aa1ca5975a57deb595dccb184fa93cf92d87ed15394c87 |
| verification/llm_entry_fixtures.py | 3568 / 88 | ed2e45465a703290a7221682bc3c936e22d2c80ed3ea84a6c6a3a5a0f1c6fc5c |
| examples/blender_llm_entry.py | 2928 / 63 | b5008e0e3a1462c1e1a321f6203537027d60b36626f0343edd79c2041e9b132c |
| docs/LLM_ENTRY_WORK_ORDER.md | 7362 / 54 | b1fad395de00fb5be1d2e7898cb4dbba9ccf39bc70cfe5088e061cdb5ec078c2 |
| docs/LLM_ENTRY_ARCHITECTURE.md | 10098 / 75 | 0566ddee00ece1650a44a8219ee07c6665694cdb20a9a6eb232c99492aaeb970 |
| docs/LLM_ENTRY_API_DRAFT.md | 6175 / 40 | faadec6cc400fda8eeddc2018a47ab692dd37082d2b30d7e9ce7e74410906174 |
| docs/LLM_ENTRY_PROTOCOL_DRAFT.md | 15134 / 65 | 5463f286413c009a1f1a4679cd8e80c356c4ad6509319601928d283b0f7fbcc8 |
