# 从动作接口转为本地几何任务

只读设计，未实现、未运行 Blender。已核对当前 `LLM_ENTRY_ARCHITECTURE.md`、Session/AO、`BlenderControl` 和 `VGRenderer`。建议保留薄桥，把收益中心改为：**模型提交目标，本地完成几何求解和实测，只返回结果或必须由模型决定的问题。** 首阶段做解析 `close_gap` 与必要事实投影；relative shape key 求根单独后置，不先建设通用规划平台。

## 1. 首个技能：一次解析平移缩小间隙

对象对的当前全局无符号表面距离为 d>0，最近见证 a 在 moving、b 在 reference；目标 0≤g≤d。取 u=(b−a)/d，平移 t=(d−g)u。

证明成立：对任意表面点 x、y，`|(x+t)−y| ≥ |x−y|−|t| ≥ d−(d−g)=g`；旧见证给上界 `|(a+t)−b|=g`，所以下一次全局表面距离恰为 g。即使最近三角形切换，下界仍成立。这比让模型算步长、比较候选、反复试探更直接；不需要 G/L 预测来批准解析解。

数学前提必须对应实际 Blender 合同：moving 的所有 evaluated vertices 只发生同一个世界平移，reference evaluated surface 不变；拓扑、单位、帧及其他输入在动作间稳定。任意旋转/缩放的初始姿态不妨碍证明，但依赖位置的 modifier、驱动、约束、共同父子关系可能破坏平移或固定参考前提。首版绑定独立刚体对，由场景适配明确能力；不恢复每调用全场景扫描。有限精度下仍由真实 after readback 与既定容差判成功。

仅支持沿该连线**缩小**间隙；把方向投影到指定轴后证明失效，增大间隙也无此保证。g=0 只证明零表面距离，不证明实体未穿透；第三物体避障、内部包含关系和装配可行性不在合同中。已有距离在容差内直接完成，不做无用写入。实测未达标就返回实际误差和控制状态，不把它改名为成功或暗中接上通用优化/回滚。

## 2. 按任务选依赖，避免无用 TD/AO

首个技能直接使用公开 `BlenderControl`，无需绕完整 Session：

`结构化目标 → Control.observe → 解析 t → Action(Translate(t)) → Control.execute → typed Outcome/Readback → 小型任务结果`

`control.py:121–202` 已提供 evaluated 捕获、全局 BC、真实写入与 readback；其 public `bridge` 可取得当前常驻网格。该任务不需要参考形变、TD、全 AO 编码再解码、CF 预测或学习。它不是不等价 fallback，而是声明不同任务职责；完整观察/形变/学习任务仍使用原 Session。两条路径不应同时持有同一 moving 的独立“当前观察”并交替执行；任务切换时明确重建/重观察，不借旧缓存推断新状态。

需要终态图片时，复用 `VGRenderer.prepare/observe`，传 Outcome.after 的真实 surface、target IDs、frame 和单位；不再为截图重复 Control.observe。显式绑定的 context meshes 由公开 `capture_context` 回调在同次 graph 下捕获到同一 bridge（可仅终态需要图时捕获）；不能漏掉遮挡物后宣称同一完整场景图。按原对象顺序构造 mesh 映射，保持颜色/身份与原 VG 语义。空表面没有见证，不能硬调用 renderer；零间隙用 NATURAL，SECTION 需要正间隙。

任务适配器只保留 scene/view_layer/objects/generations/goal、Control 和按需 renderer，不复制 Session 的私有状态机或几何算法。所有调用、构造与 close 在 Blender 主线程及显式 scene/view_layer GPU 上下文；执行传明确 target_changes，以保留 ActionStageError 的 written/not_written 语义。bridge 数组是借用视图，摘要在更新前取所需标量，不能留旧 view 当快照。render 后释放短期 PreparedScene，renderer 可驻留；stop/EOF 关闭 renderer 与 Control。上述组合仍须做新增功能资格，不能仅因组件已验收而声称入口已验收。

## 3. 模型只见两类工具与必要证据

**`run_task`** 提交 skill、对象 ID、目标/容差和明确允许的控制；返回 done、needs_decision、stopped 或 error。单位换算、名称唯一解析、公式、成功谓词在本地。首次目录确有需要才提供名称/ID/控制能力；不另造自由文本解析器。**`inspect`** 按 task/observation ID 取当前图、见证、对象定位或完整证据。建会话/关闭由宿主生命周期管理，不变成每动作往返。

默认不发全 AO、相机矩阵全集、所有候选、完整历史。结果至少有 task/observation/frame ID，moving/reference ID 与拓扑代次，目标/容差/实测距离及状态，实际控制前后值、实际平移、停止原因。需解释或继续操作时给两 witness 的对象、原三角形 ID、**世界米坐标**；预测值与实测值分开。不能只报“改善百分比”，也不能删掉定位后让模型猜方向。

首次识别对象、终态需要外观判定、或出现视觉决定点时交付当前图片；已明确对象的纯数值步骤不发图。图绑定 observation/frame/附件 ID、目标对象及全局/局部面板、NATURAL/SECTION；反投影请求再提供匹配相机信息。若 context 已丢失，不假定模型记得旧图。V 反馈仅在模型实际看图后产生，不能把送达或 native ray 通过当视觉成功；解析技能不假装执行了 CF 学习。

## 4. 第二技能与未来边界

第二阶段才做单个 active、unmasked relative shape key 的一维目标间隙求根。复用原 basis 和实际 readback，在明确区间内求根；几何连续性与有效实测端点夹根可支持二分，**稀疏样本看似单调不是全域单调证明**。G 只对当前 witness faces 做有限动作距离（`_cf_features.py:170`），L 是预测，均只能提案，不能代替全局 BC。要权衡本地真实试写次数，不能只省模型回合却让 Blender 做大量无效操作。未有合法区间/根时给一个具体决定点，不启动隐蔽多控制搜索。

未来小模型可以承担明确的图像判断或候选语义评分；当前只保留一个清晰输入输出位置，不实现模型路由平台。旋转、绕障、多对象耦合、多 shape key 联合优化、所有面应变约束均是独立后续能力；公开 TD Top-K 不能证明全局应变上界。

## 5. 最有价值的实施与验收范围

先交付一个 `close_gap` 任务适配器和一个 typed result 投影；复用既有 relay/pump、Control、BC 与 VG，不修改内核。当前架构“每步返回全 AO/图、必须通过 Session”的默认需相应改为按任务依赖选择，保留完整 Session 工具作为另一种明确能力，不能悄悄混称同责。

以相同初态、目标、控制范围、证据和达标标准比较合理逐动作工具流程与任务入口。先锁真实达标率、最终几何/控制与图像解释质量，再比较每个任务的模型回合、实测 token、图像数、总耗时、本地计算/写入次数；失败和 needs_decision 全部计入。合理基线也可以用解析公式，不能强迫其多次试错。适用多步交互任务可提出“工具往返至少减半”的预设价值目标，但须用真实模型任务验证，不能靠脚本绕过模型后直接宣布收益。

先收口解析平移和结果交付，再按实际收益决定 shape 技能；不重开已验收的 BC/CF/VG 优化循环。
