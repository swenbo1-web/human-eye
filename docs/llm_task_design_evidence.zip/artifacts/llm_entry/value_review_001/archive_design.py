"""Freeze root-owned design evidence; never stage implementation or user edits."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[3]
EVIDENCE = Path(__file__).resolve().parent
hash_bytes = lambda data: hashlib.sha256(data).hexdigest()
engine = json.loads((ROOT / 'docs/radical_acceptance_engine_v1.json').read_text(encoding='utf-8'))
sources = {name: {'sha256': hash_bytes((ROOT / name).read_bytes()),
                  'expected': row['sha256']}
           for name, row in engine['production_sources'].items()}
assert all(row['sha256'] == row['expected'] for row in sources.values())
spec_hash = hash_bytes((ROOT / 'docs/RADICAL_V1_SPEC_REVIEW.md').read_bytes())
assert spec_hash == '30b921d6a8f24863b6a1be7aaf9e5ad1e580988db2fc55ea161f0300a8cd50ec'
probe = json.loads((EVIDENCE / 'check_gap_contraction.json').read_text(encoding='utf-8'))
assert probe['passed'] and len(probe['cases']) == 32
verification = dict(checked_at=datetime.now(timezone.utc).isoformat(),
                    engine_production_sources=sources, engine_sources_unchanged=len(sources),
                    user_spec_sha256=spec_hash, analytic_design_states=32,
                    maximum_error_m=probe['maximum_error_m'],
                    blender_trials_in_root_review=0, llm_trials_in_root_review=0)
(EVIDENCE / 'root_verification.json').write_text(json.dumps(verification, indent=2) + '\n', encoding='utf-8')

decision = dict(
    decision='SELECT_TASK_VALUE_DESIGN_NOT_PRODUCT_ACCEPTANCE', date='2026-11-06', design_revision=2,
    supersedes_design='37c672c: task orchestration and primary acceptance; keeps resident transport',
    historical_design='docs/radical_acceptance_llm_entry_design.json',
    engine_sources_unchanged=len(sources), production_engine_commit=engine['production_commit'],
    llm_entry_candidate_in_progress=True, llm_entry_accepted=False,
    real_host_qualified=False, real_llm_task_value_qualified=False, new_performance_result=False,
    adopted=['goal-level run/inspect', 'public BlenderControl typed readback for close_gap',
             'global-witness closed-form gap contraction', 'task-specific minimal output',
             'no TD/fullAO/CF/image when the numerical task does not need them',
             'one optional final image in the same run', 'no mandatory feedback round',
             'reuse byte relay and persistent main-thread pump'],
    analytic_formula='delta = (d-g)*(b-a)/d for d>0, 0<=g<=d; independent rigid translation and fixed reference',
    analytic_check={'states':32, 'maximum_error_m':probe['maximum_error_m'],
                    'oracle':'independent exhaustive SVD convex-hull distances',
                    'does_not_qualify':['Blender evaluated rigid behavior', 'GUI/MCP delivery', 'LLM task benefit']},
    module_order=['E0 resident transport in parallel with E1', 'E1 analytic close_gap and decision output',
                  'E2 single relative shape-key task after E1 acceptance', 'E3 small-model residual tasks based on evidence'],
    provisional_formal_task_gate={
        'complex_episodes_per_arm':12, 'simple_controls_per_arm':2,
        'quality':'all declared E1 tasks meet actual goal/state requirements; no native-success/candidate-failure pair',
        'mean_complete_time_ratio_max':0.5, 'faster_pair_fraction_min':0.75,
        'per_family_mean_ratio_max':1.0, 'complete_task_p95_ratio_max':1.0,
        'visible_text_token_reduction_target':0.5,
        'multi_round_native_subset_decision_round_reduction_target':0.5,
        'unavailable_provider_usage':'unknown; token/cost gate unqualified, never inferred from bytes or fixed image tokens',
        'failure_cost':'preregistered task deadline, with actual duration retained',
        'native':'same model and scene; scripts, generic helpers, batching, cache, resident execution and analytic formula allowed',
        'must_freeze_exact_protocol_before_formal_results':True},
    former_bridge_microbenchmarks='secondary attribution only when an observed bottleneck justifies them; no result reclassified',
    user_spec_sha256=spec_hash,
    review='docs/LLM_TASK_VALUE_REVIEW.md', architecture='docs/LLM_ENTRY_ARCHITECTURE.md',
    work_order='docs/LLM_ENTRY_WORK_ORDER.md', evidence_archive='docs/llm_task_design_evidence.zip',
    implementation_chat='01a1abad-9d70-7260-8536-1fcd0dc7ae14',
    workflow='author completes self-tests and wakes root; root independently reviews process, architecture, algorithm and regression')
decision_path = ROOT / 'docs/radical_acceptance_llm_task_design.json'
decision_path.write_text(json.dumps(decision, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

paths = sorted(p for p in EVIDENCE.iterdir() if p.is_file())
paths += [ROOT / x for x in ('docs/LLM_TASK_VALUE_REVIEW.md', 'docs/LLM_ENTRY_ARCHITECTURE.md',
                            'docs/LLM_ENTRY_WORK_ORDER.md', 'docs/radical_acceptance_llm_task_design.json')]
payload = {p.relative_to(ROOT).as_posix(): p.read_bytes() for p in paths}
manifest = {name: {'bytes':len(data), 'sha256':hash_bytes(data)} for name, data in payload.items()}
archive = ROOT / 'docs/llm_task_design_evidence.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in payload.items():
        z.writestr(name, data)
    z.writestr('MANIFEST.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(hash_bytes(z.read(name)) == row['sha256'] for name, row in manifest.items())
print(json.dumps(dict(engine_sources_unchanged=len(sources), user_spec_unchanged=True,
                     archive_files=len(payload), archive_bytes=archive.stat().st_size,
                     archive_sha256=hash_bytes(archive.read_bytes()))))
