"""Frozen B/I workload used by the independent formal timing and resource workers."""

from contextlib import contextmanager
from dataclasses import asdict, dataclass
from hashlib import sha256
import json
from pathlib import Path
import time
from types import MappingProxyType

import numpy as np

from artifacts.integration.method_diagnostic_001.bb_diagnostic import _active_arrays, _arrays_digest
from artifacts.integration.preflight_002.bb_probe import _restore, _state
from human_eye_fast import (
    ActionResult, BlenderRadicalSession, CaptureChange, Goal, ObservationRequest, ObservationResult,
    ProbeAudit, ReferenceFrame, ViewAudit, ViewFeedback, load_cf_deployment,
)
from verification import integration_reference as reference_b
from verification.integration_fixtures import build_fixture, fixture_manifest
from verification.test_blender_radical_session import _changes, _reference_vertices
from verification.test_integration_preflight import _command, _materialize


ROOT = Path(__file__).resolve().parents[3]
PHASES = ("before", "after", "next")


def digest(data):
    return sha256(data).hexdigest()


@dataclass(slots=True)
class _BCurrent:
    fact: object
    readback: object
    attachments: MappingProxyType


@dataclass(slots=True)
class Outputs:
    before: ObservationResult
    result: ActionResult
    following: ObservationResult
    next_plan: object


@dataclass(slots=True)
class Case:
    case_id: str
    ordinal: int
    family: str
    fixture: object
    plan: dict
    deployment: object
    feedback: dict
    iterations: list

    @contextmanager
    def lane(self, role, setup_hook=None):
        with _materialize(self.fixture) as (scene, objects):
            lane = Lane(self, role, scene, objects, setup_hook=setup_hook)
            try:
                yield lane
            finally:
                lane.close()


def load_workload(manifest_path, process_index):
    manifest = manifest_path if isinstance(manifest_path, dict) else json.loads(Path(manifest_path).read_bytes())
    seed = manifest["seeds"][process_index]
    assert seed["process_index"] == process_index
    deployment_path = ROOT / seed["deployment"]
    assert digest(deployment_path.read_bytes()) == seed["deployment_sha256"]
    deployment = load_cf_deployment(deployment_path)
    if len(deployment.v_keys) != 240 or len(deployment.a_keys) != 240:
        raise ValueError("The frozen restore contract is limited to 240 non-wrapping live rows")
    specs = fixture_manifest()
    plans = manifest["formal_plans"]
    assert len(specs) == len(plans) == 24
    cases = []
    for spec, plan in zip(specs, plans, strict=True):
        assert spec.case_id == plan["case_id"]
        cases.append(Case(spec.case_id, spec.ordinal, spec.family, build_fixture(spec), plan, deployment,
                          seed["integration_feedback"][spec.case_id], manifest["iterations"]))
    return cases


def _renderer_class():
    from human_eye_fast.raycast_saccade_gpu import VGRenderer

    class _ReferenceRenderer(VGRenderer):
        """Keep the actual rank needed by the public audit without repeating model inference."""

        def observe(self, *args, rank_directions=None, **kwargs):
            self.order = None

            def rank(directions):
                self.order = rank_directions(directions)
                return self.order

            return super().observe(*args, rank_directions=rank if rank_directions is not None else None,
                                   **kwargs)

    return _ReferenceRenderer


class Lane:
    """One live host and the same public caller-held bytes and ticket duties for either role."""

    def __init__(self, case, role, scene, objects, setup_hook=None):
        self.case = case
        self.role = role
        self.scene = scene
        self.objects = objects
        fixture = case.fixture
        self.moving = objects[fixture.target_ids[0]]
        self._b_control = self._b_renderer = self._b_basis = self._b_current = None
        self._session = None
        self._closed = False
        self.command = _command(fixture.command)
        self.followup = _command(fixture.followup_command)
        self.predictor = case.plan["arms"]["deployment"]["predictor"]
        self.plans = dict(zip(PHASES, (case.plan["before"], case.plan["after_readback_and_publication"],
                                      case.plan["next"]), strict=True))
        self.top_k = self.plans["before"]["td_top_k"]
        self.generations = dict(self.plans["before"]["topology_generations"])
        change_type = CaptureChange if role == "I" else reference_b.CaptureChange
        self.changes = {name: _changes(phase, change_type) for name, phase in self.plans.items()}
        goal = Goal(*fixture.target_ids, fixture.goal_distance_m, fixture.goal_tolerance_m)
        frame_id = fixture.spec.frame_id
        generation = self.generations[fixture.target_ids[0]]
        reference_type = ReferenceFrame if role == "I" else reference_b.WorldReference
        reference = reference_type(frame_id, generation, _reference_vertices(scene, self.moving))
        if setup_hook is not None:
            setup_hook("reference_ready")
        if role == "I":
            self._session = BlenderRadicalSession(
                scene, scene.view_layers[0], objects, goal, self.generations,
                reference=reference, deployment=case.deployment,
            )
        elif role == "B":
            self._b_control = reference_b.SharedCaptureControl(
                scene, objects, goal, generations=self.generations, model=case.deployment.session())
            self._b_control.replace_reference(reference)
            self._b_renderer_class = _renderer_class()
        else:
            raise ValueError(f"Unknown formal role {role!r}")
        if setup_hook is not None:
            setup_hook("session_ready")
        if fixture.command.key_name is not None:
            self.key_name = fixture.command.key_name
            self._authored = float(self.moving.data.shape_keys.key_blocks[self.key_name].value)
            if role == "I":
                self._session.prepare_relative_basis(self.key_name)
            else:
                self._b_basis = reference_b.relative_basis_from_rna(self.moving, self.key_name)
        else:
            self.key_name = None
            assert self.moving.rotation_mode == "XYZ"
            self._authored = tuple(tuple(getattr(self.moving, channel))
                                   for channel in ("location", "rotation_euler", "scale"))
        self._pristine = _state(self.model)
        assert self._pristine[-1] == (240, 240)
        self._pristine_digest = _arrays_digest(_active_arrays(self.model))
        if setup_hook is not None:
            setup_hook("basis_ready")

    @property
    def model(self):
        return self._session._model if self.role == "I" else self._b_control._model

    @property
    def controller(self):
        return self._session._controller if self.role == "I" else self._b_control

    @property
    def renderer(self):
        return self._session._renderer if self.role == "I" else self._b_renderer

    @property
    def reference(self):
        return self._session._reference if self.role == "I" else self._b_control.reference

    @property
    def current(self):
        return self._session._current if self.role == "I" else self._b_current

    @property
    def basis(self):
        return self._session._bases if self.role == "I" else self._b_basis

    def owner_roots(self, outputs=None):
        control = self.controller
        return {
            "bridge": control.bridge, "indexes": control._indexes, "readback": control._latest,
            "model": self.model, "reference": self.reference, "renderer": self.renderer,
            "current": self.current, "basis": self.basis,
            "validation_reset_weights": None if self._closed else self._pristine[:2],
            "caller_outputs": outputs,
        }

    def reset(self):
        if self.key_name is not None:
            self.moving.data.shape_keys.key_blocks[self.key_name].value = self._authored
        else:
            self.moving.location, self.moving.rotation_euler, self.moving.scale = self._authored
        _restore(self.model, self._pristine)
        assert _arrays_digest(_active_arrays(self.model)) == self._pristine_digest
        return self._pristine_digest

    def replace_reference(self):
        fixture = self.case.fixture
        generation = self.generations[fixture.target_ids[0]]
        frame_id = fixture.spec.frame_id + 1000
        if self.role == "I":
            self._session.replace_reference(ReferenceFrame(
                frame_id, generation, _reference_vertices(self.scene, self.moving)))
        else:
            self._b_control.replace_reference(reference_b.WorldReference(
                frame_id, generation, _reference_vertices(self.scene, self.moving)))
            self._b_current = None

    def _requests(self, pair):
        row = self.case.iterations[pair]
        return tuple(ObservationRequest(row[name], self.plans[name]["mode"], "L") for name in PHASES)

    def _b_public(self, frame, ao, attachments, action=None):
        selection = frame.fact.image.rendered.metadata["selection"]
        probes = tuple(ProbeAudit(tuple(row["direction"]), row["ray_count"], row["aperture_taps"],
                                  row["target_support"]) for row in selection["probes"])
        ticket = frame.view
        audit = ViewAudit(ticket.index, tuple(selection["direction"]), selection["ray_count"],
                          probes, ticket.native_stop, self._b_renderer.order)
        current_attachments = MappingProxyType(frame.attachments)
        self._b_current = _BCurrent(frame.fact, frame.readback, current_attachments)
        prefix = (frame.readback.observation_id, frame.readback.frame_id, ao)
        suffix = (frame.image_status, ticket, audit)
        if action is None:
            return ObservationResult(*prefix, current_attachments, *suffix)
        return ActionResult(*prefix, MappingProxyType(attachments), *suffix, action.action_ticket)

    def _observe(self, phase, request):
        if self.role == "I":
            return self._session.observe(request, changes=self.changes[phase])
        if self._b_renderer is None:
            with self._b_control.scene_context():
                self._b_renderer = self._b_renderer_class()
            self._b_control._renderer = self._b_renderer
        frame = reference_b.observe(self._b_control, self._b_renderer, self.reference,
                                    request.observation_id, mode=request.image_mode, view_arm=request.view_arm,
                                    changes=self.changes[phase], top_k=self.top_k)
        return self._b_public(frame, frame.ao_bytes, frame.attachments)

    def _predict(self, current, command, action_id):
        if self.role == "I":
            return self._session.predict_action(current.observation_id, action_id, command,
                                                predictor=self.predictor)
        return reference_b.predict(self._b_control, self._b_current, command, action_id,
                                   action_arm=self.predictor, basis=self._b_basis)

    def _execute(self, prepared, request):
        if self.role == "I":
            return self._session.execute(prepared, request, changes=self.changes["after"])
        result = reference_b.execute(
            self._b_control, self._b_renderer, self.reference, self._b_current, prepared,
            request.observation_id, mode=request.image_mode, view_arm=request.view_arm,
            changes=self.changes["after"], top_k=self.top_k,
        )
        return self._b_public(result.after, result.ao_bytes, result.attachments, action=result)

    def _feedback_requests(self, requests):
        feedback_type = ViewFeedback if self.role == "I" else reference_b.ViewFeedback
        return tuple(feedback_type(request.observation_id, f"{request.observation_id}.png",
                                   self.case.feedback[name]["canonical_index"],
                                   self.case.feedback[name]["pixel_success"])
                     for name, request in zip(("before", "after"), requests[:2], strict=True))

    def _feedback(self, before, result, feedback):
        if self.role == "I":
            self._session.view_feedback(before.view_ticket, feedback[0])
            self._session.view_feedback(result.view_ticket, feedback[1])
            if result.action_ticket is not None:
                self._session.action_feedback(result.action_ticket)
        else:
            reference_b.view_feedback(self._b_control, self.model, before.view_ticket, feedback[0])
            reference_b.view_feedback(self._b_control, self.model, result.view_ticket, feedback[1])
            if result.action_ticket is not None:
                reference_b.action_feedback(self._b_control, self.model, result.action_ticket)

    def run(self, pair, *, clock=time.perf_counter_ns, stage_hook=None, after_t4=None):
        requests = self._requests(pair)
        feedback = self._feedback_requests(requests)
        ids = self.case.iterations[pair]
        t0 = clock()
        before = self._observe("before", requests[0])
        t1 = clock()
        if stage_hook is not None:
            stage_hook("t1", t1)
        prepared = self._predict(before, self.command, ids["action"])
        result = self._execute(prepared, requests[1])
        t2 = clock()
        if stage_hook is not None:
            stage_hook("t2", t2)
        self._feedback(before, result, feedback)
        t3 = clock()
        if stage_hook is not None:
            stage_hook("t3", t3)
        following = self._observe("next", requests[2])
        t_next_observed = clock()
        if stage_hook is not None:
            stage_hook("t_next_observed", t_next_observed)
        next_plan = self._predict(following, self.followup, ids["next_action"])
        t4 = clock()
        if after_t4 is not None:
            after_t4()
        if stage_hook is not None:
            stage_hook("t4", t4)
        return {"t0": t0, "t1": t1, "t2": t2, "t3": t3, "t_next_observed": t_next_observed,
                "t4": t4}, Outputs(before, result, following, next_plan)

    def proof(self, outputs):
        before, result, following = outputs.before, outputs.result, outputs.following
        pngs = tuple(row.attachments[f"{row.observation_id}.png"] for row in (before, result, following))
        public = {"before.ao.json": before.ao_bytes, "transition.ao.json": result.ao_bytes,
                  "next.ao.json": following.ao_bytes,
                  **dict(zip(("before.png", "after.png", "next.png"), pngs, strict=True))}
        checks = {"before_attachment_reused": result.attachments[f"{before.observation_id}.png"] is pngs[0],
                  "same_frame": before.frame_id == result.frame_id == following.frame_id,
                  "action_ticket_matches_arm": (result.action_ticket is not None) == (self.predictor == "L")}
        audit_rows = {}
        for offset, (name, row, png) in enumerate(zip(PHASES, (before, result, following), pngs, strict=True)):
            expected = self.case.feedback[name]
            ticket = row.view_ticket
            audit = row.view_audit
            audit_rows[name] = asdict(audit)
            native_stop = audit.native_stop
            selected = next(probe for probe in audit.probes if probe.direction == audit.direction)
            consumed = ticket._consumed if self.role == "I" else ticket.consumed
            checks[f"{name}_independently_scored_binding"] = (
                digest(png) == expected["png_sha256"] and row.frame_id == expected["frame_id"]
                and audit.canonical_index == expected["canonical_index"]
                and audit.direction == tuple(expected["direction"]) and audit.order == tuple(expected["order"])
                and audit.total_rays == expected["total_rays"] and selected.ray_count == expected["selected_rays"]
                and native_stop == expected["native_stop"]
                and ticket.observation_id == row.observation_id and consumed == (name != "next")
            )
            if offset < 2:
                slot = 240 + offset
                checks[f"{name}_actual_label"] = (
                    bool(self.model.views.known[slot, ticket.index])
                    and tuple(self.model.views.values[slot, ticket.index]) ==
                    (expected["safe"], expected["selected_rays"])
                )
        plan = outputs.next_plan
        if self.role == "I":
            observation_id, action_id, predicted = plan.observation_id, plan.action_id, plan.predicted_delta_m
            features, meters = plan._features, plan._meters
            view_features = following.view_ticket._features
        else:
            action = plan.action
            observation_id, action_id, predicted = action.before_observation_id, action.action_id, action.predicted_delta_m
            features, meters = plan.features, plan.meters
            view_features = following.view_ticket.features
        checks["next_plan_binding"] = observation_id == following.observation_id
        checks["model_writes"] = (self.model.views.writes, self.model.actions.writes) == (
            242, 240 + (self.predictor == "L"))
        proof = {"observation_id": observation_id, "action_id": action_id, "predictor": self.predictor,
                 "command": asdict(self.followup), "predicted_delta_m": predicted,
                 "action_features": None if features is None else features.tolist(), "action_meters": meters,
                 "view_features": view_features.tolist(), "view_audits": audit_rows}
        return {"public": public, "model": _active_arrays(self.model), "next": proof, "checks": checks}

    def close(self):
        if self._closed:
            return
        self._closed = True
        if self.role == "I":
            self._session.close()
        else:
            self._b_control.close()
        self._b_current = self._b_renderer = self._b_basis = self._pristine = None
