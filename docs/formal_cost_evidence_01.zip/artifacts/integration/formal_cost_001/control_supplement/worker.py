"""Untimed checks of the original affected CF controls through production I."""

from contextlib import ExitStack
import gzip
from io import BytesIO
import json
from pathlib import Path
import traceback
from types import SimpleNamespace
from zipfile import ZIP_STORED, ZipFile

import numpy as np

from human_eye_fast import CaptureChange, MeshChange, ObservationRequest, SetShapeKey, Translate, load_cf_deployment
from human_eye_fast.cerebellar_flash import triangle_pair_distance
from human_eye_fast.fast_affordance_out import ImageFact, _image, _row
from artifacts.integration.formal_cost_001 import old_cf


ROOT = old_cf.ROOT
SCHEMA = old_cf.SCHEMA
COLUMNS = old_cf.COLUMNS
OBS = COLUMNS["observation"]
OUT = COLUMNS["outcome"]
CHANGES = MeshChange.VERTICES | MeshChange.TRANSFORM | MeshChange.UNITS


def _write(path, value):
    path.write_text(json.dumps(value, allow_nan=False, ensure_ascii=False, indent=2) + "\n",
                    encoding="utf-8", newline="\n")


def _output(archive, case_id, record, filename, payload):
    archive.writestr(f"{case_id}/{filename}", payload)
    record["public"][filename] = old_cf._digest(payload)


def _control_view(native, session, expected, raw, media, proof, record):
    case = native.fixture.spec
    identity = "empty" if case.family == "empty" else "view"
    changes = dict.fromkeys(native.objects, CaptureChange(CHANGES))
    observed = session.observe(ObservationRequest(identity, "NATURAL", "F"), changes=changes)
    _output(proof, case.episode_id, record, "view.ao.json", observed.ao_bytes)
    assert observed.view_ticket is None
    document = old_cf._normalize(observed.ao_bytes, (identity,), (identity,))
    row, = old_cf._rows(document)
    clearance = row[OBS["clearance"]]
    status = clearance[COLUMNS["clearance"]["status"]]
    assert expected["success"]
    if case.family == "empty":
        assert observed.image_status == "empty_surface" and status == "empty_surface"
        assert row[OBS["image"]] is None and not observed.attachments and observed.view_audit is None
        assert observed.ao_bytes == media.read(f"{case.episode_id}/empty.json")
        record.update({"rays": 0, "image_status": observed.image_status, "clearance": status})
        return
    png = observed.attachments[f"{identity}.png"]
    _output(proof, case.episode_id, record, "view.png", png)
    assert png == media.read(f"{case.episode_id}/F.png")
    audit, score = raw["audit"], raw["score"]
    assert old_cf._digest(png) == expected["png_sha256"] == score["png_sha256"]
    assert score["passed"] == expected["pixel_success"] and score["safe"] == expected["safe"]
    assert observed.image_status == "rendered" and raw["mode"] == case.mode
    selection = audit["metadata"]["selection"]
    observed_view = observed.view_audit
    assert list(observed_view.direction) == selection["direction"]
    assert observed_view.total_rays == selection["ray_count"] == expected["rays"]
    assert observed_view.native_stop == audit["native_stop"] == expected["native_stop"]
    assert len(observed_view.probes) == len(selection["probes"])
    for actual, original in zip(observed_view.probes, selection["probes"], strict=True):
        assert (list(actual.direction), actual.ray_count, actual.aperture_taps, actual.target_support) == (
            original["direction"], original["ray_count"], original["aperture_taps"], original["target_support"],
        )
    indices = {name: i for i, name in enumerate(document[COLUMNS["package"]["object_ids"]])}
    expected_image = _image(_row, ImageFact("view.png", SimpleNamespace(metadata=audit["metadata"])), indices)
    assert old_cf._compact(row[OBS["image"]]) == old_cf._compact(expected_image)
    if case.family == "contact":
        assert status == "zero_distance" and observed_view.total_rays == 0
    elif case.family == "enclosed":
        assert not score["passed"] and not observed_view.native_stop
    else:
        assert case.family == "unobstructed" and score["passed"] and observed_view.native_stop
        assert audit["candidate"] == 0
    record.update({"rays": observed_view.total_rays, "image_status": observed.image_status,
                   "clearance": status, "archived_candidate": audit["candidate"],
                   "pixel_pass": score["pixel_success"], "strict_pass": score["passed"],
                   "native_stop": observed_view.native_stop})


def _g_from_archive(raw, command):
    before = raw["outcome"]["before"]
    moving, reference = before["target_ids"]
    a_verts, a_rows = (np.asarray(item) for item in raw["native_before"][moving])
    b_verts, b_rows = (np.asarray(item) for item in raw["native_before"][reference])
    surface = before["surface"]
    return triangle_pair_distance(
        a_verts[a_rows[surface["triangle_a"]]] + np.asarray(command.delta_world_m),
        b_verts[b_rows[surface["triangle_b"]]],
    ) - surface["distance_m"]


def _control_action(native, session, expected, raw, media, proof, record):
    case = native.fixture.spec
    spec = native.fixture.command
    clamp = case.family == "shape-readback-clamp"
    predictor = "NONE" if clamp else "L" if case.split == "diagnostic" else "G"
    if spec.kind == "translate":
        command = Translate(spec.delta_world_m)
    else:
        command = SetShapeKey(spec.key_name, spec.target_value)
    changes = dict.fromkeys(native.objects, CaptureChange(CHANGES))
    after_changes = dict.fromkeys(native.objects, CaptureChange(MeshChange.VERTICES | MeshChange.TRANSFORM))
    before = session.observe(ObservationRequest("before", "NATURAL", "F"), changes=changes)
    _output(proof, case.episode_id, record, "before.ao.json", before.ao_bytes)
    _output(proof, case.episode_id, record, "before.png", before.attachments["before.png"])
    if clamp:
        rejection = {}
        authored_before = native.key.value
        for unsupported in ("G", "L"):
            try:
                session.predict_action("before", "apply", command, predictor=unsupported)
            except ValueError as error:
                assert "slider range" in str(error)
                rejection[unsupported] = str(error)
            else:
                raise AssertionError(f"Out-of-domain command unexpectedly admitted by {unsupported}")
        assert native.key.value == authored_before == expected["control_before"]
        record["clamp_prediction_rejections"] = rejection
    plan = session.predict_action("before", "apply", command, predictor=predictor)
    result = session.execute(plan, ObservationRequest("after", "NATURAL", "F"), changes=after_changes)
    _output(proof, case.episode_id, record, "joint.ao.json", result.ao_bytes)
    _output(proof, case.episode_id, record, "after.png", result.attachments["after.png"])
    assert before.view_ticket is None and result.view_ticket is None
    assert before.attachments["before.png"] == result.attachments["before.png"]
    assert before.attachments["before.png"] == media.read(f"{case.episode_id}/before.png")
    assert result.attachments["after.png"] == media.read(f"{case.episode_id}/after.png")
    assert before.ao_bytes == media.read(f"{case.episode_id}/before.json")
    legacy = json.loads(media.read(f"{case.episode_id}/after.json"))
    current = json.loads(result.ao_bytes)
    outcome = old_cf._result(current)
    assert old_cf._rows(current)[0] == old_cf._rows(json.loads(before.ao_bytes))[0]
    measured = outcome[OUT["measured_delta_m"]]
    prediction = outcome[OUT["predicted_delta_m"]]
    assert measured == expected["measured_delta_m"]
    assert measured == outcome[OUT["distance_after_m"]] - outcome[OUT["distance_before_m"]]
    if predictor == "L":
        assert prediction == expected["comparison"]["L"]
        ticket = result.action_ticket
        assert ticket is not None and not ticket._consumed
        assert ticket._meters == expected["feature_scale_m"] and ticket._measured_delta_m == measured
        assert old_cf._bytes_equal(ticket._features, np.asarray(raw["features"], dtype=np.float64))
    else:
        assert result.action_ticket is None
        if clamp:
            assert prediction is None and spec.target_value == 20.4
            assert native.key.value == outcome[OUT["control_after"]] == expected["control_after"] == 1.
        else:
            assert spec.kind == "translate" and case.family == "parallel-box"
            independent = _g_from_archive(raw, command)
            budget = max(expected["delta_budget_m"], 64 * np.finfo(np.float64).eps * case.scale_m)
            assert abs(prediction - independent) <= budget
            assert abs(prediction - expected["comparison"]["G"]) <= budget
            host_budget = budget + 64 * np.finfo(np.float32).eps * max(
                case.scale_m, *(np.linalg.norm(mesh.vertices_m, axis=1).max() for mesh in native.fixture.meshes)
            )
            assert abs(measured - native.fixture.expected_delta_m) <= host_budget
            if spec.amplitude == 0:
                assert measured == 0. and abs(prediction) <= 64 * np.finfo(np.float64).eps * case.scale_m
            record.update({"independent_G_m": independent, "prediction_budget_m": budget,
                           "host_oracle_budget_m": host_budget})
        # The old archive reports feature-space G for the translation controls
        # and out-of-domain L for the clamp. The production contracts differ
        # only in this compared field, whose supported behavior is checked above.
        old_cf._result(legacy)[OUT["predicted_delta_m"]] = prediction
    assert old_cf._compact(current) == old_cf._compact(legacy)
    record.update({"predictor": predictor, "measured_delta_m": measured, "predicted_delta_m": prediction,
                   "distance_before_m": outcome[OUT["distance_before_m"]],
                   "distance_after_m": outcome[OUT["distance_after_m"]],
                   "control_before": outcome[OUT["control_before"]], "control_after": outcome[OUT["control_after"]]})


def run(job, out):
    from verification.cf_experiment import Inputs
    from verification.cf_fixtures import build_fixture
    from verification.cf_native import materialize

    out = Path(out)
    out.mkdir()
    inputs = Inputs(out)
    seed = job["seed"]
    config = job["inputs"]
    deployed = load_cf_deployment(BytesIO(inputs.track(ROOT / config["deployment"])))
    controls = inputs.specs(ROOT / config["control"], seed, "control")
    diagnostic = inputs.specs(ROOT / config["diagnostic"], seed, "diagnostic")
    assert (len(controls["V"]), len(controls["A"]), len(diagnostic["V"]), len(diagnostic["A"])) == (12, 12, 0, 7)
    quality = json.loads(inputs.track(ROOT / config["quality"]))
    expected = {row["id"]: row for field in ("controls", "diagnostic") for row in quality[field]}
    specs = controls["V"] + controls["A"] + diagnostic["A"]
    assert expected.keys() == {case.episode_id for case in specs}
    records = {}
    with gzip.GzipFile(fileobj=BytesIO(inputs.track(ROOT / config["records"]))) as stream:
        for line in stream:
            row = json.loads(line)
            if row["id"] in expected:
                records[row["id"]] = row
    assert records.keys() == {case.episode_id for case in specs if case.family != "empty"}
    result = []
    with (ZipFile(BytesIO(inputs.track(ROOT / config["media"]))) as media,
          ZipFile(out / "public_outputs.zip", "w", compression=ZIP_STORED) as proof,
          (out / "controls.jsonl").open("w", encoding="utf-8", newline="\n") as raw):
        assert json.loads(media.read("ao-schema.json")) == json.loads(old_cf._compact(SCHEMA))
        proof.writestr("ao-schema.json", old_cf._compact(SCHEMA))
        for case in specs:
            record = {"case_id": case.episode_id, "split": case.split, "head": case.head,
                      "family": case.family, "public": {}}
            try:
                with ExitStack() as stack:
                    native = stack.enter_context(materialize(build_fixture(case)))
                    session, _ = old_cf._make_session(native, deployed, stack, old_cf._untimed)
                    reset = old_cf._ModelReset(session._model, deployed)
                    runner = _control_view if case.head == "V" else _control_action
                    runner(native, session, expected[case.episode_id], records.get(case.episode_id),
                           media, proof, record)
                    reset.verify_action(None, None, None, False)
                record["passed"] = True
            except Exception:
                record.update({"passed": False, "error": traceback.format_exc()})
            result.append(record)
            raw.write(json.dumps(record, ensure_ascii=False, allow_nan=False,
                                 separators=(",", ":"), default=np.generic.item) + "\n")
            raw.flush()
    by_id = {row["case_id"]: row for row in result}
    opposite_pairs = []
    for family in ("tapered-beam", "multifold-beam", "nonplanar-beam"):
        left = by_id[f"A-{seed}-diagnostic-{family}-000-minus"]
        right = by_id[f"A-{seed}-diagnostic-{family}-000-plus"]
        opposite_pairs.append({"family": family, "passed": bool(
            left["passed"] and right["passed"]
            and left["control_before"] == right["control_before"]
            and left["distance_before_m"] == right["distance_before_m"]
            and left["control_after"] != right["control_after"]
        )})
    summary = {"seed": seed, "scope": "Original CF controls and diagnostics via production I/v1; untimed",
               "passed": all(row["passed"] for row in result + opposite_pairs),
               "cases": len(result), "passed_cases": sum(row["passed"] for row in result),
               "opposite_command_pairs": opposite_pairs, "case_records": "controls.jsonl",
               "outputs": "public_outputs.zip"}
    _write(out / "summary.json", summary)
    return summary
