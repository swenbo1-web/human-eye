"""Register and serially run the untimed 93-case production CF supplement."""

from argparse import ArgumentParser
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback
from zipfile import ZIP_DEFLATED, ZipFile


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
sys.path.insert(0, str(ROOT))

from artifacts.integration.method_diagnostic_001 import runtime_identity


BLENDER = Path(r"C:\Program Files\Blender Foundation\Blender 5.2\blender.exe")
SEEDS = (20261105, 79463, 310519)
ENTRY = Path(__file__).resolve()
COST = HERE.parent
DEPLOYMENTS = COST.parent / "production_functional_001/deployments"
HISTORICAL = ROOT / "artifacts/cf/formal_001"


def relative(path):
    return Path(path).resolve().relative_to(ROOT).as_posix()


def digest(value):
    return sha256(value).hexdigest()


def source_bytes():
    paths = {*ROOT.glob("human_eye_fast/**/*.py"), *ROOT.glob("verification/**/*.py"), *HERE.glob("*.py"),
             COST / "old_cf.py", Path(runtime_identity.__file__),
             *(ROOT / "docs" / name for name in ("ENGINE_INTEGRATION_API.md", "CF_ACCEPTANCE_PROTOCOL.md",
                                                 "INTEGRATION_COST_PROTOCOL.md"))}
    return {relative(path): path.read_bytes() for path in sorted(paths)}


def _observed_project():
    files = {Path(raw).resolve() for module in tuple(sys.modules.values())
             if (raw := getattr(module, "__file__", None))}
    files.add(ENTRY)
    return {relative(path): runtime_identity.identity(path)["sha256"] for path in sorted(files)
            if path.is_relative_to(ROOT) and path.is_file()}


def _worker(launch_path):
    from artifacts.integration.formal_cost_001.control_supplement import worker

    import bpy
    assert bpy.app.background
    launch = json.loads(launch_path.read_bytes())
    folder = launch_path.parent
    sys.dont_write_bytecode = True
    sys.pycache_prefix = os.environ["PYTHONPYCACHEPREFIX"]
    anchor = runtime_identity.clock_anchor()
    try:
        worker.run(launch, folder / "result")
    finally:
        runtime_identity.write_json(folder / "observed-project-imports.json", {
            "scope": "Project imports observed at exit and explicit worker entry",
            "paths": _observed_project(),
        })
        try:
            runtime_identity.write_json(folder / "runtime.json", runtime_identity.native_fingerprint(anchor))
        except Exception:
            (folder / "runtime-error.txt").write_text(traceback.format_exc(), encoding="utf-8")


def _job(out, seed):
    baseline = HISTORICAL / str(seed)
    reference = baseline / ("evaluation-completion" if seed == 20261105 else "evaluation")
    inputs = {
        "deployment": relative(DEPLOYMENTS / f"{seed}.npz"),
        "control": relative(baseline / "specs/manifest-control.json"),
        "diagnostic": relative(baseline / "specs/manifest-diagnostic.json"),
        "quality": relative(reference / "summary.json"),
        "records": relative(reference / "records.jsonl.gz"),
        "media": relative(reference / "media.zip"),
    }
    folder = out / str(seed)
    launch_path = folder / "launch.json"
    overrides = {**runtime_identity.THREAD_ENV, "PYTHONDONTWRITEBYTECODE": "1",
                 "PYTHONPYCACHEPREFIX": str(folder / "isolated-pycache")}
    env = {**os.environ, **overrides}
    argv = [str(BLENDER), "--background", "--factory-startup", "--disable-autoexec",
            "--threads", "1", "--python-exit-code", "1", "--python", str(ENTRY), "--",
            "--registered-worker", str(launch_path)]
    return {"seed": seed, "argv": argv, "directory": relative(folder), "inputs": inputs,
            "input_identities": {path: runtime_identity.identity(ROOT / path) for path in inputs.values()},
            "environment_overrides": overrides,
            "environment_effective": runtime_identity.effective_environment(env)}


def _run_job(job, registered_sources):
    folder = ROOT / job["directory"]
    folder.mkdir()
    runtime_identity.write_json(folder / "launch.json", job)
    if registered_sources != source_bytes():
        raise RuntimeError("Registered supplement source bytes changed before launch")
    env = {**os.environ, **job["environment_overrides"]}
    assert runtime_identity.effective_environment(env) == job["environment_effective"]
    assert all(runtime_identity.identity(ROOT / path) == expected
               for path, expected in job["input_identities"].items())
    print(f"Original CF untimed controls seed {job['seed']} starting", flush=True)
    with (folder / "worker.log").open("wb") as output:
        proc = subprocess.run(job["argv"], cwd=ROOT, env=env, stdout=output,
                              stderr=subprocess.STDOUT, check=False)
    reads_path = folder / "result/reads.jsonl"
    reads = [json.loads(line) for line in reads_path.read_bytes().splitlines()] if reads_path.exists() else []
    reads_by_path = {relative(Path(row["path"])): row for row in reads}
    read_match = all(reads_by_path.get(path) == identity for path, identity in job["input_identities"].items())
    read_match = read_match and set(reads_by_path) == set(job["input_identities"])
    sources_stable = registered_sources == source_bytes()
    inputs_stable = all(runtime_identity.identity(ROOT / path) == expected
                        for path, expected in job["input_identities"].items())
    observed_path = folder / "observed-project-imports.json"
    imports = json.loads(observed_path.read_bytes())["paths"] if observed_path.exists() else {}
    discrepancies = [path for path, value in imports.items()
                     if path not in registered_sources or digest(registered_sources[path]) != value]
    runtime_path = folder / "runtime.json"
    runtime = json.loads(runtime_path.read_bytes()) if runtime_path.exists() else None
    environment_stable = bool(runtime and runtime["environment"] == job["environment_effective"])
    summary_path = folder / "result/summary.json"
    summary = json.loads(summary_path.read_bytes()) if summary_path.exists() else None
    passed = bool(proc.returncode == 0 and reads and read_match and inputs_stable and sources_stable and imports
                  and not discrepancies and environment_stable and summary and summary["passed"])
    result = {"seed": job["seed"], "exit_code": proc.returncode, "passed": passed,
              "actual_input_reads_match": read_match, "stable_sources": sources_stable,
              "stable_inputs": inputs_stable, "observed_project_imports": len(imports),
              "import_discrepancies": discrepancies, "runtime_environment_stable": environment_stable,
              "cases": summary["cases"] if summary else None,
              "passed_cases": summary["passed_cases"] if summary else None}
    runtime_identity.write_json(folder / "process.json", result)
    print(json.dumps(result), flush=True)
    return result


def launch(out):
    out = Path(out).resolve()
    if not out.is_relative_to(HERE) or out == HERE:
        raise ValueError("Use a fresh output directory inside control_supplement")
    out.mkdir()
    sources = source_bytes()
    with ZipFile(out / "sources.zip", "x", compression=ZIP_DEFLATED) as archive:
        for path, value in sources.items():
            archive.writestr(path, value)
    jobs = [_job(out, seed) for seed in SEEDS]
    manifest = {
        "scope": "Original CF production functional supplement. Three native workers, serial and untimed.",
        "registered_cases_per_seed": {"V_F_controls": 12, "A_G_controls": 12, "A_L_diagnostics": 6,
                                      "A_NONE_clamp_with_G_L_rejections": 1},
        "exclusions": {
            "C_constant_and_zero_shuffle": "Historical comparison and ablation arms; no corresponding production I API.",
            "forged_scoring_negatives": "Tests of the independent validators using forged published evidence. The original regression already verified these unchanged.",
            "historical_two_scene_prequential": "Historical evaluator owns one mutable model across recreated scenes; production I owns a scene-bound model. The old replay and new I feedback lifecycle cover their respective contracts.",
        },
        "executables": {"blender": runtime_identity.identity(BLENDER),
                        "launcher_python": runtime_identity.identity(sys.executable)},
        "source_superset": {path: digest(value) for path, value in sources.items()}, "jobs": jobs,
    }
    runtime_identity.write_json(out / "manifest.json", manifest)
    results = [_run_job(job, sources) for job in jobs]
    passed = all(row["passed"] for row in results)
    runtime_identity.write_json(out / "summary.json", {"passed": passed, "scope": manifest["scope"],
                                                      "timings_collected": False, "processes": results})
    return 0 if passed else 1


def main():
    if "--registered-worker" in sys.argv:
        _worker(Path(sys.argv[sys.argv.index("--registered-worker") + 1]))
        return 0
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=HERE / "run_001")
    return launch(parser.parse_args().out)


if __name__ == "__main__":
    status = main()
    if status:
        raise SystemExit(status)
