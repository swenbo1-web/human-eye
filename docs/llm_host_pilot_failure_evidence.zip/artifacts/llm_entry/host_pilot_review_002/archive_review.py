"""Preserve actual host failure and read-only diagnosis without starting services."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
EXECUTION = ROOT / "artifacts/llm_entry/host_pilot_001/execution_001/manifest.json"
ARCHIVE = ROOT / "docs/llm_host_pilot_failure_evidence.zip"
DECISION = ROOT / "docs/radical_acceptance_llm_host_pilot_failure.json"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert not ARCHIVE.exists() and not DECISION.exists()
    assert sha(EXECUTION) == "8797d35775a781c1a79dabe0a069a82380cfc1623f27b7827f5b8439abacea1a"
    execution = json.loads(EXECUTION.read_bytes())
    refs = execution["evidence_sha256"]
    assert len(refs) == 39
    for name, digest in refs.items():
        assert sha(ROOT / name) == digest, name
    assert sha(ROOT / "docs/RADICAL_V1_SPEC_REVIEW.md") == "30b921d6a8f24863b6a1be7aaf9e5ad1e580988db2fc55ea161f0300a8cd50ec"
    paths = [ROOT / name for name in refs]
    paths += [EXECUTION, ROOT / "docs/LLM_HOST_PILOT_FAILURE_REVIEW.md"]
    paths += [p for p in HERE.iterdir() if p.is_file()]
    selected_schemas = (
        "v1/InitializeParams.json", "v2/ThreadStartParams.json", "v2/ThreadStartResponse.json",
        "v2/TurnStartParams.json", "ServerRequest.json", "ToolRequestUserInputParams.json",
        "ToolRequestUserInputResponse.json",
    )
    paths += [HERE / "approval_schema" / name for name in selected_schemas]
    entries = {p.relative_to(ROOT).as_posix(): {"bytes": p.stat().st_size, "sha256": sha(p)}
               for p in sorted(set(paths))}
    with zipfile.ZipFile(ARCHIVE, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in entries:
            archive.write(ROOT / name, name)
        archive.writestr("MANIFEST.json", json.dumps(entries, ensure_ascii=False, indent=2))
    with zipfile.ZipFile(ARCHIVE) as archive:
        assert archive.testzip() is None
        for name, item in entries.items():
            payload = archive.read(name)
            assert len(payload) == item["bytes"]
            assert hashlib.sha256(payload).hexdigest() == item["sha256"]
    decision = {
        "decision": "ACCEPT_HOST_DISCOVERY_ONLY_REWORK_APPROVAL_PATH",
        "review_number": 27, "date": "2026-11-06",
        "actual_execution_manifest_sha256": sha(EXECUTION),
        "actual_execution_evidence_references": 39, "frozen_sources_verified": 33,
        "plan_sha256": execution["plan_sha256"], "counts": execution["counts"],
        "negotiated_protocol": "2025-06-18",
        "actual_host_initialize_and_tools_list_accepted": True,
        "model_correct_call_arguments_observed": True,
        "task_cases": 2, "task_cases_passed": 0, "wire_tools_call_count": 0,
        "dispatch_failure": "MCP tool call requires approval, but approval policy is never",
        "native_rna_unchanged": True, "real_result_or_image_consumption_accepted": False,
        "normal_eof_accepted": False, "reset_cleanup_completed": True,
        "tap_final_receipts_present": False,
        "reported_turn_usage": {name: data["usage"] for name, data in execution["cases"].items()},
        "reported_cli_elapsed_s": {name: data["cli_elapsed_s"] for name, data in execution["cases"].items()},
        "per_request_or_source_token_attribution": "unavailable",
        "visible_text_image_token_breakdown": "unavailable",
        "bytes_to_tokens_or_cost_inference": False,
        "new_engine_algorithm_optimization": False, "prior_native_functional_qualification_retained": True,
        "model_contexts_consumed": 2, "authorized_contexts_remaining": 0,
        "next_scope": "offline app-server bidirectional client and configuration isolation preparation only",
        "next_model_candidate": "at most one existing occluded task, not yet authorized",
        "root_new_model_or_blender_or_app_server_sessions": 0,
        "task_benefit_accepted": False, "advance_E2": False,
        "root_reports_sha256": {name: sha(HERE / name) for name in
                                ("execution_review.md", "approval_route_review.md")},
        "official_references": ["https://learn.chatgpt.com/docs/app-server#approvals",
                                "https://learn.chatgpt.com/docs/config-file/config-reference"],
        "review": "docs/LLM_HOST_PILOT_FAILURE_REVIEW.md",
        "evidence_archive": {"path": ARCHIVE.relative_to(ROOT).as_posix(), "sha256": sha(ARCHIVE),
                             "bytes": ARCHIVE.stat().st_size, "file_count_excluding_manifest": len(entries),
                             "all_members_readback_verified": True,
                             "schema_scope": "seven relevant local schemas; all 470 generated identities remain indexed"},
    }
    DECISION.write_text(json.dumps(decision, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(decision["evidence_archive"]))


if __name__ == "__main__":
    main()
