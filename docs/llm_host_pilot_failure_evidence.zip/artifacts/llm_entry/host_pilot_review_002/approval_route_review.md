# Pilot 审批路线只读复核

结论：保留两次原失败；建议仅准备一条 **app-server stdio + 逐请求人工应答** 路线。接口已由本机离线 schema 和 OpenAI 官方文档确认；尚未证明本机这个普通 local MCP 的 `eye_run` 会实际产生该审批请求，不能标为 pilot 修复成功。下一次真实资格最多一个 `occluded` 上下文，须另行授权；本轮没有启动模型、Blender 或 app-server 会话。

## 固定证据

- `execution_001/manifest.json` SHA-256：`8797d35775a781c1a79dabe0a069a82380cfc1623f27b7827f5b8439abacea1a`。两臂已完成 MCP 2025-06-18 握手与工具发现，随后实际 `eye_run` 的错误均是 `MCP tool call requires approval, but approval policy is never`，原生写入与图片为零。这证明阻塞在宿主审批，并不能反推引擎执行失败。
- 本机 CLI：`C:/Users/v_wbobosun/AppData/Local/OpenAI/Codex/bin/14b838c1d074ff01/codex.exe`；SHA-256 `40ecc3d8b6899afd8f935a8cccb7d53ba41ffd7c199f679e186d30ddd0d0bf39`。本轮保存 root、exec、app-server、schema 的 help 与 version 原文至本目录 `approval_*_help.json`、`approval_version.json`。
- 根 CLI help 有 `-a on-request`；`exec --help` 没有 `-a`。不能据此把 `-a` 或 `-c approval_policy=...` 塞进 exec 后宣称有人可以回答审批；本轮没有进行这种模型试跑。
- 离线执行 `app-server generate-json-schema --experimental --out <本目录>/approval_schema`，生成 470 个 JSON schema；没有启动 app-server 服务。CLI 身份、命令和全部 schema 哈希见 `approval_offline_evidence.json`。CLI 启动包装器报告临时 PATH alias 目录访问被拒；schema 生成退出 0，未据此放宽权限。

## 一条具体候选

执行宿主改为该冻结 CLI 的 `app-server --stdio --strict-config`，双向 JSON 行客户端处理服务器请求，不再使用 `exec --json` 的单向事件收集器。只在下一次试验进程参数或 thread/start 的 config 覆盖中提供已冻结的 `human_eye_v1` stdio command/args；不要落盘改默认 MCP、用户配置或任何工具 annotation。

本机 `v1/InitializeParams.json` 支持以下初始化形状：

```json
{"id":1,"method":"initialize","params":{"clientInfo":{"name":"human_eye_pilot","version":"0.1.0"},"capabilities":{"experimentalApi":true}}}
```

初始化后发送 `initialized` 通知。新线程核心参数如下；`cwd` 必须替换为本次已审定的空 consumer 绝对路径：

```json
{"id":2,"method":"thread/start","params":{"model":"gpt-6.1-sol","cwd":"<empty-consumer>","ephemeral":true,"approvalPolicy":"on-request","approvalsReviewer":"user","sandbox":"read-only","config":{"web_search":"disabled","mcp_servers.human_eye_v1.tools.eye_run.approval_mode":"prompt"}}}
```

这段是请求结构示例，**不是已冻结可启动的完整试验配置**。MCP 启动参数、消费者路径、180 秒预算和源身份必须在新清单中固定。`prompt` 要求显式审批，不是 `approve`、自动接受或放宽写工具身份。官方配置参考列出每工具 `approval_mode` 与 `approvals_reviewer`；本机 `v2/ThreadStartParams.json` 明确支持这些 thread 字段，其 `ApprovalsReviewer` 描述包括 MCP 审批。[OpenAI Configuration Reference](https://learn.chatgpt.com/docs/config-file/config-reference)

`thread/start` 返回的实际 `approvalPolicy`、`approvalsReviewer`、`sandbox` 都是本机 `v2/ThreadStartResponse.json` 必填字段。启动 turn 前核对确实为 on-request、user、readOnly，并保存 `instructionSources`。若管理规则不允许，不切换绕过模式。不要把用户层显式设置当成覆盖管理规则的保证。

随后仅在新增单次任务授权到位时发送（目前不得发送）：

```json
{"id":3,"method":"turn/start","params":{"threadId":"<returned-thread-id>","input":[{"type":"text","text":"<frozen-occluded-public-prompt>"}]}}
```

`v2/TurnStartParams.json` 的必填字段只有 `threadId` 与 `input`；text 项必填 `type/text`。模型、审批与 sandbox 继承刚刚核对的线程，其他原试验参数如 reasoning effort 另列在冻结清单中，不能依赖改变入口后的默认值。

模型发起工具后，保存并展示 `item/started` 中的 server、tool、完整 arguments；对收到的 `item/tool/requestUserInput` 关联 threadId、turnId、itemId、服务器 request ID 与 question ID。只有当用户看到具体调用并选择该请求提供的单次接受选项，才回同一 request ID，例如：

```json
{"id":"<server-request-id>","result":{"answers":{"<question-id>":{"answers":["<actual-user-selected-option-label>"]}}}}
```

该方法名来自本机 `ServerRequest.json`；`ToolRequestUserInputParams.json` 要求 `isBlocking/itemId/questions/threadId/turnId`，响应来自 `ToolRequestUserInputResponse.json` 的 question-ID→answers 映射。不要硬编码猜测 Accept 标签，不用 command-execution 的 `{decision:accept}` 误答 MCP 问题，不以超时代表授权，不选择整会话信任，不自动接受未知或后续请求。官方 app-server 文档说明工具审批会请求用户输入，并在拒绝时终止该调用；文档该节措辞为 app/connector，所以普通 local MCP 的实际路由仍要实测确认。[OpenAI App Server](https://learn.chatgpt.com/docs/app-server#approvals)

收到的 pending 请求最小形状如下，字段值只能采用真实事件，不能由客户端伪造以代替宿主审批：

```json
{"id":"<server-request-id>","method":"item/tool/requestUserInput","params":{"isBlocking":true,"itemId":"<matching-mcp-item-id>","threadId":"<thread-id>","turnId":"<turn-id>","questions":[{"id":"<question-id>","header":"<server-header>","question":"<server-question>","options":[{"label":"<server-option-label>","description":"<server-option-description>"}]}]}}
```

实施客户端第一步只暴露该 pending 原文与对应 `mcpToolCall` 的 server/tool/arguments 给主干，等待主干决策，不自动回复首项。将来若用户预授权了精确单次动作，主干仍须核对实际参数、场景/进程身份与真实 requestId，然后只应答这一请求；本轮没有这份新增授权。最小 schema 文件均在本报告同目录 `approval_schema/`：`v1/InitializeParams.json`、`v2/ThreadStartParams.json`、`v2/ThreadStartResponse.json`、`v2/TurnStartParams.json`、`ServerRequest.json`、`ToolRequestUserInputParams.json`、`ToolRequestUserInputResponse.json`。这里没有要求实现完整第三方客户端，只需旧收集器支持初始化、一次 turn、双向请求挂起/应答与现有审计记录。

## 最小准备边界与剩余资格

1. app-server help **没有** exec 的 `--ignore-user-config`。不能沿用该旗标，也不能声称新入口天然继承旧隔离。新客户端需明确列出有效 MCP/插件与 instructionSources，保持既有管理规则；只用本次进程的显式禁用覆盖排除无关可选 MCP，且在任何模型 turn 前确认实际暴露工具范围。若不能保持已批准的外发范围，就停在准备阶段，把差异列入新授权清单，不能猜测 `mcp_servers={...}` 一定清空继承映射。
2. 新冻结客户端可以先用离线假请求验证请求 ID/选项映射、拒绝/取消和日志，不需要模型。但不能用此证明真实审批已过。原 tap、生产 relay、真实 eye_run、工具 annotations、Blender 控制与算法均无需修改。
3. 一个未来 `occluded` 任务足够检验路线：保持原 `target_gap_m=0.00075`、`tolerance_m=8e-9`、`image_mode=SECTION`，只请求一次 eye_run。资格链必须同时出现模型真实工具意图 → 实际审批请求 → 用户单次决定 → tap 的 tools/call → 原生一次实际位移/readback → 图像 content → 模型基于该图回答。记录审批等待与模型/工具时间，不能把人工等待混作引擎耗时。
4. 若仍未派发、审批协议不同或遇到新管理限制，保存新失败后停止；不补用旧两次额度、不切 auto-review/bypass，也不把写工具改成 readOnlyHint。旧 exec 两次失败仍是事实；本轮只确定了一条官方支持且本机 schema 存在的候选交互路线，没有增加引擎优化任务。

没有推荐 `--approve-for-me`：本机 help 明确它联动 workspace-write，且本轮选择逐请求用户应答，不需要另一模型审核额度。没有建议 `approval_mode=approve`、`--ignore-rules`、绕过 sandbox 或修改管理配置。
