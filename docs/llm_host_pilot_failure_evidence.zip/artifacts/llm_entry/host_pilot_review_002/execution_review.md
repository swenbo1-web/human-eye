# 真实宿主试跑失败的独立复核

**结论：真实 Codex 宿主的 MCP 协商、工具发现，以及模型选择正确 `eye_run` 参数已经发生；两案都在宿主审批阶段被拒绝，未向 Human Eye 派发动作。任务执行、真实结果/图像消费、正常 EOF 和任务收益均不能判 PASS。** 原生功能此前的 5/5 资格与本次宿主试跑失败是不同阶段，不能相互替换。

本次仅离线读取现存源/证据，用 `execution_probe.py` 重新解析和核算；没有新模型、Blender、网络或 IPC 调用，没有改交付、生产源、共享文档或 Git。重放结果在同目录 `execution_probe.json`。

## 原件身份

`execution_001/manifest.json` SHA 为 `8797d35775a781c1a79dabe0a069a82380cfc1623f27b7827f5b8439abacea1a`。其 **39 个引用原件逐项 hash 相符**；run manifest SHA `22445e963fb685d73611b5670a2504d132ec00ec6cb8fdc9ed5f201158ad879b`、源 ZIP SHA `06ceeab2c1230c32d38aebe07efd7a86f9d429ffc6242edb807947b16401fe69` 均符合登记。ZIP 中 **33 项源 hash 相符，当前同路径 33 项也没有差异**。

确有一个自有 Blender 进程 PID 34328、两个独立 Codex thread/context。原始 CLI、wire、native 和进程摘要相互匹配；以下结论未仅依赖交付摘要的文字状态。

## 从宿主到场景的实际链路

两案原始 requests.bin 都只有三帧，顺序完全相同：

1. `initialize`，客户端 `codex-mcp-client` / `0.167.0-alpha.3.2`，提出 `2025-06-18`；服务端同版本回应。
2. `notifications/initialized`。
3. `tools/list`；响应返回 `eye_run` 与 `eye_inspect`。

每案实测 client→server **409 bytes**、server→client **1179 bytes**，请求/响应 JSON 完整、ID 对应。**没有 `tools/call` 帧**，服务端没有执行回包。这里证明真实宿主接受了协商和工具目录，不能据此声称任务工具已获准执行。

每案 CLI 的七条公开事件中有两条 agent_message、一个 MCP call 的 started/completed，以及 thread/turn 事件。模型确实选择了登记任务所需的调用：

| 案例 | 模型提出的调用 | 实际宿主结果 |
|---|---|---|
| nonconvex | close_gap，目标 0.0006 m，容差 8e-9 m | result=null，status=failed |
| occluded | close_gap，目标 0.00075 m，容差 8e-9 m，SECTION | result=null，status=failed |

两次错误都是 **`MCP tool call requires approval, but approval policy is never`**，发生在 dispatch 前。`run_pilot.py` 登记的是 read-only CLI sandbox，未显式给出允许这次变更调用的审批通路；原件足以确定有效策略阻止了调用，不足以继续推断宿主内部哪层策略来源。不能把这一失败归因于 BC、刚体求解、渲染或模型没有选择正确工具，更没有理由重开已验收内核优化。

两份 final.txt 与公开事件里的最后 agent_message 完全一致：

- nonconvex 明确说明因审批未执行，达标、实测终态间距和实际位移均未知。
- occluded 同样明确被拒绝，未取得实测数据和 SECTION 图，因此不描述面板、颜色、位置或遮挡。

模型没有把提示词里的目标数冒充实测，也没有捏造图像细节。occluded 终答所说的“工具回包”应在审计中准确解释为**宿主生成的调用失败对象**，不是来自 Human Eye 服务端的任务回包。此时只能证明“模型遇到拒绝时如实回答”，尚不能证明成功结果或图片被模型正确使用。

## RNA、零写零图与退出码

两案 before/after RNA **逐字节相同**：

| 案例 | before = after SHA-256 | execute / confirmed writes | VG / PNG |
|---|---|---:|---:|
| nonconvex | `7f6932a1112c6667ab8f7aa1e14606c438b15c4799a23113121eb5224631eeb2` | 0 / 0 | 0 / 0 |
| occluded | `91128fad26b9eda67389001183bd596fc740892b5ce2a66a71625168799966e3` | 0 / 0 | 0 / 0 |

`native.json` 的 executions、VG events、images、run_receipts 均为空，run/checks 均为 null。源码 hook 包裹的是真实 control execute 和 VG 方法；结合 wire 无调用和独立 RNA 不变，足以确认这两次任务没有执行或生成图像。这里不把场景搭建之前的操作算成任务写入，也不宣称快照是任意外部脚本全部瞬时写入的全局证明。

Blender 和两个 CLI 的 exit code 都为 0，但两案 native 和最终 summary 明确 FAIL。失败位置是 `pilot_worker._check_case` 要求恰好一个 eye_run receipt，而实际为零。外层 `run_pilot.run` 的返回条件还要求每案 native passed，因此这些 exit 0 **没有被实现误当作任务 PASS**；它们只说明进程正常结束/CLI完成了一个答复回合。

## 关闭状态不能混成正常 EOF

每案服务端都留存：

- 主线程与 dispatch thread 都是 39836，单连接，处理三帧。
- `peer_eof=0`，`receive_error` 为 WinError 10054。
- entry.close 在显式 stop 前完成一次，随后 listener 关闭、timer 注销。
- `wire/tap.json` 不存在，只有 **0-byte `tap.json.tmp`**；relay.stderr 为空。

`_ObservedSocket.recv` 仅在真正收到空 bytes 时增加 peer_eof；OSError 则记录 receive_error。当前材料因此证明的是**连接被重置后触发 close，随后 stop 清理完成**，不是 peer FIN/EOF 成功。tap 最终凭据缺失使 tap/relay 的 exit、stdin EOF、stdout EOF、转发总量终态不能补判；空 tmp 和空 stderr 都不等于成功。原始 wire 前缀仍可支持已完成的协商/发现，不需要把整份原始材料作废。

WinError 10054 与空 tmp 说明关闭证据不足，但现有材料不能精确还原是哪一个宿主/子进程终止步骤造成 reset 或阻止最终凭据落盘。不要把“CLI退出0”“entry已close”用于填补这个未知，也不为本次失败扩展异常矩阵。

## usage 的实测值与归因边界

每个 `events.public.jsonl` 末尾各有一条 **`turn.completed.usage`**。`run_pilot._public_events` 直接保留原事件，并把 usage 字典原样追加到 receipt；本次核对 CLI result、client_done、native 嵌入值和交付摘要均相同。它不是根据字符串或 wire 大小估算出来的 token。

| 案例 | input_tokens | cached_input_tokens | output_tokens | cache_write_input_tokens | reasoning_output_tokens |
|---|---:|---:|---:|---:|---:|
| nonconvex | 39,371 | 12,544 | 184 | 0 | 0 |
| occluded | 39,628 | 25,856 | 270 | 0 | 0 |
| 原字段分别求和 | 78,999 | 38,400 | 454 | 0 | 0 |

能作的表述是“这两个真实宿主回合报告了以上 usage”。这些值的解释必须保留以下范围：

- 输入是**回合完成事件**所报字段，不是 Human Eye 单条工具 schema、单个 prompt、单次底层模型请求或某条消息的独立计数。公开记录没有逐请求输入清单或 token 来源分项，也不能从两条 agent_message 推导底层模型请求数和各自累计规则。
- cached_input_tokens 只保留为宿主报告的缓存输入字段，不能再与 input_tokens 相加制造第二份输入成本；也不能用相减后的数值声称“HE 新增 token”或计费金额。缓存命中了哪些文本、如何计费，现有记录没有提供。
- output_tokens 不是 final.txt 单独的 token 测量；没有分解预告文字、工具参数和终答的贡献。reasoning_output_tokens=0 是报告值，不是内部绝无推理的证明，也不能据此验证请求的 ultra 实际生效情况。
- 两案确实没有向模型交付 HE 图片或任务结果；这排除了“本次发送的 HE PNG/完整 AO 造成输入量”的说法。但服务端公开的 1179 bytes、短任务提示和宿主实际模型上下文是不同计量层，**不能将 wire bytes 换算成模型 token**，也不能断言约 4 万全部来自 HE、全部来自宿主，或据此算出二者比例。
- `model_requested=gpt-6.1-sol`、reasoning_requested=ultra 是启动请求配置；公开 usage 未给出独立服务端模型快照或逐请求计费凭据。本次不扩查账户、价格或外部 provider。

两案输入值相差 257、缓存值相差 13,312、输出相差 86，仅是两个失败回合的观测差值；不能归因为 SECTION 的图像 token（实际无图），不能当作缓存优化收益，也没有 N 臂可形成双臂结论。

事件记录中的 turn completed 分别约 **14.764 / 16.551 s**，CLI exit 分别约 **18.845 / 20.327 s**。它们是这次失败回合的诊断时间，包含宿主流程；不是成功任务耗时、引擎时延或正式收益样本。CLI stderr 的模型目录刷新超时是另一条实际日志，不能凭它定量解释耗时或 token 来源。

## 阶段判定

| 阶段 | 本次结论 |
|---|---|
| 实际宿主 MCP initialize / tools/list | 通过，两案有真实 wire |
| 模型按公开任务提出预期调用 | 已观察，两案参数正确且未重试 |
| 宿主批准并派发 eye_run | 未通过，审批策略在 dispatch 前阻止 |
| 引擎执行与真实结果交付 | 本次未发生，不推翻此前独立原生资格 |
| 模型使用真实结果或图片 | 未验证；此次仅验证如实报告失败 |
| 正常 peer EOF / tap 最终凭据 | 未通过；reset 清理完成另行记录 |
| 任务成功率、端到端节省、文字/图片 token 收益 | 未取得资格，不作收益裁决 |

下一步应先在正常授权与审批机制下明确可实际派发这次变更工具的宿主通路，并保留本次失败原件；不改写 `eye_run` 的写入语义来冒充只读，不靠本轮消耗数字启动内核优化。是否登记下一次有界复验由根侧决定，本审查没有启动、追加或授权任何新试跑。
