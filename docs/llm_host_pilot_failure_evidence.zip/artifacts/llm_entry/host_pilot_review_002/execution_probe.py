"""Read-only replay of archived host pilot evidence; no subprocess or network."""
from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import json

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "artifacts/llm_entry/host_pilot_001"
OUT = Path(__file__).with_suffix(".json")


def read(path):
    return json.loads(path.read_bytes())


def digest(raw):
    return sha256(raw).hexdigest()


def frames(raw):
    assert raw.endswith(b"\n")
    return [json.loads(line) for line in raw.splitlines()]


def main():
    record_path = BASE / "execution_001/manifest.json"
    assert digest(record_path.read_bytes()) == "8797d35775a781c1a79dabe0a069a82380cfc1623f27b7827f5b8439abacea1a"
    record = read(record_path)
    assert len(record["evidence_sha256"]) == 39
    for path, expected in record["evidence_sha256"].items():
        assert digest((ROOT / path).read_bytes()) == expected, path
    run = BASE / "run_001"
    plan = read(run / "manifest.json")
    assert digest((run / "manifest.json").read_bytes()) == record["plan_sha256"]
    assert digest((run / "sources.zip").read_bytes()) == record["source_archive_sha256"]
    assert len(plan["sources"]) == 33
    current_mismatch = []
    with ZipFile(run / "sources.zip") as z:
        for path, expected in plan["sources"].items():
            assert digest(z.read(path)) == expected
            if digest((ROOT / path).read_bytes()) != expected:
                current_mismatch.append(path)
    process, summary = read(run / "process-summary.json"), read(run / "summary.json")
    assert process["blender_exit_code"] == 0 and process["sources_stable"]
    assert process["runner_error"] is None and summary["status"] == "failed"
    assert process["blender_pid"] == summary["pid"] == 34328
    rows = []
    for name, expected_usage in (("nonconvex", (39371, 12544, 184)), ("occluded", (39628, 25856, 270))):
        folder = run / name
        requests_raw, responses_raw = (folder / "wire/requests.bin").read_bytes(), (folder / "wire/responses.bin").read_bytes()
        requests, responses = frames(requests_raw), frames(responses_raw)
        assert [r["method"] for r in requests] == ["initialize", "notifications/initialized", "tools/list"]
        assert [r["id"] for r in responses] == [r["id"] for r in requests if "id" in r] == [0, 1]
        assert requests[0]["params"]["protocolVersion"] == responses[0]["result"]["protocolVersion"] == "2025-06-18"
        assert [t["name"] for t in responses[1]["result"]["tools"]] == ["eye_run", "eye_inspect"]
        assert len(requests_raw) == 409 and len(responses_raw) == 1179
        events = frames((folder / "events.public.jsonl").read_bytes())
        timing = frames((folder / "event-timing.jsonl").read_bytes())
        assert len(events) == len(timing) == 7
        assert [e["type"] for e in events] == [t["kind"] for t in timing]
        assert all(a["elapsed_s"] <= b["elapsed_s"] for a, b in zip(timing, timing[1:]))
        starts = [e["item"] for e in events if e["type"] == "item.started"]
        attempts = [e["item"] for e in events if e["type"] == "item.completed" and e["item"]["type"] == "mcp_tool_call"]
        assert len(starts) == len(attempts) == 1
        attempt = attempts[0]
        assert attempt["server"] == "human_eye_v1" and attempt["tool"] == "eye_run"
        assert attempt["status"] == "failed" and attempt["result"] is None
        assert attempt["error"]["message"] == "MCP tool call requires approval, but approval policy is never"
        assert starts[0]["arguments"] == attempt["arguments"]
        assert attempt["arguments"] == {"task": "close_gap", "target_gap_m": .0006 if name == "nonconvex" else .00075,
                                        "tolerance_m": 8e-9, **({} if name == "nonconvex" else {"image_mode": "SECTION"})}
        messages = [e["item"]["text"] for e in events if e["type"] == "item.completed" and e["item"]["type"] == "agent_message"]
        assert len(messages) == 2
        final = (folder / "final.txt").read_text(encoding="utf-8").rstrip("\r\n")
        assert final == messages[-1]
        usage = [e["usage"] for e in events if "usage" in e]
        assert len(usage) == 1 and events[-1]["type"] == "turn.completed"
        used = usage[0]
        assert (used["input_tokens"], used["cached_input_tokens"], used["output_tokens"]) == expected_usage
        assert used["cache_write_input_tokens"] == used["reasoning_output_tokens"] == 0
        cli, done, native = read(folder / "cli-result.json"), read(folder / "client_done.json"), read(folder / "native.json")
        assert cli == done == native["client_done"] == process["cases"][name]["cli"]
        assert cli["observed_usage"] == usage == record["cases"][name]["usage"]
        assert cli["exit_code"] == 0 and cli["collector_stopped"] and not cli["timed_out"]
        assert cli["turn_completed_s"] == timing[-1]["elapsed_s"]
        assert cli["invalid_event_lines"] == cli["omitted_reasoning_events"] == 0
        assert native == next(c for c in summary["cases"] if c["case"] == name)
        assert native["status"] == "failed" and native["confirmed_writes"] == 0
        assert native["executions"] == native["vg_events"] == native["images"] == native["run_receipts"] == []
        assert native["run"] is None and native["checks"] is None
        before, after = (folder / "before-rna.json").read_bytes(), (folder / "after-rna.json").read_bytes()
        assert before == after and read(folder / "before-rna.json") == read(folder / "after-rna.json")
        transport = native["transport"]
        assert transport["frames"] == 3 and transport["connections"] == 1 and transport["peer_eof"] == 0
        assert "10054" in transport["receive_error"]
        assert transport["main_thread_id"] == transport["dispatch_thread_id"] == 39836
        assert transport["closes"] == [{"thread_id": 39836, "during_stop": False, "completed": True}]
        assert transport["stop_requested"] and transport["listener_closed"] and transport["timer_unregistered"]
        assert not (folder / "wire/tap.json").exists()
        assert (folder / "wire/tap.json.tmp").read_bytes() == b""
        assert not list(folder.rglob("*.png"))
        rows.append({"case": name, "thread_id": events[0]["thread_id"], "protocol": "2025-06-18",
                     "request_methods": [r["method"] for r in requests], "request_bytes": len(requests_raw),
                     "response_bytes": len(responses_raw), "wire_tool_calls": 0, "host_attempt": attempt,
                     "final_text": final, "rna_before_after_sha256": digest(before), "writes": 0, "pngs": 0,
                     "cleanup": {"peer_eof": 0, "receive_error": transport["receive_error"], "entry_closed": True,
                                 "listener_closed": True, "timer_unregistered": True, "tap_receipt": "missing; empty tmp"},
                     "usage_from_turn_completed": used, "usage_attribution": "no per-message/tool/HE/visible-text/image breakdown",
                     "cli_exit_code": 0, "native_status": "failed", "turn_completed_s": cli["turn_completed_s"],
                     "cli_exit_s": cli["elapsed_until_cli_exit_s"], "public_prompt_utf8_bytes": (run / f"{name}-public-prompt.txt").stat().st_size})
    total = {k: sum(r["usage_from_turn_completed"][k] for r in rows) for k in rows[0]["usage_from_turn_completed"]}
    result = {"scope": "offline evidence recomputation only; no model/Blender/network/IPC/subprocess",
              "manifest_sha256": digest(record_path.read_bytes()), "evidence_hashes_verified": 39,
              "archived_source_hashes_verified": 33, "current_source_mismatches": current_mismatch,
              "cases": rows, "raw_usage_field_sums": total,
              "usage_warning": "cached and input are separate reported fields, not additive cost categories; no HE attribution or billing derivation",
              "stage_verdict": {"host_handshake_discovery": "PASS", "model_selected_intended_request": "OBSERVED",
                                "tool_dispatch_execution": "BLOCKED_BEFORE_DISPATCH", "model_result_image_consumption": "UNTESTED",
                                "clean_peer_eof": "NOT_PASSED", "reset_cleanup": "OBSERVED", "task_benefit": "NOT_QUALIFIED"},
              "checks_passed": True}
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(OUT), "evidence": 39, "source_mismatches": current_mismatch, "cases": 2, "usage_sums": total}))


if __name__ == "__main__":
    main()
