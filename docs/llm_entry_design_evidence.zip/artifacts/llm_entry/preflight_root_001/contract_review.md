# 已验收引擎的大模型接入口：最小常驻契约建议

结论：**默认一条明确动作请求完成一次真实闭环，不增加模型审批往返。** 入口在 Blender 进程内常驻一个 `BlenderRadicalSession`，把模型已经给出的命令依次交给现有 predict/execute，再消费真实 A 票据；对新 after 图的 V 判断留给模型看过图后的下一请求。保留现有 AO 原 bytes，普通动作只交付本次新 PNG。CF、网格、参考、特征和计划对象均留在宿主，不成为大模型每轮输入。

这是独立设计提议，供主端收敛后冻结；不是已实现或已测收益。只读取现行 `blender_radical_session.py`、AO schema/公开消费者、冻结 API 和整机验收，不改生产/docs/git，不运行 Blender、LLM/API 或新性能试验。已验收六模块不重开优化。第一阶段可由主端派实施方创建隔离接入文件和有限功能预检；下文工具细分与收益数字是候选，不代替主端的正式协议。

## 1. 外部 LLM 与 CF 是两种不同消费者

外部多模态 LLM 看实际 PNG 和公开结构化事实，选择明确 Translate/SetShapeKey 命令，并可判断实际图像的 pixel_pass。CF 是宿主内的 V 视角排序/经验库与 A 动作预测/经验库；它不理解聊天，不替代外部 LLM，也不证明大模型看过图。

“脚本解析 AO 成功”“工具给出 PNG 路径”“用户界面显示图”“把图登记为附件”均不足以声称模型使用图像。真正模型接入必须把 PNG 作为选定宿主/提供方支持的多模态输入送入实际模型调用，并保留这次输入与模型原始答复的验证侧证据。不可把 PNG base64 塞进普通文本并称作视觉输入。

## 2. 默认动作的精确顺序

模型已收到观察 O 和其图像，发出 `act(from=O, command=C, view_feedback=...)`。这条请求自身就是执行明确 C 的意图。

```text
真实的已有 O 图反馈（若提供且有 V 票据）
→ predict_action(O, new_action_id, C, predictor)
→ 本地 PreparedAction：保留真实 before、明确 C、预测、必要特征
→ execute(该原计划, new_after_id, 显式 after changes)
→ action_feedback(实际有限 Outcome 产生的 A 票据；若存在)
→ 返回原联合 AO、after 图、image_status 与当前 observation_id
```

`PreparedAction` 是本地语义绑定，不等于需要新增模型确认。默认路径不得省去它、把预测当实测、跳过宿主回读，亦不得因为“安全”再添一轮审批。预测值和实际使用的 action_id/before/after/command/control/distance 已在原联合 AO Outcome 中，不另生成一份可能漂移的结果摘要。

下一条动作可以直接基于这个真实 after 当前观察：先消费模型这时给出的 after 图 V，再对下一明确命令作新的预测和执行。CF A 已读到上次真实反馈，下一次 VG 也读到已到达的 V 更新。若场景没有外部变化，**不为模拟每个底层函数而自动额外 observe(next)**。

当模型明确要求刷新/换视角，或宿主声明帧、上下文等真实变化时，显式 observe 才产生真正的新观察。该 next 不是旧 after 改个名字；也不能在它尚未交给模型时生成其 pixel_pass。模型若想先比较预测再决定，才调用 predict-only；之后明确执行原计划或改发另一个明确命令。

## 3. 最小工具面与参数

建议只注册 `eye.open`、`eye.step`、`eye.close` 三个工具。`step` 使用短的判别联合；不同操作的必需参数不混在一个任意 kwargs 字典。下面是语义契约，命名由主端最终冻结。

| 工具/操作 | 模型提交的最少参数 | 宿主调用与返回 |
|---|---|---|
| `open` | 已明确的任务配置，或宿主启动时已绑定该配置时无参数 | 创建会话并首次 observe；返回 schema/version 一次、静态目标/动作支持信息、原 AO、新 PNG 和当前观察 ID。不能按 GUI 当前选择猜对象。 |
| `step: act` | `from` 当前观察 ID；`command`；可选已有图 `view_feedback` | 按上节 V→predict→execute→A；仅一次请求/响应。明确命令只允许 world-meter Translate 或指定 key/value。 |
| `step: observe` | 可选已有图反馈；显式刷新请求/模式；宿主提供本次真实 changes | 消费已有反馈后实际 observe，返回新的 AO/PNG/当前 ID；没有动作、没有新图评分。 |
| `step: predict` | `from`、明确 command | 只调用 predict_action，返回当前 plan ID、绑定观察、命令和预测值或 NoAction；不写宿主。此路径仅由模型主动选择。 |
| `step: execute` | 当前 plan ID | 执行该原 PreparedAction，返回实际联合 AO/新 PNG。作为显式底层编排操作，A 票据留给显式 feedback；不暗中复制默认 act 的自动反馈。 |
| `step: feedback` | 指明已呈现 observation 的 `pixel_pass`；可选 `action=true` | 依给定观察顺序消费相应 V，再消费本地真实 A；不给任意 delta/feature/ray 参数。用于明确评分、无后续动作或原五段同责调用。 |
| `step: read` | 无，或明确请求 schema/bootstrap | 只返回最后一个已发布公开包及其**完整**附件，供新上下文独立恢复；不触发 capture/render/学习，也不假称其仍可执行。成本单列。 |
| `close` | 可选最后一份真实反馈 | 先处理明确反馈，再调用 session.close 并清除 facade 持有对象；不默认补评分、不训练尚未提供的 V。 |

默认 `act` 无外部 plan ID，也无需 LLM 重复 image key、canonical index、ray 数和拓扑 mask。模型反馈可简化为 `{observation_id, pixel_pass}`；宿主从该公开观察的原 V ticket 填入真实附件键和候选 ID。`pixel_pass` 缺省代表没有消费判断，绝不解释为 false 或 true。

`predictor`、view arm、image mode 可由明确的会话配置固定；调用确实需要变化时才显式覆盖。无部署时只能明确 F 与 NONE/G，不自动降级。NONE 是调用者选择的真实执行域，不是失败后的 fallback。

普通 serial transport 绑定一个 facade 实例，不需要全局 session 表。若宿主工具服务确实共用多会话路由，只用它既有的 session handle；不能另外加来源账本、TTL、哈希许可、重放表或后台监控状态机。

## 4. 输出采用原 AO，图像按交付边界复用

第一版优先把 `ObservationResult/ActionResult.ao_bytes` 原文作为工具的文本内容发送，只进行传输所需的 UTF-8 表达；不先全量 parse 成 dict 再重新 encode，不包成 base64，不同时再发一份完整命名事实副本。AO 的世界米、原面、TD/Top-K、参考/采样/位置帧、SECTION、实际命令及 Outcome 语义原样保留。

工具的轻量头只补原 wrapper 中 AO 没有的信息：当前 observation_id、image_status、是否有可反馈 V、是否可执行/存在 plan，以及本次附件交付绑定。正常 `act` 的图像内容只取 `<after_id>.png`；原 before PNG 已由前一次公开观察交付，不重渲染、不从 `ActionResult.attachments` 再发送第二次。

**不能把“曾经在这个工具连接发过”写成“任何模型上下文都看过”。** 联合 AO 仍引用 before 图，故每次增量动作响应应明确给出：

```text
new_image:       after observation / after attachment key
before_ref:     before observation / before attachment key
before_delivery: supplied by the preceding successful public result
```

这只是公开引用，不是视觉消费证明。宿主须满足以下两个明确消费方式之一：

- 连续上下文模式：模型输入中保留前一已交付图的可用上下文/原生附件引用，工具不再传其 PNG bytes。
- 独立恢复模式：新消费者显式 `read` 最后完整公开包及所有引用 PNG，再继续操作。该接口复用宿主持有的 bytes，不重采集。schema 在新消费者首次需要时再交付；恢复调用、传输、模型图像输入及缓存都计费。

`read` 是显式读取能力，不是错误后偷偷回放或 compatibility fallback。首版只保留最后一个公开包，不能承诺任意历史观察都可恢复。若调用方既没有 before 图上下文又没有执行恢复，不能把联合包宣传为独立完整视觉输入。

工具到宿主少传一次 PNG，不自动等于提供方 prefill 也少一次：无状态模型 API 可能重传聊天图像，状态化接口可能保留引用，图像/文本缓存也可能仍有费用。验证必须分别记录 engine→宿主和宿主→LLM 的真实请求字节、图像输入与 token；不能由 Python bytes 共享推算远端费用或上下文能力。

## 5. 常驻状态和内存所有权

| 所有者 | 常驻内容 | 释放/变化 |
|---|---|---|
| 引擎 session | 唯一 controller/bridge/目标 indexes、当前事实、TD 参考、一个 renderer、显式 CF 会话及预备基 | 沿原 API 更新、替换参考及 close；不在 facade 再建一套网格/索引/模型。 |
| facade | 引擎引用；短 ID 计数；最后成功公开结果的 AO/PNG 引用；固定的可反馈票据槽；最多一个显式 predict-only 计划 | 普通 act 的计划在同一次调用消费即释放；新公开结果替换旧包，不追加完整历史。 |
| 验证/独立消费者 | 需要保存的公开 bytes、schema、模型实际请求/答复记录 | 属于明确调用者持有，不能算作生产零成本。 |

最后公开 `ActionResult` 本身拥有一个联合 AO 和两个不可变 PNG 引用，可直接支持 `read`；不再复制像素或解码为常驻 ndarray。引擎 current 与它共享 after PNG bytes。生产内部不保存完整聊天，也不把外部模型上下文拷贝进 session。

为显式原五段路径，可选保留“最近 before”和“当前”两个固定 V 槽，A 最多保留最近一次未反馈的实际票据；不是任意 observation ID 的未决表。默认 act 在写入前消费已有 V、写入后消费 A，所以通常只留当前图 V。**一槽或两槽由实施预检确定，不作为本报告强制新增状态**：若选择一槽，原五段由显式调用方持有原票据，不得让它悄悄丢掉 before V；若选两槽，则在接口中明确其固定窗口。更早未评分的票据退出这个窄接口支持域，不伪造反馈；无限迟到仍可由底层 Python API 原调用者持有，本 facade 不承诺它。

执行中的旧/新公开结果及传输 buffer 可短暂重叠，必须计入峰值；“最终只留一个包”不等于峰值只有一张图。close 清除 facade 的计划/票据/公开缓存、引擎资源；消费者自己已持有的不可变 bytes 仍可消费。close 不要求驱动或 Python allocator 瞬间归零。

## 6. 初始化的最低真实输入与主线程约束

宿主冷配置至少包含：

1. 明确 scene 与所属 view layer；有序稳定 ID→Blender Object 映射；Goal 指定 moving/reference 两个不同目标，额外对象为有序 VG context。
2. 各对象初始 topology_generation；Goal 的世界米 target_distance/tolerance；明确 image mode、view arm、动作 predictor。
3. 一个匹配 moving generation 的 `ReferenceFrame(frame_id, world_m_snapshot)`。完整参考数组只在宿主进程内传一次，不经过 LLM。若要求当前姿态作参考，冷初始化明确采集当前 evaluated 世界米坐标；不能把 authored location/Basis 当参考。构造 API 先要参考，这个冷采集成本不得藏进热基准。
4. 若用 R/L，显式 CFDeployment 或其 v1 NPZ；它不是外部 LLM 模型。G/L shape 支持的 key 在冷阶段从真实 relative_key 预备局部基；不每轮重发或扫描 authored 顶点。

LLM 不负责产生网格数组、units matrix、变更掩码或凭空发明 generation。场景拥有者在本机提供每次 capture changes：自身明确动作后的两目标几何刷新、静态 context NONE、真实 context TRANSFORM/UNITS/TOPOLOGY 等。入口不添加全场景自动 dirty 扫描或来源验证。

所有 bpy/RNA/capture/predict/execute/render/close 及其状态转换串行提交到**原 Blender 主线程及 GPU 上下文**。网络线程只传递小请求和公开返回值，不解引用 RNA，不并行运行两个 step；使用宿主已有主线程调度接缝，不新建恢复队列、工作线程池或全局引擎管理层。

目标 topology/appearance、目标 pair 或不兼容目标支持域变化：close 后以新会话代和匹配参考重新 open。context topology：显式 TOPOLOGY+新 generation，仍沿原 API；同代参考替换：宿主明确 replace_reference 后当前/计划失效，下一次真实 observe 再发布。shape relative_key/authored 定义变化：显式重新 prepare 或重开。不得仅改名字/代号把旧引用当新几何。

## 7. 支持域与失败保持

Translate 仍是世界米明确向量。G/L 只在已验收有限几何假设下使用；relative shape key 的 active/unmasked/row correspondence/slider-range 等支持域不扩大。没有部署时不猜模型；SECTION 非正间隙不偷换 NATURAL。disabled、empty_surface、section_requires_positive_gap 和 rendered 保留；空面/已达目标 NoAction 不发生写入、A 或伪造新图。零距不是接触/相交分类器。

stage error 原样表达 prepare/not_written、write/unknown、target_readback/written 或后续阶段/written。已有实际 Outcome 必须保留；默认 act 若错误附实际 A 票据，仍只能基于它更新，不从请求值猜 delta。错误后当前执行资格撤销；最后公开 bytes 只可读取，不能当作新的宿主状态继续动作。恢复由调用者明确 observe，不重试、不回滚、不补图。

以上是既有动作和所有权语义，不应扩成新防御链。

## 8. 必须分开的两条同责验收路径

**新逐动作交互路径。** B 为使用同一已验收引擎的直接公开 API 编排，I 为新入口；双方均按 `已有图真实 V → predict → execute →真实 A`。用同一真实消费者与相同初始部署/命令产生和评分新图。因为 V 提前到 after render 之前，after VG 可以与旧正式五段的图不同；这是新交互时序，不能拿旧 PNG 全同当其前提，也不能说仅包装、完全无行为变化。

**原完整五段路径。** 用显式 observe/predict/execute/feedback/observe/predict 保持原顺序：先真实 before/after，消费者看过图后按原 before V、after V、A 次序反馈，再做真实 next 与下一明确预测。无需改变默认 act 策略来等旧图。该路径的 before、action、feedback、next、连续 total 责任不能省略；低层调用仍执行相同算法、真实更新和公开消费。

两条路径分别报告，不能把默认路径省掉额外 next 的总时长与原完整五段直接算提速；不能用脚本标签替代实际 LLM看图，又宣称测到外部模型总耗时。若显式路径没有模型判断参与，只能称公开消费者/服务成本证据。

## 9. 可复核基准与建议收益门

以下门是本预检建议，主端须在实施前固定实际旧入口基线、命令/场景清单、模型版本和费用批次；本报告没有测得这些收益。

### A. 交付语义与交换结构硬门

- 已有 24 主例/3 CF 部署用于同责公共输出核对，原无图、零距、SECTION、NoAction、真实失败 Outcome、close/重开边界保留；不重训 CF 或重开六模块收益验收。
- 每个正常默认 act **1 请求+1 响应**；本地 predict/execute 各一次、实际 A 0或1次、自动额外 observe 为0。只有明确 predict/observe/read 请求另计。
- 正常渲染动作只交付1个新 after PNG；before 的 PNG 重发为0，图像尺寸/双面板/无损质量不变。schema 在连续消费者上下文只 bootstrap 一次，网格/完整历史/CF特征与权重每轮传输为0。
- 原 AO bytes 与原新图 bytes 从真实结果直接转交；公开消费不可缺字段或靠私有数组补事实。独立消费者可用 schema+本次新图+明确 prior binding 解码；`read` 路径必须能以完整包独立消费。初始图、schema、恢复再取及完整附件缓存均计数。
- 不假设旧入口每个底层函数都各走一次远程请求。若实际旧入口已经一次RPC执行整个脚本，必须如实记1，不能人为拆成多次来做更差基线。

### B. 成本门：分别计交换、宿主服务和实际 LLM

每个调用记录 request/response 数、方向、UTF-8与二进制/最终base64后的真实wire bytes、PNG数量/bytes、schema bytes、已引用/重新取得图像数、公开结果持有/释放；记录冷初始化、主线程排队、引擎服务、序列化、传输、模型等待/生成、完整用户闭环。计数在验证层，生产不常驻监控账本。

建议首要收益门：在固定正常渲染动作主集，对实际旧入口累计 wire bytes **减少至少30%**，默认动作往返数不增；若基线确有逐方法远程请求，另要求请求数至少减半。新接口只有零图像/已达目标等边界时分别报告，不删它们后声称全体收益；它们仍须正确且不新增无用调用。若真实基线已经只发 after 图、只 bootstrap 一次且单RPC，不能虚构30%可得收益，应在实施前承认主要价值仅是受控接口和代码简化。

同责宿主服务集合 p95 建议 **I/B≤1.05**；完整五段另按原工作边界报告，冷 open/close 和恢复路径单列。不能把模型不参与的本地序列化时间称为大模型提效。托管资源建议沿既有增量预算 current≤256KiB、完整窗口peak≤1MiB，同时硬性禁止 facade 第二套网格/索引/模型和随回合数增长的历史缓存；B/I持有同等公开结果和schema，所有传输/暂存副本如实计入。

实际 LLM 调用另冻结同一多模态模型、图像细节设置、system/tool定义、温度、任务和配对顺序；提供方若报告 cached/uncached/image token，分别保存，不能把缓存命中推算成零成本。相同任务成功率与视觉负例不退化，实际端到端p95不退化超过5%作为建议预算；费用和token收益只能由实际请求/usage记录得出，不能由删掉一个本地PNG引用估算。费用规模及固定重复数由主端事前确定，不在本预检调用模型。

### C. 真正公开消费者与模型视觉证据

公开消费者只读 AO/schema/实际交付PNG和显式prior binding；核对世界米、目标顺序、原面/代号、TD指标/Top-K、参考帧、命令/实际control/测距/预测分离。独立恢复消费者不借用生产私有对象，应能从 read 的完整包完成同一核对。

实际模型资格另要求：在真实模型输入中存在正确图像内容，并输出能随图像变化而变化的可判定视觉回答/反馈。使用原严格视觉负例和固定的可区分公开图像题，与无图/错图对照区分纯文本捷径；观察模型原答，不由脚本代写 pixel_pass。结构化数值答案正确只证明AO消费，不证明视觉。消费者判断错误如实暴露给验收，不在生产添 oracle 过滤器来把错误反馈“修正”成成功。

任务层质量用同责新时序的独立评价，精确事实/字节一致项不放宽；模型自主选择命令导致路径不同的试验另报任务完成、真实目标值、动作数与反馈质量，不拿它冒充逐步骤B/I数值等价。所有未评分的新 after/next图保持无V反馈，不把CF native_stop自贴成模型pixel_pass。

## 10. 只有测出文本瓶颈时才考虑的编码接缝

原联合 AO 重复了 before 的结构化事实，保留它可避免第一版全量 parse/reencode 和新 schema。若实际 LLM token 成本证明这是主瓶颈，最小后续接缝应在编码器仍持有公开 fact 时一次生成明确新版本的增量包：`before_ref + after_observation + actual_outcome`，而不是序列化后切字符串或按私有内存拼字段。

该增量包必须明确 before 引用的恢复规则及成本，并另做公共消费者等价；**不能删除 before observation 后仍假称完整 `he-ao/1`**。本阶段不实现这个接缝、不改 AO或引擎，不因为换入口就重开已验收模块。

## 11. 实施预检要确定、目前不能宣称完成的事项

- 具体宿主传输/工具协议版本，以及它如何把图像送给实际模型。先验证真实支持的多模态消息形态；不要为了支持尚未选定的多家宿主建立通用兼容层。
- pending V 仅当前一槽还是固定 before/current 两槽；原五段由 facade 显式操作覆盖还是由公开 Python 调用者持票据覆盖。选定后写清迟到窗口，不扩大成表或TTL。
- 任务配置与 capture changes 的宿主入口、当前参考的冷采集方式、上下文更新如何在下一 step 前显式提交。LLM不接管这些真实宿主状态。
- 实际旧入口及其请求/图片/字段基线。正式收益门、固定重复数与模型费用批次尚待主端冻结，本报告建议值不是已批准的测试运行规模。
- 真正 LLM 看图、输出真实 pixel_pass、自主动作和全链费用/时延均**未验收**；公开脚本与有限功能预检不能关闭这部分。

最终建议先冻结单往返默认 act、原bytes/单新图交付、最后完整包恢复及两条独立同责时序。这样收益来自交换和调用安排，真实计划、实测、视觉与学习责任均保留。
