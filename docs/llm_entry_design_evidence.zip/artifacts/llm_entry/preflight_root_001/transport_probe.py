"""Read-only source inventory for the LLM entry transport review (no engine imports)."""
from pathlib import Path
import ast
import hashlib
import json
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().with_name("transport_probe.json")
FILES = [
    "human_eye_plugin/production_server.py", "human_eye_plugin/mcp_transport.py",
    "human_eye_plugin/blender_mcp_host.py", "human_eye_plugin/router_server.py",
    "human_eye_plugin/live_spatial_mcp.py", "human_eye_hook.py",
    "human_eye_plugin/live_service.py", "human_eye_plugin/host_runtime.py",
    "human_eye_plugin/blender_host.py", "human_eye_plugin/router_process.py",
    "human_eye_plugin/blender_process.py", "human_eye_plugin/blender_worker.py",
    "human_eye_plugin/live_hooks.py", "human_eye_plugin/agent_hooks.py",
    "human_eye_plugin/agent_setup.py", "human_eye_plugin/auto_router.py",
    "human_eye_plugin/episode_gateway.py", "human_eye_plugin/native_observation.py",
    "human_eye_plugin/mcp_server.py", "human_eye_plugin/__init__.py",
    "human_eye_plugin/plugin_facade.py", "human_eye_plugin/mcp_config.json",
    "examples/agents/live_entry.py", "pyproject.toml",
    "module_3_1_mcp_protocol_ipc_engine.py",
    "human_eye_fast/blender_radical_session.py", "human_eye_fast/control.py",
    "human_eye_fast/raycast_saccade_gpu.py", "human_eye_fast/fast_affordance_out.py",
    "human_eye_fast/__init__.py",
]
ADDON = Path("C:/Users/v_wbobosun/AppData/Roaming/Blender Foundation/Blender/5.2/scripts/addons/blender_mcp.py")

def inventory(path, relative=None):
    blob = path.read_bytes()
    source = blob.decode("utf-8-sig")
    result = {"path": str(path), "repo_path": relative, "bytes": len(blob),
              "lines": len(source.splitlines()), "sha256": hashlib.sha256(blob).hexdigest()}
    if path.suffix == ".py":
        tree = ast.parse(source, filename=str(path))
        result["definitions"] = [{"name": node.name, "line": node.lineno, "end": node.end_lineno}
                                 for node in ast.walk(tree)
                                 if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef))]
        if path == ADDON:
            for node in tree.body:
                if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "bl_info" for t in node.targets):
                    try:
                        info = ast.literal_eval(node.value)
                        result["bl_info"] = {k: info[k] for k in ("name", "version", "blender") if k in info}
                    except (ValueError, TypeError):
                        pass
    return result

rows = [inventory(ROOT / f, f) for f in FILES]
rows.append(inventory(ADDON))
result = {
    "kind": "static_source_review_not_runtime_measurement",
    "recorded_utc": datetime.now(timezone.utc).isoformat(),
    "repository": str(ROOT), "source_count": len(rows), "sources": rows,
    "normal_path_counts_derived_by_reading": {
        "old_text_or_projection_observe": {"blender_rpc": 1, "native_full_capture": 1},
        "old_native_image_observe_warm": {"blender_rpc": 2, "native_full_capture": "3 + 2*N, N is one or two native PNGs", "png_tempfiles": "N"},
        "old_native_image_observe_cold": {"blender_rpc": 3, "native_full_capture": "3 + 2*N", "png_tempfiles": "N"},
        "old_successful_non_noop_transform_no_hooks": {"blender_rpc": 4, "native_full_capture": 5, "full_capture_payloads_crossing_tcp": 4},
        "installed_addon_timer_return_seconds": 0.05,
        "old_native_png_base64_encode_stages": ["episode_gateway.native_look", "native_observation.validate_readonly_observation", "live_spatial_mcp._tool_result"],
    },
    "limits": ["No Blender/API/process startup or live socket requests", "No timing, throughput, idle CPU, runtime addon identity or loaded source assertion", "Only file identity/AST inventory is mechanically recomputed; call counts are static review conclusions"],
}
OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"output": str(OUT), "source_count": len(rows), "addon_sha256": rows[-1]["sha256"]}, ensure_ascii=False))
