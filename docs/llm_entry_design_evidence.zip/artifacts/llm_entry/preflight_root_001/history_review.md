新版大模型入口的历史证据审查：应替换旧传输底座，而不是继续压缩旧回执。

本次只读审查发现，最值得删除的是重复启动、每次请求的全源读取与模块见证、以 Python 代码承载 JSON 的中转、嵌套 JSON 字符串、重复报表及图像编解码。不能据此给新版预填提速百分比：旧数据涉及不同引擎、不同任务和不同计时窗口，多个近期报告的私有原始批次并不在当前仓库。坐标语义、任务覆盖范围、实际动作后的反馈属于有效事实，须在简化后保留；旧配额、来源防护、激活迁移、审批与多层守门流程不作为新版运行约束继承。

审查边界：登记任务 9d00ae4e-3ed1-4247-ba40-3f204cad1f5d；CPU 离线读取，不运行旧测量脚本、Blender、GUI、GPU或模型，不修改生产代码、docs、Git及旧证据。附属 [history_evidence_probe.py](<D:/human eye/human-eye/artifacts/llm_entry/preflight_root_001/history_evidence_probe.py>) 只用标准库读取文件、重算已有汇总、记录 SHA，并生成 [history_evidence_probe.json](<D:/human eye/human-eye/artifacts/llm_entry/preflight_root_001/history_evidence_probe.json>)；执行 exit 0。新报告本身不是一次性能试验。

**证据等级与可定位结论。** A 为本次直接检查的既有数据或源码结构；B 为作者报告中的量测，未找到对应完整原件；C 为推断或方案。A 中“当前公开源码”只能证明本次所读文件的结构，不能替代历史执行源身份。

| 证据与定位 | 本次可确认的事实 | 对新版入口的含义与限制 |
| --- | --- | --- |
| B：[SOURCE_GUARD_COST_ACCEPTANCE:21](<D:/human eye/human-eye/docs/SOURCE_GUARD_COST_ACCEPTANCE.md:21>)；A：[runtime_identity:50](<D:/human eye/human-eye/human_eye_plugin/runtime_identity.py:50>)、[live_service:600](<D:/human eye/human-eye/human_eye_plugin/live_service.py:600>) | 报告热观察316个文件模块、380次路径解析；每次完整读取125源、3,605,379 B，125文件SHA＋1总SHA。公开源码确认 `_identity_rejection`→`check_source_drift`→重新枚举、读取、哈希，并非仅启动时做一次。 | 全源读取是可直接删除的热路径工作。125及字节数属于历史报告，未把当前源码静态阅读冒充对当时样本的复算。不要再为路径解析做第二轮微优化。 |
| B：[SOURCE_GUARD_COST_ACCEPTANCE:45](<D:/human eye/human-eye/docs/SOURCE_GUARD_COST_ACCEPTANCE.md:45>) | 8个AB/BA块：文字median/p95 80.287/85.540→74.552/80.892 ms；热图134.184/156.673→129.623/151.566 ms；owned完整生命周期p95却1548.072→1621.508 ms，+4.74%。 | 减少一道检查的局部收益不能宣传为整个生命周期改善。旧实现的短请求已付出数十毫秒包装成本，值得改底座，但这些数字不是新版下界。 |
| B：[M1_RELEASE_COST_AND_DEADLINE_ACCEPTANCE:29](<D:/human eye/human-eye/docs/M1_RELEASE_COST_AND_DEADLINE_ACCEPTANCE.md:29>) | 89源清单median9.875 ms；完整source drift10.506→7.2722 ms。实际stdio/TCP间隙调用median35.0547→32.58545 ms，两组p95差−16.4692 ms，但配对增量p95 **+3.3827 ms**，原+0.5 ms门失败。 | 保留失败，不把“两个p95相减”替代配对门；不相加嵌套profile跨度。旧门属于旧协议，不自动成为新版运行成本门。 |
| A：[blender_mcp_host:292](<D:/human eye/human-eye/human_eye_plugin/blender_mcp_host.py:292>)、[458](<D:/human eye/human-eye/human_eye_plugin/blender_mcp_host.py:458>)、[566](<D:/human eye/human-eye/human_eye_plugin/blender_mcp_host.py:566>) | 请求字典先转JSON，再写进Python代码，再装入 `execute_code` JSON；响应外层JSON包含stdout字符串，之后又解析固定前缀内的JSON。每次 `_exchange` 调用 `_connect`，收到一个JSON后关闭连接；接收循环对累积buffer尝试解码/解析。 | 这是需要替换的旧通道，不应成为新版LLM→已验收引擎的必经路径。重复扫描缓冲区属于静态可见工作，未量测其耗时占比。 |
| A：[live_service:934](<D:/human eye/human-eye/human_eye_plugin/live_service.py:934>)、[live_spatial_mcp:454](<D:/human eye/human-eye/human_eye_plugin/live_spatial_mcp.py:454>)、[engineering_stdio:37](<D:/human eye/human-eye/verification/engineering_stdio.py:37>) | facts被JSON编码为 `context_text`；MCP投影会再解析/改写、deepcopy并序列化metadata为文本；外层JSON-RPC还要序列化。旧实验stdio入口逐行decode/encode。 | 一个规范结构化结果应直接贯穿引擎和适配器；MCP要求的最外层文本/协议包装可保留一次，内部无需JSON字符串互套。 |
| B＋A：[SEGMENT_BRIEF_TRANSPORT:7](<D:/human eye/human-eye/docs/SEGMENT_BRIEF_TRANSPORT.md:7>)、[live_spatial_mcp:499](<D:/human eye/human-eye/human_eye_plugin/live_spatial_mcp.py:499>) | segment brief保留所有诊断，以同结果 `$ref` 去重；只有≥256 B且≥10%才采用，否则回到full。先生成full，再计算brief及收益，客户端还需解引用。 | 这是对旧冗余格式的补丁，不是新版理想合同。不要搬入full/brief/compact多级投影、碰撞检测和回退树。旧普通observe brief与segment brief省略策略不同，不能混称统一无损压缩。 |
| A：[engineering_owned_server:89](<D:/human eye/human-eye/verification/engineering_owned_server.py:89>)、[engineering_native_service:45](<D:/human eye/human-eye/verification/engineering_native_service.py:45>)、[live_spatial_mcp:474](<D:/human eye/human-eye/human_eye_plugin/live_spatial_mcp.py:474>) | N_shared图像链从PNG文件读取并base64编码；service解码后又编码；MCP多图分支再解码、处理并编码；消费脚本再解码写PNG。单图分支会解码验证后原样转发base64，不能混称每条图路径都完全相同。 | 中间层保留一个图像buffer/句柄；只在最终传输适配点编码一次。MCP图像块与文字分离这个方向应保留，不要把base64重复放进正文。静态读到多步复制不等于测得这些步骤是总瓶颈。 |
| B：[M2_ENGINEERING_TRANSPORT_ACCEPTANCE:35](<D:/human eye/human-eye/docs/M2_ENGINEERING_TRANSPORT_ACCEPTANCE.md:35>)；A：[measure_engineering_transport:34](<D:/human eye/human-eye/verification/measure_engineering_transport.py:34>)、[94](<D:/human eye/human-eye/verification/measure_engineering_transport.py:94>) | 72任务、24 Blender＋24 MCP进程；首次median1.331–2.719 s，热态0.139–0.340 s；180 host调用/252任务RPC，54 image块、PNG合计4,323,555 B，文字每任务2,805–13,433 B。首次包含host启动，热态不包含。 | 这是一整套验收负载，含重复收据、额度探针、像素复核等。不能当普通用户任务最少调用数。源码中服务端WIRE落盘在回包前、客户端PNG写入在窗口内；客户端整批RESPONSES.json在elapsed之后。不能笼统把全部留档算进同一个窗口。 |
| B：[M2_ENGINEERING_TRANSPORT_ACCEPTANCE:11](<D:/human eye/human-eye/docs/M2_ENGINEERING_TRANSPORT_ACCEPTANCE.md:11>)、[57](<D:/human eye/human-eye/docs/M2_ENGINEERING_TRANSPORT_ACCEPTANCE.md:57>) | dense1808公开3个边界中的2个位置，第3个成员省略且无位置摘要；不能自主判断全球最近区域。固定ROI图12/12不证明选区通过。新HE、模型试次均0，M2价值未通过。 | 不能为少字节删掉决定任务答案的范围摘要。新版可只输出必要结果，但须表达是否完整、是否存在未定位/未计算部分；不必继承64成员硬上限、180秒等旧配额。 |
| B：[B3E_PRO_TASK_QUALIFICATION:27](<D:/human eye/human-eye/docs/B3E_PRO_TASK_QUALIFICATION.md:27>) | 普通/固定core/合理native初答完整正确1/10、10/10、10/10；补查9/0/0，最终都10/10。首阶段文件99,924/99,427/39,288 B。core只少497 B（约0.497%）；native比core短约60.485%。 | 最佳对照应是合理计算后的精简native事实，不能故意让对照看海量原始三角。文件字节不是实际上下文；少9次补查不是少9次模型往返。core由操作者给定，不证明自主选区。 |
| B：[REGION_WITNESS_TASK_PILOT:25](<D:/human eye/human-eye/docs/REGION_WITNESS_TASK_PILOT.md:25>) | 每路8次新CLI，完整CLI小计37.98/38.87/35.42 s，数学/序列化0.163/0.231/0.567 s；三路均1/1。数学/序列化仅各自CLI小计约0.43%/0.59%/1.60%，但余量未细分。 | 强烈支持优先减少重复启动/采集/包装链，不能将剩余98%+全归因于启动或IPC，更不能预报同等幅度加速。每路两目录、四事实和补查两次采集，不是八次同一几何查询。 |
| B：[REGION_WITNESS_TASK_PILOT:39](<D:/human eye/human-eye/docs/REGION_WITNESS_TASK_PILOT.md:39>)、[49](<D:/human eye/human-eye/docs/REGION_WITNESS_TASK_PILOT.md:49>) | 输入文件264,299/234,836/322,757 B；模型可见工具文本126,027/107,477/87,908 B，排序不同。控制器曾错接selected/resolved及旧schema；原入口只允许基础报告之前补查，没有提前停止。 | 统一schema直接消费；不把新版包伪装为旧包。先给可回答的基础事实，后续详情是按需取用，不强制在答案出现前预跑全部补查。可见输出、文件和provider输入分别计量。 |
| B：[hooks/ADAPTATION_REPORT:94](<D:/human eye/hooks/ADAPTATION_REPORT.md:94>)、[109](<D:/human eye/hooks/ADAPTATION_REPORT.md:109>) | 作者称每次Hook新起Python约0.2 s，未找到对应原计时样本；六项CLI测试成功和配置/重启成功仍未让实际workspace写入触发Hook，后记记录sandbox路径跳过。 | Hook不应成为新版数据交换正确性的前提，也不应为每事件新起进程。这里是历史宿主行为，不是对今天宿主的断言；0.2 s不能作为已复核的新收益。 |
| B：[HUMAN_EYE_9_7_2_OPTIMIZATION_AND_TEST_REPORT:39](<D:/human eye/HUMAN_EYE_9_7_2_OPTIMIZATION_AND_TEST_REPORT.md:39>)、[43](<D:/human eye/HUMAN_EYE_9_7_2_OPTIMIZATION_AND_TEST_REPORT.md:43>) | JSON只导vertices/faces，丢local_axes后旋转处方漂移4.5–42°、平移71–98 mm；处方器/自检共用错误轴，形成自证。单体与分包双实现同进程报不同结果。 | 简化接口保留实际需要的坐标框架、单位、矩阵/轴约定；引擎单一实现，适配器不复制几何算法。删旧防御层不等于删掉定义数学意义的数据。 |
| A：[audit.py:16](<D:/human eye/blind_test_2026-10-21/audit/audit.py:16>)、[132](<D:/human eye/blind_test_2026-10-21/audit/audit.py:132>)，本次probe中的stored_local_token_ledgers | 原audit两份各8场景JSON存在；逐项重算所有ledger与合计相等。旧/后plugin总计23,910/23,977，本地对照20,706/20,698。源码用cl100k_base＋固定每图256；并非provider账单。 | 这组原件能核证本地账本汇总，不能核证总报告中“1934 tokens”属于同一范围或实际模型消费。未重跑tokenizer，也未认定这些文件是那条headline的对应批次。 |
| A＋B：[V19_REPORT:105](<D:/human eye/V19_REPORT.md:105>)、[122](<D:/human eye/V19_REPORT.md:122>)及本次probe | 重复参考体有理化6.24/20.49 ms及预计1.17×来自报告；_probe中4份tm摘要可读取，但场景数不同且无逐样本/运行身份。另有8份10月kernel性能摘要，及751,450 B优化zip，SHA97a50b6e…6a6208与报告一致。 | 有旧原件不意味着能把kernel毫秒迁移为LLM入口基线。1.17×仍是当时设想；20–40 ms进程启动也未找到配对原样本。包哈希吻合仅确认包，不证明报告全部测量。 |

近期原始证据缺口是实质限制：当前 `D:/human eye/human-eye/verification/fixes` 不存在；顶层 `D:/human eye/verification` 为空。activation/reload、triarm_bundle_r1、review_cycle001/006等引用目录均缺失；工作区含隐藏/忽略目录的文件名扫描也未找到相关COST_QUALIFICATION_SUMMARY、PROFILE_ATTRIBUTION、REGISTERED_HE_GATES等原件。故本报告未宣称独立重算M1/M2/B3E/source-guard的分位数、时序、来源及PNG真值。顶层早期audit、kernel摘要与zip已读并哈希，不用它们填补后续批次缺证。

**最贵的重复链与实施优先顺序。** 这里按应消除的架构工作排序，不把不同任务的毫秒放到同一张成本占比图。

1. 先切断“每次事实查询→CLI启动→重新导入/来源绑定→host采集→计算→序列化→落盘→关闭/发布”的重复生命周期。旧区域任务数学仅占小部分，而完整新CLI平均约4.43–4.86秒/次；这个均值不是启动时间。新版接入既有引擎会话，场景与引擎状态在会话内驻留；正常下一次请求只传意图及必要变化。无需为了接LLM重开已验收BC等算法优化。
2. 删除每次请求全文件扫描/哈希、已加载模块来源逐项检查及配套防御协议。构建/测试归档可在计时窗口外留一次版本证据，不加入模型回复，不循环传源码清单。旧source-guard优化只省了其中一小段，继续沿旧层层证明路径优化收益有限。
3. 引擎到模型适配器采用直接结构化调用；跨进程确有需要时只设计一种请求/结果交换。删除通用 `execute_code`、stdout前缀拆包、Python字符串内JSON及每字段再解析的中转。会话能复用的连接与缓冲不要每次重建。此项为新方案，不宣称单独换连接就有确定加速。
4. 一次观察只生成一份规范事实、一份图像产物。让报告/模型使用同一结果，不重建facts，不重复附完整request、steps、源身份、诊断镜像、context_text。按需取细节时引擎直接计算或返回对应产物，不让模型在几份重复报告及 `$ref` 中自行拼装。实际任务需要的步骤/历史才显式返回。
5. 删除运行常态中的验收探针与档案往返。原生图像无需先磁盘落PNG、读回base64、跨层反复验证再另写PNG；实验原件应由测试层独立留存。配置自动Hook再工具观察造成的“双捕获”在本次证据里没有完整同请求计量，只列为新设计应避免的重复风险，不能写成已经测到的固定成本。

源码重用和状态复用须以当前已验收引擎定义的会话/版本为基础，不能返回期望值冒充新的观察。前述策略不要求把旧TaskStore、nonce链、配额、故障隔离、迁移激活及全套防御结构复制到新入口。

**交换的删除与保留。**

| 对象 | 新入口建议 | 保留的数学/任务意义 |
| --- | --- | --- |
| 全场景顶点/面、重复相机/轴信息 | 引擎内持有；仅场景首次接入或必要变化进入底层；不默认倒给模型 | 对象与场景/帧标识、坐标/单位/变换语义，按当前引擎合同一次明确 |
| context_text字符串、普通/brief/compact并行报表、同事实多份镜像 | 一个版本化结果结构直接投影成模型所需字段，删除自定义解引用树 | 完成任务所需数值、关系、选择范围及真实负反馈 |
| 巨量几何原始数组与全审计trace | 留在引擎/测试证据层；不作为默认模型输入 | 公共结果必须足以回答实际任务；若未计算或范围不完整，明确表达，不输出假阴性 |
| PNG与base64 | 一个产物，最终适配器按消费者要求编码/交付一次；文字只附必要图像关联 | 模型确实收到的图、对应对象/视图/观察；路径存在不等于图已交付 |
| 指令/期望残差/实际残差混写 | 返回真正执行所得结果，必要时提供实际前后状态差 | 旧“命令位移当实际位移、缓存期望当复检”错误不能重现；这是结果语义，不是旧守门策略 |
| 来源/预算/权限/Hook运行详情 | 从新运行数据链删去；测试版本证据独立留档 | 不把磁盘配置、工具注册或CLI手测冒充真实入口成功 |
| 后续细节 | 第一结果后按任务需要取用，已有事实与产物可直接引用内部状态 | 不用先强制补查全部样本来掩盖基础结果是否有用；不为展示重新执行动作 |

未知并非只能使用一个通用unknown：至少须区分没有目标、没有计算该部分、已计算但无法确定、图中不可见、执行未完成这几类事实。可用简短固定字段，无需继承旧诊断树。M2省略位置导致无法选区、B3E外围极值冒充core、旧Y1忽略passed=false都说明这部分删错会让短报文失去价值；没有证据支持全局删除它们。

**可用的收益基线与一次有限验收。** 新版应以当前已验收引擎为计算基线。比较“直接调用同一引擎得到规范结果”和“经新LLM适配器得到同一结果”的新增成本；必须经过MCP的宿主，另测这一层真实交付，不混入旧复杂服务再称其为必要底座。旧报告只给出问题量级和失误案例，不替代新版B/I实测。

公平任务基线应为合理的原生精简事实＋同等可选操作，不是故意冗长的原始数组。以同一任务成功标准对比实际可见事实/图及后续真实反馈；目录、局部ROI、全局覆盖、是否能完成下一步分别保持一致。为压字节改变可回答域时必须明确，是不同接口能力，不能作为无退化收益。

这轮可先冻结结构性目标，等待实施后测值：稳定会话内每请求新启动进程数0、热请求全源码读取字节0、facts内部嵌入JSON字符串0、同一事实默认重复表示0；图片只在最终需要的传输层编码，不循环解码重编码。这些是本次提出的设计验收项，当前没有新版实现结果。正常未变场景不应为报告显示重新采集；真正动作后获取当前结果的必要工作不能冒称“可删重复”。

测量至少分开：冷启动至首个可消费结果、驻留会话请求到结果、引擎计算、序列化/复制、真实IPC与最终模型可见交付；完整任务从首意图到任务答复另列。嵌套阶段用于解释，不能相加。分别记录文字UTF-8、PNG原始字节、实际wire字节、启动/调用/捕获次数、实际可见工具内容；provider usage缺失就保留缺测。测试侧保留原件、失败与反例，必要时另计留档开销，不让留档变成产品每次操作的前提。

一次事前确定的同输入、同版本、交错B/I比较即可验收接入收益和无退化；没有新失败不继续用新增候选反复刷同一模块。模型质量/任务时长/费用若还未执行真实消费，本阶段只验收结构和传输，不代填模型收益。既有原33点等引擎历史失败不被接口报告覆盖，不重开算法重优。

**本轮明确不能宣称的收益。**

- 不能称已节省3.6 MB模型上下文：那是每请求源码读取报告值，未曾全部传给模型。删除读取与减少模型输入是两件事。
- 不能称生命周期余量98%全可删除，不能将旧kernel 3 ms对CLI数秒算提速，也不能将旧1.17×预测当已实现。
- 不能称MCP image块消除了base64 wire开销；独立图像块避免正文重复，标准base64仍约有4/3编码膨胀，实际总wire需实测。
- 不能将文件字节、cl100k_base本地token估算、固定256图像估值、工具调用数、父端模型阶段数互换为provider token/调用/美元。497 B或60.485%是旧文件的算术差，非新收益。
- 不能用源码结构或小样本p95证明尾部稳定、杀毒/OS原因或统计显著性；不能把旧10.107秒Hook注入先后顺序当性能改善。
- 不能把M2的N_shared叫无插件基线，也不能把重启/配置完成叫当前宿主入口已生效。运行验收应观察实际入口的结果，不要求重建旧激活防护系统。
- 不能用报告汇总补回缺失原始来源、把旧失败改成通过，或为减报文删除任务必要覆盖及负反馈。

可立即交给接入实施的结论是：复用当前引擎，一份输入意图、一份实际结果、一次必要图像交付；将旧执行代码桥、重复编码、全源扫描与防御性生命周期整体移出新路径。收益由这条新路径的真实测量确认，几何算法和已验收结果继续作为固定参照。
