"""Offline history evidence inventory. Reads existing files only; never imports engine.

Writes only history_evidence_probe.json beside this script. No timing, host, GPU,
Blender, model calls, or attempted reconstruction of absent private evidence.
"""
from pathlib import Path
import hashlib
import json
import statistics
import zipfile

BASE = Path('D:/human eye')
REPO = BASE / 'human-eye'
OUT = Path(__file__).resolve().with_suffix('.json')

def file_record(path):
    if not path.is_file():
        return {'path': str(path), 'exists': False}
    raw = path.read_bytes()
    return {'path': str(path), 'exists': True, 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}

docs = [REPO / 'docs' / (name + '.md') for name in (
    'SEGMENT_BRIEF_TRANSPORT', 'M2_ENGINEERING_TRANSPORT_ACCEPTANCE',
    'M1_RELEASE_COST_AND_DEADLINE_ACCEPTANCE', 'B3E_PRO_TASK_QUALIFICATION',
    'SOURCE_GUARD_COST_ACCEPTANCE', 'REGION_WITNESS_TASK_PILOT')]
docs += [BASE / name for name in (
    'V19_REPORT.md', 'HUMAN_EYE_9_7_2_OPTIMIZATION_AND_TEST_REPORT.md',
    'ATTENTION_CACHE_20261023_ANALYSIS.md', 'VISUAL_GAIN_AUTO_OFFSET_ANALYSIS.md',
    'PLUGIN_TRUST_ENGINEERING.md', 'hooks/HOOK_GUARD_REPORT.md',
    'hooks/ADAPTATION_REPORT.md')]
sources = [REPO / name for name in (
    'human_eye_plugin/live_spatial_mcp.py', 'human_eye_plugin/live_service.py',
    'human_eye_plugin/runtime_identity.py', 'human_eye_plugin/verified_source_loader.py',
    'human_eye_plugin/blender_mcp_host.py', 'human_eye_plugin/task_brief.py',
    'verification/engineering_stdio.py', 'verification/engineering_native_service.py',
    'verification/engineering_owned_server.py',
    'verification/measure_engineering_transport.py')]
sources += [BASE / 'blind_test_2026-10-21/audit/audit.py',
            BASE / '_incoming_v19/_probe/timing_probe.py']
missing = [REPO / name for name in (
    'verification/fixes', 'verification/fixes/20261030_v21_activation/REPORT.md',
    'verification/fixes/20261030_v21_reload/REPORT.md',
    'verification/fixes/20261102_safety_source_batch/triarm_bundle_r1',
    'verification/fixes/20261103_review_cycle001',
    'verification/fixes/20261103_review_cycle006')]

audits = []
root = BASE / 'blind_test_2026-10-21/audit/results'
for name in ('audit_baseline.json', 'audit.json'):
    path = root / name
    rows = json.loads(path.read_text(encoding='utf-8-sig'))
    by_stage = {}
    totals = {'plugin': 0, 'baseline': 0}
    for row in rows:
        for arm in totals:
            assert sum(s[arm] for s in row['ledger'].values()) == row['ledger_totals'][arm]
            totals[arm] += row['ledger_totals'][arm]
        for stage, value in row['ledger'].items():
            dst = by_stage.setdefault(stage, {'plugin': 0, 'baseline': 0})
            for arm in dst:
                dst[arm] += value[arm]
    audits.append({**file_record(path), 'scenes': len(rows), 'scene_ids': [r['scene'] for r in rows],
                   'sum_local_ledger_units': totals,
                   'mean_local_ledger_units': {k: v / len(rows) for k, v in totals.items()},
                   'by_stage_local_ledger_units': by_stage,
                   'scope': 'Stored aggregate integers independently summed; not re-tokenized. '
                            'audit.py uses cl100k_base and adds fixed 256/image; not provider usage.'})

perf = []
for path in sorted(root.glob('perf_*.json')):
    perf.append({**file_record(path), 'stored_values': json.loads(path.read_text(encoding='utf-8-sig')),
                 'scope': 'Old in-process kernel summaries, not new measurements or IPC/model latency.'})
v19 = []
for path in sorted((BASE / '_incoming_v19/_probe').glob('tm_*.json')):
    obj = json.loads(path.read_text(encoding='utf-8-sig'))
    v19.append({**file_record(path), 'cases': len(obj), 'stored_values': obj,
                'scope': 'Existing kernel summary; no per-sample trace/runtime/source manifest in this file.'})

archive = BASE / 'artifacts/human_eye_engine_cloud_9_7_2_optimized.zip'
archive_record = file_record(archive)
if archive.is_file():
    with zipfile.ZipFile(archive) as z:
        archive_record.update(members=len(z.infolist()),
            uncompressed_member_bytes=sum(i.file_size for i in z.infolist()),
            scope='Container hash/central directory only; no engine extraction or execution.')

anchors = {}
needles = ['context_text', '3,605,379', '786,833,426', '35.0547', '3.3827',
           '99,924', '99,427', '39,288', '4323555', '180次', 'CLI 总壁钟',
           '264299', '10.107', '0.2s', 'skip 8-Phase', '1.17', '20–40',
           'cl100k_base', 'VISUAL = 256', 'source_check', 'sendall',
           'base64.b64decode', 'base64.b64encode', 'complete_task_ms',
           'RESPONSES.json', "save('WIRE_", 'local_axes', '126027']
for path in docs + sources:
    if path.is_file():
        rows = []
        for n, line in enumerate(path.read_text(encoding='utf-8-sig').splitlines(), 1):
            hits = [s for s in needles if s in line]
            if hits:
                rows.append({'line': n, 'matches': hits, 'text': line})
        anchors[str(path)] = rows

result = {
    'scope': 'CPU offline read of historical local reports/code/JSON only. No new performance evidence.',
    'reports': [file_record(p) for p in docs], 'current_public_source_snapshots': [file_record(p) for p in sources],
    'source_identity_limit': 'These hashes identify files read now; they do not prove they were executed in the historical private runs.',
    'private_evidence_locations': [{'path': str(p), 'exists': p.exists()} for p in missing],
    'top_level_verification_contents': [p.name for p in (BASE / 'verification').iterdir()],
    'stored_local_token_ledgers': audits, 'stored_kernel_summaries': perf,
    'v19_stored_summaries': v19, 'optimized_archive': archive_record,
    'report_derived_not_measured': {
        'B3E_core_vs_primary_saved_bytes': 99924 - 99427,
        'B3E_core_vs_primary_saved_fraction': (99924 - 99427) / 99924,
        'B3E_native_vs_core_saved_fraction': (99427 - 39288) / 99427,
        'region_cli_ms_per_call_A_B_C': [37980 / 8, 38870 / 8, 35420 / 8],
        'region_math_serialization_fraction_of_cli_A_B_C': [0.163/37.98, 0.231/38.87, 0.567/35.42],
        'scope': 'Arithmetic on author report values only. No attribution of the residual to startup or IPC.'},
    'line_anchors': anchors,
}
OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'output': str(OUT), 'reports': len(docs), 'source_files': len(sources),
                  'stored_ledgers': len(audits), 'kernel_summaries': len(perf),
                  'v19_summaries': len(v19),
                  'ledger_sums': [x['sum_local_ledger_units'] for x in audits],
                  'archive': archive_record}, ensure_ascii=False))
