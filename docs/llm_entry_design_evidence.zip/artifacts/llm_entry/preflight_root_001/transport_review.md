# 新引擎大模型入口：传输链只读预审

任务：`9d00ae4e-3ed1-4247-ba40-3f204cad1f5d`。只审查磁盘源、安装的 addon 文件和公开官方线程说明；未启动 Blender、GPU、引擎、API、socket 探测或安装，未修改生产、配置、文档、git。源身份见同目录 `transport_probe.json`；该清单不代表运行中 Blender 已加载相同字节。

**建议采用：外部纯字节 stdio relay → 一条持久 loopback TCP → Blender 主线程非阻塞 pump → 同一常驻 `BlenderRadicalSession`。** Blender 内解析一次 MCP 请求、生成一次最终 MCP 响应；relay 不解析 JSON、不重封装图像、不运行算法。既有 BlenderMCP 只可作一次初始化通道，不进新热路径。没有静态证据阻止实现；但 GUI 调度、空闲 CPU、真实图片交付和输入绑定仍须限定资格验证，不能以旧引擎成绩代替。

## 1. 旧入口的实际链路

下表计数针对正常成功路径，已绑定目标对、无额外 hook、非结构/表面任务，不含客户端进程内部未知转发。一次 RPC 指一问一答；跨进程单向传输次数是其两倍。

| 路径 | MCP 服务器 ↔ Blender RPC | Blender 内全场景 `_capture` | 全量几何 TCP 负载 / 图像 |
|---|---:|---:|---|
| `observe(include_image=False)` 或显式 analytical projection | 1 | 1 | 一份 scene；projection 在外部 Python 生成 |
| native image observe，能力缓存已热 | 2 | `3 + 2N`，即 5 或 7 | 第一次 scene；第二次返回含 `capture` 和 `native_scene` 的 evidence，以及 N 个 PNG |
| native image observe，首次能力探针 | 3 | 同上 | 另加小型 capabilities RPC |
| 普通成功非 no-op `transform` | 4 | 5 | 四次返回都带 scene，apply 的内部 before capture 不另传；最后图由旧 router 生成 |

N 为 1 或 2 个 native 图。native image observe 不只是“捕获一次再截图”：`BlenderSceneHost.observe_readonly_native` 首尾各 capture，一张图的 `_readonly_render_view` 再前后各 capture，加外部最初 capture，即 `1 + 1 + 2N + 1`。证据：`blender_host.py:1336, 1374, 1414, 1447`。

默认生产路径：`production_server.py:111–116` 构造一次 `LiveSpatialService`，进入 `live_spatial_mcp.run_stdio_mcp_server`；`live_service.py:307` 默认实例为 `BlenderMCPHost`。`GuardedHostRuntime` / `HumanEyeAutoRouter` 是该外部进程里的普通对象，**并不额外经过 `router_server` 子进程**。

普通观察：MCP handler → `LiveSpatialService.observe` → `capture_scene` → `_before_model_on_captured_scene` 直接复用这次 snapshot → 可选能力探针和 `observe_readonly_native` → `_save` → MCP content。冷/热 native 有图观察，计入宿主↔外部 MCP 的一次 stdio 往返，共 8/6 次单向进程边界；无图/投影为 4 次。参与的是宿主、外部服务器、Blender 三个进程，不能把类调用算成新进程。

普通 transform：`_prepare` 内 `before_model.capture_scene` → `execute_action.capture_scene` → `apply_transform` → 独立 `capture_scene` readback。apply 内再 capture before / after，所以四次 TCP 往返、五次 native capture。apply 已返回 after scene，runtime 仍捕获一次独立 after；计入 MCP stdio 为 10 次单向边界。`host_runtime.py:241, 318, 350`；`blender_host.py:2005, 2071, 2133`。no-op、拒绝、失败/回滚、goal-segment 是别的路径，不能套用这个固定数。

## 2. 可直接移除的重复工作与不可省边界

### 旧 TCP / JSON / 图像

- `BlenderMCPHost._exchange` 每 RPC 创建并关闭 TCP；每个连接又让 addon 新建 client thread。每个 host 请求把小参数 JSON 塞进 Python 源代码，再把代码放入外层 `execute_code` JSON。Blender 端每次读取、SHA256、compile/exec `blender_host.py`、新建 host 对象（`blender_mcp_host.py:284, 356, 449, 565`）。持久存储仅部分放在 `bpy.app.driver_namespace`；不能把整个 host 视为驻留实例。
- capture 将所有目标范围 mesh 的 vertices/faces/edges 转成 Python list；先用完整 JSON 计算 revision，又把完整 result JSON 打印进 stdout，再由 addon 把 stdout 字符串二次 JSON 包装。外部先解析外层，再解析 stdout 中内层 envelope。每次 recv 都把累计 buffer 重新 decode/尝试 JSON loads，增加大包前缀重复处理。`blender_host.py:437–579`；`blender_mcp_host.py:475, 565`。
- native evidence 同时含 scene world vertices/faces 和 native 的 local/world vertices/faces。旧外部 `_validated_scene` 还会完整 JSON 编码计算 fingerprint（`auto_router.py:368`）。`scene_delta` 是已传完整 capture 后的公开投影，不能称其避免全量 native 几何跨进程。
- native PNG 每图发生三次 base64 编码：Workbench native helper 初次；`native_observation.py:788–793` 解码、提取公开 PNG 再编码；`live_spatial_mcp.py:474–477` 又解码/处理/编码。Blender 内审计还解码以算 hash。native PNG 清理可能改变辅助 chunk，不应假称旧三个阶段字节必然完全相同。analytical projection 是 BytesIO PNG→一次 base64，MCP 层只解码检查后转发原字符串，不能混为同一种重复数。
- `live_spatial_mcp._tool_result` deepcopy service result；完整 metadata dumps 后，brief / compact 模式可能再 dumps。最终 content 已将图像从 text 移到 ImageContent，**没有把同一个 base64 再留在 text**（454–534）。最终 wire 又 dumps 整个 JSON-RPC 响应；`annotate(output_bytes=...)` 还完整 UTF-8 encode 一次计数（701）。输入 `wire.requests→parse_request→validate_request` 后，handler 622 又 validate，含再次 dumps 的 size check。

### 文件与 worker 生命周期

- 默认 live 的 mesh RPC 使用 TCP，不是请求文件轮询。**但确有热路径文件成本**：每 RPC 源文件读取；`_locked` 读 state、sidecar lock；`_save` export+完整 dumps 计大小，变更时又序列化、写临时文件、flush/fsync/replace；audit 为文件记录。观察状态未变时有显式跳过写盘分支，不能笼统说每次都 fsync。成功 transform 在提交前 inflight 和完成后至少两次 state 保存。`live_service.py:738–828, 1238, 1258`；`agent_hooks.py:51–64`。
- 旧 native 图像的 `episode_gateway.native_look:918,937–941,964` 每图创建临时 PNG 路径，`render(write_still=True)` 写盘、读取 PNG、最后删除。这是图像中转文件成本，虽非两个进程通过文件交接。新 `VGRenderer` 已在内存产生 PNG bytes，不能把新薄入口重新接回旧磁盘渲染。
- `production_server` 常驻；其每次工具调用没有新建 Python/Blender worker。`router_process.ExternalRouterProcess` 是另一条嵌入式 Blender→外部 router 方案：构造时 Popen 一次，之后 JSON-lines pipes 常驻，每请求新建 writer thread；默认 live 不走它。
- `BlenderProcessHost` 构造时启动一个 `--background` Blender worker，之后 stdin/stdout pipes 常驻；它打开独立 .blend，不连接用户已打开的 Blender。它也不是默认 live。将它用于功能资格可以，但不能冒充同一 GUI 场景、GPU 上下文或 UI 调度成本。
- `human_eye_hook.py` 是宿主每事件运行的命令进程；重型事件在同一新进程导入 `live_hooks`，再新建 `LiveSpatialService`，不是调用已常驻 MCP 服务。prompt 可能额外 observe；PreToolUse transform 额外 preview；若走旧重型 PostToolUse 也 observe，实际轻路由可提前处理，所以不能无条件把所有三种 hook 都计成一次捕获。Windows 安装还可能加 PowerShell 命令包装。新入口不必继承这些自动重复观察和防御 hook。
- `human_eye_plugin.__init__` eager 导入 `plugin_facade` 及旧 operators。模块/console 入口会承受这层启动导入；新 stdio relay 用独立标准库脚本即可，不应为复用小 wire helper导入整个旧 plugin。旧 `module_3_1...` / facade 的共享内存设计，不在已核实默认 live 工具热链中，不能引用“零拷贝 IPC”名称代替真实链路证明。

## 3. 已安装 BlenderMCP 能复用什么

磁盘位置：`C:/Users/v_wbobosun/AppData/Roaming/Blender Foundation/Blender/5.2/scripts/addons/blender_mcp.py`，身份写入 probe JSON。未检查运行中加载的 module，因此仅称“已安装文件”。

它的 server 常驻，accept 后每 client 一条 Python thread；client 读 JSON 入队；**主线程** `_drain_command_queue` 执行命令、JSON dumps、阻塞 `sendall`；结束返回 `0.05` 秒（1510–1538）。这只是配置的轮询间隔，不是严格 50ms 延迟上界、p95 或平均值；UI 工作会推迟 timer。native/GPU 执行确实在主线程，但大响应发送也会阻塞该线程。

可复用一次 `execute_code` 的主线程引导来 import/start 新桥；也可直接提供显式 start/stop 示例脚本。不能无改动注册新 typed handler：其 `handlers` 字典每次 `_execute_command_internal` 局部建立（1619），没有发现公开 extension registry。monkeypatch 内部分发会绑定第三方实现，不是最小稳定依赖。

旧 addon 自身存在后台线程。新桥不创建 Blender Python 线程，不等于当前 Blender 进程完全没有线程；用旧 addon 引导后若它继续运行，必须限定这项声明。后续若要隔离其扰动，应在资格前明确是否停止旧 addon，不能在测后选择最有利版本。本轮没有停止它。

官方 [Blender 5.0 线程说明](https://docs.blender.org/api/5.0/info_gotchas_threading.html) 仍不支持与 Blender 长期并行的 Python 线程；“线程不碰 bpy”不是足够豁免。相关 [#139602](https://projects.blender.org/blender/blender/pulls/139602) 及[移除跨线程 timer 示例的提交](https://projects.blender.org/c-s/blender/commit/a010c1c8b801c07fbfb976eaf1bf391b3f3a42eb) 与此一致。本次官方页面直开失败，相关内容经搜索索引查到；不据此宣称已逐行审过完整 PR。选同主线程非阻塞 pump 可避开新增这一类线程依赖。

## 4. 推荐薄桥的具体合同

```text
MCP 宿主
  ⇅ 原生 MCP JSON-lines / stdio
标准库 relay：原样 bytes，全双工，常驻
  ⇅ 一个持久 loopback TCP 连接，原样 MCP 行
Blender 主线程 pump：非阻塞收/发、完整行后解析一次、顺序 dispatch
  → 同一 BlenderRadicalSession / controller / resident geometry / renderer / CF model
  ← ao_bytes + PNG bytes + 小型身份/票据元数据
  → 最终 MCP TextContent + ImageContent，只在这里 base64
```

正常一次 observe 或一次已明确命令的 action 可以只需 **一** 个 MCP tool 往返和 **一** 个 relay↔Blender 往返（4 次单向进程边界）；没有额外 capture RPC、公开几何 payload、router 子进程、文件消息队列。独立 predict + execute 若都暴露为工具则天然两次往返；不能把两工具责任和合并 action 的数字混报。

1. **relay 全双工且不猜通知是否有响应。** Windows pipe/stdin 与 socket 不是统一可 select 的对象。可在外部 relay 使用标准库双向转发线程；这些不在 Blender 内，无 bpy/GPU。不得采用“每输入一行就等一行输出”的死锁设计：initialize 后 notification 没有响应，合法 MCP 请求也可能紧邻到达。stdout 只写 MCP bytes，日志走 stderr。relay 不做 JSON parse/dumps，不生成假响应，不自动重发写操作。
2. **Blender pump 与 I/O 全在主线程。** listener/accepted socket 非阻塞，timer 在 Blender 主线程注册；维护 recv buffer 和完整 `\n` 帧，支持多行同包、单行跨包、UTF-8 字符跨包。send 保存 pending bytes/memoryview 和 offset，遇到不可写下次继续，不能使用阻塞 sendall；一次 pump 的 I/O 工作有明确调度预算以避免待发大图占死 UI。两端设置 `TCP_NODELAY` 是合理的小消息设置，不能承诺它消除 timer/OS 等待。
3. **常驻一个明确绑定的 engine session。** 初始化固定 scene、view_layer、实际 object 映射、goal、generations、reference 和 deployment；只在 Blender 内构造实际 RNA/ReferenceFrame，绝不让客户端传整 mesh。`BlenderRadicalSession` 168 明定主线程/GPU 上下文；构造/渲染/关闭都遵守它。已有 bridge 和 renderer 生命周期必须跨请求保留。
4. **工具是 API 编排，不再加旧安全层。** observe 明确 image mode、F/R/L、每对象变化标志；action 可在一次 dispatch 中 `predict_action`→`execute`，用当前 observation、明确 command、predictor 和 after request。若产品需要先看预测再决定执行，则保留 predict/execute 两步及 token；不能为少一次往返把用户未批准的动作提前执行。V 反馈保留 observation ID/attachment key/canonical index/实际 pixel verdict；A 反馈只消费服务端真实 Outcome ticket，不让客户端填写 measured delta。可把已收到的反馈与下一 observe 合并成一请求，执行顺序和基线一致。
5. **票据留在 Blender。** `PreparedAction`、view/action ticket 包含 owner、内部数组和 consumed 状态，不能 dataclass-asdict 发给模型。桥仅保存有界生命周期的映射/当前 ticket，公开 observation/action/token ID 与必要可解释字段。它是既有引擎 API 的忠实映射，不能把同一反馈重放或假造学习标签当“去防御”。也不需要添加旧回滚、quarantine、全场景 hash、重试、WAL、hook gate。
6. **AO 不回解析；PNG 不重复压缩。** `ao_bytes.decode('utf-8')` 直接放唯一 TextContent，保持原 AO 内容；必须在最终 JSON 字符串里正确转义。现有 AO 自身已经是 JSON bytes，因此“单 JSON 薄桥”准确指无中间协议解包/重包，不是从引擎到宿主完全只有一次编码。PNG 原 bytes 只最终 base64 一次，MCP ImageContent 的 `data` 使用标准 base64；不写图片文件、不 decode/re-encode、不在 text 再塞 base64。ActionResult 原含 before+after 附件，第一版照合同交付，不悄悄省 before 图制造收益。
7. **仍有真实复制。** GPU readback、PNG 压缩、AO JSON 编码、base64 的 `4*ceil(n/3)` 字节、MCP 字符串/UTF-8 buffer、socket/pipe/宿主解析均存在。此方案将 base64 也通过 loopback，较二进制本地桥多约 1/3 PNG 字节，但省掉外部反序列化/再次封装。能否更快是待测的端到端问题，不能称零拷贝、零传输成本或保证 5%以内。
8. **保持已有失败状态。** `ActionStageError(stage, write_status, outcome)` 在执行后出错时必须如实公开 written/not_written 等信息；断线/输出失败不自动重放 action。这个要求只是防止入口撒谎或二次执行，不恢复旧防御策略。session close / 文件切换 / 新 target topology 的生命周期由明确操作处理；不在每次调用偷偷扫描整场景猜变化。

## 5. 实现选项与公平基线

| 选项 | 层级/成本 | 判断 |
|---|---|---|
| A. 推荐的 raw stdio relay + Blender 单主线程 pump | 一层本地透明转发；Blender 直接最终 MCP JSON；每图一次 base64 | 首版最少协议层，适合已打开 GUI；须验证调度与 CPU |
| B. 外部 typed MCP server + 主线程二进制本地 bridge | 小 JSON 参数 + 原 AO/PNG binary，本地 socket 不传 base64；外部组 MCP | 少约 1/3 本地 PNG 字节，增加 framing/外部装配模块；可作替代设计，不必首版同时维护两套 |
| C. 旧 addon execute_code 调用常驻 session | 可用很短 stub，避免每次整文件 compile；仍 stdout 内层 JSON、外层 JSON、50ms timer 路径 | 能验证 session 是否能运行，不能作推荐最薄正式入口；更不能套旧 BlenderMCPHost 重构防御链 |
| D. 独立 headless Blender worker | 无 live GUI timer；owned .blend 生命周期不同 | 只作相同 handler/内容的资格环境。不得替代 GUI 传输和主线程调度验收 |
| E. 在 Blender 内直接 HTTP MCP | 可移除 stdio relay，但引入 HTTP/MCP 服务实现和异步/线程/依赖部署 | 当前宿主 stdio 接入需求下不是最小范围，无需先做 |

真正低成本同责基线应为：**同一 accepted Session、同一初态/场景/动作/CF arm/反馈顺序，同一个 dispatcher 和最终 MCP content builder，直接在 Blender 主线程调用；对照新工具入口。** 要含相同 AO bytes、PNG 数量/尺寸/bytes、实际 RNA 写入/readback、view selection/rays、实际 V/A 学习状态。B 不能只测旧 `cf_native`、NONE/no-image、预先算好的 AO、不同部署或没有学习反馈；I 不能删公开事实/图片后说“传输优化”。只有完整 MCP 最终 response bytes 等责时，差值才是桥的新增成本。

需要分别给 engine-direct（已有测量范围）、direct-handler（含 MCP base64/最终序列化）、wire-entry（含 relay/socket/timer）绝对成本，不能把不同端点混算。若未来测相同 handler 的 headless direct，必须明确环境差异，不能从相减结果声称 GUI wire-only 精确开销。计时起止、初次启动、常驻热态、byte counts、timer 等待、partial sends、空闲 CPU在实验前固定；本次没有性能数字或硬门建议，交由根侧统一冻结一次。

旧 `human_eye_scene_observe/transform` 支持全场景、旧图像布局、SE(3) rotation、部分结构/表面任务、guard与持久状态；新 API 是明确绑定目标、Translate/SetShapeKey、TD/BC/VG/CF、1024×512 PNG。两者职责不同。旧路径可提供结构性成本诊断，不能作为新功能性能比的唯一“同责薄 B”，也不能宣称新入口已兼容所有旧工具。

## 6. 最小文件与必须先明确的事项

首版 source-checkout 方案只需以下 **3 个实现文件、2 个测试文件、1 个示例**（建议名称，未创建）：

| 文件 | 唯一职责 |
|---|---|
| `human_eye_llm_stdio.py` | 纯标准库全双工字节 relay；连接本地固定 endpoint，不 import 旧 plugin 或新 engine |
| `human_eye_fast/llm_entry.py` | MCP tools/schema、JSON请求分发、Session/ticket 编排、唯一最终 content 编码 |
| `human_eye_fast/blender_llm_bridge.py` | 显式 start/stop、主线程 nonblocking sockets/timer、接收帧/待发 buffer、实例生命周期 |
| `verification/test_llm_entry.py` | CPU stub 检查调用顺序、内容/票据/失败状态，以及同一 handler 的实际 Blender资格入口 |
| `verification/test_llm_transport.py` | CPU pipe/socket 测试分片、合包、UTF-8、部分写、通知无响应、EOF、原字节转发；不导入 Blender |
| `examples/blender_llm_entry.py` | 显式 scene/object/goal/reference/deployment 绑定与启动/关闭示例，不扫描全仓库/执行网络安装 |

已有 `pyproject.toml` 明确列 py-modules；若要 wheel/console 安装，另需把 root relay 加入列表并新设独立 console entry，**不得把既有 `human-eye-live` 默默改指向新能力**。若先直接 `python absolute/path/human_eye_llm_stdio.py`，此配置改动不必要。客户端 MCP 注册是后续部署项；当前没有安装/改注册。旧 addon、production_server、mcp_transport、router、hooks、已验收引擎文件都不需要为这个方案修改。

必须明确后才能声称完整完成的事项：

- **绑定来源与变化责任**：实际 scene/view_layer、对象稳定 ID、reference frame、CF deployment 从哪一个明确配置/已有场景获取；谁声明 NONE / TRANSFORM / VERTICES / UNITS / TOPOLOGY / APPEARANCE。新 API 要求每对象 CaptureChange；target topology/appearance 必须开新 session。若允许 UI/其他工具在 observation 和 action 间任意改场景，又省略变化声明，入口就不能保证复用状态正确。应先限定首版 single-owner episode，而非恢复全场景防御扫描。
- **学习反馈来源**：L 需要真实 view PNG 评估，不能把 transport delivered 当 pixel_pass；A 需真实 action outcome。缺少反馈来源可明确只支持 F/G/NONE 的某个测试，但不得以此算全 L 能力验收。
- **GUI pump 资格**：真实主线程timer调度、UI可响应、空闲CPU、1024×512或 before+after 大包、socket非阻塞部分写；headless smoke无法覆盖。新桥在当前主线程 GPU 上下文是否可正常调用已验收renderer需验证，不靠 addon 安装文件推断。
- **资源/结束语义**：结束session或停止bridge时在主线程 close renderer/model/controller、释放 pending buffers/socket；不能每call生灭worker，也不能把停止relay等同已证明Blender资源释放。仅单client/串行episode的首版应公开这一合同，无需新增多租户框架。
- **MCP真实交付**：CPU byte equivalence可先做；最后须通过真实宿主看到原生 image blocks 和正确 AO/attachment 对应，不能拿文件路径、控制台 base64 或“已生成图”替代宿主可见图片。宿主后段若重编码/转发由宿主决定，桥不声称控制它。

以上是接口与计量边界，不是新算法优化任务。没有理由重开已验收的 BC/CF/VG 优化循环；先完成同责入口资格，再按根侧事前冻结的成本门验收一次。
