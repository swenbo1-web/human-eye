"""Run the original two-scene CF cost boundaries through the production I path."""

from contextlib import ExitStack
from dataclasses import dataclass
import gzip
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import sys
from time import perf_counter_ns
from types import ModuleType, SimpleNamespace
from zipfile import ZIP_STORED, ZipFile

import numpy as np

from human_eye_fast import (
    BlenderRadicalSession, CaptureChange, Goal, ObservationRequest, ReferenceFrame,
    ViewFeedback, load_cf_deployment,
)
from human_eye_fast.fast_affordance_out import ImageFact, _image, _row, public_schema
from verification.cf_report import ARMS, ORDERS, SEEDS, _action_report, _bootstrap, _time_report, _view_report


ROOT = Path(__file__).resolve().parents[3]
SCHEMA = public_schema()
COLUMNS = {name: {column: index for index, column in enumerate(columns)}
           for name, columns in SCHEMA["columns"].items()}
CANONICAL_ROLES = {"V": ("view",), "before": ("before",), "A": ("before", "after")}


def _write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, allow_nan=False, indent=2) + "\n",
                    encoding="utf-8", newline="\n")


def _compact(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":")).encode()


def _digest(value):
    return sha256(value).hexdigest()


def _path(value):
    return ROOT / value


def _rows(document):
    return document[COLUMNS["package"]["observations"]]


def _result(document):
    return document[COLUMNS["package"]["outcome"]]


def _normalize(payload, roles, ids, *, action_id=None, drop_prediction=False):
    """Normalize only observation, attachment and action IDs by known roles."""
    document = json.loads(payload)
    package = COLUMNS["package"]
    obs, image, outcome = COLUMNS["observation"], COLUMNS["image"], COLUMNS["outcome"]
    assert document[package["version"]] == SCHEMA["versions"]["candidate"]
    assert document[package["length_unit"]] == "m"
    assert len(roles) == len(ids)
    for row, role, original in zip(_rows(document), roles, ids, strict=True):
        assert row[obs["observation_id"]] == original
        row[obs["observation_id"]] = role
        graphic = row[obs["image"]]
        if graphic is not None:
            assert graphic[image["path"]] == f"{original}.png"
            graphic[image["path"]] = f"{role}.png"
    measured = _result(document)
    if action_id is None:
        assert measured is None
    else:
        assert measured[outcome["action_id"]] == action_id
        assert measured[outcome["before_observation_id"]] == ids[0]
        assert measured[outcome["after_observation_id"]] == ids[1]
        measured[outcome["action_id"]] = "apply"
        measured[outcome["before_observation_id"]] = "before"
        measured[outcome["after_observation_id"]] = "after"
        if drop_prediction:
            measured[outcome["predicted_delta_m"]] = None
    return document


def _media_entries(inputs, archives, stack):
    readers = [stack.enter_context(ZipFile(BytesIO(inputs.track(_path(path))))) for path in archives]
    index = {name: reader for reader in readers for name in reader.namelist()}

    def read(name):
        return index[name].read(name)

    assert json.loads(read("ao-schema.json")) == json.loads(_compact(SCHEMA))
    return read


def _audit_entries(inputs, archives, views, actions):
    views_by_id = {(row["id"], arm): row for arm in ARMS for row in views[arm]}
    action_ids = {row["id"] for row in actions}
    view_proof, action_features = {}, {}
    for archive in archives:
        with gzip.GzipFile(fileobj=BytesIO(inputs.track(_path(archive)))) as stream:
            for line in stream:
                row = json.loads(line)
                key = row["id"], row.get("arm")
                if key in views_by_id:
                    audit, score = row["audit"], row["score"]
                    for field in ("png_sha256", "candidate", "selected_rays", "rays", "native_stop", "witness"):
                        assert row[field] == views_by_id[key][field]
                    assert score["passed"] == row["success"]
                    assert score["safe"] == row["safe"] == (score["pixel_success"] and row["native_stop"])
                    assert score["png_sha256"] == row["png_sha256"]
                    ordered_candidates = tuple(dict.fromkeys(ray["candidate"] for ray in audit["trace"]))
                    view_proof[key] = {
                        "pixel_pass": score["pixel_success"], "metadata": audit["metadata"],
                        "order": tuple(audit["order"]), "ray_counts": tuple(
                            int(sum(ray["candidate"] == index for ray in audit["trace"]))
                            for index in ordered_candidates
                        ),
                    }
                elif row["id"] in action_ids:
                    action_features[row["id"]] = np.asarray(row["features"], dtype=np.float64)
    assert view_proof.keys() == views_by_id.keys()
    assert action_features.keys() == action_ids
    return view_proof, action_features


def _bytes_equal(left, right):
    return (left.dtype, left.shape, left.tobytes()) == (right.dtype, right.shape, right.tobytes())


class _ModelReset:
    """Restore and verify the original non-wrapping active-prefix trajectory."""

    def __init__(self, model, deployed):
        self.model = model
        self.view_weights = deployed.v_weights
        self.action_weights = deployed.a_weights
        self.view_bank = deployed.v_keys, deployed.v_values, deployed.v_known
        self.action_bank = deployed.a_keys, deployed.a_values, deployed.a_known
        assert self._prefix_matches(model.views, self.view_bank, 0)
        assert self._prefix_matches(model.actions, self.action_bank, 0)
        assert _bytes_equal(model.view_head.weights, self.view_weights)
        assert _bytes_equal(model.action_head.weights, self.action_weights)

    @staticmethod
    def _prefix_matches(bank, expected, appended):
        count = len(expected[0])
        return (count == 240 and count + 1 < bank.capacity and bank.writes == count + appended
                and all(_bytes_equal(actual[:count], target) for actual, target
                        in zip((bank.keys, bank.values, bank.known), expected, strict=True)))

    def restore(self):
        model = self.model
        np.copyto(model.view_head.weights, self.view_weights)
        np.copyto(model.action_head.weights, self.action_weights)
        model.views.writes = len(self.view_bank[0])
        model.actions.writes = len(self.action_bank[0])
        assert self._prefix_matches(model.views, self.view_bank, 0)
        assert self._prefix_matches(model.actions, self.action_bank, 0)

    def verify_view(self, index, safe, rays, arm):
        model = self.model
        assert self._prefix_matches(model.views, self.view_bank, 1)
        assert self._prefix_matches(model.actions, self.action_bank, 0)
        assert _bytes_equal(model.action_head.weights, self.action_weights)
        slot = len(self.view_bank[0])
        assert np.flatnonzero(model.views.known[slot]).tolist() == [index]
        assert model.views.values[slot, index].tolist() == [safe, rays]
        expected = model.view_head.clone()
        np.copyto(expected.weights, self.view_weights)
        if arm == "L":
            expected.learn_view(model.views.keys[slot, index], safe)
        assert _bytes_equal(model.view_head.weights, expected.weights)

    def verify_action(self, features, meters, delta, learned):
        model = self.model
        assert self._prefix_matches(model.views, self.view_bank, 0)
        assert self._prefix_matches(model.actions, self.action_bank, int(learned))
        assert _bytes_equal(model.view_head.weights, self.view_weights)
        expected = model.action_head.clone()
        np.copyto(expected.weights, self.action_weights)
        if learned:
            slot = len(self.action_bank[0])
            assert _bytes_equal(model.actions.keys[slot], features)
            residual = delta / meters - features[1]
            assert model.actions.known[slot].tolist() == [True]
            assert model.actions.values[slot].tolist() == [residual]
            expected.learn_action(features, residual)
        assert _bytes_equal(model.action_head.weights, expected.weights)


def _make_session(native, deployed, stack, clock):
    started = clock()
    goal = Goal(*native.targets, 0., 0.)
    generations = dict.fromkeys(native.objects, 1)
    session = stack.enter_context(BlenderRadicalSession(
        native.scene, native.scene.view_layers[0], native.objects, goal, generations,
        reference=ReferenceFrame(0, 1, native.rest), deployment=deployed,
    ))
    if native.key is not None:
        session.prepare_relative_basis(native.key.name)
    return session, clock() - started


@dataclass(frozen=True)
class _Attempt:
    view_ao: bytes
    view_png: bytes
    before_ao: bytes
    before_png: bytes
    joint_ao: bytes
    after_png: bytes
    started: int
    middle: int
    ended: int
    audit: object
    action_meters: float | None
    ticket_consumed: bool

    def media(self):
        return {"view.ao.json": self.view_ao, "view.png": self.view_png,
                "before.ao.json": self.before_ao, "before.png": self.before_png,
                "joint.ao.json": self.joint_ao, "after.png": self.after_png}


def _run_f(renderer, view, action, model, reference, baseline_arm, clock):
    # Keep the original call boundary, old renderer reuse and G work.
    started = clock()
    image, payload, _ = view.run(renderer, model, "F")
    middle = clock()
    result = action.run(renderer, baseline_arm, constant=reference)
    ended = clock()
    return _Attempt(payload, image.png, result.before_payload, result.before_png.png,
                    result.after_payload, result.after_png.png, started, middle, ended,
                    image.metadata, None, False)


def _run_i(view, action, command, view_request, before_request, after_request, action_id,
           arm, baseline_arm, view_changes, action_changes, after_changes, feedback, clock):
    started = clock()
    view_result = view.observe(view_request, changes=view_changes)
    view.view_feedback(view_result.view_ticket, feedback)
    middle = clock()
    before = action.observe(before_request, changes=action_changes)
    plan = action.predict_action(before.observation_id, action_id, command,
                                 predictor="L" if arm == "L" else baseline_arm)
    after = action.execute(plan, after_request, changes=after_changes)
    if arm == "L":
        action.action_feedback(after.action_ticket)
    ended = clock()
    return _Attempt(
        view_result.ao_bytes, view_result.attachments[feedback.attachment_key],
        before.ao_bytes, before.attachments[f"{before.observation_id}.png"],
        after.ao_bytes, after.attachments[f"{after.observation_id}.png"],
        started, middle, ended, view_result.view_audit,
        after.action_ticket._meters if after.action_ticket is not None else None,
        view_result.view_ticket._consumed and (after.action_ticket._consumed if arm == "L" else
                                              after.action_ticket is None),
    )


def _prove_view(attempt, expected, evidence, view_id, expected_png):
    assert attempt.view_png == expected_png
    assert _digest(attempt.view_png) == expected["png_sha256"]
    doc = _normalize(attempt.view_ao, CANONICAL_ROLES["V"], (view_id,))
    observation, = _rows(doc)
    columns = COLUMNS["observation"]
    archived_selection = evidence["metadata"]["selection"]
    if expected["arm"] == "F":
        selection = attempt.audit["selection"]
        assert selection == archived_selection
        assert attempt.audit["witness"] == expected["witness"]
    else:
        audit = attempt.audit
        assert (audit.canonical_index, audit.direction, audit.total_rays, audit.native_stop, audit.order) == (
            expected["candidate"], tuple(archived_selection["direction"]), expected["rays"],
            expected["native_stop"], evidence["order"],
        )
        actual = [(list(probe.direction), probe.ray_count, probe.aperture_taps, probe.target_support)
                  for probe in audit.probes]
        expected_probes = [(probe["direction"], probe["ray_count"], probe["aperture_taps"],
                            probe["target_support"]) for probe in archived_selection["probes"]]
        assert actual == expected_probes
        assert tuple(probe.ray_count for probe in audit.probes) == evidence["ray_counts"]
        assert attempt.ticket_consumed
    assert observation[columns["frame_id"]] == expected["frame_id"]
    indices = {key: index for index, key in enumerate(doc[COLUMNS["package"]["object_ids"]])}
    archived_image = _image(_row, ImageFact("view.png", SimpleNamespace(metadata=evidence["metadata"])), indices)
    assert _compact(observation[columns["image"]]) == _compact(archived_image)
    observation[columns["image"]] = None
    return _digest(_compact(doc))


def _prove_action(attempt, expected, archived, ids, action_id, arm):
    assert attempt.before_png == archived["before_png"]
    assert attempt.after_png == archived["after_png"]
    before = _normalize(attempt.before_ao, CANONICAL_ROLES["before"], ids[:1])
    assert _compact(before) == archived["before_ao"]
    joint = _normalize(attempt.joint_ao, CANONICAL_ROLES["A"], ids, action_id=action_id)
    assert _compact(_rows(joint)[0]) == _compact(_rows(before)[0])
    outcome = _result(joint)
    fields = COLUMNS["outcome"]
    assert outcome[fields["measured_delta_m"]] == expected["measured_delta_m"]
    predicted = outcome[fields["predicted_delta_m"]]
    if arm == "L":
        assert attempt.action_meters == expected["feature_scale_m"]
        assert _compact(joint) == archived["joint_ao_L"]
    else:
        # The old quality table computed G in the full feature path. Compare
        # this narrow prediction to the paired original F timing path instead.
        outcome[fields["predicted_delta_m"]] = None
        assert _compact(joint) == archived["joint_ao_without_prediction"]
    return predicted


def _legacy_view_features(view, witness):
    """Reconstruct the old V input from the completed F capture without another capture or draw."""
    from mathutils import Vector
    from human_eye_fast.cerebellar_flash import FIXED_ORDER
    from human_eye_fast.raycast_saccade_gpu import _EPS32, _FIXED, _ORBIT, _transverse

    point_a, point_b = witness["point_a"], witness["point_b"]
    axis = (Vector(point_b) - Vector(point_a)).normalized()
    u = _transverse(_FIXED, axis)
    u = u.normalized() if u.length_squared > _EPS32**2 else axis.orthogonal().normalized()
    v = axis.cross(u).normalized()
    directions = tuple((c * u + s * v).normalized() for c, s in _ORBIT)
    meshes = {key: view.bridge.get(key) for key in view.native.objects}
    # Only the original features callback is needed. Supply the original
    # fixed-order response here because inference is verified by the real arm.
    no_prediction = SimpleNamespace(rank_view=lambda key, arm: FIXED_ORDER)
    surface = SimpleNamespace(point_a=point_a, point_b=point_b)
    rank, features = view.ranker(meshes, surface, no_prediction, "L")
    rank(directions)
    result, = features
    return result


def _record_proof(attempt, out, media, raw_sample, arm, *, save):
    outputs = attempt.media()
    raw_sample["proof_sha256"] = {name: _digest(data) for name, data in outputs.items()}
    if save:
        for name, data in outputs.items():
            media.writestr(f"{out}/{arm}/{name}", data)


def _inputs_for_episode(media, view, action, view_rows):
    a_base = action.episode_id
    a_before = media(f"{a_base}/before.json")
    a_joint = media(f"{a_base}/after.json")
    views = {}
    for arm in ARMS:
        expected = media(f"{view.episode_id}/{arm}.png")
        assert _digest(expected) == view_rows[arm]["png_sha256"]
        views[arm] = expected
    archive = {
        "before_ao": _compact(_normalize(a_before, CANONICAL_ROLES["before"], ("before",))),
        "joint_ao_L": _compact(_normalize(a_joint, CANONICAL_ROLES["A"], ("before", "after"), action_id="apply")),
        "joint_ao_without_prediction": _compact(_normalize(
            a_joint, CANONICAL_ROLES["A"], ("before", "after"), action_id="apply", drop_prediction=True,
        )),
        "before_png": media(f"{a_base}/before.png"),
        "after_png": media(f"{a_base}/after.png"),
    }
    return views, archive


def _run_episode(stack, renderer, view_spec, action_spec, model, frozen, deployed,
                 scored, audit, features, read_media, proof_zip, raw_arms, legacy, seed_index, i, *, clock):
    from verification.cf_fixtures import build_fixture
    from verification.cf_native import _CHANGES, materialize
    from human_eye_fast import MeshChange, SetShapeKey

    view_native = stack.enter_context(materialize(build_fixture(view_spec)))
    action_native = stack.enter_context(materialize(build_fixture(action_spec)))
    assert tuple(action_native.objects) == action_native.targets
    original_view, original_action = legacy.ViewEpisode(view_native), legacy.ActionEpisode(action_native)
    command = SetShapeKey(original_action.command.key_name, original_action.command.value)
    view, v_init_ns = _make_session(view_native, deployed, stack, clock)
    action, a_init_ns = _make_session(action_native, deployed, stack, clock)
    view_reset, action_reset = _ModelReset(view._model, deployed), _ModelReset(action._model, deployed)
    view_changes = dict.fromkeys(view_native.objects, CaptureChange(_CHANGES))
    action_changes = dict.fromkeys(action_native.objects, CaptureChange(_CHANGES))
    after_changes = dict.fromkeys(action_native.objects, CaptureChange(MeshChange.VERTICES | MeshChange.TRANSFORM))
    measured = clock is perf_counter_ns
    episode = {"ordinal": i, "view_id": view_spec.episode_id, "view_family": view_spec.family,
               "action_id": action_spec.episode_id, "action_family": action_spec.family, "samples": []}
    if measured:
        episode["initialization_ns"] = {"I_view": v_init_ns, "I_action": a_init_ns}
    expected_view = {arm: scored["views"][arm][i] for arm in ARMS}
    expected_action = scored["actions"][i]
    assert expected_action["id"] == action_spec.episode_id
    assert all(row["id"] == view_spec.episode_id for row in expected_view.values())
    view_pngs, action_archive = _inputs_for_episode(read_media, view_spec, action_spec, expected_view)
    v_evidence = {arm: audit[view_spec.episode_id, arm] for arm in ARMS}
    expected_v_key = None
    for repeat in range(10 if measured else 1):
        order = ORDERS[(seed_index + i + repeat) % len(ORDERS)]
        sample = {"repeat": repeat, "order": order, "arms": {}}
        if measured:
            sample["warmup"] = repeat < 5
        by_arm = {}
        keys_by_arm = {}
        for arm in order:
            original_action.reset()
            arm_view = expected_view[arm]
            evidence = v_evidence[arm]
            if arm == "F":
                view_id, before_id, after_id, act_id = "view", "before", "after", "apply"
                attempt = _run_f(renderer, original_view, original_action, model, frozen.reference,
                                 frozen.reference_arm, clock)
            else:
                view_reset.restore()
                action_reset.restore()
                tag = f"{repeat}-{arm}"
                view_id, before_id, after_id, act_id = (f"{role}-{tag}" for role in ("view", "before", "after", "apply"))
                view_request = ObservationRequest(view_id, view_spec.mode, arm)
                before_request = ObservationRequest(before_id, "NATURAL", "F")
                after_request = ObservationRequest(after_id, "NATURAL", "F")
                feedback = ViewFeedback(view_id, f"{view_id}.png", arm_view["candidate"], evidence["pixel_pass"])
                attempt = _run_i(view, action, command, view_request, before_request,
                                 after_request, act_id, arm, frozen.reference_arm, view_changes,
                                 action_changes, after_changes, feedback, clock)
            row = {}
            if measured:
                row.update({
                    "t0_ns": attempt.started, "t1_ns": attempt.middle, "t2_ns": attempt.ended,
                    "total_ns": attempt.ended - attempt.started, "V_ns": attempt.middle - attempt.started,
                    "A_ns": attempt.ended - attempt.middle,
                })
            quality_error = None
            try:
                view_facts = _prove_view(attempt, arm_view, evidence, view_id, view_pngs[arm])
                predicted = _prove_action(attempt, expected_action, action_archive, (before_id, after_id),
                                          act_id, arm)
                if arm != "F":
                    view_reset.verify_view(arm_view["candidate"], arm_view["safe"], arm_view["selected_rays"], arm)
                    action_reset.verify_action(features[action_spec.episode_id], attempt.action_meters,
                                               expected_action["measured_delta_m"], arm == "L")
                    keys_by_arm[arm] = view_reset.model.views.keys[len(view_reset.view_bank[0])].copy()
                    row["v_features_sha256"] = _digest(keys_by_arm[arm].tobytes())
                elif expected_v_key is None:
                    expected_v_key = _legacy_view_features(original_view, attempt.audit["witness"])
                row.update({"view_fact_sha256": view_facts, "predicted_delta_m": predicted})
            except AssertionError as error:
                import traceback

                quality_error = {"error": str(error), "traceback": traceback.format_exc()}
                row["equivalence_failure"] = quality_error
            _record_proof(attempt, f"{i:02d}/{repeat:02d}", proof_zip, row, arm,
                          save=not measured or repeat == 5 or quality_error is not None)
            raw_arms.write(_compact({"ordinal": i, "repeat": repeat, "order": order, "arm": arm, **row}).decode() + "\n")
            raw_arms.flush()
            sample["arms"][arm] = row
            by_arm[arm] = attempt
            del attempt
        if all("view_fact_sha256" in row for row in sample["arms"].values()):
            rows = sample["arms"]
            if len({row["view_fact_sha256"] for row in rows.values()}) != 1:
                sample["paired_equivalence_failure"] = "Standalone view AO differs beyond image and role ID"
            elif float.hex(rows["F"]["predicted_delta_m"]) != float.hex(rows["R"]["predicted_delta_m"]):
                sample["paired_equivalence_failure"] = "Production G prediction differs from original timed G"
            elif any(not _bytes_equal(actual, expected_v_key) for actual in keys_by_arm.values()):
                sample["paired_equivalence_failure"] = "Production V feature key differs from the legacy F capture"
                sample["legacy_v_features"] = expected_v_key.tolist()
                sample["production_v_features"] = {arm: key.tolist() for arm, key in keys_by_arm.items()}
            sample["legacy_v_features_sha256"] = _digest(expected_v_key.tobytes())
            if "paired_equivalence_failure" in sample and measured and repeat != 5:
                for arm, attempt in by_arm.items():
                    for name, data in attempt.media().items():
                        proof_zip.writestr(f"{i:02d}/{repeat:02d}/{arm}/{name}", data)
                del attempt
        by_arm.clear()
        episode["samples"].append(sample)
    return episode


def _legacy_native(inputs, archive_path):
    """Load old F native classes and controller into worker-local modules."""
    from verification import cf_native

    files = {
        "control": "human_eye_fast/control.py",
        "native": "verification/cf_native.py",
    }
    with ZipFile(BytesIO(inputs.track(archive_path))) as archive:
        source = {name: archive.read(path) for name, path in files.items()}
    # Check that the historical verification adapter still binds the actual
    # fixtures and kernels present in the current registered source closure.
    assert (ROOT / files["native"]).read_bytes() == source["native"]
    control = ModuleType("human_eye_fast._old_cf_frozen_control")
    control.__package__ = "human_eye_fast"
    sys.modules[control.__name__] = control
    exec(compile(source["control"], f"{archive_path}!{files['control']}", "exec"), control.__dict__)
    legacy = ModuleType("verification._old_cf_frozen_native")
    legacy.__package__ = "verification"
    sys.modules[legacy.__name__] = legacy
    exec(compile(source["native"], f"{archive_path}!{files['native']}", "exec"), legacy.__dict__)
    for name in ("Action", "BlenderControl", "Goal", "SetShapeKey", "Translate"):
        setattr(legacy, name, getattr(control, name))
    assert legacy.materialize.__module__ != cf_native.materialize.__module__
    return legacy, {files[name]: _digest(raw) for name, raw in source.items()}


def _untimed():
    return 0


def _run(manifest_path, out_dir, process_index, clock):
    import bpy
    from human_eye_fast.raycast_saccade_gpu import VGRenderer
    from verification.cf_experiment import Inputs

    assert bpy.app.background
    measured = clock is perf_counter_ns
    manifest = json.loads(Path(manifest_path).read_bytes())
    config = manifest["seeds"][process_index]
    seed = int(config["seed"])
    assert SEEDS[process_index] == seed and config["process_index"] == process_index
    old = config["old_cf"]
    out = Path(out_dir)
    out.mkdir(parents=True)
    inputs = Inputs(out)
    specs = inputs.specs(_path(old["evaluation_manifest"]), seed, "evaluation")
    assert all(len(specs[head]) == 60 for head in ("V", "A"))
    assert _path(old["seal_record"]).resolve() == _path(config["snapshot"]).with_suffix(".json").resolve()
    frozen = inputs.frozen(_path(config["snapshot"]))
    assert frozen.reference_arm == "G"
    deployed = load_cf_deployment(BytesIO(inputs.track(_path(config["deployment"]))))
    scored = json.loads(inputs.track(_path(old["quality_summary"])))
    if measured:
        historical = json.loads(inputs.track(_path(old["historical_timing"])))
        historical_report, _ = _time_report(historical["episodes"], seed=seed)
    audit, features = _audit_entries(inputs, old["records_archives"], scored["views"], scored["actions"])
    baseline_sources = _path(old["baseline_sources"])
    legacy, frozen_source_members = _legacy_native(inputs, baseline_sources)
    renderer = VGRenderer()
    model = frozen.session()
    episodes = []
    raw_name = "timing.jsonl" if measured else "qualification.jsonl"
    arm_name = "arm_timing.jsonl" if measured else "arm_qualification.jsonl"
    try:
        with (ExitStack() as archives,
              ZipFile(out / "public_proof.zip", "w", compression=ZIP_STORED) as proof_zip,
              (out / raw_name).open("w", encoding="utf-8", newline="\n") as raw,
              (out / arm_name).open("w", encoding="utf-8", newline="\n") as raw_arms):
            media = _media_entries(inputs, old["media_archives"], archives)
            proof_zip.writestr("ao-schema.json", _compact(SCHEMA))
            for i, (view, action) in enumerate(zip(specs["V"], specs["A"], strict=True)):
                with ExitStack() as fixtures:
                    row = _run_episode(fixtures, renderer, view, action, model, frozen, deployed, scored,
                                       audit, features, media, proof_zip, raw_arms, legacy, process_index, i,
                                       clock=clock)
                raw.write(_compact(row).decode() + "\n")
                raw.flush()
                episodes.append(row)
                if i % 10 == 9:
                    stage = "cost" if measured else "quality prequalification"
                    print(f"Old CF production {stage} seed {seed}: {i + 1}/60", flush=True)
    finally:
        model.close()
        renderer.close()
    view_quality, view_samples, view_ids = _view_report(scored["views"])
    action_quality, action_samples, action_ids = _action_report(scored["actions"])
    assert ([row["view_id"] for row in episodes], [row["action_id"] for row in episodes]) == (view_ids, action_ids)
    failures = []
    for row in episodes:
        for sample in row["samples"]:
            for arm in sample["order"]:
                if problem := sample["arms"][arm].get("equivalence_failure"):
                    failures.append({"ordinal": row["ordinal"], "repeat": sample["repeat"], "arm": arm, **problem})
            if problem := sample.get("paired_equivalence_failure"):
                failures.append({"ordinal": row["ordinal"], "repeat": sample["repeat"], "error": problem})
    status = "UNVERIFIED" if failures else "PASS"
    result = {
        "scope": "Original 60 paired two-scene episodes per seed",
        "seed": seed, "status": status, "timings_collected": measured,
        "roles": {"F": "Original ViewEpisode F then original ActionEpisode G",
                  "R": "Production deployment v1 view R then production action G",
                  "L": "Production deployment v1 view L then production action L"},
        "responsibility": [
            "F replays the exact old path with a reused VG renderer. Production uses one session and renderer per independent scene.",
            "Production performs its required public binding, ticket consumption, and attachments; old F retains its original work.",
            "The A segment observes before with F, uses an explicit prediction and actual action, then publishes joint AO and actual before/after PNG.",
            "The old implementation predicted before rendering the before image. The production API observes and publishes before the bound prediction.",
            "Both old paths evaluate from restored seed state. The production V and A models are independent by scene, so V feedback cannot change the A head used for this episode.",
        ],
        "equivalence_failure_count": len(failures), "equivalence_failures": failures,
        "quality_reference_matched": not failures, "quality_reference": {"view": view_quality, "action": action_quality},
        "original_executed_members": {"archive": str(baseline_sources), "member_sha256": frozen_source_members},
        "case_count": len(episodes),
    }
    if measured:
        report, samples = _time_report(episodes, view_ids, action_ids, seed=seed)
        costs_pass = all(item["all"]["L"]["passed"] for item in report.values())
        status = "UNVERIFIED" if failures else "PASS" if costs_pass else "FAIL"
        result.update({
            "status": status, "qualified_cost_gate": status == "PASS",
            "observed_cost_gate_if_equivalent": costs_pass,
            "timing": report, "historical_timing_reference_only": historical_report,
            "paired_bootstrap": _bootstrap([view_samples], [action_samples], [samples]),
            "warm_repeats": 5, "measured_repeats": 5,
            "evidence": "timing.jsonl has all absolute clocks and proof hashes; public_proof.zip retains first measured and all mismatching outputs",
        })
        result["responsibility"].append(
            "Recorded timestamps span only native service and feedback, excluding proof, offline score access and archive writes."
        )
    else:
        result["evidence"] = "qualification.jsonl and public_proof.zip retain each untimed public-result proof"
    _write(out / "summary.json", result)
    return result


def qualify(manifest_path, out_dir, process_index):
    """Verify every deployed legacy view/action arm once without interval clocks."""
    return _run(manifest_path, out_dir, process_index, _untimed)


def run(manifest_path, out_dir, process_index):
    """Run the single registered measured legacy CF regression for this seed."""
    return _run(manifest_path, out_dir, process_index, perf_counter_ns)


def pooled(results, output):
    """Old CF pooled descriptive estimates without overriding the per-seed gates."""
    samples = []
    for directory, seed in zip(results, SEEDS, strict=True):
        path = Path(directory)
        summary = json.loads((path / "summary.json").read_bytes())
        assert summary["seed"] == seed
        episodes = [json.loads(line) for line in (path / "timing.jsonl").read_bytes().splitlines()]
        samples.append(_time_report(episodes, seed=seed)[1])
    _write(Path(output), _bootstrap([], [], samples))
