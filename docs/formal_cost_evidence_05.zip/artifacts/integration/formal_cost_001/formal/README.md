# 统一 Blender 正式成本结果

本轮结果为 **UNVERIFIED**，提交主干独立复审。正式批次沿用冻结的分种子时延门、旧 CF 原双场景门和资源观测门。聚合描述单列，历史 B/B 失败保留。 [登记清单](manifest.json) · [机器汇总](summary.json)

| 种子 | 同场景时延 | 旧 CF | 托管资源 | RSS/DXGI |
| --- | --- | --- | --- | --- |
| 20261105 | [PASS](latency-20261105/result/summary.json) | [PASS](old-cf-20261105/result/summary.json) | [UNVERIFIED](managed-comparison-20261105.json) | [PASS](os-comparison-20261105.json) |
| 79463 | [PASS](latency-79463/result/summary.json) | [PASS](old-cf-79463/result/summary.json) | [UNVERIFIED](managed-comparison-79463.json) | [PASS](os-comparison-79463.json) |
| 310519 | [PASS](latency-310519/result/summary.json) | [PASS](old-cf-310519/result/summary.json) | [UNVERIFIED](managed-comparison-310519.json) | [PASS](os-comparison-310519.json) |

RSS/DXGI 只比较预定阶段点和有效窗口样本的观测最大值。时延门逐种子、逐段判定，资源门逐种子、逐案例判定。完整原始时序、评分输入、已加载状态、进程读数和失败都保存在登记目录。
