"""Read the retained native results and correct the descriptive rollup key."""

from collections import Counter, defaultdict
import json
from pathlib import Path
import sys

import numpy as np


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
FORMAL = HERE.parent / "formal"
sys.path.insert(0, str(ROOT))

from artifacts.integration.formal_cost_001 import report
from artifacts.integration.method_diagnostic_001.runtime_identity import write_json


BOUNDARIES = {"before": ("t0", "t1"), "action": ("t1", "t2"), "feedback": ("t2", "t3"),
              "next": ("t3", "t4"), "continuous_total": ("t0", "t4")}


def _pooled(out, seeds):
    results = {}
    for segment in BOUNDARIES:
        rows = [case for seed in seeds
                for case in report._summary(out / f"latency-{seed}")["segments"][segment]["by_case"].values()]
        p95 = {role: float(np.quantile([case["arms"][role]["median_ns"] for case in rows], .95,
                                      method="linear")) for role in ("B", "I")}
        results[segment] = {"case_seed_rows": len(rows), "p95_ns": p95, "I_over_B": p95["I"] / p95["B"]}
    return results


def _recompute(out):
    manifest = json.loads((out / "manifest.json").read_bytes())
    results = {}
    for seed in (row["seed"] for row in manifest["seeds"]):
        directory = out / f"latency-{seed}"
        records = defaultdict(list)
        pairs = Counter()
        with (directory / "result/intervals.jsonl").open(encoding="utf-8") as stream:
            for line in stream:
                row = json.loads(line)
                case, role, pair = row["ordinal"], row["role"], row["pair"]
                pairs[case, pair, role] += 1
                assert row["warmup"] == (pair < 5)
                for segment, (left, right) in BOUNDARIES.items():
                    clocks = row["counter_ns"]
                    duration = clocks[right] - clocks[left]
                    assert duration == row["ns"][segment]
                    if pair >= 5:
                        records[segment, case, role].append(duration)
        assert len(pairs) == 24 * 36 * 2 and set(pairs.values()) == {1}
        saved = report._summary(directory)
        seed_results = {}
        for segment in BOUNDARIES:
            p95 = {}
            for role in ("B", "I"):
                cases = [records[segment, ordinal, role] for ordinal in range(24)]
                assert all(len(row) == 31 for row in cases)
                p95[role] = float(np.quantile([np.median(row) for row in cases], .95, method="linear"))
            ratio = p95["I"] / p95["B"]
            assert p95 == saved["segments"][segment]["p95_ns"]
            assert ratio == saved["segments"][segment]["I_over_B"]
            seed_results[segment] = {"p95_ns": p95, "I_over_B": ratio}
        results[str(seed)] = seed_results
    return results


def main():
    write_json(FORMAL / "independent-latency-recompute.json", {
        "source": "retained absolute counter stamps and all registered raw rows",
        "measured_arm_rows": 3 * 24 * 31 * 2,
        "warm_arm_rows": 3 * 24 * 5 * 2,
        "per_seed": _recompute(FORMAL),
        "report_correction": "The registered postprocessor used the numeric cases count for its descriptive rollup. "
                             "The corrected reader uses by_case. No raw results or gate calculations were changed.",
    })
    report._latency_pooled = _pooled
    report.summarize(FORMAL)


if __name__ == "__main__":
    main()
