"""Register all inputs and run the approved serial integration-cost batch once."""

from argparse import ArgumentParser
from hashlib import sha256
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import traceback
from zipfile import ZIP_DEFLATED, ZipFile


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT))

from artifacts.integration.method_diagnostic_001.runtime_identity import (
    THREAD_ENV, clock_anchor, effective_environment, identity, native_fingerprint, write_json,
)


BLENDER = Path(r"C:\Program Files\Blender Foundation\Blender 5.2\blender.exe")
PYTHON = Path(r"D:\human eye\venv\Scripts\python.exe")
METHOD = HERE.parent / "method_diagnostic_001"
PREVIOUS = HERE.parent / "preflight_002"
FUNCTIONAL = HERE.parent / "production_functional_001"
PROTOCOL = ROOT / "docs/INTEGRATION_COST_PROTOCOL.md"
DECISION = ROOT / "docs/radical_acceptance_method_diagnostic.json"
BASELINE_REVIEW = ROOT / "docs/radical_acceptance_integration_rework.json"
SEEDS = ("20261105", "79463", "310519")
FORMAL = HERE / "formal"
LIMITS = {"integration_latency_ratio": 1.05, "old_cf_latency_ratio": 1.10,
          "managed_current_delta_bytes": 262_144, "managed_peak_delta_bytes": 1_048_576,
          "rss_observed_delta_bytes": 8_388_608, "gpu_observed_delta_bytes": 8_388_608}


def read(path):
    return json.loads(path.read_bytes())


def relative(path):
    return path.resolve().relative_to(ROOT).as_posix()


def hash_bytes(payload):
    return sha256(payload).hexdigest()


def snapshot(scope):
    formal_sources = {
        "qualification": [HERE / name for name in ("orchestrate.py", "common.py", "qualify.py")],
        "old-qualification": [HERE / "orchestrate.py", *HERE.glob("old_cf*.py")],
        "formal": list(HERE.glob("*.py")),
    }[scope]
    sources = {*ROOT.glob("human_eye_fast/**/*.py"), *ROOT.glob("verification/**/*.py"),
               *formal_sources, *METHOD.glob("*.py"), *PREVIOUS.glob("*.py"),
               ROOT / "docs/ENGINE_INTEGRATION_API.md", PROTOCOL, DECISION, BASELINE_REVIEW}
    return {relative(path): path.read_bytes() for path in sorted(sources)}


def freeze_checks():
    decision = read(DECISION)
    assert decision["decision"] == "FREEZE_FORWARD_COST_PROTOCOL"
    assert identity(PROTOCOL)["sha256"] == decision["sources"][relative(PROTOCOL)]["sha256"]
    previous = read(FUNCTIONAL / "source-identity.json")
    for path, expected in previous["production_and_verification_sources"].items():
        actual = identity(ROOT / path)
        assert {key: actual[key] for key in ("sha256", "bytes")} == expected, path
    known = read(BASELINE_REVIEW)["sources"]["verification/integration_reference.py"]
    assert identity(ROOT / "verification/integration_reference.py")["sha256"] == known["sha256"]


def _role_inputs(seed, kind):
    if kind in ("old-cf", "old-qualification"):
        paths = list(seed["old_cf"].values())
        paths = [item for value in paths for item in (value if isinstance(value, list) else [value])]
    elif kind == "qualification" and seed["process_index"] == 0:
        path = ROOT / seed["previous_functional_tree"]
        paths = [relative(file) for file in path.rglob("*") if file.is_file()]
    else:
        paths = []
    if kind in ("latency", "managed", "os"):
        for feedback in seed["integration_feedback"].values():
            for row in feedback.values():
                paths.extend((row["visual_path"], row["png_path"]))
    return [seed["snapshot"], seed["deployment"], *paths]


def _seed_specs():
    frozen = read(PREVIOUS / "manifest.json")
    exported = read(FUNCTIONAL / "deployments/summary.json")["seeds"]
    specs = []
    for index, name in enumerate(SEEDS):
        current = frozen["deployments"][index]
        entry = exported[name]["deployment_file"]
        assert str(current["seed"]) == name and identity(ROOT / entry["path"])["sha256"] == entry["sha256"]
        base = ROOT / "artifacts/cf/formal_001" / name
        directories = [base / "evaluation"]
        if index == 0:
            directories.append(base / "evaluation-completion")
        specs.append({
            "process_index": index, "seed": int(name),
            "snapshot": current["sealed_path"], "snapshot_sha256": current["sealed_sha256"],
            "deployment": entry["path"], "deployment_sha256": entry["sha256"],
            "old_cf": {
                "evaluation_manifest": relative(base / "specs/manifest-evaluation.json"),
                "seal_record": relative(base / "seal/frozen.json"),
                "quality_summary": relative(directories[-1] / "summary.json"),
                "media_archives": [relative(folder / "media.zip") for folder in directories],
                "records_archives": [relative(folder / "records.jsonl.gz") for folder in directories],
                "historical_timing": relative(base / "performance/timing.json"),
                "baseline_sources": relative(METHOD / "sources.zip"),
            },
            "previous_functional_tree": relative(FUNCTIONAL / "native_functional_final/result/L") if index == 0 else None,
        })
    return specs


def _attach_prerequisite(seeds, qualification_root, old_qualification_root):
    for directory, names in ((qualification_root, ("common.py", "qualify.py")),
                             (old_qualification_root, ("old_cf.py",))):
        sources = read(directory / "manifest.json")["source_superset"]
        for name in names:
            path = HERE / name
            assert identity(path)["sha256"] == sources[relative(path)], path
    for seed in seeds:
        seed_id = seed["seed"]
        folder = qualification_root / f"qualification-{seed_id}"
        report = read(folder / "process.json")
        assert report["verified_process"], folder
        summary = read(folder / "result/summary.json")
        assert summary["all_cases_passed"] and len(summary["cases"]) == 24
        old = old_qualification_root / f"old-qualification-{seed_id}"
        assert read(old / "process.json")["verified_process"], old
        assert read(old / "result/summary.json")["status"] == "PASS", old
        seed["qualification_reports"] = [relative(folder / "result/summary.json"),
                                         relative(folder / "result/feedback.json"),
                                         relative(folder / "process.json"),
                                         relative(folder / "runtime.json"),
                                         relative(old / "result/summary.json"),
                                         relative(old / "process.json")]
        seed["integration_feedback"] = read(folder / "result/feedback.json")
        for phases in seed["integration_feedback"].values():
            for row in phases.values():
                assert identity(ROOT / row["png_path"])["sha256"] == row["png_sha256"]
                assert identity(ROOT / row["visual_path"])["sha256"] == row["visual_sha256"]


def _layout(kind):
    if kind != "formal":
        return [(kind, index, None) for index in range(3)]
    layout = [(phase, index, None) for phase in ("latency", "old-cf") for index in range(3)]
    for instrument in ("managed", "os"):
        for index in range(3):
            roles = ("B", "I") if index % 2 == 0 else ("I", "B")
            layout.extend((instrument, index, role) for role in roles)
    return layout


def _jobs(kind, out, seeds):
    records = []
    for phase, index, role in _layout(kind):
        seed = seeds[index]
        name = f"{phase}-{seed['seed']}" + (f"-{role}" if role else "")
        folder = out / name
        overrides = {**THREAD_ENV, "PYTHONDONTWRITEBYTECODE": "1",
                     "PYTHONPYCACHEPREFIX": str(folder / "isolated-pycache")}
        args = [str(BLENDER), "--background", "--factory-startup", "--disable-autoexec",
                "--threads", "1", "--python-exit-code", "1", "--python", str(Path(__file__).resolve()),
                "--", "--worker", str(out / "manifest.json"), name]
        inputs = _role_inputs(seed, phase)
        if kind == "formal":
            inputs.extend(seed["qualification_reports"])
        inputs = sorted({*inputs, relative(PROTOCOL), relative(DECISION), relative(PREVIOUS / "manifest.json"),
                         relative(FUNCTIONAL / "source-identity.json"), relative(FUNCTIONAL / "deployments/summary.json")})
        records.append({
            "job_id": name, "kind": phase, "role": role, "process_index": index, "seed": seed["seed"],
            "folder": relative(folder), "argv": args,
            "input_files": {path: identity(ROOT / path)["sha256"] for path in inputs},
            "environment_overrides": overrides,
            "environment_effective": effective_environment({**os.environ, **overrides}),
        })
    return records


def _portable_runtime():
    argv = [str(PYTHON), "-B", "-c", (
        "import json,sys,numpy,PIL;"
        "print(json.dumps({'python':sys.version,'numpy':[numpy.__version__,numpy.__file__],"
        "'pillow':[PIL.__version__,PIL.__file__]}))"
    )]
    return {**read_json_process(argv), "executable": identity(PYTHON), "argv": argv}


def read_json_process(argv):
    return json.loads(subprocess.check_output(argv, cwd=ROOT))


def register(kind, out, qualification_root=None, old_qualification_root=None):
    freeze_checks()
    seeds = _seed_specs()
    if kind == "formal":
        _attach_prerequisite(seeds, qualification_root, old_qualification_root)
    original = read(PREVIOUS / "manifest.json")
    source_bytes = snapshot(kind)
    iterations = [{"pair": pair, "before": f"before-{pair:02}", "after": f"after-{pair:02}",
                   "next": f"next-{pair:02}", "action": f"act-{pair:02}",
                   "next_action": f"next-act-{pair:02}"} for pair in range(38)]
    manifest = {
        "scope": kind, "protocol": identity(PROTOCOL), "pillow_python": str(PYTHON),
        "source_superset": {name: hash_bytes(payload) for name, payload in source_bytes.items()},
        "formal_plans": original["formal_plans"], "seeds": seeds, "iterations": iterations,
        "limits": LIMITS,
        "latency": {"warm_pairs": list(range(5)), "measured_pairs": list(range(5, 36)),
                    "creation_order": "(process_index + case_ordinal) % 2",
                    "execution_order": "(process_index + case_ordinal + pair_index) % 2",
                    "within_interval_observation": "QPC t0..t4 and one next observe/predict boundary; GC callback",
                    "outside_interval_observation": "equal AO/PNG/model/next proof and durable JSON/bytes/NPZ for each role"},
        "resource": {"adapter_description": "NVIDIA GeForce RTX 3060", "adapter_luid": [0, 83164],
                     "node": 0, "interval_ns": 2_000_000, "warm_pairs": list(range(5)), "hot_pair": 5,
                     "lifecycle_pairs": [36, 37], "current_gate_points": [
                         "hot_outputs_held", "hot_outputs_released", "hot_reference_replaced"],
                     "rss_gpu_metric": "observed sampled maximum; t0-pre/stage points and valid periodic hot samples"},
        "prior_b_b_next_failure_unchanged": 1.0768101359922175,
        "runtime_registration": {"blender_executable": identity(BLENDER), "portable": _portable_runtime(),
                                 "platform": platform.platform(), "processor": platform.processor(),
                                 "logical_cpu_count": os.cpu_count()},
    }
    if kind == "formal":
        example_runtime = read(qualification_root / "qualification-20261105/runtime.json")
        keys = ("blender_version", "python_version", "python_executable", "python_dll", "numpy", "gpu")
        expected = {key: example_runtime[key] for key in keys}
        for seed in seeds:
            directory = qualification_root / f"qualification-{seed['seed']}"
            actual = read(directory / "runtime.json")
            assert {key: actual[key] for key in keys} == expected, directory
        manifest["runtime_registration"]["native_expected"] = expected
    manifest["jobs"] = _jobs(kind, out, seeds)
    out.mkdir(parents=True)
    with ZipFile(out / "sources.zip", "x", compression=ZIP_DEFLATED) as archive:
        for name, payload in source_bytes.items():
            archive.writestr(name, payload)
    path = out / "manifest.json"
    write_json(path, manifest)
    print(f"Registered {kind}: {identity(path)['sha256']}", flush=True)
    return path


def _project_imports():
    paths = {Path(raw).resolve() for module in tuple(sys.modules.values())
             if (raw := getattr(module, "__file__", None))}
    paths.add(Path(__file__).resolve())
    return {relative(path): identity(path)["sha256"] for path in sorted(paths)
            if path.is_relative_to(ROOT) and path.is_file()}


def worker(manifest_path, job_id):
    manifest = read(manifest_path)
    job = next(job for job in manifest["jobs"] if job["job_id"] == job_id)
    kind, index = job["kind"], job["process_index"]
    directory = ROOT / job["folder"]
    output = directory / "result"
    sys.dont_write_bytecode = True
    sys.pycache_prefix = os.environ["PYTHONPYCACHEPREFIX"]
    anchor = clock_anchor()
    try:
        if kind == "qualification":
            from artifacts.integration.formal_cost_001.qualify import run
            run(manifest_path, output, index)
        elif kind in ("old-cf", "old-qualification"):
            from artifacts.integration.formal_cost_001 import old_cf
            if kind == "old-cf":
                old_cf.run(manifest_path, output, index)
            else:
                result = old_cf.qualify(manifest_path, output, index)
                if result["status"] != "PASS":
                    raise RuntimeError("Production old CF quality prerequisites failed; see retained result")
        elif kind == "latency":
            from artifacts.integration.formal_cost_001.latency import run
            run(manifest_path, output, index)
        else:
            from artifacts.integration.formal_cost_001.resources import run
            run(manifest_path, output, index, job["role"], kind)
    finally:
        write_json(directory / "project-imports.json",
                   {"scope": "observed project imports at exit", "paths": _project_imports()})
        try:
            write_json(directory / "runtime.json", native_fingerprint(anchor))
        except Exception:
            (directory / "runtime-error.txt").write_text(traceback.format_exc(), encoding="utf-8")


def _inputs_match(inputs):
    return all(identity(ROOT / name)["sha256"] == expected for name, expected in inputs.items())


def _current_source_ids(scope):
    return {name: hash_bytes(payload) for name, payload in snapshot(scope).items()}


def _run_job(job, manifest_path, manifest, registered):
    scope = manifest["scope"]
    if identity(manifest_path) != registered or _current_source_ids(scope) != manifest["source_superset"]:
        raise RuntimeError("Frozen registration or source identity changed before launch")
    if not _inputs_match(job["input_files"]):
        raise RuntimeError(f"Frozen input changed before {job['job_id']}")
    environment = {**os.environ, **job["environment_overrides"]}
    if effective_environment(environment) != job["environment_effective"]:
        raise RuntimeError("Effective environment changed after registration")
    directory = ROOT / job["folder"]
    directory.mkdir()
    write_json(directory / "launch.json", {**job, "manifest": registered})
    print(f"Starting {job['job_id']}", flush=True)
    with (directory / "worker.log").open("wb") as log:
        completed = subprocess.run(job["argv"], cwd=ROOT, env=environment, stdout=log,
                                   stderr=subprocess.STDOUT, check=False)
    runtime_path, receipt = directory / "runtime.json", directory / "project-imports.json"
    runtime = read(runtime_path) if runtime_path.exists() else {}
    observed = read(receipt)["paths"] if receipt.exists() else {}
    mismatches = [path for path, sha in observed.items() if manifest["source_superset"].get(path) != sha]
    expected_native = manifest["runtime_registration"].get("native_expected", {})
    result = {"job_id": job["job_id"], "exit_code": completed.returncode,
              "stable_sources": _current_source_ids(scope) == manifest["source_superset"],
              "stable_inputs": identity(manifest_path) == registered and _inputs_match(job["input_files"]),
              "runtime_matches": bool(runtime and runtime["environment"] == job["environment_effective"]
                                      and runtime["blender_executable"] == manifest["runtime_registration"]["blender_executable"]
                                      and runtime["gpu"]["backend"] == "OPENGL"
                                      and manifest["resource"]["adapter_description"] in runtime["gpu"]["renderer"]
                                      and all(runtime[key] == value for key, value in expected_native.items())),
              "observed_source_files": len(observed), "observed_source_mismatches": mismatches}
    result["verified_process"] = bool(result["exit_code"] == 0 and result["stable_sources"]
                                      and result["stable_inputs"] and result["runtime_matches"]
                                      and observed and not mismatches)
    write_json(directory / "process.json", result)
    print(f"Finished {job['job_id']}: {result}", flush=True)
    return result


def execute(manifest_path):
    manifest = read(manifest_path)
    registered = identity(manifest_path)
    path = manifest_path.parent / "batch-started.json"
    with path.open("x", encoding="utf-8") as stream:
        json.dump({"manifest": registered, "scope": manifest["scope"], "start": clock_anchor()}, stream)
    results = [_run_job(job, manifest_path, manifest, registered) for job in manifest["jobs"]]
    valid = all(result["verified_process"] for result in results)
    write_json(manifest_path.parent / "batch-processes.json", {"scope": manifest["scope"],
               "all_processes_verified": valid, "processes": results, "end": clock_anchor()})
    return 0 if valid else 1


def main():
    if "--worker" in sys.argv:
        start = sys.argv.index("--worker")
        worker(Path(sys.argv[start + 1]), sys.argv[start + 2])
        return 0
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=("qualify", "qualify-old", "register", "execute"))
    parser.add_argument("--qualification-dir", type=Path, default=HERE / "qualified_001")
    parser.add_argument("--old-qualification-dir", type=Path, default=HERE / "qualified_old_001")
    args = parser.parse_args()
    qualification = args.qualification_dir.resolve()
    old_qualification = args.old_qualification_dir.resolve()
    if any(path.parent != HERE or not path.name.startswith("qualified_") for path in (qualification, old_qualification)):
        raise ValueError("Use a dedicated qualified_N directory in this evidence tree")
    if args.operation == "qualify":
        return execute(register("qualification", qualification))
    if args.operation == "qualify-old":
        return execute(register("old-qualification", old_qualification))
    if args.operation == "register":
        register("formal", FORMAL, qualification_root=qualification, old_qualification_root=old_qualification)
        return 0
    return execute(FORMAL / "manifest.json")


if __name__ == "__main__":
    status = main()
    if status:
        raise SystemExit(status)
