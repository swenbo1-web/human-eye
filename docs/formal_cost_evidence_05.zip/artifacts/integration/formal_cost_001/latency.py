"""Frozen one-process-per-seed Blender B/I latency measurement."""

from contextlib import ExitStack
import gc
from hashlib import sha256
import json
from pathlib import Path
import time
import traceback

import numpy as np


ROLES = ("B", "I")
SEEDS = (20261105, 79463, 310519)
WARM_PAIRS = 5
PAIR_COUNT = 36
CASE_COUNT = 24
LIMIT = 1.05
STAMP_KEYS = ("t0", "t1", "t2", "t3", "t_next_observed", "t4")
GATE_SEGMENTS = ("before", "action", "feedback", "next", "continuous_total")
DETAIL_SEGMENTS = ("next_observe", "next_predict")
SEGMENTS = GATE_SEGMENTS + DETAIL_SEGMENTS
PUBLIC_MEMBERS = {"before.ao.json", "transition.ao.json", "next.ao.json",
                  "before.png", "after.png", "next.png"}
MODEL_MEMBERS = {f"{arm}_{kind}" for arm in ("a", "v")
                 for kind in ("weights", "writes", "keys", "values", "known")}


def _json(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False,
                      separators=(",", ":"))


def _write(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write("\n")


def _append(path, value):
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(_json(value) + "\n")


def _identity(data):
    return sha256(data).hexdigest()


def _anchor():
    before = time.perf_counter_ns()
    utc = time.time_ns()
    after = time.perf_counter_ns()
    return {"qpc_before_ns": before, "utc_unix_ns": utc, "qpc_after_ns": after}


def _order(parity):
    return ROLES[::-1] if parity % 2 else ROLES


def _times(stamps):
    values = [stamps[key] for key in STAMP_KEYS]
    if values != sorted(values):
        raise ValueError(f"Non-monotonic counters: {stamps}")
    t0, t1, t2, t3, observed, t4 = values
    return dict(zip(SEGMENTS, (t1-t0, t2-t1, t3-t2, t4-t3, t4-t0, observed-t3,
                               t4-observed), strict=True))


def _model_identity(arrays):
    digest = sha256()
    members = {}
    for name, source in sorted(arrays.items()):
        array = np.asarray(source)
        if array.dtype.hasobject:
            raise TypeError(f"Model state member {name!r} must be numeric or boolean")
        contiguous = array if array.flags.c_contiguous else np.ascontiguousarray(array)
        data = memoryview(contiguous).cast("B")
        member = {"dtype": array.dtype.str, "shape": list(array.shape),
                  "sha256": _identity(data)}
        digest.update(_json((name, member)).encode("utf-8"))
        members[name] = member
    return {"sha256": digest.hexdigest(), "members": members}


def _proof(out, role, evidence):
    """Keep same outside-timing audit and separate content stores for each arm."""
    public = evidence["public"]
    arrays = evidence["model"]
    checks = dict(evidence["checks"])
    if public.keys() != PUBLIC_MEMBERS or arrays.keys() != MODEL_MEMBERS or not checks:
        raise ValueError("Incomplete public, model or input-binding evidence")
    for name, value in checks.items():
        if type(value) is not bool:
            raise TypeError(f"Proof check {name!r} must be a boolean")
    store = out / "proof_store" / role
    public_ids = {}
    for key, data in sorted(public.items()):
        if type(data) is not bytes:
            raise TypeError(f"Public proof member {key!r} is not immutable bytes")
        digest = _identity(data)
        member = store / "public" / f"{digest}.bin"
        if not member.exists():
            member.write_bytes(data)
        public_ids[key] = {"sha256": digest, "bytes": len(data),
                           "file": member.relative_to(out).as_posix()}
    model_id = _model_identity(arrays)
    path = store / "model" / f"{model_id['sha256']}.npz"
    if not path.exists():
        np.savez(path, **arrays)
    return {"public": public_ids, "model": {**model_id, "file": path.relative_to(out).as_posix()},
            "next": evidence["next"], "checks": checks}


def _equivalence(pair):
    b, i = (pair[role] for role in ROLES)
    names = b["public"].keys() | i["public"].keys()
    different_public = [
        name for name in sorted(names) if b["public"].get(name, {}).get("sha256")
        != i["public"].get(name, {}).get("sha256")
    ]
    bindings = _json(b["next"]) == _json(i["next"])
    model = b["model"]["members"] == i["model"]["members"]
    pristine = bool(b["pristine_active_state"]) and b["pristine_active_state"] == i["pristine_active_state"]
    failed_checks = {role: [name for name, valid in pair[role]["checks"].items() if not valid]
                     for role in ROLES}
    bound = not any(failed_checks.values())
    return {"different_public_members": different_public, "next_fields_exact": bindings,
            "post_feedback_active_model_exact": model, "all_binding_and_repeat_checks_valid": bound,
            "pristine_active_state_exact": pristine, "failed_checks": failed_checks,
            "equivalent": not different_public and bindings and model and pristine and bound}


def _case(case, out, process_index):
    creation = _order(process_index + case.ordinal)
    clock = time.perf_counter_ns
    rows, pairs = [], []
    repeat_model = {}
    with ExitStack() as stack:
        lanes = {role: stack.enter_context(case.lane(role)) for role in creation}
        physical_ids = {role: f"{process_index}/{case.ordinal}/{id(lane):x}"
                        for role, lane in lanes.items()}
        if len(set(physical_ids.values())) != len(ROLES):
            raise ValueError("Roles must hold independent physical lane instances")
        prior_t4 = None
        for pair in range(PAIR_COUNT):
            order = _order(process_index + case.ordinal + pair)
            proofs = {}
            for execution_index, role in enumerate(order):
                lane = lanes[role]
                row = {
                    "case_id": case.case_id, "ordinal": case.ordinal, "family": case.family,
                    "pair": pair, "warmup": pair < WARM_PAIRS, "role": role,
                    "physical_instance": physical_ids[role],
                    "creation_index": creation.index(role), "creation_roles": creation,
                    "execution_index": execution_index, "execution_roles": order,
                }
                try:
                    reset_begin = clock()
                    pristine = lane.reset()
                    reset_end = clock()
                    stamps, outputs = lane.run(pair, clock=clock)
                    row.update(counter_ns=stamps, ns=_times(stamps),
                               reset_ns=reset_end-reset_begin,
                               prior_arm_t4_to_t0_ns=None if prior_t4 is None else stamps["t0"]-prior_t4)
                    _append(out / "intervals.jsonl", row)
                    rows.append(row)
                    prior_t4 = stamps["t4"]
                    evidence = lane.proof(outputs)
                    proof = _proof(out, role, evidence)
                    del outputs, evidence
                    digest = proof["model"]["sha256"]
                    prior = repeat_model.setdefault(role, digest)
                    proof["checks"]["same_active_state_across_repeats"] = digest == prior
                    proof["pristine_active_state"] = pristine
                    proofs[role] = proof
                    _append(out / "proofs.jsonl", {
                        **{name: row[name] for name in ("case_id", "ordinal", "pair", "role",
                                                        "physical_instance", "warmup")},
                        "t4_to_proof_serialization_ns": clock() - stamps["t4"], **proof,
                    })
                except Exception:
                    _append(out / "failure_context.jsonl", {
                        **row, "qpc_ns": clock(), "traceback": traceback.format_exc(),
                    })
                    raise
            match = {"case_id": case.case_id, "ordinal": case.ordinal, "pair": pair,
                     "warmup": pair < WARM_PAIRS, **_equivalence(proofs)}
            _append(out / "pairs.jsonl", match)
            pairs.append(match)
    return rows, pairs


def _p95(values):
    return float(np.quantile(values, .95, method="linear"))


def _stats(values):
    return {"count": len(values), "median_ns": float(np.median(values)),
            "p95_ns": _p95(values), "minimum_ns": int(min(values)), "maximum_ns": int(max(values))}


def _ratio(i, b):
    return None if b <= 0 else i / b


def _summarize_case(rows, segment):
    measured = [row for row in rows if not row["warmup"]]
    if len(measured) != 2 * (PAIR_COUNT-WARM_PAIRS):
        raise ValueError("Missing measured arms")
    by_role = {role: {row["pair"]: row for row in measured if row["role"] == role} for role in ROLES}
    if any(sorted(role_rows) != list(range(WARM_PAIRS, PAIR_COUNT)) for role_rows in by_role.values()):
        raise ValueError("Measured pairs are incomplete")
    samples = {role: [row["ns"][segment] for row in role_rows.values()]
               for role, role_rows in by_role.items()}
    arm = {role: _stats(values) for role, values in samples.items()}
    differences = [by_role["I"][pair]["ns"][segment] - by_role["B"][pair]["ns"][segment]
                   for pair in range(WARM_PAIRS, PAIR_COUNT)]
    medians = {
        role: {str(position): _stats([row["ns"][segment] for row in role_rows.values()
                                      if row["execution_index"] == position])
               for position in range(len(ROLES))}
        for role, role_rows in by_role.items()
    }
    chronology = {role: [float(np.median(block)) for block in np.array_split(values, 3)]
                  for role, values in samples.items()}
    return {"family": measured[0]["family"], "arms": arm,
            "I_over_B_medians": _ratio(arm["I"]["median_ns"], arm["B"]["median_ns"]),
            "paired_I_minus_B": _stats(differences),
            "paired_I_minus_B_ns_in_pair_order": differences,
            "by_execution_index": medians, "chronological_third_medians_ns": chronology}


def _aggregate(cases):
    p95 = {role: _p95([data["arms"][role]["median_ns"] for data in cases.values()]) for role in ROLES}
    return {"cases": len(cases), "p95_ns": p95, "I_over_B": _ratio(p95["I"], p95["B"]),
            "I_minus_B_p95_ns": p95["I"] - p95["B"],
            "paired_I_minus_B_ns": _stats([
                delta for case in cases.values() for delta in case["paired_I_minus_B_ns_in_pair_order"]
            ]),
            "p95_of_case_paired_medians_ns": _p95([
                case["paired_I_minus_B"]["median_ns"] for case in cases.values()
            ])}


def _summarize(case_rows):
    if len(case_rows) != CASE_COUNT:
        raise ValueError("Expected all 24 frozen cases")
    summary = {}
    for segment in SEGMENTS:
        cases = {key: _summarize_case(rows, segment) for key, rows in case_rows.items()}
        families = {}
        for key, item in cases.items():
            families.setdefault(item["family"], {})[key] = item
        if len(families) != 6 or any(len(members) != 4 for members in families.values()):
            raise ValueError("Expected six case families with four cases each")
        group = _aggregate(cases)
        ratio = group["I_over_B"]
        eligible = {name: case for name, case in cases.items() if case["I_over_B_medians"] is not None}
        worst_ratio = max(eligible, key=lambda name: eligible[name]["I_over_B_medians"]) if eligible else None
        summary[segment] = {
            **group, "gate": ("UNVERIFIED" if ratio is None else "PASS" if ratio <= LIMIT else "FAIL")
            if segment in GATE_SEGMENTS else "DESCRIPTIVE_ONLY",
            "by_case": cases, "by_family": {key: _aggregate(family) for key, family in families.items()},
            "worst_case_by_I_over_B_medians": worst_ratio,
            "largest_I_case_median": max(cases, key=lambda name: cases[name]["arms"]["I"]["median_ns"]),
            "largest_paired_I_minus_B_case_median": max(cases, key=lambda name: cases[name]["paired_I_minus_B"]["median_ns"]),
        }
    return summary


def _gc_overlap(rows, events):
    starts = {}
    collections = []
    for event in events:
        generation = event["generation"]
        if event["event"] == "start":
            starts[generation] = event["qpc_ns"]
        elif generation in starts:
            collections.append((starts.pop(generation), event["qpc_ns"]))
    counts = {}
    stages = {
        "before": ("t0", "t1"), "action": ("t1", "t2"), "feedback": ("t2", "t3"),
        "next_observe": ("t3", "t_next_observed"), "next_predict": ("t_next_observed", "t4"),
        "continuous_total": ("t0", "t4"),
    }
    for role in ROLES:
        counts[role] = {}
        for name, (left, right) in stages.items():
            spans = []
            for row in rows:
                if row["role"] != role or row["warmup"]:
                    continue
                start, end = (row["counter_ns"][key] for key in (left, right))
                spans.append(sum(max(0, min(end, stop)-max(start, begin)) for begin, stop in collections))
            counts[role][name] = {"measured_rows_with_overlap": sum(value > 0 for value in spans),
                                  "maximum_overlap_ns": max(spans, default=0)}
    return counts


def run(manifest_path, out_dir, process_index):
    """Run the preregistered 36 pairs per case without excluding slow rows."""
    from artifacts.integration.formal_cost_001.common import load_workload

    if process_index not in range(len(SEEDS)):
        raise ValueError("Unregistered process index")
    if not gc.isenabled():
        raise RuntimeError("The frozen protocol requires GC enabled")
    out = Path(out_dir)
    out.mkdir(parents=True)
    for role in ROLES:
        for directory in ("public", "model"):
            (out / "proof_store" / role / directory).mkdir(parents=True)
    manifest_path = Path(manifest_path)
    workload = list(load_workload(manifest_path, process_index))
    if [case.ordinal for case in workload] != list(range(CASE_COUNT)):
        raise ValueError("Case order differs from the frozen 24-case sequence")
    start = _anchor()
    clock = time.perf_counter_ns
    empty = []
    for _ in range(1000):
        a = clock()
        b = clock()
        empty.append(b-a)
    _write(out / "clock.json", {"perf_counter": vars(time.get_clock_info("perf_counter")),
                               "empty_ns": empty, "empty_summary": _stats(empty), "start": start})
    gc_initial = {"enabled": gc.isenabled(), "thresholds": gc.get_threshold(), "counts": gc.get_count()}
    events, active_gc = [], {}

    def gc_event(event, info):
        stamp = clock()
        generation = info["generation"]
        if event == "start":
            active_gc[generation] = stamp
        started = active_gc.pop(generation, None) if event == "stop" else None
        events.append({"qpc_ns": stamp, "event": event,
                       "duration_ns": None if started is None else stamp-started, **info})

    cases = {}
    all_pairs = []
    gc.callbacks.append(gc_event)
    try:
        for case in workload:
            if case.case_id in cases:
                raise ValueError(f"Duplicate case ID {case.case_id!r}")
            rows, pairs = _case(case, out, process_index)
            cases[case.case_id] = rows
            all_pairs.extend(pairs)
    except Exception:
        _write(out / "failure.json", {"phase": "latency", "process_index": process_index,
                                     "seed": SEEDS[process_index], "completed_cases": list(cases),
                                     "traceback": traceback.format_exc()})
        raise
    finally:
        gc.callbacks.remove(gc_event)
        _write(out / "gc.json", {"initial": gc_initial, "end_counts": gc.get_count(), "events": events})
        _write(out / "time_anchors.json", {"start": start, "end": _anchor()})

    segments = _summarize(cases)
    raw = [row for rows in cases.values() for row in rows]
    failed = [item for item in all_pairs if not item["equivalent"]]
    timing = [segments[name]["gate"] for name in GATE_SEGMENTS]
    status = ("FAIL" if "FAIL" in timing else "UNVERIFIED" if "UNVERIFIED" in timing else "PASS")
    spacing = {role: _stats([row["prior_arm_t4_to_t0_ns"] for row in raw
                             if row["role"] == role and not row["warmup"]
                             and row["prior_arm_t4_to_t0_ns"] is not None]) for role in ROLES}
    result = {
        "scope": "same-scene internal service; excludes independent consumer scoring/wait",
        "process_index": process_index, "seed": SEEDS[process_index],
        "manifest_sha256": _identity(manifest_path.read_bytes()),
        "warm_pairs_per_case": WARM_PAIRS, "measured_pairs_per_case": PAIR_COUNT-WARM_PAIRS,
        "case_count": len(cases), "raw_arm_records": len(raw),
        "matched_pairs": len(all_pairs) - len(failed), "mismatched_pairs": failed,
        "quality_gate": "FAIL" if failed else "PASS", "latency_gate": status,
        "status": "FAIL" if failed else status, "ratio_limit": LIMIT, "segments": segments,
        "gc_measured_overlap": _gc_overlap(raw, events),
        "measured_prior_arm_t4_to_t0_ns": spacing,
        "instrumentation": {
            "timed": "absolute QPC boundaries, an additional next-observe/predict QPC call and normal GC with timestamp callback",
            "outside": "same-order proof, SHA-256 and content storage per arm, pair comparison, original sample/label checks, and reset",
            "influence": "clock and GC overhead are not subtracted; outside work influences spacing and is recorded",
        },
        "timing_gate_uses_pooled_data": False,
    }
    _write(out / "summary.json", result)
    return result
