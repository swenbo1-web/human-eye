"""Runtime observations for bounded native integration diagnostics."""

from hashlib import file_digest
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time


THREAD_ENV = {
    "OMP_NUM_THREADS": "1",
    "OPENBLAS_NUM_THREADS": "1",
    "MKL_NUM_THREADS": "1",
    "BLIS_NUM_THREADS": "1",
    "VECLIB_MAXIMUM_THREADS": "1",
    "NUMEXPR_NUM_THREADS": "1",
}
ENV_KEYS = tuple(sorted({
    *THREAD_ENV, "OMP_DYNAMIC", "MKL_DYNAMIC", "OMP_PROC_BIND", "OMP_PLACES",
    "OPENBLAS_CORETYPE", "MKL_CBWR", "CUDA_VISIBLE_DEVICES", "CUDA_DEVICE_ORDER",
    "HIP_VISIBLE_DEVICES", "ONEAPI_DEVICE_SELECTOR", "BLENDER_GPU_BACKEND",
    "CYCLES_DEVICE", "PYTHONHASHSEED", "PYTHONNOUSERSITE", "PYTHONPATH",
    "PYTHONDONTWRITEBYTECODE", "PYTHONPYCACHEPREFIX",
}))


def identity(path):
    path = Path(path).resolve(strict=True)
    with path.open("rb") as stream:
        return {"path": str(path), "bytes": path.stat().st_size,
                "sha256": file_digest(stream, "sha256").hexdigest()}


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, allow_nan=False, indent=2) + "\n",
                    encoding="utf-8", newline="\n")


def effective_environment(environment):
    return {key: environment.get(key) for key in ENV_KEYS}


def module_info(module):
    if module is None:
        return None
    return {"version": getattr(module, "__version__", None),
            "path": getattr(module, "__file__", None)}


def clock_anchor():
    monotonic_before_ns = time.perf_counter_ns()
    utc_ns = time.time_ns()
    monotonic_after_ns = time.perf_counter_ns()
    return {"monotonic_before_ns": monotonic_before_ns, "utc_ns": utc_ns,
            "monotonic_after_ns": monotonic_after_ns}


def python_dll():
    if sys.platform != "win32":
        return None
    from ctypes import WinDLL, c_void_p, c_uint32, c_wchar_p, create_unicode_buffer

    kernel = WinDLL("kernel32", use_last_error=True)
    kernel.GetModuleHandleW.argtypes = (c_wchar_p,)
    kernel.GetModuleHandleW.restype = c_void_p
    kernel.GetModuleFileNameW.argtypes = (c_void_p, c_wchar_p, c_uint32)
    kernel.GetModuleFileNameW.restype = c_uint32
    handle = kernel.GetModuleHandleW(f"python{sys.version_info.major}{sys.version_info.minor}.dll")
    name = create_unicode_buffer(32768)
    if handle and kernel.GetModuleFileNameW(handle, name, len(name)):
        return identity(name.value)
    return None


def native_fingerprint(anchor):
    import bpy
    import gpu

    try:
        driver = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,driver_version,driver_model.current,pci.bus_id",
             "--format=csv,noheader"], capture_output=True, check=False, timeout=15, text=True
        )
        driver_record = {"exit_code": driver.returncode, "stdout": driver.stdout.strip(),
                         "stderr": driver.stderr.strip()}
    except (OSError, subprocess.TimeoutExpired) as error:
        driver_record = {"unavailable": str(error)}
    clock = time.get_clock_info("perf_counter")
    return {
        "scope": "native effective runtime; Pillow entry is null if not imported by this worker",
        "pid": os.getpid(),
        "platform": platform.platform(),
        "blender_version": bpy.app.version_string,
        "blender_executable": identity(bpy.app.binary_path),
        "python_version": sys.version,
        "python_executable": identity(sys.executable),
        "python_dll": python_dll(),
        "numpy": module_info(sys.modules.get("numpy")),
        "pillow": module_info(sys.modules.get("PIL")),
        "gpu": {"renderer": gpu.platform.renderer_get(), "vendor": gpu.platform.vendor_get(),
                "backend": gpu.platform.backend_type_get(), "version": gpu.platform.version_get(),
                "nvidia_smi": driver_record},
        "environment": effective_environment(os.environ),
        "clock": {"implementation": clock.implementation, "resolution_seconds": clock.resolution,
                  "monotonic": clock.monotonic, "start": anchor, "end": clock_anchor()},
    }
