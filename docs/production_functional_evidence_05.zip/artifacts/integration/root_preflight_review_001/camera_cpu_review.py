"""Independent CPU replay of archived camera/PNG evidence. No production imports.

Does not recast native geometry; saved native ray owners are audited against PNGs.
Keeps the exact existing direction tolerance (atol=rtol=8*float32 epsilon).
"""
import base64
from hashlib import sha256
from pathlib import Path
import json
import math

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "artifacts/integration/preflight_001/native_002"
OUT = Path(__file__).with_suffix(".json")
TOL = float(8 * np.finfo(np.float32).eps)
AXIS = np.linspace(8, 503, 25).astype(int)
GRID = np.column_stack((np.tile(AXIS, 25), np.repeat(AXIS, 25)))
COLORS = np.rint(255 * np.array(((.08, .10, .14, 1), (.82, .24, .15, 1),
                                (.16, .60, .90, 1), (.36, .40, .45, 1)))).astype(int)


def close(a, b):
    return bool(np.allclose(a, b, atol=TOL, rtol=TOL))


def unit(a):
    a = np.asarray(a, dtype=float)
    return a / np.linalg.norm(a)


def angle(a, b):
    a, b = unit(a), unit(b)
    return float(np.arctan2(np.linalg.norm(np.cross(a, b)), a @ b))


def unpack(data, dtype, shape):
    return np.frombuffer(base64.b64decode(data), dtype=dtype).reshape(shape)


def matches(a, b):
    return np.all(np.abs(np.asarray(a, dtype=int) - np.asarray(b, dtype=int)) <= 1, axis=-1)


def project(points, vp):
    p = np.column_stack((points, np.ones(len(points)))) @ vp.T
    return (p[:, :2] / p[:, 3, None] * (1, -1) + 1) * 256 - .5


def longest(bits):
    best = run = 0
    for bit in bits:
        run = run + 1 if bit else 0
        best = max(best, run)
    return int(best)


def neighbors(point):
    u, v = point
    return [(x, y) for y in range(max(0, math.floor(v)-3), min(512, math.floor(v)+5))
            for x in range(max(0, math.floor(u)-3), min(512, math.floor(u)+5))
            if (x-u)**2 + (y-v)**2 <= 9]


def line(a, b):
    x, y = (math.floor(v+.5) for v in a)
    last_x, last_y = (math.floor(v+.5) for v in b)
    dx, dy = abs(last_x-x), -abs(last_y-y)
    sx, sy = (1 if last_x > x else -1), (1 if last_y > y else -1)
    error, points = dx+dy, []
    while True:
        points.append((x, y))
        if (x, y) == (last_x, last_y):
            return points
        doubled = error*2
        if doubled >= dy:
            error += dy
            x += sx
        if doubled <= dx:
            error += dx
            y += sy


def camera(record, scale, selected):
    rna, gpu = record["rna"], record["gpu"]
    world = np.array(rna["matrix_world"], dtype=float)
    world[:3, 3] *= scale
    rotation = world[:3, :3]
    backward = rotation[:, 2]
    selected = np.asarray(selected)
    view, projection, vp = (np.asarray(gpu[key]) for key in ("view", "projection", "view_projection"))
    w, near, far = (rna[k] for k in ("ortho_scale", "clip_start", "clip_end"))
    analytic = np.array(((2/w, 0, 0, -2*rna["shift_x"]),
                         (0, 2/w, 0, -2*rna["shift_y"]),
                         (0, 0, -2/(far-near), -(far+near)/(far-near)), (0, 0, 0, 1)))
    recorded_projection = np.asarray(rna["projection"])
    gpu_axis = -unit(np.linalg.inv(vp)[:3, 2])
    component_error = backward - selected
    budget = TOL + TOL * np.abs(selected)
    checks = {
        "orthographic": rna["type"] == "ORTHO" and 0 < near < far and w > 0,
        "rotation": bool(close(rotation.T @ rotation, np.eye(3)) and np.linalg.det(rotation) > 0),
        "analytic_projection": close(analytic, recorded_projection),
        "gpu_view": close(view, np.linalg.inv(world)),
        "gpu_projection": close(projection, recorded_projection @ np.diag((1/scale, 1/scale, 1/scale, 1))),
        "gpu_view_projection": close(vp, projection @ view),
        "direction": close(backward, selected),
    }
    return {"selected": selected.tolist(), "rna_backward": backward.tolist(),
            "gpu_backward_normalized": gpu_axis.tolist(),
            "selected_norm": float(np.linalg.norm(selected)), "rna_norm": float(np.linalg.norm(backward)),
            "component_error": component_error.tolist(), "component_budget": budget.tolist(),
            "component_budget_ratio": (np.abs(component_error)/budget).tolist(),
            "normalized_direction_passes": close(unit(backward), unit(selected)),
            "angle_rad": angle(backward, selected), "angle_degrees": angle(backward, selected)*180/np.pi,
            "gpu_vs_selected_angle_rad": angle(gpu_axis, selected),
            "gpu_vs_rna_angle_rad": angle(gpu_axis, backward),
            "orthogonality_max_error": float(np.max(np.abs(rotation.T @ rotation - np.eye(3)))),
            "checks": checks}, view, vp


def review(path):
    payload = path.read_bytes()
    raw = json.loads(payload)
    e, score = raw["evidence"], raw["score"]
    meta = e["metadata"]
    png_path = path.with_name(path.name.replace(".visual.json", ".png"))
    png = png_path.read_bytes()
    with Image.open(png_path) as im:
        pixels = np.asarray(im.convert("RGBA"))
    assert pixels.shape == (512, 1024, 4)
    assert sha256(png).hexdigest() == score["png_sha256"]
    targets = e["expected"]["target_ids"]
    palette = np.array([COLORS[0]] + [COLORS[1+targets.index(key)] if key in targets else COLORS[3]
                                     for key in e["mesh_ids"][1:]])
    witness = e["expected"]["witness"]
    points = np.asarray((witness["point_a"], witness["point_b"]))
    details = {}
    for panel, side in enumerate(("global", "local")):
        selected = unit((1, -1, 1)) if side == "global" else meta["selection"]["direction"]
        detail, view, vp = camera(meta["views"][side], meta["meters_per_blender_unit"], selected)
        projected = project(points, vp)
        assert np.allclose(projected, e["witness_pixels"][side], rtol=0, atol=.005)
        grid = e["grid"][side]
        owners = unpack(grid["owners_i32le"], "<i4", (625,))
        bottom = unpack(grid["bottom_rgba"], "u1", (625, 4))
        bad = set(np.flatnonzero(~matches(bottom, palette[owners])).tolist())
        for i, near in grid["edge_owners"]:
            if i in bad and matches(bottom[i], palette[near]).any():
                bad.remove(i)
        mask = (GRID[:, 1] >= 64) & (GRID[:, 1] <= 447)
        mask &= GRID[:, 0] < 511 if panel == 0 else GRID[:, 0] > 0
        for point in projected:
            mask &= ((GRID-point)**2).sum(axis=1) > 32**2
        public = pixels[GRID[:, 1], GRID[:, 0]+512*panel]
        drift = np.count_nonzero(mask & (public != bottom).any(axis=1))
        detail["grid"] = {"count": 625, "unresolved_owner_color_mismatches": len(bad),
                          "public_drift_pixels": int(drift)}
        detail["witness_pixels"] = projected.tolist()
        details[side] = detail
        assert len(bad) == 0 and drift == 0
        assert all(v for k, v in detail["checks"].items() if k != "direction")
        if side == "local":
            local_points, local_view = projected, view
    codes = [e["mesh_ids"].index(key) for key in targets]

    def sample(record, expected_pixels):
        xy = np.asarray(record["pixels"], dtype=int)
        assert np.array_equal(xy, expected_pixels)
        owner = np.asarray(record["owners"], dtype=int)
        face = np.asarray(record["faces"], dtype=int)
        depth = np.asarray([np.inf if v is None else v for v in record["depth_m"]])
        count = np.asarray(e["face_counts"])
        assert (((owner == 0) & (face == -1) & np.isinf(depth)) |
                ((owner > 0) & (face >= 0) & (face < count[owner]) & np.isfinite(depth) & (depth > 0))).all()
        bottom = unpack(record["bottom_rgba"], "u1", (len(xy), 4))
        public = pixels[xy[:, 1], xy[:, 0]+512]
        ok = matches(bottom, palette[owner]) & matches(public, palette[owner])
        return xy, owner, depth, ok

    support = []
    for point, code, record in zip(local_points, codes, e["samples"]["supports"]):
        _, owner, _, ok = sample(record, neighbors(point))
        support.append(int(np.count_nonzero((owner == code) & ok)))
    xy, owner, depth, ok = sample(e["samples"]["interior"], line(*local_points)[1:-1])
    delta = local_points[1] - local_points[0]
    separation = float(np.linalg.norm(delta))
    fraction = np.clip((xy-local_points[0]) @ delta/separation**2, 0, 1)
    depths = -(np.column_stack((points, np.ones(2))) @ local_view[2])
    clear = ~np.isin(owner, codes) & (depth > depths[0] + fraction*(depths[1]-depths[0]) + e["depth_tolerance_m"])
    run = longest(clear & ok)
    image_usable = min(support) >= 2 and run >= 3 and abs(separation-meta["selection"]["gap_pixels"]) <= .005
    assert image_usable
    direction_passes = all(details[side]["checks"]["direction"] for side in details)
    assert direction_passes == score["checks"]["directions"]
    assert direction_passes == score["passed"]  # All eight have no other archived failures.
    return {"case": path.parent.name, "phase": path.stem.split('.')[0],
            "evidence_sha256": sha256(payload).hexdigest(), "png_sha256": sha256(png).hexdigest(),
            "camera": details, "public_support_pixels": support, "public_gap_run": run,
            "projected_gap_pixels": separation, "pixel_subset_passes": bool(image_usable),
            "strict_direction_passes": direction_passes,
            "archived_passed": score["passed"], "archived_safe": score["safe"],
            "archived_failed_checks": [k for k, v in score["checks"].items() if not v]}


def native_probe_review(path):
    """Analyze the separately parent-executed native CPU diagnostic, if available."""
    payload = path.read_bytes()
    native = json.loads(payload)
    items = []
    for sample in native["samples"]:
        source = BASE / sample["case"] / (sample["phase"] + ".visual.json")
        assert sha256(source.read_bytes()).hexdigest() == sample["source_sha256"]
        direction = np.asarray(sample["direction"])
        before = np.asarray(sample["before_assignment"])
        archived = np.asarray(sample["archived_rna_matrix"])
        quaternion = np.asarray(sample["quaternion"], dtype=float)
        w, x, y, z = quaternion / np.linalg.norm(quaternion)
        # An independent float64 rotation from the returned native quaternion.
        double_axis = np.array((2*(x*z+w*y), 2*(y*z-w*x), 1-2*(x*x+y*y)))
        rounds = []
        for round_trip in sample["round_trips"]:
            actual = np.asarray(round_trip["readback_matrix"])
            rounds.append({"location_label": round_trip["location_label"],
                           "rotation_exactly_equals_before_assignment": bool(np.array_equal(actual[:3, :3], before[:3, :3])),
                           "rotation_exactly_equals_archived": bool(np.array_equal(actual[:3, :3], archived[:3, :3])),
                           "axis_change": (actual[:3, 2]-before[:3, 2]).tolist()})
        assert all(r["rotation_exactly_equals_before_assignment"] and r["rotation_exactly_equals_archived"] for r in rounds)
        items.append({"case": sample["case"], "phase": sample["phase"],
                      "quaternion_norm": float(np.linalg.norm(quaternion)),
                      "native_before_assignment_axis": before[:3, 2].tolist(),
                      "native_before_assignment_error": (before[:3, 2]-direction).tolist(),
                      "float64_normalized_quaternion_axis": double_axis.tolist(),
                      "float64_normalized_quaternion_axis_error": (double_axis-direction).tolist(),
                      "native_matrix_minus_float64_quaternion_axis": (before[:3, 2]-double_axis).tolist(),
                      "quaternion_direction_passes": close(double_axis, unit(direction)),
                      "quaternion_direction_angle_rad": angle(double_axis, direction),
                      "round_trips": rounds})
    return {"raw_sha256": sha256(payload).hexdigest(), "blender": native["blender"],
            "execution_owner": "parent/root; child reviewer executed CPU reanalysis only",
            "samples": items}


def main():
    cases = [review(path) for path in sorted(BASE.glob("*/*.visual.json"))]
    assert len(cases) == 8
    assert sum(case["strict_direction_passes"] for case in cases) == 7
    result = {"direction_atol_rtol": TOL, "case_count": len(cases), "strict_passes": 7,
              "png_subset_passes": 8,
              "scope": "CPU archive reanalysis only; no fresh native geometry rays, render, model, or timings",
              "cases": cases}
    native_path = Path(__file__).with_name("native_camera_probe.json")
    if native_path.exists():
        result["parent_native_probe_reanalysis"] = native_probe_review(native_path)
    result["source_hashes"] = {
        relative: sha256((ROOT / relative).read_bytes()).hexdigest() for relative in (
            "human_eye_fast/raycast_saccade_gpu.py",
            "verification/cf_visual_acceptance.py",
            "verification/test_raycast_saccade_gpu.py",
            "docs/ENGINE_INTEGRATION_PROTOCOL_DRAFT.md",
        )}
    OUT.write_text(json.dumps(result, indent=2, allow_nan=False), encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ("cases", "parent_native_probe_reanalysis", "source_hashes")}, indent=2))


if __name__ == "__main__":
    main()
