# production_functional_001 合同、基线与覆盖复核

**结论：当前生产功能主链可以条件前进；整机功能/成本尚未验收。** seed 20261105 的 24 个 L 主例、3 个 F/G 和 3 个 R/G 对照确实经过生产 `BlenderRadicalSession` 和 v1 部署；旧 CF 全量质量则实际走旧 `cf_native` 组合路径。两部分证据都有效，但不可互相替代。最小余项是补生产入口的旧清单回归，以及正式三 seed 计时所需的另外两 seed 新场景真实反馈。不要重开已验收模型优化。

本次只读 CPU 审查源码、冻结 ZIP 和原始输出；没有运行 Blender/GPU、性能实验或修改实施源/旧证据。可复算脚本为同目录 `contract_analysis.py`，完整结果为 `contract_analysis.json`。部署格式和独立示例由根侧另审。

## 1. 独立核对结果

- 交付 `source-identity.json` 登记的 **1403 个产物**全部字节数/SHA-256 匹配。`native_functional_final` 的 569 项归档源码、29 项实际加载项目源与登记匹配。B 的 `verification/integration_reference.py` 仍为冻结版本 `95fff56d…`。
- 30 条 B/I 场景对实际存在：L 24、F 3、R 3；每对有 before/transition/next 三个 AO，加 before/after/next 三个 PNG。逐文件读取得到 **180 对真实 bytes 相等**，不是读取 summary 的 `byte_exact` 标志。
- 逐份读取 **90 对严格视觉 score 对象**完全相同；每臂 87/90 合格。L 为 69/72，F/R 各 9/9。每份实际 PNG 的摘要也与评分记录绑定一致。
- 严格失败恰为 L nested-drums-1/before 的 `section_declaration`，以及 L carried-screen-0 的 after/next `directions`。两臂相同；实际反馈记录确认前两项提交 false，next 没有反馈。不能把这些输出写成“全部视觉通过”，也不应为接线验收修改 scorer/容差或重开 VG 优化。
- 逐例比较原始 `record.json`，CF 推理/更新输入与调用序列、feedback state、实测 delta、当前和下一预测值完全相同。所有阶段捕获的对象顺序/mask 相等；每个 phase 内每对象一次、同一 graph，每臂整个闭环只有一个 bridge；没有预测/反馈阶段新增捕获。
- 14 条原生控制的 summary 与实际 `controls/results.json` 一致。其来源是 7 个原生控制函数中的 14 个命名断言结果，不能误写成 14 个独立进程或 14 次统计重复。

14 项覆盖为：空参考、已达目标、零距 NATURAL、零距 SECTION、零距打开、reference-follows 显式 NONE、物理同尺度单位重编码、目标行重排/新代、上下文拓扑、非 Basis key、参考替换、同帧不同 ID、错绑定/重复反馈、双会话/关闭重开。票据负标签在状态控制里明确是合成输入，用于状态机测试，不冒充外部真实视觉评分；正式反馈来自上面的独立 scorer。

## 2. 两条实际执行路径

### 生产主链是真正的 I/B 对照

`test_blender_radical_session.py:_api` 的 I 分支创建 `BlenderRadicalSession`，传入显式 scene/view layer/对象/代号/ReferenceFrame/deployment，并通过公开 observe、predict_action、execute、view_feedback、action_feedback 完成闭环。部署由 `run()` 的 `load_cf_deployment()` 加载。相对 key 的 authored basis 在创建阶段同样准备。

B 分支直接用 `SharedCaptureControl`、VGRenderer、`frozen.session()` 和已冻结 reference 函数编排，没有把 B 改成 I 的别名。两侧采用相同固定 fixture、命令、reference 数据、mask、代号、图像模式、AO、TD/Top-K 和实际反馈。B 使用原 FrozenModels 作为验证侧参数供给，I 使用 v1 导出；这对功能比较合理，部署参数等价由根侧另验。功能回放的 B 必须与后续正式成本 B 保持同样责任和静态缓存机会。

需要准确记住版本：reference 组合逻辑未改，但其继承的 `BlenderControl` 是本轮最小接缝版 `85025e57…`，并非整棵对象图都来自旧 commit。构造/默认接口适配属于本轮已登记修改，不能仅用 `42ddcf2` 一词替代实际源身份。当前主链字节、调用和捕获证据没有显示由此产生 B/I 工作不等价。

### 旧 CF 全量回放并未调用生产会话

实际链条是：

`replay_cf_quality_after_integration.native()` → `cf_experiment.run(stage="evaluate")` → `cf_experiment.evaluate()` → `cf_native.ViewEpisode/ActionEpisode`。

模型入口是 `load_frozen()`；ViewEpisode 自己维护 bridge/index 并直接 VG/encode，ActionEpisode 直接构造 `BlenderControl` 并手工预测、执行、出图、AO。该链没有 `BlenderRadicalSession(...)` 或 `load_cf_deployment(...)` 调用。runtime 里出现新模块名，是 `human_eye_fast.__init__` 公共导出在导入时带入；**模块被 import 不能证明其生产入口被执行。**

旧回放本身经过独立核对，每 seed：

| 数据 | 实际数量/一致性 |
| --- | --- |
| V 主集 | F/R/L/zero/shuffle 各 60 例 |
| A 主集 | 60 例 |
| 主媒体 ZIP | 629 个成员，成员内容身份与原档一致 |
| 主 raw | 388 条，与原档逐条规范内容一致 |
| 连续反馈媒体/raw | 10 个媒体成员、4 条 raw，与原档一致 |
| 质量 summary/负例 | 与原档一致；仅排除 environment 和预登记 `score_ns`、`elapsed_ns` 两类附带计时字段 |

三个 seed 均成立，且已逐份比较原始 gzip/ZIP，而非只信 `comparison.matches`。首 seed R 的既有失败保持。**这些证据证明旧组件路径与控制器默认接缝的兼容性，不能证明新生产会话在旧清单上完整保留 CF 收益。**

这一差别是实际待完成任务，而非措辞偏好：`ENGINE_INTEGRATION_WORK_ORDER.md:34` 明确要求“用已封存的三个模型和原清单核对生产接线”。当前旧回放没有满足其中的生产接线部分。

## 3. 三 seed 时延准备的剩余范围

生产主链 `run()` 明确断言 snapshot 等于 `DEPLOYMENT_SNAPSHOTS[0]`，启动实参也仅为 **20261105**。因此另外两个 seed 的部署导出/CPU 等价，不能被写成它们在新 24 场景中已完成真实视角选择、PNG、反馈和 next 闭环。

冻结 `INTEGRATION_COST_PROTOCOL.md` 要求正式每个 seed 使用该功能轮真实输出的独立评分，并绑定 PNG/方向/ray/操作。seed 79463/310519 可能选中不同方向、得到不同 PNG/标签，不能直接复用 20261105 的反馈表。正式三 seed 性能开启前需要补齐这两份真实功能/反馈数据；无需重跑已完整保留的 seed0 来制造新成功记录。

当前功能 runner **不能直接套计时器作为正式 harness**：`_audit` 在 VG 路径中做独立原生 mesh snapshot、额外视觉审计，并在 CF 调用时 `.tolist()` 复制输入；`_run_arm` 还保留 oracle 数组、三阶段 rendered 记录和全部对账 bytes。这些都是合理功能审计成本，但不属于生产服务热段，也不符合正式资源的临时引用释放约束。

正式 harness 应沿已冻结的诊断节奏：真实公开调用进 t0…t4，票据校验/消费和参数更新在段内；oracle、评分、哈希、归档在 t4 后，B/I 同量对账，保留 QPC/next 分界与 GC。不得将功能轮内的 `_audit` hook 带入时延或资源轮后称为真实生产成本，也不能删掉生产必要回读、AO/PNG 或票据操作来抵消审计开销。

## 4. 最小补齐建议

**A. 完成旧清单的生产入口适配，一次固定回归。** 使用原三 seed、原 V60/A60 fixture 和已封存参数的 v1 等价导出；I 的实际 V F/R/L 及 A L/G 行必须从 `BlenderRadicalSession` 的公开路径产生。保留原 V ray/质量和 A 米制 MAE 口径、原预测/实测命令、控制/诊断/负例、反馈后 next 状态。旧双场景 V→独立 A 的组织和旧 1.10 成本边界继续保留，与新同场景 1.05 分开。适配器放验证侧，不把 FrozenModels、oracle、旧路径或隐藏模式塞入生产。

完整旧报告仍保留 V 五臂（F/R/L/zero/shuffle）和 A 的 C/G/L 等原对照。**固定旧对照可以复用：** zero/shuffle 属已封存的消融比较，C 属验证侧常数基线；可沿用本轮已逐条核对的旧输出，明确标为旧对照，避免重新训练或为接线重做模型选择。生产部署的 F/R/L 和真实 A L/G 不能由这些旧结果代替。如果报告要进一步声称“五臂全部经过新生产路径”，则需把固定 zero/shuffle 参数显式提供给既有 L 入口执行，不增加新的生产模式，也不重新拟合。不要一边沿旧对照，一边把其行数计成生产回放次数。

旧控制/负例中与新会话绑定、回读、预测、反馈有关的项目应在适配 I 上执行；不受接线影响、只验证固定消融模型或旧常数算法的证据可继续引用。参考 frame、对象代号、原始面号、TD 参考和实际帧按旧语义显式传入，不使用宽泛字段归一化掩盖生产输出变化。原已知失败继续保留，差异先报告而不是自动放宽容差。

**B. 另两个 seed 的新 24 主例真实评分。** 同一冻结场景/命令/mask，使用对应 v1 部署建立 B/I 的实际输出与反馈表。对齐公开 bytes、真实 CF 输入/更新、before/after/next、ray 和捕获责任；固定所有成功和失败标签，再登记正式三 seed 计时输入。F/R 的既定少量接口对照不必因这个准备步骤扩成新算法优化试验。

**C. 正式前仅核对 harness 责任与版本。** 确保 reference B 的冻结组合逻辑和本轮必要接缝适配明确归档；两侧计划/反馈绑定、完整发布、合法 basis/参考缓存对等。冷加载/参考准备单列，热态不额外生成基线目标索引或保留额外历史。功能轮 oracle hooks 不进入成本热段。功能差异未解决前不启正式实验；补齐通过后按已批准协议启动一次正式成本试验，不再开启无边界 B/B 或模型优化循环。

根侧已获实施方承认旧 CF 路径范围，并准备上述生产适配和另两 seed 真实评分。建议把本轮已成立的功能证据接受为阶段成果，留下这两项明确尾项和独立成本验收，避免重复已通过的工作或提前宣称整机 PASS。
