"""Replay the delivered public example without touching its sealed outputs."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from verification import run_radical_functional_job as launcher
from verification.verify_blender_radical_example import check

out = Path(__file__).resolve().parent
author = ROOT / 'artifacts/integration/production_functional_001'
recipe_path = author / 'example_fixture_002/recipe.json'
recipe = json.loads(recipe_path.read_bytes())
argv = recipe['example_argv']
args = argv[argv.index('--') + 1:]
result = out / 'example_001/result'
args[args.index('--out') + 1] = str(result)
launcher.OUTPUT_ROOT = out
extra = [ROOT / name for name in json.loads((author / 'native_functional_final/launch.json').read_bytes())['source_superset']]
extra.extend([Path(__file__).resolve(), ROOT / 'verification/verify_blender_radical_example.py'])
inputs = [recipe_path, Path(args[args.index('--blend') + 1]),
          Path(args[args.index('--deployment') + 1]), Path(args[args.index('--view-scores') + 1])]
status = launcher.launch(out / 'example_001', ROOT / 'examples/blender_radical_session.py', args, inputs, extra)
if status:
    raise SystemExit(status)
recipe['example_out'] = str(result)
recipe['example_argv'] = [*argv[:argv.index('--') + 1], *args]
new_recipe = out / 'example_001/recipe.json'
new_recipe.write_text(json.dumps(recipe, indent=2) + '\n', encoding='utf-8')
check(new_recipe, out / 'example_001/consumer-check.json')
report = json.loads((out / 'example_001/consumer-check.json').read_bytes())
assert report['passed']
original = author / 'example_fixture_002/example-output'
files = sorted(result.iterdir())
assert files
for file in files:
    assert file.read_bytes() == (original / file.name).read_bytes(), file.name
print(json.dumps({'public_consumer': report['passed'], 'all_output_files_exact': len(files)}))
