# production_functional_001 来源独立复核

结论：交付身份及各轮归档相互一致，可用于最终生产功能审查。CPU 复核脚本为 `provenance_probe.py`，结果为 `provenance_probe.json`；没有重跑 Blender/GPU，没有修改交付源码、评分器或数据。

交付 identity 的 SHA-256 为 `95230b0d96b945d937d666c337a3f3aa44b808d6df077efbaf69cc1a9ab7c8d0`。其列出的 **1403** 个文件全部按实际字节数及 SHA-256 核对一致，目录没有额外未列入文件（identity 自身除外）。

## 最终 13 源文件与运行源码

13 个交付源码身份全部在已保存的相应运行 ZIP 中找到完全匹配字节，并非每个 ZIP 都应包含全部 13 项：

- `native_functional_final/sources.zip` 覆盖最终公开包入口、control、BlenderRadicalSession、CF deployment loader、完整原生功能测试、控制测试和运行器。
- `example_run_002/sources.zip` 覆盖最终独立公开示例。
- `old_cf_quality/sources.zip` 覆盖离线 exporter、CF deployment 测试、便携故障测试、示例公开消费者及旧 CF 回放器的最终版本。

脚本逐 run 区分“当轮已有但后来修订”和“本来就不属于当轮源码归档”，不能将未执行的示例或测试不在某次 ZIP 中误报为源码漂移。全部 11 个普通 launch/source ZIP 的每个条目都与当轮 launch.source_superset 一致；退出导入回执路径和摘要均可在当轮 ZIP 中对账，注册输入一致，保存的 source/input 稳定性结果为 true。

五个 final identity 明列过程（legacy_control_003、legacy_bridge_001、native_functional_final、example_make_002、example_run_002）的 process 记录与 identity 摘要逐字段一致。`legacy_control_001` 是需要保留的例外：Blender 退出码记录为 0，但 runtime.json 缺失且有 runtime-error.txt，stable_runtime_environment=false；它不能被后续成功覆盖成“第一次全部通过”。早期 control/source 修订、第一轮示例对账资料都保留，最终功能依据来自最终对应运行。

审查时 root HEAD 是 `c25b63802bf077c831d201dc5c5d35645473f902`，与旧设计基线 `42ddcf2` 不是同一提交。当前 13 源文件摘要碰巧全部等于最终交付；此状态单独记录，未用新 HEAD 冒充所有历史 run 的来源。

## 图像与旧质量档案身份

独立逐字节比较最终 30 个案例/臂组合的 before/transition/next AO 及 before/after/next PNG，**180 对 B/I 公开文件完全相同**。90 对视觉 evidence 对象和严格 score 也全部相同，独立像素与相机/剖切复核另见 `visual_review.md`。

VG 源码与 preflight_001 原生归档逐字节相同；CF 视觉评分器及原 VG 相机/容差验证器的摘要仍分别为 `079c47c0ffa7f868a19819f942c068dc3cf4934d96514e1a54a5b98d81e7e797`、`624c4a9be846ffd983c235c5aaee58e3c69c29d0142999fc3e03ba765c85eb0c`。本轮没有通过修改 VG 或评分口径把旧失败改为成功。

旧 CF 的单独 source ZIP、三个 seed 的 launch、注册原输入、comparison 输出文件列表及实际摘要均核对一致；三个 comparison 都保留 matches=true、输入/源码稳定及完整 runtime 的记录。这里认证来源和回放记录身份，没有新做旧 CF 全量原生几何/像素 oracle，也不把 quality replay 的附带耗时当正式性能证据。

便携 unittest 日志没有独立逐进程源码 ZIP，最终对应源文件可从上述最终 ZIP 取得，但不能把事后归档升级为便携进程的实时导入审计。原生退出回执亦是退出时项目文件身份，不是 import-open 事件日志。这些限定不妨碍此次整机功能证据使用；无需为扩充取证范围重开测试循环。
