"""Seal fixed author identity plus root review, without modifying author evidence."""
from hashlib import sha256
import gzip
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[3]
AUTHOR = ROOT / 'artifacts/integration/production_functional_001'
REVIEW = Path(__file__).resolve().parent
identity = json.loads((AUTHOR / 'source-identity.json').read_bytes())
paths = {AUTHOR / name for name in identity['artifact_files_relative_to_this_directory']}
paths.add(AUTHOR / 'source-identity.json')
paths.update(ROOT / name for name in identity['production_and_verification_sources'])
paths.update(p for p in REVIEW.rglob('*') if p.is_file() and not any(
    part in {'__pycache__', 'isolated-pycache'} for part in p.parts))
paths.update(ROOT / name for name in ('docs/PRODUCTION_FUNCTIONAL_REVIEW.md',
    'artifacts/integration/root_preflight_review_001/camera_cpu_review.py',
    'artifacts/integration/method_diagnostic_001/runtime_identity.py'))
paths.update(ROOT / f'artifacts/cf/formal_001/{seed}/seal/frozen.npz'
             for seed in ('20261105', '79463', '310519'))
for group, base in (('artifact_files_relative_to_this_directory', AUTHOR),
                    ('production_and_verification_sources', ROOT)):
    for name, record in identity[group].items():
        data = (base / name).read_bytes()
        assert len(data) == record['bytes'] and sha256(data).hexdigest() == record['sha256'], name

batches, batch, count = [], [], 0
for path in sorted(paths):
    size = path.stat().st_size
    if batch and count + size > 32 * 1024 * 1024:
        batches.append(batch)
        batch, count = [], 0
    batch.append(path)
    count += size
if batch:
    batches.append(batch)
index = {'scope': 'Fixed production functional delivery and independent review; full production old-CF regression and cost remain pending',
         'author_identity_sha256': sha256((AUTHOR / 'source-identity.json').read_bytes()).hexdigest(),
         'archives': [], 'files': {}}
for number, members in enumerate(batches, 1):
    target = ROOT / f'docs/production_functional_evidence_{number:02}.zip'
    manifest = {}
    with ZipFile(target, 'x', compression=ZIP_DEFLATED) as z:
        for path in members:
            name = path.relative_to(ROOT).as_posix()
            data = path.read_bytes()
            manifest[name] = {'bytes': len(data), 'sha256': sha256(data).hexdigest()}
            z.writestr(name, data)
        z.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    with ZipFile(target) as z:
        assert z.testzip() is None
        assert set(z.namelist()) == set(manifest) | {'manifest.json'}
        for name, record in manifest.items():
            data = z.read(name)
            assert data == (ROOT / name).read_bytes()
            assert sha256(data).hexdigest() == record['sha256']
            index['files'][name] = {**record, 'archive': target.name}
    index['archives'].append({'path': target.relative_to(ROOT).as_posix(), 'files': len(manifest),
        'bytes': target.stat().st_size, 'sha256': sha256(target.read_bytes()).hexdigest()})
target = ROOT / 'docs/production_functional_evidence_index.json.gz'
target.write_bytes(gzip.compress((json.dumps(index, ensure_ascii=False, indent=2) + '\n').encode('utf-8'), mtime=0))
print(json.dumps({'files': len(index['files']), 'archives': index['archives'], 'roundtrip_exact': True}))
