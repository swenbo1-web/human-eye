# production_functional_001：生产状态与控制接缝复审

2026-11-06；integration_state_review。已检查生产 `blender_radical_session.py`、`control.py` 实际 diff、相关单元测试、原生控制源与交付记录。未运行 Blender/GPU，未修改生产或交付源。本次新增证据仅为本目录 state_probe.py、state_probe.json 和本文。

## 结论

**状态、所有权和控制接缝侧通过，未发现必须返工的正确性缺陷。可进入主干批准的正式成本验证。** 此结论不代替正式计时/资源方法冻结，也不主张已获得集成性能收益。无需为了完成复审再优化一轮。

复核时源码与交付身份一致：

- control.py：85025e57aeac604243f0ff207886621b30674e5c643dc1451522e5ea7351506b。
- blender_radical_session.py：81ab7aa48685f07586f397ace0eec27ba77ce36c8de5c09277930dbdc007e5d1。

## 部分捕获失败和 fresh NONE：修复确实成立

生产 `BlenderControl._capture` 在可能修改 bridge 借用世界数组前，取出旧 index tuple 并将 self._indexes 清空；仅在两目标 capture、必要 refit、BC 全部成功后重新挂回。失败时不会把旧 packed triangles/bounds 当成新 bridge 几何的有效索引。这比只清空 observation 更关键：否则下一次 NONE 可以合法复用桥内已经变更的数据，却跳过过期索引更新。

独立 state_probe 未使用 B reference 控制实现，也没有复用交付测试的 StubBridge。它构造48个对应三角形的平行面，真值由平面距离独立给出；实际调用生产 controller、SurfaceIndex、session 与 AO。分别注入：

1. moving 借用 world buffer 已改写，第二 target capture 失败。
2. 两目标都已捕获，第二 index.update 失败。
3. 两索引处理后，BC 查询失败。

三例均返回 target_readback/written、无伪造 Outcome，宿主只写一次，session/current/旧 indexes 失效。之后用户显式发起 fresh observe 并声明 NONE，重新建立两索引，所得间隙均为解析真值 **0.75 m**。该恢复不是自动重试，也没有第二份常驻 bridge/index。

该 NONE 证明限定为“桥中已有成功捕获的最新几何”，并且本探针失败的 reference 在宿主没有变动。若某对象宿主已变、却尚未成功捕获，调用者在恢复观察中仍须声明其真实变化；NONE 不代表强制重新读取未知变化。这是既定 trusted-input 掩码语义，不是新增防御层或缺陷。

## 最小 seam 和原默认 controller

只新增显式 view_layer、target mask、同 graph context 回调和必要的具名错误边界。controller 仍是唯一目标 bridge/index 所有者；observe/execute 各一次全局 BC；context 不再通过第二次目标观察取得状态。

执行顺序正确：读原控制→setter→目标求值/BC→actual control_after→真实 Outcome→同图 context。setter 自身异常报告 unknown；目标/control_after 未测得时 Outcome=None；测得后 context/TD/render/AO 失败保留真实 Outcome，并可附同一实测 delta 的一次 A ticket。session 撤销计划和 current，不回滚、不重试、不替换图片。

默认旧 controller 只有传入新 seam/mask 才启用 ActionStageError。独立 CPU 另核对：

- 已达 Goal 时返回 None，零写入，保留原 current 行为。
- 直接空面动作仍真实写入，measured_delta_m=None；统一 session 的 NO_SURFACE 政策没有渗入默认控制器。
- 默认调用在 graph/prepare 阶段失败仍保留原 RuntimeError 类型与原来的 pre-write current 行为，没有强行包装为新阶段异常。

原生旧控制器/桥证据由交付提供，本次不冒称重新运行。新字段 `_context_capture_callback` 不遮蔽旧 B 的 `_capture_context` 方法；这避免了继承适配器回归。索引异常失效不改变成功路径的几何算法。

## 计划、票据、参考、代号和公开消费

- PreparedAction 以独立 owner token、精确 before readback 身份和一次消费绑定。执行开始后当前公开 observation 失效，其余同 observation 计划不能重复写入。新观察、参考替换和 close 同样撤销旧计划。没有未决表、TTL、历史查询或会话全局注册。
- V ticket 绑定实际 observation/attachment/canonical index，保存真实选中 probe rays、native stop 和必要特征；R 只写库、L 按原 CF 更新。A ticket 仅保存真实 measured delta、前特征和尺度，消费者不能提交任意 delta。迟到反馈不依赖 current，因此 reference replacement/下一观察后仍可消费一次；close 和 foreign owner 在更新前拒绝。
- 交付原生 `_sessions` 控制实际覆盖两独立模型交错、reference replacement 后迟到反馈、错观察/附件/方向、重复、跨会话、关闭和重开旧票据拒绝。此测试明确使用 synthetic negative 标签测试状态机，没有把它包装为新的 V 质量证据。
- ReferenceFrame 通过独立 bytes buffer 持有世界米制数组，用户原数组再修改不影响快照。独立 probe 验证不能重新设置 writeable=True。每对象 generation 拷贝并逐对象发布；context TOPOLOGY 成功捕获后才更新对应 generation。目标拓扑/外观仍通过新 session 处理。
- 对外结果为 frozen dataclass、AO/PNG bytes、MappingProxyType 附件及轻量 audit/ticket，不公开借用 mesh。独立 probe 验证结果和附件不能普通赋值修改，关闭后旧 bytes 保持可读。
- before 联合包仅在 AO 会读取前位置（TD witness 或显式 selected face）时复制一份 moving world。AO `_deformation` 只有这些 face_ids 才读取 position_vertices，因此无展示行时跳过复制是语义等价的。独立可变 buffer probe 验证实际 after 覆写后，联合 AO 的 before 仍与原公开观察相同。
- close 释放 renderer/model 后在 finally 清理 controller captures/index/宿主引用及 context 回调，再清空 bases/reference/current。独立 CPU 核对 bridge/index/callback 已分离；GPU/camera 实际释放仍依据交付原生控制，不从 CPU 结果推断。

## 算法与激进首版边界

这次接线没有引入备用求解器、隐式模式切换、预测失败后降级、自动动作重试、场景扫描或内容 hash。新增检查属于显式输入边界、动作绑定、支持域与资源所有权；不是重复计算式防御链。

shape G 新路径只变换当前见证面的三行 basis，再调用原窄相；与原 geometry_delta 定义一致，仍是“当前两个 witness faces 的有限预测”，没有将其误宣称为未来全局 BC 真值。L 使用完整合法特征并复用其中的 G。静态 basis 绑定对象/key/relative_key，authored 定义修改由显式 prepare_relative_basis 刷新，热路径不扫描/hash 全数组。

独立 CPU 数学 probe 用一般非均匀线性矩阵与 .001 m/BU，令 world basis 对平行面给出已知法向位移，shape G 预测为 -0.03750000000000009 m，解析值为 -0.037500000000000006 m。它验证三行变换的单位/线性语义，不冒称 Blender RNA、driver 或 modifier 支持域被 CPU 模拟验证；后者仍按冻结合同和原生用例处理。

## 本次实际运行和限制

- 本目录 state_probe.py：上述三个失败恢复、默认 controller、shape G 数学及公开所有权全部通过；state_probe.json 留存原值与源码 SHA256。纯 CPU synthetic host，实际使用生产核心，不使用 B 作为结果 oracle。
- 独立重跑 `verification.test_blender_radical_failures` 与 `verification.test_radical_session_controls.RadicalSessionPortableFailures`，共4项通过，覆盖8个实际生产 seam 失败边界及已测 Outcome 的 A ticket。
- 已读交付65项便携回归日志和原生状态控制记录；没有为此重复执行全部旧模块测试。未运行正式性能、训练、Blender 或 GPU。

状态侧必修项：无。建议保持当前源码冻结，按主干最终批准的方法进入正式成本验证；若成本未达标，再按实测归因处理，不因本次流程额外开启优化循环。
