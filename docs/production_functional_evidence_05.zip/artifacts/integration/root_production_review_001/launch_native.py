"""Use the inspected archived launcher for one root-only native process."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from verification import run_radical_functional_job as launcher

out = Path(__file__).resolve().parent
launcher.OUTPUT_ROOT = out
author = ROOT / 'artifacts/integration/production_functional_001'
registration = json.loads((author / 'native_functional_final/launch.json').read_bytes())
extra = [ROOT / name for name in registration['source_superset']]
extra.append(Path(__file__).resolve())
inputs = [ROOT / 'artifacts/cf/formal_001/20261105/seal/frozen.npz',
          author / 'deployments/20261105.npz', author / 'source-identity.json']
status = launcher.launch(out / 'native_001', out / 'native_replay.py',
    ['--out', str(out / 'native_001/result')], inputs, extra)
raise SystemExit(status)
