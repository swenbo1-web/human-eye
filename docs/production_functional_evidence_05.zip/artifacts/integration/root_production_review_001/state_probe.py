"""Independent CPU host fixture for production state seams; no Blender runtime."""

from contextlib import nullcontext
from dataclasses import FrozenInstanceError
from hashlib import sha256
import json
from pathlib import Path
import sys
from types import SimpleNamespace as NS
from unittest.mock import patch

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from human_eye_fast import (
    BlenderRadicalSession, CaptureChange, Goal, MeshChange, ObservationRequest,
    ReferenceFrame, SetShapeKey, Translate,
)
from human_eye_fast import control as control_module
from human_eye_fast.control import Action, ActionStageError, BlenderControl
from human_eye_fast.resident_bridge import ResidentMesh
from human_eye_fast.fast_affordance_out import public_schema
from verification.test_fast_affordance_out import decode_public


class Matrix:
    def __init__(self, translation=(0., 0., 0.)):
        self.translation = translation

    def copy(self):
        return Matrix(tuple(self.translation))


class Object:
    def __init__(self, name, vertices, faces, events):
        self.name, self.vertices, self.faces = name, vertices, faces
        self.events, self._matrix = events, Matrix()

    def evaluated_get(self, graph):
        return self

    @property
    def matrix_world(self):
        return self._matrix

    @matrix_world.setter
    def matrix_world(self, value):
        self.events.append(("write", self.name, tuple(value.translation)))
        self._matrix = value


class Layers(list):
    def get(self, name):
        return next((row for row in self if row.name == name), None)


class Bridge:
    def __init__(self):
        self.rows = {}
        self.fail_once = None

    def capture(self, key, obj, graph, scale, changes=MeshChange.NONE):
        if self.fail_once == key:
            self.fail_once = None
            raise RuntimeError("Independent injected second-target capture failure")
        previous = self.rows.get(key)
        if previous is not None and not changes:
            return previous
        world = (obj.vertices + np.asarray(obj.matrix_world.translation)) * scale
        transform = np.eye(4)
        transform[:3, 3] = np.asarray(obj.matrix_world.translation) * scale
        if previous is None:
            previous = ResidentMesh(obj.vertices.copy() * scale, world.copy(), obj.faces.copy(),
                                    transform, None)
            self.rows[key] = previous
        else:
            previous.world_m[:] = world
            previous.world_from_local[:] = transform
        return previous

    def get(self, key):
        return self.rows[key]

    def clear(self):
        self.rows.clear()


def host(empty_reference=False):
    # 48 matching triangles in parallel planes give an independent exact gap.
    yz = np.array([[0., 0.], [.5, 0.], [0., .5]])
    faces = np.arange(48 * 3, dtype=np.int32).reshape(-1, 3)
    base = np.concatenate([np.column_stack((np.ones(3), yz + [2. * i, 0.]))
                           for i in range(48)])
    events = []
    objects = {"moving": Object("moving", base, faces, events),
               "reference": Object("reference", base + [1., 0., 0.],
                                   faces[:0] if empty_reference else faces, events)}
    layer = NS(name="explicit")
    scene = NS(frame_current=17, view_layers=Layers([layer]), unit_settings=NS(scale_length=1.))
    graph = object()
    context = NS(temp_override=lambda **_: nullcontext(), evaluated_depsgraph_get=lambda: graph)
    return scene, layer, objects, context, events, base


def request(name):
    return ObservationRequest(name, None, "F")


def session_fixture():
    scene, layer, objects, context, events, base = host()
    with patch.dict(sys.modules, {"bpy": NS(context=context)}):
        session = BlenderRadicalSession(scene, layer, objects, Goal("moving", "reference", 0., 0.),
                                        {"moving": 1, "reference": 2},
                                        reference=ReferenceFrame(16, 1, base))
    session._controller.bridge = Bridge()
    changes = {key: CaptureChange(MeshChange.VERTICES | MeshChange.TRANSFORM) for key in objects}
    return session, changes, events


def main():
    evidence = {"scope": "Independent CPU synthetic host; real production controller/index/session/AO"}
    failures = []
    for case in ("second-capture", "second-refit", "bc-query"):
        session, changes, events = session_fixture()
        try:
            initial = session.observe(request("before"), changes=changes)
            old_indexes = session._controller._indexes
            before = decode_public(initial.ao_bytes, public_schema())["observations"][0]
            assert before["clearance"]["distance_m"] == 1.
            plan = session.predict_action("before", "act", Translate((.25, 0., 0.)), predictor="NONE")
            if case == "second-capture":
                session._controller.bridge.fail_once = "reference"
                fault = nullcontext()
            elif case == "second-refit":
                fault = patch.object(old_indexes[1], "update", side_effect=RuntimeError("Second refit"))
            else:
                fault = patch.object(control_module, "surface_distance", side_effect=RuntimeError("BC"))
            with fault:
                try:
                    session.execute(plan, request("failed-after"), changes=changes)
                except ActionStageError as error:
                    assert (error.stage, error.write_status, error.outcome) == ("target_readback", "written", None)
                else:
                    raise AssertionError("Injected fault did not fire")
            assert session._controller._indexes is None
            assert session._controller._latest is None and session._current is None
            assert len(events) == 1
            unchanged = {key: CaptureChange(MeshChange.NONE) for key in changes}
            fresh = session.observe(request("fresh"), changes=unchanged)
            restored = decode_public(fresh.ao_bytes, public_schema())["observations"][0]
            assert restored["clearance"]["distance_m"] == .75
            assert all(old is not new for old, new in zip(old_indexes, session._controller._indexes))
            assert len(events) == 1
            failures.append({"case": case, "triangles_per_target": 48,
                             "written_once": True, "discarded_incomplete_indexes": True,
                             "fresh_NONE_gap_m": restored["clearance"]["distance_m"]})
        finally:
            session.close()
    evidence["recovery"] = failures

    legacy = []
    for case in ("reached", "empty", "default-prepare-error"):
        scene, layer, objects, context, events, base = host(empty_reference=case == "empty")
        goal = Goal("moving", "reference", 1. if case == "reached" else 0., 0.)
        with patch.dict(sys.modules, {"bpy": NS(context=context)}):
            controller = BlenderControl(scene, objects, goal)
        controller.bridge = Bridge()
        try:
            before = controller.observe("before")
            action = Action("act", "before", Translate((.25, 0., 0.)))
            if case == "default-prepare-error":
                with patch.object(context, "evaluated_depsgraph_get", side_effect=RuntimeError("before write")):
                    try:
                        controller.execute(action, "after")
                    except RuntimeError as error:
                        assert type(error) is RuntimeError and controller._latest is before
                    else:
                        raise AssertionError("Expected original raw error")
                assert not events
            elif case == "reached":
                assert controller.execute(action, "after") is None
                assert controller._latest is before and not events
            else:
                result = controller.execute(action, "after")
                assert result.measured_delta_m is None and len(events) == 1
                assert result.control_after == (.25, 0., 0.)
            legacy.append({"case": case, "preserved": True})
        finally:
            controller.close()
    evidence["default_control"] = legacy

    session, changes, events = session_fixture()
    try:
        session.observe(request("shape-math"), changes=changes)
        moving = session._controller.bridge.get("moving")
        linear = np.array([[1.1, -.3, .2], [.2, 1.7, -.1], [0., .2, .8]])
        moving.world_from_local[:3, :3] = linear
        scale, q, target = .001, .25, .625
        desired_world_basis = np.broadcast_to((.1, 0., 0.), moving.world_m.shape)
        local_bu_basis = (desired_world_basis @ np.linalg.inv(linear).T) / scale
        # Test the new three-row G arithmetic against an analytic plane shift;
        # no Blender RNA semantics or authored-key validation is simulated here.
        with patch.object(session, "_shape_inputs", return_value=(q, local_bu_basis, scale)):
            predicted, features, meters = session._predict_finite(
                SetShapeKey("analytic-key", target), session._current.readback.surface, "G")
        expected = -(target - q) * .1
        assert abs(predicted - expected) < 1e-13 and features is None and meters is None
        evidence["shape_G_analytic_math"] = {"general_linear_matrix": True, "scale_m_per_BU": scale,
                                            "predicted_m": predicted, "analytic_m": expected}
    finally:
        session.close()

    session, changes, events = session_fixture()
    try:
        original = session.observe(request("before"), changes=changes)
        plan = session.predict_action("before", "act", Translate((.25, 0., 0.)), predictor="G")
        result = session.execute(plan, request("after"), changes=changes)
        before = decode_public(original.ao_bytes, public_schema())["observations"][0]
        assert decode_public(result.ao_bytes, public_schema())["observations"][0] == before
        try:
            result.attachments["bad"] = b"mutated"
        except TypeError:
            pass
        else:
            raise AssertionError("Public attachments mutable")
        try:
            result.image_status = "mutated"
        except FrozenInstanceError:
            pass
        else:
            raise AssertionError("Public result mutable")
        reference = session._reference
        try:
            reference.moving_world_m.flags.writeable = True
        except ValueError:
            pass
        else:
            raise AssertionError("Reference can regain write access")
        snapshot = original.ao_bytes, result.ao_bytes
        session.close()
        assert (original.ao_bytes, result.ao_bytes) == snapshot
        assert not session._controller.bridge.rows and session._controller._indexes is None
        assert session._controller._context_capture_callback is None
        evidence["public_ownership"] = {"joint_before_matches": True, "attachments_readonly": True,
                                       "result_frozen": True, "reference_immutable_buffer": True,
                                       "old_bytes_after_close": True, "resources_detached": True}
    finally:
        session.close()

    evidence["source_sha256"] = {name: sha256((ROOT / name).read_bytes()).hexdigest() for name in (
        "human_eye_fast/control.py", "human_eye_fast/blender_radical_session.py",
        "verification/test_blender_radical_failures.py")}
    Path(__file__).with_suffix(".json").write_text(json.dumps(evidence, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(evidence, indent=2))


if __name__ == "__main__":
    main()
