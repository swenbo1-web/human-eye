"""CPU-only source/evidence identity audit for production_functional_001."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "artifacts/integration/production_functional_001"
OUT = Path(__file__).with_suffix(".json")
EXPECTED = "95230b0d96b945d937d666c337a3f3aa44b808d6df077efbaf69cc1a9ab7c8d0"


def digest(data):
    return sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def check(data, expected):
    assert len(data) == expected["bytes"] and digest(data) == expected["sha256"]


def archive(path):
    with ZipFile(path) as z:
        assert len(z.namelist()) == len(set(z.namelist()))
        return {name:z.read(name) for name in z.namelist()}


def main():
    identity_bytes = (BASE / "source-identity.json").read_bytes()
    assert digest(identity_bytes) == EXPECTED
    identity = json.loads(identity_bytes)
    files = identity["artifact_files_relative_to_this_directory"]
    assert len(files) == 1403
    for name, item in files.items():
        check((BASE / name).read_bytes(), item)
    listed = set(files) | {"source-identity.json"}
    additional = sorted(p.relative_to(BASE).as_posix() for p in BASE.rglob("*")
                        if p.is_file() and p.relative_to(BASE).as_posix() not in listed)
    final_sources = identity["production_and_verification_sources"]
    assert len(final_sources) == 13
    final_archive = archive(BASE / "native_functional_final/sources.zip")
    example_archive = archive(BASE / "example_run_002/sources.zip")
    cf_archive = archive(BASE / "old_cf_quality/sources.zip")
    final_source_archives = {}
    for name, item in final_sources.items():
        for label, source_archive in (("native_functional_final", final_archive),
                                      ("example_run_002", example_archive), ("old_cf_quality", cf_archive)):
            if name in source_archive and digest(source_archive[name]) == item["sha256"]:
                check(source_archive[name], item)
                final_source_archives[name] = label
                break
        else:
            raise AssertionError(("No archive matches delivered source", name))
    current_sources = {}
    for name, item in final_sources.items():
        path = ROOT / name
        current_sources[name] = {"delivery_sha256":item["sha256"],
                                 "current_sha256":digest(path.read_bytes()) if path.exists() else None}
    runs = []
    for launch_path in sorted(BASE.glob("*/launch.json")):
        folder = launch_path.parent
        launch, process = read(launch_path), read(folder / "process.json")
        sources = archive(folder / "sources.zip")
        hashes = {name:digest(data) for name,data in sources.items()}
        assert hashes == launch["source_superset"]
        observed = read(folder / "observed-project-imports.json")["paths"]
        assert len(observed) == process["observed_project_files"]
        assert all(hashes[name] == value for name,value in observed.items())
        assert process["observed_source_mismatches"] == []
        assert process["stable_sources"] and process["stable_inputs"]
        for item in launch["input_files"]:
            path = Path(item["path"])
            relative = path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT) else None
            data = sources[relative] if relative in sources else path.read_bytes()
            check(data, item)
        runtime_path = folder / "runtime.json"
        runtime_matches = None
        if runtime_path.exists():
            runtime = read(runtime_path)
            runtime_matches = runtime["environment"] == launch["environment_effective"]
            assert runtime_matches == process["stable_runtime_environment"]
            assert runtime["blender_executable"] == launch["blender_executable"]
        else:
            assert folder.name == "legacy_control_001" and not process["stable_runtime_environment"]
            assert (folder / "runtime-error.txt").is_file()
        diff = [name for name,item in final_sources.items() if hashes.get(name) != item["sha256"]]
        runs.append({"run":folder.name, "exit_code":process["exit_code"],
                     "source_files":len(sources), "observed_files":len(observed),
                     "runtime_environment_matches":runtime_matches,
                     "different_or_missing_final_delivery_sources":diff,
                     "present_but_revised_final_sources":[name for name in diff if name in hashes],
                     "final_sources_outside_this_archive":[name for name in diff if name not in hashes],
                     "archive_and_inputs_verified":True})
    for name, expected in identity["native_process_checks"].items():
        assert read(BASE / name / "process.json") == expected
    cf = BASE / "old_cf_quality"
    cm = read(cf / "manifest.json")
    cs = archive(cf / "sources.zip")
    assert set(cs) == set(cm["source_files"])
    for name,item in cm["source_files"].items():
        check(cs[name], item)
    cf_runs = []
    for job in cm["jobs"]:
        folder = cf / str(job["seed"])
        assert read(folder / "launch.json") == job
        for path,item in job["inputs"].items():
            check(Path(path).read_bytes(), item)
        comparison = read(folder / "comparison.json")
        assert comparison["matches"] and comparison["exit_code"] == 0
        assert comparison["stable_inputs"] and comparison["stable_sources"] and comparison["runtime_complete"]
        assert comparison["actual_input_reads_match"] and not comparison["observed_import_mismatches"]
        for name,item in comparison["output_files"].items():
            check((folder / name).read_bytes(), item)
        cf_runs.append({"seed":job["seed"], "comparison_matches":True,
                        "archive_final_source_differences":[name for name,item in final_sources.items()
                                                           if name not in cs or digest(cs[name]) != item["sha256"]]})
    pairs = 0
    summary = read(BASE / "native_functional_final/result/summary.json")
    for row in summary["main"]:
        folder = BASE / "native_functional_final/result" / row["view_arm"] / row["case"]
        for name in ("before.ao.json", "transition.ao.json", "next.ao.json", "before.png", "after.png", "next.png"):
            assert (folder / "B" / name).read_bytes() == (folder / "I" / name).read_bytes()
            pairs += 1
    assert pairs == identity["b_i_public_byte_pairs"] == 180
    assert final_archive["human_eye_fast/raycast_saccade_gpu.py"] == (
        ROOT / "artifacts/integration/preflight_001/native_002-source/raycast_saccade_gpu.py").read_bytes()
    assert digest(final_archive["verification/cf_visual_acceptance.py"]) == "079c47c0ffa7f868a19819f942c068dc3cf4934d96514e1a54a5b98d81e7e797"
    assert digest(final_archive["verification/test_raycast_saccade_gpu.py"]) == "624c4a9be846ffd983c235c5aaee58e3c69c29d0142999fc3e03ba765c85eb0c"
    result = {"scope":"CPU archive identity and public byte pairing only; no Blender/GPU invocation",
              "source_identity_sha256":EXPECTED, "registered_artifacts_checked":len(files),
              "additional_files_not_in_author_identity":additional,
              "final_delivery_sources":13, "final_source_archives":final_source_archives,
              "final_archives_match_all_delivery_sources":True,
              "review_base":identity["git_review_base"],
              "current_root_HEAD":subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT,text=True).strip(),
              "current_source_snapshot_separate_from_history":current_sources,
              "runs":runs, "old_cf_archive":cf_runs,
              "public_B_I_byte_pairs_verified":pairs,
              "VG_and_visual_scoring_code_unchanged_from_reviewed_preflight":True,
              "limitations":["Portable unittest logs do not have a separate per-run source ZIP; native/example/old-CF ZIPs together cover the 13 delivered sources.",
                             "Observed-import receipts are exit-time project file identities, not an import-open audit.",
                             "Historical process stability is a recorded result, not re-observed by this CPU review."]}
    OUT.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+"\n",encoding="utf-8")
    print(json.dumps({k:v for k,v in result.items() if k not in ("runs","current_source_snapshot_separate_from_history","limitations")},indent=2))


if __name__ == "__main__":
    main()
