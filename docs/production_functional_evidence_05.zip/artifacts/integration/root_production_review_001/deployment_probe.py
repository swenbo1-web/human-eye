"""Independent deployment interpretation from sealed NPZ arrays, CPU only."""
import importlib.abc
import json
from pathlib import Path
import sys
from hashlib import sha256
import numpy as np

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
class NoBlender(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] in {'bpy', 'gpu', 'mathutils', 'bmesh', 'bgl', 'gpu_extras'}:
            raise AssertionError('Ordinary package import attempted ' + fullname)
sys.meta_path.insert(0, NoBlender())
import human_eye_fast

def design(raw, mean, scale, quadratic, view):
    x = np.array(raw, dtype=np.float64, copy=True)
    if view:
        x[..., 2:] = np.log1p(x[..., 2:])
    x = (x - mean) / scale
    parts = [x]
    if quadratic:
        pairs = [(i, j) for i in range(x.shape[-1]) for j in range(i, x.shape[-1])]
        parts.append(np.stack([x[..., i] * x[..., j] for i, j in pairs], axis=-1))
    parts.append(np.ones((*x.shape[:-1], 1)))
    return np.concatenate(parts, axis=-1)

reports = []
for seed in ('20261105', '79463', '310519'):
    source = ROOT / f'artifacts/cf/formal_001/{seed}/seal/frozen.npz'
    exported = ROOT / f'artifacts/integration/production_functional_001/deployments/{seed}.npz'
    with np.load(source, allow_pickle=False) as z:
        raw = {key: z[key] for key in z.files}
    expected = {'version': np.asarray(1), 'retrieval_scale': raw['retrieval_scale'],
        'v_keys': raw['view_keys'], 'v_values': raw['view_feedback'].astype(np.float64),
        'v_known': np.ones(raw['view_feedback'].shape[:-1], dtype=bool),
        'a_keys': raw['action_keys'], 'a_values': raw['action_labels'][:, None],
        'a_known': np.ones((len(raw['action_keys']), 1), dtype=bool)}
    for short, long in (('v', 'view'), ('a', 'action')):
        for field in ('mean', 'scale', 'weights', 'quadratic', 'lambda'):
            expected[f'{short}_{field}'] = raw[f'{long}_head_{field}']
    deployment = human_eye_fast.load_cf_deployment(exported)
    for key, value in expected.items():
        actual = np.asarray(getattr(deployment, key))
        assert actual.shape == value.shape and np.array_equal(actual, value), key
        if actual.ndim:
            try:
                actual.setflags(write=True)
            except ValueError:
                pass
            else:
                raise AssertionError('Mutable deployment ' + key)
    model, separate = deployment.session(), deployment.session()
    for short, bank, other in (('v', model.views, separate.views), ('a', model.actions, separate.actions)):
        assert bank.writes == len(expected[f'{short}_keys']) == 240
        for field in ('keys', 'values', 'known'):
            array = getattr(bank, field)
            assert np.array_equal(array[:240], expected[f'{short}_{field}'])
            assert not np.shares_memory(array, getattr(other, field))
    for query in expected['v_keys']:
        scores = design(query, expected['v_mean'], expected['v_scale'],
                        bool(expected['v_quadratic']), True) @ expected['v_weights']
        ordered = tuple(sorted(range(16), key=lambda index: (-scores[index], index)))
        assert model.rank_view(query, 'L') == ordered
        distances = np.square((expected['v_keys'] - query) / expected['retrieval_scale']).reshape(240, -1).sum(axis=1)
        nearest = min(range(240), key=lambda index: (distances[index], index))
        values = expected['v_values'][nearest]
        ordered = tuple(sorted(range(16), key=lambda index: (-2 * values[index, 0], values[index, 1], index)))
        assert model.rank_view(query, 'R') == ordered
        assert model.rank_view(query, 'F') == tuple(range(16))
    errors = []
    for query in expected['a_keys']:
        score = design(query, expected['a_mean'], expected['a_scale'],
                       bool(expected['a_quadratic']), False) @ expected['a_weights']
        wanted = .01 * (query[1] + score)
        actual = model.predict_delta(query, .01)
        errors.append(abs(actual - wanted))
        assert np.isclose(actual, wanted, rtol=2e-14, atol=1e-16)
    reports.append({'seed': seed, 'source_sha256': sha256(source.read_bytes()).hexdigest(),
        'deployment_sha256': sha256(exported.read_bytes()).hexdigest(), 'fields': len(expected),
        'live_rows_per_bank': 240, 'F_R_L_rank_queries_each': 240, 'A_predictions': 240,
        'max_prediction_abs_error_m': max(errors), 'ownership_passed': True})
    model.close()
    assert separate.views.writes == separate.actions.writes == 240
    separate.close()
result = {'numpy_only_import': True, 'seeds': reports,
          'scope': 'Exact conversion and independent arithmetic on archived train arrays; not held-out production quality.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))
