"""Independent CPU camera/plane/PNG replay of final B/I visual evidence.

Saved native ray ownership is checked against decoded PNGs; no fresh geometry rays.
The unchanged helper module is an earlier root-written CPU auditor, not VG/CF code.
"""
from collections import Counter
from hashlib import sha256
import importlib.util
import json
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "artifacts/integration/production_functional_001/native_functional_final/result"
OUT = Path(__file__).with_suffix(".json")
HELPER = ROOT / "artifacts/integration/root_preflight_review_001/camera_cpu_review.py"
spec = importlib.util.spec_from_file_location("root_camera_helpers", HELPER)
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)


def read(path):
    return json.loads(path.read_bytes())


def visual(path):
    raw = read(path)
    e, score = raw["evidence"], raw["score"]
    m = e["metadata"]
    png = path.with_name(path.name.replace(".visual.json", ".png"))
    data = png.read_bytes()
    assert sha256(data).hexdigest() == score["png_sha256"]
    with Image.open(png) as im:
        image = np.asarray(im.convert("RGBA"))
    assert image.shape == (512,1024,4)
    expected = e["expected"]
    targets = expected["target_ids"]
    assert m["target_ids"] == targets and m["frame_id"] == expected["frame_id"] and m["mode"] == expected["mode"]
    assert m["meters_per_blender_unit"] == expected["scale_length"]
    assert m["witness"] == {**expected["witness"], "status":expected["status"]}
    palette = np.array([h.COLORS[0]]+[h.COLORS[1+targets.index(key)] if key in targets else h.COLORS[3]
                                    for key in e["mesh_ids"][1:]])
    w = m["witness"]
    points = np.asarray((w["point_a"], w["point_b"]))
    cameras, grids = {}, {}
    for panel,side in enumerate(("global","local")):
        selected = h.unit((1,-1,1)) if side == "global" else m["selection"]["direction"]
        c, view, vp = h.camera(m["views"][side], expected["scale_length"], selected)
        assert all(v for k,v in c["checks"].items() if k != "direction")
        px = h.project(points, vp)
        assert np.allclose(px,e["witness_pixels"][side],atol=.005,rtol=0)
        grid = e["grid"][side]
        owner = h.unpack(grid["owners_i32le"],"<i4",(625,))
        bottom = h.unpack(grid["bottom_rgba"],"u1",(625,4))
        bad = set(np.flatnonzero(~h.matches(bottom,palette[owner])).tolist())
        for i,near in grid["edge_owners"]:
            if i in bad and h.matches(bottom[i],palette[near]).any():
                bad.remove(i)
        mask = (h.GRID[:,1]>=64)&(h.GRID[:,1]<=447)
        mask &= h.GRID[:,0]<511 if panel==0 else h.GRID[:,0]>0
        for point in px:
            mask &= ((h.GRID-point)**2).sum(axis=1)>32**2
        public = image[h.GRID[:,1],h.GRID[:,0]+panel*512]
        drift = int(np.count_nonzero(mask & (public!=bottom).any(axis=1)))
        assert not bad and drift==0
        grids[side] = {"rays":625,"unresolved_owner_color_mismatches":len(bad),"public_drift":drift}
        cameras[side] = c
        if side == "local":
            local_px, local_view = px, view
    section_detail = None
    section_ok = m["mode"] == "NATURAL" and m["section"] is None
    if m["mode"] == "SECTION":
        section = m["section"]
        axis = (points[1]-points[0])/w["distance_m"]
        direction = np.asarray(cameras["local"]["rna_backward"])
        normal = h.unit(direction-(direction@axis)*axis)
        declared = np.asarray(section["normal"])
        center = points.mean(axis=0)
        section_ok = (section["kept_side"] == "<=0"
                      and np.allclose(section["point_m"],center,atol=e["depth_tolerance_m"],rtol=h.TOL)
                      and h.close(declared,normal))
        p32 = points.astype(np.float32)
        a32 = p32[1]-p32[0]
        a32 /= np.linalg.norm(a32)
        d32 = np.asarray(m["selection"]["direction"],dtype=np.float32)
        n32 = d32-(d32@a32)*a32
        n32 /= np.linalg.norm(n32)
        section_detail = {"strict_normal":normal.tolist(),"declared_normal":declared.tolist(),
                          "error":(declared-normal).tolist(),"budget":(h.TOL*(1+np.abs(normal))).tolist(),
                          "axis_float64":axis.tolist(),"axis_float32_points":a32.tolist(),
                          "float32_reconstruction":n32.tolist(),
                          "float32_reconstruction_bit_equal":bool(np.array_equal(n32.astype(float),declared)),
                          "declared_dot_float64_axis":float(declared@axis),
                          "angle_rad":h.angle(declared,normal),
                          "midpoint_error_m":(np.asarray(section["point_m"])-center).tolist()}
    assert bool(section_ok) == score["checks"]["section_declaration"]
    direction_ok = all(c["checks"]["direction"] for c in cameras.values())
    assert direction_ok == score["checks"]["directions"]
    codes = [e["mesh_ids"].index(t) for t in targets]
    def sample(record, expected_xy):
        xy = np.asarray(record["pixels"],dtype=int)
        assert np.array_equal(xy,expected_xy)
        owner = np.asarray(record["owners"],dtype=int)
        face = np.asarray(record["faces"],dtype=int)
        depth = np.asarray([np.inf if x is None else x for x in record["depth_m"]])
        counts = np.asarray(e["face_counts"])
        assert (((owner==0)&(face==-1)&np.isinf(depth))|
                ((owner>0)&(face>=0)&(face<counts[owner])&np.isfinite(depth)&(depth>0))).all()
        bottom = h.unpack(record["bottom_rgba"],"u1",(len(xy),4))
        public = image[xy[:,1],xy[:,0]+512]
        return xy,owner,depth,h.matches(bottom,palette[owner])&h.matches(public,palette[owner])
    support = []
    for px,code,raw_sample in zip(local_px,codes,e["samples"]["supports"]):
        _,owner,_,ok = sample(raw_sample,h.neighbors(px))
        support.append(int(np.count_nonzero((owner==code)&ok)))
    xy,owner,depth,ok = sample(e["samples"]["interior"],h.line(*local_px)[1:-1])
    delta = local_px[1]-local_px[0]
    separation = float(np.linalg.norm(delta))
    fraction = np.clip((xy-local_px[0])@delta/separation**2,0,1)
    depths = -(np.column_stack((points,np.ones(2)))@local_view[2])
    clear = ~np.isin(owner,codes)&(depth>depths[0]+fraction*(depths[1]-depths[0])+e["depth_tolerance_m"])
    run = h.longest(clear&ok)
    assert min(support)>=2 and run>=3 and abs(separation-m["selection"]["gap_pixels"])<=.005
    assert len(e["trace"]) == e["ray_count"] == m["selection"]["ray_count"]
    assert sum(p["ray_count"] for p in m["selection"]["probes"]) == e["ray_count"]
    failed = [k for k,v in score["checks"].items() if not v]
    assert all(k in ("directions","section_declaration") for k in failed)
    assert score["passed"] == bool(direction_ok and section_ok)
    return {"file":path.relative_to(BASE).as_posix(),"png_sha256":score["png_sha256"],
            "passed":score["passed"],"failed_checks":failed,"direction_ok":direction_ok,
            "section_ok":bool(section_ok),"section_detail":section_detail if not section_ok else None,
            "grids":grids,"support":support,"gap_run":run,"projected_gap":separation,
            "local_camera":cameras["local"] if failed else None}


def main():
    rows, feedback = [], []
    counts = Counter()
    for i_path in sorted(BASE.glob("*/*/I/*.visual.json")):
        b_path = i_path.parent.parent / "B" / i_path.name
        i,b = read(i_path),read(b_path)
        assert i["score"] == b["score"]
        assert i["evidence"] == b["evidence"]
        row = visual(i_path)
        rows.append(row)
        arm = i_path.relative_to(BASE).parts[0]
        counts[arm+"_total"] += 1
        counts[arm+"_pass"] += int(row["passed"])
    assert len(rows)==90 and sum(r["passed"] for r in rows)==87
    assert counts==Counter({"L_total":72,"L_pass":69,"F_total":9,"F_pass":9,"R_total":9,"R_pass":9})
    for folder in sorted(BASE.glob("*/*")):
        if not (folder/"I/record.json").exists():
            continue
        i,b = read(folder/"I/record.json"),read(folder/"B/record.json")
        assert i["model_calls"]==b["model_calls"] and i["feedback_state"]==b["feedback_state"]
        calls = [call for call in i["model_calls"] if call["method"]=="learn_view"]
        assert all(call["phase"]=="feedback" for call in calls)
        if folder.parent.name == "F":
            assert calls==[]
            continue
        assert len(calls)==2
        for phase,call in zip(("before","after"),calls):
            raw = read(folder/"I"/(phase+".visual.json"))
            assert call["args"][:3]==[raw["evidence"]["candidate"],raw["score"]["safe"],raw["evidence"]["selected_rays"]]
            if not call["args"][1]:
                feedback.append({"case":folder.name,"arm":folder.parent.name,"phase":phase,
                                 "actual_learn_view_args":call["args"],"kwargs":call["kwargs"]})
    assert len(feedback)==2
    result = {"scope":"Independent CPU camera/plane/PNG sample replay; no fresh native geometry rays or renders",
              "helper_sha256":sha256(HELPER.read_bytes()).hexdigest(),"counts":dict(counts),
              "B_I_score_and_evidence_equal_pairs":90,"pixel_subset_passes":90,
              "strict_passes_per_side":87,"actual_negative_feedback":feedback,
              "failures":[r for r in rows if not r["passed"]],"records":rows}
    OUT.write_text(json.dumps(result,indent=2,allow_nan=False)+"\n",encoding="utf-8")
    print(json.dumps({k:v for k,v in result.items() if k not in ("records","failures")},indent=2))


if __name__ == "__main__":
    main()
