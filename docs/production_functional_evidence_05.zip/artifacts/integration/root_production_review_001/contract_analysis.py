"""Read-only CPU evidence audit; no imports of Blender or live engine code."""
from collections import Counter
from hashlib import sha256
import gzip
import json
from pathlib import Path
from zipfile import ZipFile

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'artifacts/integration/production_functional_001'
OUT=Path(__file__).parent
def read(p):return json.loads(p.read_bytes())
def digest(data):return sha256(data).hexdigest()
def norm(v):
    if isinstance(v,dict):return {k:norm(x) for k,x in v.items() if k not in ('score_ns','elapsed_ns')}
    if isinstance(v,list):return [norm(x) for x in v]
    return v
def canon(v):return json.dumps(norm(v),ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
identity=read(BASE/'source-identity.json')
artifact_errors=[]
for name,value in identity['artifact_files_relative_to_this_directory'].items():
    data=(BASE/name).read_bytes()
    if len(data)!=value['bytes'] or digest(data)!=value['sha256']:artifact_errors.append(name)
assert not artifact_errors
job=BASE/'native_functional_final'
launch=read(job/'launch.json')
with ZipFile(job/'sources.zip') as archive:
    source_errors=[name for name,expected in launch['source_superset'].items() if digest(archive.read(name))!=expected]
    assert not source_errors
    observed=read(job/'observed-project-imports.json')['paths']
    assert all(digest(archive.read(name))==expected for name,expected in observed.items())
    archived_sources={name:digest(archive.read(name)) for name in ('verification/test_blender_radical_session.py','verification/test_radical_session_controls.py','verification/integration_reference.py','human_eye_fast/control.py')}
summary=read(job/'result/summary.json')
result={'scope':'CPU archive/record/byte audit only; no native runs or implementation edits',
    'source_identity_sha256':digest((BASE/'source-identity.json').read_bytes()),
    'artifact_identity_checks':{'entries':len(identity['artifact_files_relative_to_this_directory']),'errors':artifact_errors},
    'native_archive':{'source_entries':len(launch['source_superset']),'observed_entries':len(observed),'hash_errors':source_errors,'selected_sources':archived_sources},
    'main':{},'old_cf_quality':{}}
public_pairs=score_pairs=0;failures=[];main=[];negative_submitted=[]
for item in summary['main']:
    arm,case=item['view_arm'],item['case'];folder=job/'result'/arm/case
    records={kind:read(folder/kind/'record.json') for kind in ('B','I')}
    for name in ('before.ao.json','transition.ao.json','next.ao.json','before.png','after.png','next.png'):
        assert (folder/'B'/name).read_bytes()==(folder/'I'/name).read_bytes(),(arm,case,name)
        public_pairs+=1
    for key in ('model_calls','feedback_state','measured_delta_m','predicted_delta_m','next_prediction_m'):
        assert records['B'][key]==records['I'][key],(arm,case,key)
    def captures(record):
        rows=record['capture_calls'];assert len({r['bridge'] for r in rows})==1
        for phase in ('before','after','next'):
            batch=[r for r in rows if r['phase']==phase]
            assert batch and len({r['graph'] for r in batch})==1
            assert len({r['object'] for r in batch})==len(batch)
        assert {r['phase'] for r in rows}=={'before','after','next'}
        return [{k:r[k] for k in ('phase','object','mask')} for r in rows]
    assert captures(records['B'])==captures(records['I'])
    scores={}
    for phase in ('before','after','next'):
        b=read(folder/'B'/f'{phase}.visual.json');i=read(folder/'I'/f'{phase}.visual.json')
        assert b['score']==i['score'];score_pairs+=1;scores[phase]=b['score']
        png=(folder/'B'/f'{phase}.png').read_bytes();assert digest(png)==b['score']['png_sha256']
        if not b['score']['passed']:
            failures.append({'arm':arm,'case':case,'phase':phase,'checks':[k for k,v in b['score']['checks'].items() if not v]})
    events=[e for e in records['B']['model_calls'] if e['method']=='learn_view']
    assert len(events)==(0 if arm=='F' else 2)
    for event,phase in zip(events,('before','after')):
        # learn_view args are selected index, native_stop AND strict pixel verdict, rays.
        assert event['args'][1] == scores[phase]['safe']
        if not event['args'][1]:negative_submitted.append({'arm':arm,'case':case,'phase':phase})
    main.append({'arm':arm,'case':case,'predictor':item['predictor'],'captures_per_arm':len(records['B']['capture_calls']),
                 'model_calls_per_arm':len(records['B']['model_calls'])})
assert public_pairs==180 and score_pairs==90
controls=summary['controls'];assert controls==read(job/'result/controls/results.json')
result['main']={'snapshot_sha256':summary['frozen_sha256'],'deployment_sha256':summary['deployment_sha256'],
    'chain_counts':dict(Counter(x['view_arm'] for x in summary['main'])),'actual_public_byte_pairs':public_pairs,
    'actual_strict_score_pairs':score_pairs,'strict_pass_per_arm':score_pairs-len(failures),'strict_failures':failures,
    'negative_feedback_submitted_per_arm':negative_submitted,'rows':main,'controls':controls,'control_count':len(controls)}

def media_ids(paths):
    result={}
    for path in paths:
        with ZipFile(path) as z:
            for info in z.infolist():
                data=z.read(info);identity=(len(data),digest(data))
                if info.filename in result:assert result[info.filename]==identity
                result[info.filename]=identity
    return result
def raw_rows(paths):
    result=[]
    for path in paths:
        with gzip.open(path,'rt',encoding='utf-8') as f:
            result.extend(canon(json.loads(line)) for line in f)
    return result
def tree_ids(folder):return {p.relative_to(folder).as_posix():digest(p.read_bytes()) for p in folder.rglob('*') if p.is_file()}
oldroot=BASE/'old_cf_quality'
old_manifest=read(oldroot/'manifest.json')
with ZipFile(oldroot/'sources.zip') as z:
    for name,value in old_manifest['source_files'].items():
        data=z.read(name);assert len(data)==value['bytes'] and digest(data)==value['sha256']
    replay=z.read('verification/replay_cf_quality_after_integration.py').decode()
    experiment=z.read('verification/cf_experiment.py').decode()
    native=z.read('verification/cf_native.py').decode()
    assert 'cf_experiment.run(Namespace(' in replay
    assert 'from verification.cf_native import ActionEpisode, ViewEpisode' in experiment
    assert 'self.controller = BlenderControl(' in native
    assert not any(word in replay+experiment+native for word in ('BlenderRadicalSession(', 'load_cf_deployment('))
for seed in (20261105,79463,310519):
    actual=oldroot/str(seed);original=ROOT/'artifacts/cf/formal_001'/str(seed)
    archives=[original/'evaluation']
    if (original/'evaluation-completion').is_dir():archives.append(original/'evaluation-completion')
    final=archives[-1]
    expected_summary=read(final/'summary.json');actual_summary=read(actual/'summary.json')
    a={k:v for k,v in actual_summary.items() if k!='environment'}
    e={k:v for k,v in expected_summary.items() if k!='environment'}
    assert canon(a)==canon(e)
    expected_media=media_ids([p/'media.zip' for p in archives]);actual_media=media_ids([actual/'media.zip'])
    assert expected_media==actual_media
    expected_raw=raw_rows([p/'records.jsonl.gz' for p in archives]);actual_raw=raw_rows([actual/'records.jsonl.gz'])
    assert expected_raw==actual_raw
    pre_media=media_ids([actual/'prequential/media.zip']);assert pre_media==media_ids([final/'prequential/media.zip'])
    pre_raw=raw_rows([actual/'prequential/records.jsonl.gz']);assert pre_raw==raw_rows([final/'prequential/records.jsonl.gz'])
    assert tree_ids(actual/'visual-negatives')==tree_ids(final/'visual-negatives')
    runtime=read(actual/'runtime-native.json')
    for name,value in runtime['observed_project_modules'].items():assert old_manifest['source_files'][name]==value
    result['old_cf_quality'][str(seed)]={'summary_same_excluding_environment_and_two_duration_fields':True,
        'view_counts':{arm:len(rows) for arm,rows in actual_summary['views'].items()},'action_count':len(actual_summary['actions']),
        'media_members':len(actual_media),'normalized_raw_records':len(actual_raw),
        'prequential_media_members':len(pre_media),'prequential_raw_records':len(pre_raw),
        'runtime_modules':len(runtime['observed_project_modules']),
        'path':'replay native -> cf_experiment.evaluate -> cf_native ViewEpisode/ActionEpisode; load_frozen; no production session/deployment invocation'}
result['old_cf_scope']='Legacy component quality and seam compatibility, not full production-session replay of the original CF suite.'
(OUT/'contract_analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
print('ARTIFACT',result['artifact_identity_checks'],'NATIVE_SOURCE',result['native_archive'])
print('MAIN',{k:v for k,v in result['main'].items() if k not in ('rows','controls')})
print('OLD_CF',result['old_cf_quality'])
