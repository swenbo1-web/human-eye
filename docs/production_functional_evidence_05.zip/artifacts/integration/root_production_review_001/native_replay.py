"""Fixed root functional replay; no timing or optimization experiment."""
from pathlib import Path
import sys
import json
from hashlib import sha256

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))

def main():
    import bpy
    from human_eye_fast.cf_deployment import load_cf_deployment
    from human_eye_fast.fast_affordance_out import public_schema
    from verification.cf_training import load_frozen
    from verification.cf_visual_acceptance import PillowWorker
    from verification.integration_fixtures import fixture_manifest, build_fixture, _formal_plan
    from verification.test_blender_radical_session import _run_arm
    from verification.test_radical_session_controls import run_controls
    assert bpy.app.background
    out = Path(sys.argv[sys.argv.index('--out') + 1])
    out.mkdir(parents=True)
    author = ROOT / 'artifacts/integration/production_functional_001'
    frozen = load_frozen(ROOT / 'artifacts/cf/formal_001/20261105/seal/frozen.npz')
    deployment = load_cf_deployment(author / 'deployments/20261105.npz')
    schema = public_schema()
    records = []
    # Fixed before execution: all six families, both finite command kinds,
    # ordinary and section images, both known strict-negative scenes.
    selected = (0, 5, 9, 13, 17, 20)
    with PillowWorker(Path(r'D:\human eye\venv\Scripts\python.exe')) as scorer:
        for index in selected:
            spec = fixture_manifest()[index]
            plan = _formal_plan(spec)
            fixture = build_fixture(spec)
            predictor = plan['arms']['deployment']['predictor']
            runs = {}
            for kind in ('B', 'I'):
                folder = out / spec.case_id / kind
                runs[kind] = _run_arm(kind, fixture, plan, 'L', predictor, frozen,
                                      deployment, scorer, schema, folder)
                prior = author / 'native_functional_final/result/L' / spec.case_id / kind
                for file in sorted(folder.glob('*')):
                    if file.name.endswith(('.png', '.ao.json')):
                        assert file.read_bytes() == (prior / file.name).read_bytes(), str(file)
                archived = json.loads((prior / 'record.json').read_bytes())
                for field in ('model_calls', 'feedback_state', 'measured_delta_m',
                              'predicted_delta_m', 'next_prediction_m'):
                    # JSON canonicalization only converts tuples to archived lists.
                    assert json.loads(json.dumps(runs[kind][0][field])) == archived[field], (spec.case_id, kind, field)
            assert runs['B'][1:] == runs['I'][1:], spec.case_id
            records.append({'case': spec.case_id, 'predictor': predictor,
                            'public_and_scores_equal': True, 'archive_equal': True,
                            'strict': {role: {'passed': score['passed'],
                                        'failed_checks': [k for k, v in score['checks'].items() if not v]}
                                       for role, score in runs['I'][3].items()}})
        controls = run_controls(out / 'controls', deployment, schema)
    (out / 'summary.json').write_text(json.dumps({'selected_indices': selected, 'main': records,
        'controls': controls, 'scope': 'Independent process replay of fixed subset; not independent implementation or performance measurement'}, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'cases': len(records), 'controls': len(controls), 'status': 'PASS'}))

if __name__ == '__main__':
    main()
