# 统一 Blender 会话生产接线与功能证据

按主干 42ddcf2 冻结的接口实现生产会话、最小控制器接缝、CF v1 加载器和独立后台示例。普通 NumPy 环境可导入公开接口。以下证据用于功能复审。正式 I/B、旧 CF 性能及资源增量仍由主干单独审定。 [冻结 API](../../../docs/ENGINE_INTEGRATION_API.md)

| 验证 | 结果 |
| --- | --- |
| [原生功能](native_functional_final/result/summary.json) | 24 个部署 L 主例及 3 个 F/G、3 个 R/G 固定对照。共 180 对 B/I AO 或 PNG 字节一致，公开捕获/帧、预测和实测、活动模型状态一致。另通过 14 个原生控制，部署格式控制见下一行。 |
| [三个 CF 部署](deployments/summary.json) | 原三个封存模型离线导出。每 seed 核对 18 个字段、两库各 240 个活动行及写入次序、F/R/L 排序、A 预测、一次归档真实 V/A 反馈后的状态。 |
| [便携回归](portable_final/unittest.log) · [NumPy-only 入口](portable_001/numpy-only-import.json) | 65 项通过。包含真实接缝的便携故障注入、写后 Outcome、部分捕获失败后恢复索引、借用前事实保持、部署和数组/BC/AO/TD/CF 回归。用导入钩子拒绝 Blender 模块时普通入口仍可导入。 |
| [旧控制器](legacy_control_003/worker.log) · [旧 Blender 桥](legacy_bridge_001/worker.log) | 原生控制器的直接空面写入和无有限 delta 保持，其他动作矩阵及桥检查通过。 |
| [独立后台示例](example_fixture_002/recipe.json) · [公开消费者](example_fixture_002/consumer-check.json) | 显式 .blend、scene、view layer、对象 ID、拓扑代、参考帧、部署、mode 和命令。实际 PNG 绑定已归档评分，反馈后生成下一观察。原公开消费者读回 3 个 AO、3 个 PNG 和 schema，角色归一后的事实及 PNG 与历史匹配。 |
| [旧 CF 全量质量](old_cf_quality/summary.json) | 三个封存 seed 各 60 个 V 案例的五个臂和 60 个 A 案例，含原控制、诊断、连续反馈和负例。每 seed 的质量、媒体和记录与原证据一致，首个 seed 的 R 射线比 0.8125 保持原失败。 |

严格视觉每臂 87/90，L 为 69/72，F 和 R 各 9/9。随动屏的 after/next 保持同一 `directions` 失败。嵌套双鼓的 before 仅 `section_declaration` 失败，法向 y 分量差约 `1.71e-6`，高于 `1.18e-6` 的该分量容差，像素网格无误配。归档见证转 float32 后可以逐分量复算声明法向。两臂输出和严格判定一致，实际提交的两个失败反馈保持 false，next 没有反馈。 [嵌套双鼓严格评分](native_functional_final/result/L/I-nested-drums-1/I/before.visual.json) · [随动屏严格评分](native_functional_final/result/L/I-carried-screen-0/I/after.visual.json)

初次公开示例的独立对账发现示例默认的参考物体代号为 2，历史显式代号为 1，实际回读及三幅 PNG 已吻合。示例增加逐对象 `--generation` 参数，第二次以历史公开代号对账。原始失败记录保留。首次旧控制器测试的四个动作断言通过，运行时采集因未初始化 GPU 失败。后续在测试结束后单独初始化 GPU 取得设备指纹。旧薄基线回归还发现控制器回调字段名会遮蔽其已有同名方法，字段已改名。部分捕获失败的独立复核补上了索引失效和下一观察恢复测试。 [示例首轮对账](example_fixture_001/consumer-check.json) · [首次指纹错误](legacy_control_001/runtime-error.txt)

本轮较早完成的两次冻结 B/B 诊断分别得到下一查询比值 1.0123 和 1.0033，全部 next 工作与反馈后模型状态一致。原先 1.0768 的失败保留，原因仍未确定。独立 B 资源链重置追踪峰后得到 7,445,833 B 窗口峰，采样目标 2 ms 的实际最大间隔为 22.402 ms，只报告样本可见峰。 [限定诊断登记](../method_diagnostic_001/manifest.json) · [资源诊断](../method_diagnostic_001/resource/result/summary.json)

启动记录绑定实际命令、白名单环境、运行时、输入和源码快照。公开输出与源码摘要见 [交付身份](source-identity.json)。
