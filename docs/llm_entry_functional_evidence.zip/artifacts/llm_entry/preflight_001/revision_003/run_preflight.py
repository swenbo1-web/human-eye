"""Register the R1–R4 checks and exactly one authorized two-process native recheck."""

from argparse import ArgumentParser
from dataclasses import asdict
from hashlib import sha256
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
from zipfile import ZIP_DEFLATED, ZipFile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
NATIVE_WORKER = HERE / "task_native_worker.py"
PREVIOUS = HERE.parent / "revision_002"
BASE = "37c672c"
PYTHON = Path(r"D:\human eye\venv\Scripts\python.exe")
BLENDER = Path(r"C:\Program Files\Blender Foundation\Blender 5.2\blender.exe")
ENV = dict.fromkeys(("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                     "BLIS_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS",
                     "PYTHONDONTWRITEBYTECODE"), "1")
ENV_KEYS = (*ENV, "PYTHONPYCACHEPREFIX", "PYTHONPATH", "PYTHONHASHSEED",
            "OMP_DYNAMIC", "MKL_DYNAMIC", "CUDA_VISIBLE_DEVICES", "BLENDER_GPU_BACKEND")
PRODUCTION = (
    "human_eye_llm_stdio.py", "human_eye_fast/blender_llm_bridge.py",
    "human_eye_fast/llm_entry.py", "human_eye_fast/local_tasks.py",
    "examples/blender_llm_entry.py",
)
CONTRACT = ("docs/LLM_ENTRY_ARCHITECTURE.md", "docs/LLM_ENTRY_WORK_ORDER.md",
            "docs/LLM_ENTRY_API_DRAFT.md", "docs/LLM_ENTRY_PREFLIGHT_REVIEW.md",
            "docs/LLM_ENTRY_RECHECK_PROTOCOL.md")
CPU = ("verification/test_llm_entry.py", "verification/test_local_tasks.py")
NATIVE = ("verification/llm_entry_fixtures.py", "verification/test_bc_acceptance.py",
          "verification/test_raycast_saccade_gpu.py")
RUNTIME = "artifacts/integration/method_diagnostic_001/runtime_identity.py"
sys.path.insert(0, str(ROOT))

from artifacts.integration.method_diagnostic_001.runtime_identity import identity, write_json


def _git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()


def _sources(phase):
    frozen = [name for name in _git("ls-tree", "-r", "--name-only", BASE, "human_eye_fast").splitlines()
              if name.endswith(".py")]
    if len(frozen) != 17:
        raise RuntimeError("Expected 17 frozen engine sources")
    subprocess.run(["git", "diff", "--exit-code", BASE, "--", *frozen], cwd=ROOT, check=True)
    paths = [ROOT / name for name in (*frozen, *PRODUCTION, *CONTRACT, RUNTIME)]
    paths.append(Path(__file__))
    if phase == "cpu":
        paths.extend(ROOT / name for name in CPU)
    else:
        paths.append(NATIVE_WORKER)
        paths.extend(ROOT / name for name in NATIVE)
    return {path.relative_to(ROOT).as_posix(): path.read_bytes() for path in sorted(paths)}


def _jobs(phase, out):
    if phase == "cpu":
        return [{
            "name": "cpu", "timeout_s": 60, "hidden": False,
            "argv": [str(PYTHON), "-B", "-m", "unittest", "-v",
                     "verification.test_local_tasks", "verification.test_llm_entry"],
        }], {}
    from artifacts.llm_entry.preflight_001.revision_003.task_native_worker import NATIVE_CASES, case_calls
    from verification.llm_entry_fixtures import EPISODES

    jobs, cases = [], {}
    for name, options in NATIVE_CASES.items():
        if len(options) > 6:
            raise RuntimeError("Each native process is limited to six cases")
        args = ["--factory-startup", "--disable-autoexec", "--threads", "1", "--python-exit-code", "1",
                "--python", str(NATIVE_WORKER), "--", "--mode", name, "--out", str(out / name / "result"),
                "--python", str(PYTHON)]
        if name == "background":
            args.insert(0, "--background")
        jobs.append({"name": name, "timeout_s": 150, "hidden": name == "gui",
                     "case_names": [key for key, _, _ in options],
                     "argv": [str(BLENDER), *args]})
        cases[name] = [
            {"fixture": asdict(EPISODES[key]), "calls": case_calls(EPISODES[key], inspections, mode)}
            for key, inspections, mode in options
        ]
    if [(job["name"], job["case_names"]) for job in jobs] != [
        ("background", ["nonconvex", "parented", "already-reached"]), ("gui", ["occluded", "parented-rescaled"]),
    ]:
        raise RuntimeError("Register the exact original cases in one background process followed by one factory GUI")
    return jobs, cases


def _environment(out, name):
    overrides = {**ENV, "PYTHONPYCACHEPREFIX": str(out / name / "isolated-pycache")}
    return overrides, {key: ({**os.environ, **overrides}).get(key) for key in ENV_KEYS}


def _launch(phase, out, job, registered_sources, manifest_path, executable):
    name = job["name"]
    folder = out / name
    folder.mkdir()
    if _sources(phase) != registered_sources or identity(job["argv"][0]) != executable:
        raise RuntimeError("Source or executable changed after registration")
    overrides, recorded = _environment(out, name)
    if recorded != job["environment_effective"]:
        raise RuntimeError("Environment changed after registration")
    write_json(folder / "launch.json", {**job, "manifest": identity(manifest_path)})
    kwargs = {}
    if job["hidden"]:
        startup = subprocess.STARTUPINFO()
        startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startup.wShowWindow = subprocess.SW_HIDE
        kwargs["startupinfo"] = startup
    print(f"Starting {name}", flush=True)
    result = {"name": name, "exit_code": None, "timed_out": False, "launch_error": None}
    with (folder / "worker.log").open("wb") as log:
        try:
            child = subprocess.run(job["argv"], cwd=ROOT, env={**os.environ, **overrides},
                                   stdout=log, stderr=subprocess.STDOUT, timeout=job["timeout_s"], **kwargs)
            result["exit_code"] = child.returncode
        except subprocess.TimeoutExpired:
            result["timed_out"] = True
        except OSError as error:
            result["launch_error"] = str(error)
    report_path = folder / "result/summary.json"
    report = json.loads(report_path.read_bytes()) if report_path.is_file() else {}
    result["reported_status"] = report.get("status")
    result["case_count"] = len(report.get("jobs", []))
    result["case_names"] = [case.get("name") for case in report.get("jobs", [])]
    result["sources_stable"] = _sources(phase) == registered_sources
    result["executable_stable"] = identity(job["argv"][0]) == executable
    result["passed"] = bool(
        result["exit_code"] == 0 and result["sources_stable"] and result["executable_stable"]
        and (phase == "cpu" or (report.get("status") == "passed" and result["case_names"] == job["case_names"]))
    )
    write_json(folder / "process.json", result)
    print(json.dumps(result), flush=True)
    return result


def run(phase, attempt):
    out = HERE / f"{phase}_{attempt:03d}"
    if out.exists():
        raise FileExistsError(out)
    prior_native = sorted(HERE.glob("native_*/**/launch.json"))
    if phase == "native" and prior_native:
        raise RuntimeError("Revision 003 native launch markers exist. This authorized recheck cannot repeat.")
    previous = {
        "reviewed_delivery_manifest": identity(PREVIOUS / "delivery_001/manifest.json"),
        "reviewed_delivery_source_zip": identity(PREVIOUS / "delivery_001/sources.zip"),
        "failed_native_manifest": identity(PREVIOUS / "native_001/manifest.json"),
        "failed_native_summary": identity(PREVIOUS / "native_001/summary.json"),
        "background_launch": identity(PREVIOUS / "native_001/background/launch.json"),
        "gui_launch": identity(PREVIOUS / "native_001/gui/launch.json"),
        "windows_pid_probe": identity(PREVIOUS / "venv_pid_probe_001/stdout.txt"),
    }
    if (previous["reviewed_delivery_manifest"]["sha256"] != "4b4da2c2825aef8b84d1bc6f2f2b1dc4b4fac7f5b33ed0ebab624bb25316f56c"
            or previous["reviewed_delivery_source_zip"]["sha256"] != "b8e04f01a331d21e4d1f53ab72f41a77c8f49fc9589a66593089a51b8fafde3e"):
        raise RuntimeError("Prior delivery archive differs from independent review 024")
    jobs, cases = _jobs(phase, out)
    for job in jobs:
        job["environment_overrides"], job["environment_effective"] = _environment(out, job["name"])
    sources = _sources(phase)
    executables = {"launcher": identity(sys.executable), "portable_python": identity(PYTHON)}
    if phase == "native":
        executables["blender"] = identity(BLENDER)
    manifest = {
        "revision": 3, "scope": phase, "frozen_engine_base": BASE, "head": _git("rev-parse", "HEAD"),
        "sources": {name: sha256(raw).hexdigest() for name, raw in sources.items()},
        "executables": executables, "platform": platform.platform(), "launcher_version": sys.version,
        "jobs": jobs, "cases": cases, "data": "Native fixtures constructed in process from frozen source; no external scene or model",
        "native_process_budget": {"authorized_for_this_recheck": 2, "registered": len(jobs) if phase == "native" else 0},
        "prior_revision_evidence": previous,
        "transport_preflight": identity(HERE.parent / "transport_003" / "manifest.json"),
        "limits": ["MCP 2025-06-18, one JSON TextContent and one optional PNG ImageContent",
                   "Non-directory inspect uses the task_id returned by eye_run; complete wire frames are recorded",
                   "GUI visibility measured from the worker's first observation and around each case; no claim before Python initialization",
                   "Native factory GUI and background, no user Blender or host registration",
                   "No model, provider, performance, or actual host image-consumption qualification"],
    }
    out.mkdir()
    with ZipFile(out / "sources.zip", "x", ZIP_DEFLATED) as archive:
        for path, raw in sources.items():
            archive.writestr(path, raw)
    manifest_path = out / "manifest.json"
    write_json(manifest_path, manifest)
    print(f"Registered {phase}: {identity(manifest_path)['sha256']}", flush=True)
    executable = executables["portable_python" if phase == "cpu" else "blender"]
    results = [_launch(phase, out, job, sources, manifest_path, executable) for job in jobs]
    passed = all(result["passed"] for result in results)
    write_json(out / "summary.json", {"phase": phase, "passed": passed, "processes": results})
    return 0 if passed else 1


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("cpu", "native"))
    parser.add_argument("--attempt", type=int, default=1)
    args = parser.parse_args()
    if not 1 <= args.attempt <= 999 or (args.phase == "native" and args.attempt != 1):
        parser.error("Only CPU qualification can use a numbered retry")
    sys.exit(run(args.phase, args.attempt))
