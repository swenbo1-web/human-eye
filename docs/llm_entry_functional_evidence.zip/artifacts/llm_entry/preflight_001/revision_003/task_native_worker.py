"""Drive a native LLMEntry through an independent client and the real stdio relay."""

from argparse import ArgumentParser
from contextlib import contextmanager
from copy import deepcopy
from hashlib import sha256
import json
from math import isclose
import os
from pathlib import Path
import subprocess
import sys
from threading import get_ident, main_thread
from time import monotonic, sleep
import traceback
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[4]
NO_WINDOW = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
PROTOCOL_VERSION = "2025-06-18"
POLL_INTERVAL = 0.005
NATIVE_CASES = {
    "background": (("nonconvex", ("directory", "witness"), None),
                   ("parented", ("witness",), None),
                   ("already-reached", ("witness",), None)),
    "gui": (("occluded", ("witness",), "SECTION"),
            ("parented-rescaled", ("witness",), None)),
}


def _write_json(path, data):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(data, stream, allow_nan=False, indent=2)
        stream.write("\n")


def _read_json(path):
    return json.loads(path.read_bytes())


def _tool_fields(result):
    assert "structuredContent" not in result
    text = result["content"][0]
    assert text["type"] == "text"
    fields = json.loads(text["text"])
    assert isinstance(fields, dict)
    return fields


class _Rpc:
    def __init__(self, relay, requests, responses):
        self.relay = relay
        self.requests = requests
        self.responses = responses
        self.request_id = 0

    def send(self, method, params=None, *, notify=False):
        frame = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            frame["params"] = params
        if not notify:
            self.request_id += 1
            frame["id"] = self.request_id
        raw = json.dumps(frame, separators=(",", ":"), allow_nan=False).encode("utf-8") + b"\n"
        self.requests.write(raw)
        self.requests.flush()
        self.relay.stdin.write(raw)
        self.relay.stdin.flush()
        if notify:
            return None

        raw = self.relay.stdout.readline()
        self.responses.write(raw)
        self.responses.flush()
        assert raw.endswith(b"\n"), "Expected a complete MCP response line"
        response = json.loads(raw)
        assert response["jsonrpc"] == "2.0" and response["id"] == self.request_id, response
        assert "error" not in response, response
        return response["result"]


def _exchange(rpc, calls):
    initialized = rpc.send("initialize", {
        "protocolVersion": PROTOCOL_VERSION,
        "capabilities": {},
        "clientInfo": {"name": "native-task-qualification", "version": "2"},
    })
    assert initialized["protocolVersion"] == PROTOCOL_VERSION, initialized
    assert "tools" in initialized["capabilities"], initialized
    rpc.send("notifications/initialized", notify=True)
    listing = rpc.send("tools/list")
    assert [tool["name"] for tool in listing["tools"]] == ["eye_run", "eye_inspect"], listing

    results = []
    latest_task = None
    for call in calls:
        name = call["name"]
        arguments = dict(call["arguments"])
        if (name == "eye_inspect" and arguments["evidence"] != "directory"
                and "task_id" not in arguments):
            assert latest_task is not None, "No prior task ID for inspection"
            arguments["task_id"] = latest_task
        result = rpc.send("tools/call", {"name": name, "arguments": arguments})
        if name == "eye_run":
            latest_task = _tool_fields(result).get("task_id")
        results.append(result)
    return {"initialized": initialized, "listing": listing, "results": results}


def _external_client(config_path):
    config = _read_json(config_path)
    folder = config_path.parent
    with (
        (folder / "requests.jsonl").open("xb") as requests,
        (folder / "responses.jsonl").open("xb") as responses,
        (folder / "relay.stderr").open("xb") as stderr,
        subprocess.Popen(
            [sys.executable, "-B", str(ROOT / "human_eye_llm_stdio.py"), "--port", str(config["port"])],
            cwd=ROOT, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr,
            creationflags=NO_WINDOW,
        ) as relay,
    ):
        try:
            report = _exchange(_Rpc(relay, requests, responses), config["calls"])
            relay.stdin.close()
            trailing = relay.stdout.read(1)
            responses.write(trailing)
            assert trailing == b"", "Unexpected relay stdout after the final response"
            assert relay.wait(timeout=5) == 0, relay.returncode
            report.update(client_pid=os.getpid(), client_parent_pid=os.getppid(), stdio_relay={
                "pid": relay.pid, "exit_code": relay.returncode, "stdin_eof": True, "stdout_eof": True,
                "request_bytes": requests.tell(), "response_bytes": responses.tell(),
            })
            _write_json(folder / "client.json", report)
        finally:
            if relay.poll() is None:
                relay.kill()


def _reap(child):
    if child is not None and child.poll() is None:
        try:
            child.wait(timeout=2)
        except subprocess.TimeoutExpired:
            child.kill()
            child.wait(timeout=5)


def wire_run(*, folder, python, binding, calls, vg_events=(), timeout=40.0):
    """Yield scheduling delays, then return client and native transport reports.

    Call on Blender's main thread. In background mode consume the generator and
    sleep for each delay. In GUI mode advance it from a Blender timer. The
    bridge's own timer drives all GUI dispatch. The caller owns the fixture and
    verifies the returned tool results and the independent RNA readback.
    """
    import bpy
    from human_eye_fast.blender_llm_bridge import Bridge, start
    from human_eye_fast.llm_entry import LLMEntry

    owner = main_thread().ident
    assert get_ident() == owner
    background = bpy.app.background
    folder = Path(folder).resolve()
    folder.mkdir(parents=True, exist_ok=True)
    native = {"pid": os.getpid(), "background": background, "main_thread_id": owner,
              "driver": "background main-thread pump" if background else "bpy.app.timers",
              "dispatch_thread_id": None, "connections": 0, "handler_calls": 0,
              "dispatch_vg_operations": [], "entry_close_vg_operations": [],
              "entry_close_calls": 0, "entry_close_thread_id": None,
              "session_present_at_eof": False, "session_closed": None}

    class TrackedEntry(LLMEntry):
        def __init__(self):
            assert get_ident() == owner
            super().__init__(binding)
            native["connections"] += 1

        def handle_line(self, line):
            assert get_ident() == owner
            native["dispatch_thread_id"] = get_ident()
            native["handler_calls"] += 1
            before = len(vg_events)
            try:
                return super().handle_line(line)
            finally:
                native["dispatch_vg_operations"].append([event["operation"] for event in vg_events[before:]])

        def close(self):
            assert get_ident() == owner
            native["entry_close_calls"] += 1
            native["entry_close_thread_id"] = get_ident()
            session = self._session
            native["session_present_at_eof"] = session is not None
            before = len(vg_events)
            try:
                super().close()
            finally:
                native["entry_close_vg_operations"].extend(event["operation"] for event in vg_events[before:])
            if session is not None:
                native["session_closed"] = session._closed

    bridge = listener = callback = child = client = None

    def finish_transport():
        nonlocal client
        native["listener_open_before_stop"] = listener is not None and listener.fileno() != -1
        native["entry_close_calls_before_stop"] = native["entry_close_calls"]
        process = {"launched_pid": None, "exit_code": None, "client_pid": None,
                   "client_parent_pid": None, "relationship": "unreported"}
        native["client_process"] = process
        try:
            try:
                if bridge is not None:
                    bridge.stop()
            finally:
                _reap(child)
        finally:
            try:
                native["listener_closed"] = listener is not None and listener.fileno() == -1
                native["timer_unregistered"] = callback is None or not bpy.app.timers.is_registered(callback)
                if child is not None:
                    process.update(launched_pid=child.pid, exit_code=child.returncode)
                    client_path = folder / "client.json"
                    if client_path.is_file():
                        client = _read_json(client_path)
                        process.update(client_pid=client["client_pid"], client_parent_pid=client["client_parent_pid"])
                        if process["client_pid"] == child.pid:
                            process["relationship"] = "direct"
                        elif os.name == "nt" and process["client_parent_pid"] == child.pid:
                            # A Windows venv executable can launch the reporting interpreter.
                            process["relationship"] = "windows_immediate_child"
                        else:
                            process["relationship"] = "mismatch"
            finally:
                _write_json(folder / "native-transport.json", native)

    try:
        bridge = Bridge(TrackedEntry) if background else start(TrackedEntry)
        listener = bridge._listener
        callback = bridge._timer_callback
        native["address"] = bridge.address
        native["timer_registered"] = callback is not None and bpy.app.timers.is_registered(callback)
        assert native["timer_registered"] == (not background)
        config_path = folder / "client-config.json"
        _write_json(config_path, {"port": bridge.address[1], "calls": calls})
        with (folder / "client.stderr").open("xb") as stderr:
            child = subprocess.Popen(
                [str(python), "-B", str(Path(__file__).resolve()), "--client", str(config_path)],
                cwd=ROOT, stdout=stderr, stderr=stderr, creationflags=NO_WINDOW,
            )
        deadline = monotonic() + timeout
        while True:
            assert get_ident() == owner
            status = child.poll()
            if status not in (None, 0):
                raise RuntimeError(f"External MCP client exited {status}. See {folder / 'client.stderr'}")
            if status == 0 and native["entry_close_calls"]:
                break
            if monotonic() >= deadline:
                raise TimeoutError("External MCP client or Entry EOF cleanup did not finish")
            if background:
                bridge.pump()
            yield POLL_INTERVAL

        assert native["connections"] == native["entry_close_calls"] == 1, native
        assert native["handler_calls"] == 3 + len(calls), native
        assert not native["session_present_at_eof"] or native["session_closed"] is True, native
        assert listener.fileno() != -1, "Bridge already stopped before explicit stop"
    except BaseException as primary:
        try:
            finish_transport()
        except Exception as cleanup_error:
            primary.add_note(f"Transport cleanup also failed: {cleanup_error!r}")
        raise
    else:
        finish_transport()

    assert native["listener_closed"] and native["timer_unregistered"], native
    assert native["entry_close_calls"] == native["entry_close_calls_before_stop"] == 1, native
    assert native["client_process"]["relationship"] in {"direct", "windows_immediate_child"}, native["client_process"]
    return {"client": client, "native": native}


def _owned_windows(*, hide):
    from ctypes import WinDLL, WINFUNCTYPE, byref, create_unicode_buffer, wintypes

    user = WinDLL("user32", use_last_error=True)
    callback_type = WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    user.EnumWindows.argtypes = (callback_type, wintypes.LPARAM)
    user.GetWindowThreadProcessId.argtypes = (wintypes.HWND, wintypes.LPDWORD)
    user.GetClassNameW.argtypes = (wintypes.HWND, wintypes.LPWSTR, wintypes.INT)
    user.IsWindowVisible.argtypes = (wintypes.HWND,)
    user.ShowWindow.argtypes = (wintypes.HWND, wintypes.INT)
    windows = []

    @callback_type
    def collect(handle, _):
        process = wintypes.DWORD()
        thread = user.GetWindowThreadProcessId(handle, byref(process))
        class_name = create_unicode_buffer(256)
        if process.value == os.getpid() and user.GetClassNameW(handle, class_name, len(class_name)):
            if class_name.value.startswith("GHOST"):
                was_visible = bool(user.IsWindowVisible(handle))
                if hide and was_visible:
                    user.ShowWindow(handle, 0)
                windows.append({"hwnd": handle, "thread_id": thread, "pid": process.value,
                                "class": class_name.value, "visible_on_observation": was_visible,
                                "visible": bool(user.IsWindowVisible(handle))})
        return True

    assert user.EnumWindows(collect, 0), "Could not enumerate Blender GHOST windows"
    return windows


def _require_hidden(windows):
    assert windows, "No owned Blender GHOST window found"
    assert not any(row["visible"] for row in windows), windows


def _inspect_call(evidence, **arguments):
    return {"name": "eye_inspect", "arguments": {"evidence": evidence, **arguments}}


def case_calls(spec, inspections, image_mode):
    from verification.llm_entry_fixtures import request_arguments

    calls = {}
    if "directory" in inspections:
        calls["directory"] = _inspect_call("directory")
    run_args = request_arguments(spec)
    if image_mode is not None:
        run_args["image_mode"] = image_mode
    calls["run"] = {"name": "eye_run", "arguments": run_args}
    for evidence in inspections:
        if evidence != "directory":
            calls[evidence] = _inspect_call(evidence)
    if image_mode == "SECTION":
        calls.update(result=_inspect_call("result"), section_camera=_inspect_call("camera"),
                     natural_image=_inspect_call("image", image_mode="NATURAL"),
                     natural_camera=_inspect_call("camera"), repeat_image=_inspect_call("image"))
    return calls


@contextmanager
def _renderer_probe(events):
    from human_eye_fast.raycast_saccade_gpu import VGRenderer

    init, observe, close = VGRenderer.__init__, VGRenderer.observe, VGRenderer.close

    def record(renderer, operation):
        event = {"operation": operation, "renderer_id": id(renderer), "completed": False}
        events.append(event)
        return event

    def counted_init(renderer, *args, **kwargs):
        event = record(renderer, "init")
        init(renderer, *args, **kwargs)
        event["completed"] = True

    def counted_observe(renderer, *args, **kwargs):
        event = record(renderer, "render")
        rendered = observe(renderer, *args, **kwargs)
        keys = ("frame_id", "target_ids", "mesh_ids", "mode", "section", "meters_per_blender_unit", "views")
        event.update(completed=True, png_sha256=sha256(rendered.png).hexdigest(),
                     metadata={key: deepcopy(rendered.metadata[key]) for key in keys})
        return rendered

    def counted_close(renderer, *args, **kwargs):
        event = record(renderer, "close")
        close(renderer, *args, **kwargs)
        event["completed"] = True

    with (patch.object(VGRenderer, "__init__", counted_init), patch.object(VGRenderer, "observe", counted_observe),
          patch.object(VGRenderer, "close", counted_close)):
        yield


def _verify_images(spec, results, fields, after, events):
    from verification.llm_entry_fixtures import MOVING, REFERENCE, validate_image

    run = fields["run"]
    assert results["result"]["content"][0] == results["run"]["content"][0]
    assert results["repeat_image"]["content"] == results["natural_image"]["content"]
    assert [event["operation"] for event in events] == ["init", "render", "render", "close"], events
    assert len({event["renderer_id"] for event in events}) == 1, events
    assert all(event["completed"] for event in events), events

    rendered = {}
    for label, mode, camera_label, actual in (("run", "SECTION", "section_camera", events[1]),
                                               ("natural_image", "NATURAL", "natural_camera", events[2])):
        compact = fields[label]["image"] if label == "run" else fields[label]
        camera = fields[camera_label]
        source = actual["metadata"]
        assert camera["evidence"] == "camera" and camera["unit"] == "m", camera
        for key in ("task_id", "frame_id", "observation_id", "moving_id", "reference_id"):
            assert camera[key] == run[key], (key, camera, run)
        for key in ("status", "mode", "image_id", "scene_object_ids", "section", "panels"):
            assert camera[key] == compact[key], (key, camera, compact)
        assert "views" not in compact and "meters_per_blender_unit" not in compact, compact
        assert source["frame_id"] == run["frame_id"] and source["target_ids"] == [MOVING, REFERENCE], source
        assert source["mode"] == mode and source["mesh_ids"] == compact["scene_object_ids"], source
        assert source["section"] == compact["section"], source
        assert camera["meters_per_blender_unit"] == source["meters_per_blender_unit"], camera
        assert isclose(source["meters_per_blender_unit"], spec.scale, rel_tol=1e-6), source
        assert camera["views"] == source["views"], camera
        receipt = validate_image(spec, results[label], run, after, mode=mode)
        assert receipt["png_sha256"] == actual["png_sha256"], receipt
        assert isinstance(compact["image_id"], str) and compact["image_id"], compact
        rendered[mode] = {**receipt, "image_id": compact["image_id"]}

    assert rendered["SECTION"]["image_id"] != rendered["NATURAL"]["image_id"]
    assert rendered["SECTION"]["png_sha256"] != rendered["NATURAL"]["png_sha256"]
    return rendered


def _run_case(opts, folder, name, inspections, image_mode):
    from examples.blender_llm_entry import binding_for
    from human_eye_fast.control import BlenderControl
    from verification.llm_entry_fixtures import (
        EPISODES, MOVING, REFERENCE, case, validate,
    )

    spec = EPISODES[name]
    calls = case_calls(spec, inspections, image_mode)
    original_execute = BlenderControl.execute
    executions = 0
    vg_events = []

    def counted_execute(control, *args, **kwargs):
        nonlocal executions
        executions += 1
        return original_execute(control, *args, **kwargs)

    with case(spec) as fixture:
        before = fixture.snapshot()
        _write_json(folder / "before-rna.json", before)
        try:
            binding = binding_for(fixture.scene, fixture.view_layer, fixture.objects, MOVING, REFERENCE,
                                  image_mode=image_mode, context_objects=fixture.context)
            with patch.object(BlenderControl, "execute", counted_execute), _renderer_probe(vg_events):
                wire = yield from wire_run(folder=folder, python=opts.python, binding=binding,
                                           calls=list(calls.values()), vg_events=vg_events)
        finally:
            try:
                after = fixture.snapshot()
                _write_json(folder / "after-rna.json", after)
            finally:
                _write_json(folder / "operations.json", {"executions": executions, "vg": vg_events})

        results = dict(zip(calls, wire["client"]["results"], strict=True))
        fields = {label: _tool_fields(result) for label, result in results.items()}
        for label, result in results.items():
            assert result["isError"] is False, (label, fields[label])
            has_image = image_mode is not None and label in {"run", "natural_image", "repeat_image"}
            block_types = ["text", "image"] if has_image else ["text"]
            assert [block["type"] for block in result["content"]] == block_types, label
        run_fields = fields["run"]
        assert (run_fields["unit"], run_fields["moving_id"], run_fields["reference_id"]) == ("m", MOVING, REFERENCE)
        checks = validate(spec, run_fields, before, after)
        assert executions == (1 if run_fields["write_status"] == "written" else 0), executions
        native = wire["native"]
        assert native["session_present_at_eof"] and native["session_closed"]
        expected = {} if image_mode is None else {"run": ["init", "render"], "natural_image": ["render"]}
        assert native["dispatch_vg_operations"] == [[], [], []] + [expected.get(label, []) for label in calls]
        assert native["entry_close_vg_operations"] == ([] if image_mode is None else ["close"])
        if "directory" in results:
            directory = fields["directory"]
            assert (directory["status"], directory["evidence"], directory["unit"]) == ("available", "directory", "m")
            assert directory["tasks"] == ["close_gap"], directory
            assert [(obj["id"], obj["role"]) for obj in directory["objects"]] == [(MOVING, "moving"),
                                                                                 (REFERENCE, "reference")]
        if "witness" in results:
            witness = fields["witness"]
            assert witness["status"] == "available" and witness["task_id"] == run_fields["task_id"], witness
            assert witness["observation_id"] == run_fields["observation_id"], witness
            assert witness["frame_id"] == run_fields["frame_id"], witness
            actual_gap = run_fields["after_gap_m"] if executions else run_fields["before_gap_m"]
            assert abs(witness["gap_m"] - actual_gap) <= run_fields["tolerance_m"], witness
        if image_mode is not None:
            checks["images"] = _verify_images(spec, results, fields, after, vg_events)
        else:
            assert not vg_events and "image" not in run_fields
        operations = [event["operation"] for event in vg_events]
        counts = {operation: operations.count(operation) for operation in ("init", "render", "close")}
        return {"checks": checks, "executions": executions, "vg_counts": counts,
                "run": run_fields, "native_transport": native,
                "stdio_relay": wire["client"]["stdio_relay"], "client_pid": wire["client"]["client_pid"]}


def _run_cases(opts, report):
    for index, (name, inspections, image_mode) in enumerate(NATIVE_CASES[opts.mode], 1):
        folder = opts.out / f"{index:02d}-{name}"
        folder.mkdir()
        job = {"name": name, "folder": folder.name, "image_mode": image_mode, "inspections": inspections}
        report["jobs"].append(job)
        try:
            try:
                if opts.mode == "gui":
                    job["windows_before"] = _owned_windows(hide=False)
                    _require_hidden(job["windows_before"])
                job.update((yield from _run_case(opts, folder, name, inspections, image_mode)))
            finally:
                if opts.mode == "gui":
                    job["windows_after"] = _owned_windows(hide=False)
                    _require_hidden(job["windows_after"])
            job["status"] = "passed"
        except Exception:
            job.update(status="failed", traceback=traceback.format_exc())
            _write_json(folder / "failure.json", job)
        yield POLL_INTERVAL


def _native_main(opts):
    import bpy

    assert get_ident() == main_thread().ident
    assert bpy.app.background == (opts.mode == "background")
    initial_windows = None if bpy.app.background else _owned_windows(hide=True)
    opts.out = opts.out.resolve()
    opts.out.mkdir(parents=True, exist_ok=True)
    report = {"mode": opts.mode, "pid": os.getpid(), "blender_version": bpy.app.version_string,
              "blender_binary": bpy.app.binary_path, "blender_background": bpy.app.background, "jobs": []}
    if not bpy.app.background:
        report["hidden_windows_at_script_initialization"] = initial_windows
    jobs = _run_cases(opts, report)

    def finish():
        complete = len(report["jobs"]) == len(NATIVE_CASES[opts.mode])
        passed = complete and "fatal" not in report and all(job["status"] == "passed" for job in report["jobs"])
        report["status"] = "passed" if passed else "failed"
        _write_json(opts.out / "summary.json", report)

    if bpy.app.background:
        try:
            for delay in jobs:
                sleep(delay)
        except Exception:
            report["fatal"] = traceback.format_exc()
            jobs.close()
        finish()
        if report["status"] != "passed":
            raise RuntimeError(f"Native tasks failed. See {opts.out / 'summary.json'}")
        return

    def tick():
        try:
            window = next(iter(bpy.context.window_manager.windows), None)
            assert window is not None, "The factory GUI has no Blender window"
            with bpy.context.temp_override(window=window):
                return next(jobs)
        except StopIteration:
            try:
                report["hidden_windows_at_end"] = _owned_windows(hide=False)
                _require_hidden(report["hidden_windows_at_end"])
            except Exception:
                report["fatal"] = traceback.format_exc()
        except Exception:
            report["fatal"] = traceback.format_exc()
            jobs.close()
        finish()
        bpy.ops.wm.quit_blender()
        return None

    def setup():
        try:
            windows = _owned_windows(hide=True)
            if not windows and monotonic() < setup_deadline:
                return POLL_INTERVAL
            report["hidden_windows_before_cases"] = windows
            _require_hidden(windows)
            bpy.app.timers.register(tick, first_interval=0.0)
        except Exception:
            report["fatal"] = traceback.format_exc()
            finish()
            bpy.ops.wm.quit_blender()
        return None

    setup_deadline = monotonic() + 5
    bpy.app.timers.register(setup, first_interval=0.0)


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--client", type=Path)
    parser.add_argument("--mode", choices=tuple(NATIVE_CASES))
    parser.add_argument("--out", type=Path)
    parser.add_argument("--python", type=Path)
    arguments = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else sys.argv[1:]
    opts = parser.parse_args(arguments)
    if opts.client is not None:
        _external_client(opts.client)
    elif None not in (opts.mode, opts.out, opts.python):
        sys.path.insert(0, str(ROOT))
        _native_main(opts)
    else:
        parser.error("Provide --client or all of --mode, --out and --python")
