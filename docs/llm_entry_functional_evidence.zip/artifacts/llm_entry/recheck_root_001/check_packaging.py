"""Build an offline wheel and check the new stdio entry without installing it."""
from pathlib import Path
import configparser
import hashlib
import json
import os
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parent / 'packaging'
OUT = BASE / 'build_004'
OUT.mkdir()
tmp = OUT / 'tmp'
tmp.mkdir(exist_ok=True)
deps = BASE / 'build_deps'
env = dict(os.environ, TMP=str(tmp), TEMP=str(tmp), PIP_DISABLE_PIP_VERSION_CHECK='1', PYTHONPATH=str(deps))
assert (deps / 'setuptools/build_meta.py').is_file()
command = [sys.executable, '-B', '-c',
           'import sys; import setuptools.build_meta as backend; print(backend.build_wheel(sys.argv[1]))',
           str(OUT)]
with (OUT / 'build.log').open('wb') as log:
    build = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
record = dict(command=command, exit_code=build.returncode,
              earlier_attempts=['Default sandbox TEMP build tracker was not writable.',
                                'Second offline attempt could not import setuptools.build_meta; logs preserved in packaging root.',
                                'Third attempt built files but pip nested wheel path exceeded the Windows path limit; build_003 preserved.'])
(OUT / 'build.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
if build.returncode:
    print(json.dumps(record))
    raise SystemExit(build.returncode)
wheel, = OUT.glob('*.whl')
with zipfile.ZipFile(wheel) as z:
    names = z.namelist()
    entry_path, = (n for n in names if n.endswith('.dist-info/entry_points.txt'))
    entries = configparser.ConfigParser()
    entries.read_string(z.read(entry_path).decode())
    assert entries['console_scripts']['human-eye-task-mcp'] == 'human_eye_llm_stdio:main'
    assert entries['console_scripts']['human-eye-mcp-server'] == 'human_eye_plugin.production_server:main'
    for name in ('human_eye_llm_stdio.py', 'human_eye_fast/local_tasks.py',
                 'human_eye_fast/llm_entry.py', 'human_eye_fast/blender_llm_bridge.py'):
        assert z.read(name) == (ROOT / name).read_bytes(), name
code = ('import sys; sys.path.insert(0, sys.argv[1]); import human_eye_llm_stdio as m; '
        'assert m.__file__.startswith(sys.argv[1]); sys.argv=["human-eye-task-mcp","--help"]; m.main()')
help_result = subprocess.run([sys.executable, '-I', '-B', '-c', code, str(wheel)],
                             cwd=OUT, env=env, capture_output=True)
(OUT / 'entry_help.txt').write_bytes(help_result.stdout + help_result.stderr)
assert help_result.returncode == 0 and b'--port' in help_result.stdout
record.update(wheel=wheel.name, bytes=wheel.stat().st_size,
              sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(),
              stdio_and_three_new_modules_match=True, old_entry_unchanged=True,
              wheel_import_and_help_passed=True, installed=False)
(OUT / 'result.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record))
