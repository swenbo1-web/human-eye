"""Targeted offline closure of R1-R4 from revision_003 frozen bytes; no Blender/GPU."""
from pathlib import Path
from contextlib import nullcontext
import base64
import hashlib
import json
import sys
import types
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().with_suffix('.json')
BASE = ROOT / 'artifacts/llm_entry/preflight_001'
DELIVERY = BASE / 'revision_003/delivery_001'
manifest_blob = (DELIVERY / 'manifest.json').read_bytes()
manifest = json.loads(manifest_blob)
assert hashlib.sha256(manifest_blob).hexdigest() == 'dc44bf3b9d5f024c7acce38bb71bd0b8bf0482e8801662d8e766025a1a092d8a'
zip_hash = hashlib.sha256((DELIVERY / 'sources.zip').read_bytes()).hexdigest()
assert zip_hash == manifest['sources_zip_sha256']
archive = zipfile.ZipFile(DELIVERY / 'sources.zip')
old = zipfile.ZipFile(BASE / 'revision_002/delivery_001/sources.zip')
for name, digest in manifest['source_sha256'].items():
    assert hashlib.sha256(archive.read(name)).hexdigest() == digest, name
current = {}
for name in ('human_eye_fast/local_tasks.py', 'human_eye_fast/llm_entry.py',
             'examples/blender_llm_entry.py', 'human_eye_fast/blender_llm_bridge.py', 'human_eye_llm_stdio.py'):
    current[name] = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
    assert current[name] == manifest['source_sha256'][name]
core = [name for name in manifest['source_sha256'] if name.startswith('human_eye_fast/')
        and name not in ('human_eye_fast/local_tasks.py', 'human_eye_fast/llm_entry.py',
                         'human_eye_fast/blender_llm_bridge.py')]
assert len(core) == 17 and all(archive.read(name) == old.read(name) for name in core)
for name in ('human_eye_llm_stdio.py', 'human_eye_fast/blender_llm_bridge.py'):
    assert archive.read(name) == old.read(name)

package = types.ModuleType('human_eye_fast'); package.__path__ = []
sys.modules['human_eye_fast'] = package
def load(name, path):
    module = types.ModuleType(name); module.__file__ = '<frozen>/' + path
    sys.modules[name] = module
    exec(compile(archive.read(path), module.__file__, 'exec'), module.__dict__)
    return module
load('human_eye_fast.resident_bridge', 'human_eye_fast/resident_bridge.py')
load('human_eye_fast.blender_resident_bridge', 'human_eye_fast/blender_resident_bridge.py')
bc = load('human_eye_fast.fast_bvh_clearance', 'human_eye_fast/fast_bvh_clearance.py')
control = load('human_eye_fast.control', 'human_eye_fast/control.py')
tasks = load('human_eye_fast.local_tasks', 'human_eye_fast/local_tasks.py')
entry = load('human_eye_fast.llm_entry', 'human_eye_fast/llm_entry.py')
assert not any(hasattr(tasks, name) for name in ('_eligible', '_plain_mesh', '_fixed_parents', '_local_static'))
assert '_blocked' not in archive.read('human_eye_fast/local_tasks.py').decode()
assert '_write_blocked' not in archive.read('human_eye_fast/llm_entry.py').decode()
assert 'isclose' not in archive.read('human_eye_fast/local_tasks.py').decode()

NS = types.SimpleNamespace
IDS = ('A', 'B')
world = NS(distance=5., fail_next=False, override_surface=None)
events = []
class BoundObject:
    type = 'MESH'
    def __init__(self, name): self.name = name
    def __getattr__(self, name):
        raise AssertionError('Unexpected object/dependency inspection: ' + name)
objects = {name: BoundObject(name) for name in (*IDS, 'context')}
layer = NS(name='Layer', objects=objects)
scene = NS(view_layers={'Layer': layer}, frame_current=7, frame_subframe=0.,
           unit_settings=NS(scale_length=.001))
def surface(d):
    return bc.SurfaceDistance(d, 0, 1, (0., 0., 0.), (.6*d, .8*d, 0.))
class FakeBridge:
    def capture(self, key, obj, graph, scale, mask):
        events.append(('capture', key, float(scale), int(mask)))
        return NS(object_id=key)
class FakeControl:
    def __init__(self, scene, objects, goal, *, view_layer):
        self.goal = goal; self.bridge = FakeBridge()
        events.append(('control_init', goal.distance_m))
    def observe(self, oid):
        events.append(('observe', oid, world.distance))
        self.before = control.ClearanceReadback(oid, 7, IDS, world.override_surface or surface(world.distance))
        return self.before
    def execute(self, action, after_id, *, target_changes):
        events.append(('execute', action.action_id, list(action.command.delta_world_m)))
        if world.fail_next:
            world.fail_next = False
            world.distance = 3.
            after = control.ClearanceReadback(after_id, 7, IDS, surface(world.distance))
            outcome = control.Outcome(self.goal, action, self.before, after, (0., 0., 0.),
                (1.2, 1.6, 0.), world.distance-self.before.surface.distance_m, False)
            raise control.ActionStageError('context', 'written', outcome)
        world.distance = self.goal.distance_m
        after = control.ClearanceReadback(after_id, 7, IDS, surface(world.distance))
        return control.Outcome(self.goal, action, self.before, after, (0., 0., 0.),
            action.command.delta_world_m, world.distance-self.before.surface.distance_m, True)
    def close(self): events.append(('control_close', self.goal.distance_m))
tasks.BlenderControl = FakeControl

graphics = {'init': 0, 'prepare': 0, 'render': 0, 'close': 0}
rendered = []
class FakeVG:
    def __init__(self): graphics['init'] += 1
    def prepare(self, meshes):
        graphics['prepare'] += 1
        assert list(meshes) == [*IDS, 'context']
        return meshes
    def observe(self, meshes, readback, **kwargs):
        graphics['render'] += 1
        n = graphics['render']
        metadata = {'mode': kwargs['mode'], 'mesh_ids': list(meshes),
            'section': {'point_m': [0., float(n), 0.]} if kwargs['mode'] == 'SECTION' else None,
            'meters_per_blender_unit': kwargs['scale_length'],
            'views': {'actual_render_serial': n, 'gpu': {'matrix': [float(n), 0., 0., 1.]}},
            'selection': {'direction': [1., 0., 0.]}}
        png = ('stub-image-%d' % n).encode()
        rendered.append((png, metadata, kwargs['frame_id']))
        return NS(png=png, metadata=metadata)
    def close(self): graphics['close'] += 1
render_module = types.ModuleType('human_eye_fast.raycast_saccade_gpu'); render_module.VGRenderer = FakeVG
sys.modules[render_module.__name__] = render_module
bridge_module = types.ModuleType('human_eye_fast.blender_llm_bridge'); bridge_module.start = lambda *a, **kw: None
sys.modules[bridge_module.__name__] = bridge_module
sys.modules['bpy'] = NS(context=NS(temp_override=lambda **kw: nullcontext(), evaluated_depsgraph_get=lambda: object()))
example = load('architecture_example', 'examples/blender_llm_entry.py')
binding = example.binding_for(scene, layer, objects, *IDS, image_mode='NATURAL',
                              context_objects={'context': objects['context']})
def connected():
    obj = entry.LLMEntry(binding)
    obj.handle_line(json.dumps({'jsonrpc':'2.0','id':1,'method':'initialize',
                               'params':{'protocolVersion':entry.PROTOCOL_VERSION}}).encode())
    obj.handle_line(b'{"jsonrpc":"2.0","method":"notifications/initialized"}')
    return obj
def call(obj, name, arguments):
    raw = obj.handle_line(json.dumps({'jsonrpc':'2.0','id':2,'method':'tools/call',
                                     'params':{'name':name,'arguments':arguments}}).encode())
    result = json.loads(raw)['result']
    return json.loads(result['content'][0]['text']), result
def run(obj, target, mode=None):
    args = {'task':'close_gap','target_gap_m':target,'tolerance_m':1e-7}
    if mode is not None: args['image_mode'] = mode
    return call(obj, 'eye_run', args)
def inspect(obj, task_id, evidence, mode=None):
    args = {'task_id':task_id,'evidence':evidence}
    if mode is not None: args['image_mode'] = mode
    return call(obj, 'eye_inspect', args)

e = connected(); world.fail_next = True
failed, failed_wire = run(e, 2.)
assert failed['write_status'] == 'written' and failed['after_gap_m'] == 3.
event_count = len(events)
failed_copy, _ = inspect(e, failed['task_id'], 'result')
failed_witness, _ = inspect(e, failed['task_id'], 'witness')
assert failed_copy == failed and failed_witness['status'] == 'unavailable'
assert len(events) == event_count and graphics['init'] == 0
fresh, fresh_wire = run(e, 2.)
assert fresh['status'] == 'reached' and fresh['before_gap_m'] == 3.
assert len([x for x in events if x[0] == 'execute']) == 2
assert len([x for x in events if x[0] == 'observe']) == 2
assert len(fresh_wire['content']) == 1
assert {'image','ao','views','camera','witness'}.isdisjoint(fresh)
e.close()
e = connected()
reconnected, _ = run(e, 1.)
assert reconnected['status'] == 'reached' and reconnected['before_gap_m'] == 2.
assert graphics['init'] == 0
e.close()

e = connected()
picture, picture_wire = run(e, .5, 'NATURAL')
task_id = picture['task_id']
event_count, before_graphics = len(events), dict(graphics)
receipt, receipt_wire = inspect(e, task_id, 'result')
camera, camera_wire = inspect(e, task_id, 'camera')
image, image_wire = inspect(e, task_id, 'image')
assert receipt == picture
assert len(receipt_wire['content']) == len(camera_wire['content']) == 1
assert camera['image_id'] == picture['image']['image_id'] == image['image_id']
assert camera['views'] == rendered[-1][1]['views'] and camera['meters_per_blender_unit'] == .001
assert base64.b64decode(image_wire['content'][1]['data']) == rendered[-1][0]
assert len(events) == event_count and graphics == before_graphics
assert 'views' not in picture['image'] and 'meters_per_blender_unit' not in picture['image']
section, section_wire = inspect(e, task_id, 'image', 'SECTION')
camera2, _ = inspect(e, task_id, 'camera')
assert camera2['image_id'] == section['image_id'] != camera['image_id']
assert camera2['views'] == rendered[-1][1]['views'] and camera2['section'] == rendered[-1][1]['section']
changed_goal, _ = run(e, .25, 'NATURAL')
assert changed_goal['status'] == 'reached'
assert graphics == {'init':1,'prepare':3,'render':3,'close':0}
e.close(); e.close()
assert graphics == {'init':1,'prepare':3,'render':3,'close':1}

# Replay the earlier witness-roundoff finding; no new BC search/acceptance run.
prior = json.loads((ROOT/'artifacts/llm_entry/implementation_root_001/algorithm_probe.json').read_text(encoding='utf8'))
w = next(row for row in prior['witness_revalidation_cases'] if not row['candidate_guard_accepts'])
world.override_surface = bc.SurfaceDistance(w['bc_distance'], 0, 0, tuple(w['point_a']), tuple(w['point_b']))
world.distance = w['bc_distance']
s = tasks.CloseGapSession(scene, layer, objects, tasks.CloseGapTask(*IDS, w['bc_distance']/2, 1e-7))
roundoff = s.run(before_id='roundoff-before', after_id='roundoff-after')
assert roundoff.status == 'reached' and roundoff.reason is None
s.close(); world.override_surface = None

report = {'scope':'R1-R4 targeted CPU doubles and frozen source identity; no native/GPU/transport/performance run',
          'manifest_sha256':hashlib.sha256(manifest_blob).hexdigest(),'sources_zip_sha256':zip_hash,
          'verified_source_count':len(manifest['source_sha256']), 'current_identity':current,
          'unchanged_core_count':len(core),'relay_and_bridge_unchanged':True,
          'R1':{'known_error_preserved':failed,'explicit_fresh_task':fresh,'same_binding_reconnection':reconnected,
                'error_result_roundtrips_without_compute':failed_copy==failed,'invalid_error_witness':failed_witness},
          'R2':{'hot_dependency_checks_absent':True,'prior_roundoff_case_now_executes':roundoff.status,
                'test_object_prohibits_parent_modifier_animation_inspection':True},
          'R3':{'three_new_images_across_goal_change':graphics,'numeric_requests_before_images_constructed_zero':True},
          'R4':{'result_exact_roundtrip':receipt==picture,'camera1':camera,'camera2':camera2,
                'result_camera_cached_image_trigger_no_compute':True,'default_image_has_no_camera_matrices':True,
                'base64_bytes_match_source_stub':True},
          'known_limitation':'Zero-gap SECTION-to-NATURAL cross-mode extra rendering remains documented; not expanded or measured',
          'events':events,'assertions':'PASS'}
OUT.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'output':str(OUT),'verified_sources':len(manifest['source_sha256']),
                  'core_unchanged':len(core),'R1_R4':'PASS','renderer':graphics}))
