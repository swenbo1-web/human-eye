# Revision 003 原生功能独立验收

**结论：本次限定原生复验可判 5/5 PASS。** 两个进程覆盖原五个场景，原始终态 RNA、独立几何、真实 IPC、主线程执行、EOF 关闭及按需 GPU/图像证据均闭合。`revision_002/native_001` 仍保持 **0/5 FAIL**，本次结果没有补写旧证据或改写旧判定。此结论不是实际 MCP 宿主、模型看图、任务效率或 token 收益通过。

审查只读取冻结源 ZIP 和既有原生记录，运行 `native_acceptance_probe.py` 做离线 CPU 重算；没有新启动 Blender/GUI/GPU、IPC、模型或性能测试，没有修改作者证据、生产文件、文档或 Git。可重放脚本及完整数字见同目录 `native_acceptance_probe.py/json`。

## 身份、原案例及旧失败

- 交付 manifest SHA：`dc44bf3b9d5f024c7acce38bb71bd0b8bf0482e8801662d8e766025a1a092d8a`，与委派目标一致；交付 ZIP SHA：`097b33d5ac975c613a7a353b0fd7802ef01eef69d068571ff75bd054078fa4b3`。
- 独立逐项核对 **40 项交付源、33 项原生源、12 项引用证据**；原生 ZIP 各源与交付 ZIP 相同。原有 17 个引擎源、bridge 和 relay 共 19 项与旧原生 ZIP 完全相同。本次接入/local_tasks/example 按 R1–R4 修正，不能称整份候选源未变；但原引擎算法及传输源未漂移。
- 新 worker SHA：`4a050e7a6580325d4d73f2ff12c445ccfcc2d428ff331c3d6e66daa68404243d`；新 runner SHA：`86d9f9617fda85eb45643c24161a4c0efe030756f000dddc1c7195f10c0090f7`。
- 原/新各保留两个 launch 记录，新 runner 明确引用旧 manifest/summary/launch/PID probe，不删除原 markers。旧 summary 仍 `passed=false`。
- 新 manifest 的案例字段改为完整 `calls`，不能直接将两个 `cases` 字典不等认定为场景漂移。逐例归一核对后，**fixture、run 参数、目标、容差、场景及顺序不变**；全部五份新 before RNA 与旧 before RNA 逐字节相同。Fixture、case、snapshot、网格构造、request_arguments、几何 validate 等 AST 未变。唯一新增调用在已授权的 occluded 案例：结果取回、两次相机查询、NATURAL 图、重复当前图。
- 独立数值 oracle 与 PNG decoder 源均与旧批相同。源身份分别为 `4a96257e22c09dee0d19d294a66fb498f931accd880dfb3d8d982f5ecf37e371` 和 `624c4a9be846ffd983c235c5aaee58e3c69c29d0142999fc3e03ba765c85eb0c`。

## 十份实际 RNA 的重新计算

after RNA 由 worker 在 fixture context 内、wire/EOF 清理后、场景删除前直接再次读取 evaluated depsgraph、对象矩阵及三角网格并保存，原生成逻辑没有从工具回包拼装 after。记录现在全部存在。本次离线 probe 从冻结测试源只抽取数值 oracle 函数，不导入 Blender 或生产求解器；对每个 before/after 的实际三角网格重新进行全三角形对独立凸支持最小二乘距离计算，没有调用作者 summary 的计算结果作为输入。

| 案例 | 重算 before 距离（m） | 重算 after 距离（m） | 控制执行次数 | 最大顶点位移分量偏差（m） |
|---|---:|---:|---:|---:|
| nonconvex | 0.0010000000474974457 | 0.0006000004099682086 | 1 | 3.625e-10 |
| parented | 0.001000000047497446 | 0.0007500000356230813 | 1 | 5.464e-11 |
| already-reached | 0.001000000047497446 | 0.001000000047497446 | 0 | 0 |
| occluded | 0.001000000047497446 | 0.0007500000356230813 | 1 | 5.464e-11 |
| parented-rescaled | 0.00999999977648253 | 0.007499999832361864 | 1 | 5.464e-10 |

全部保持原 **8e-9 m** 距离/位移门。重算值与作者 oracle 摘要差异至多浮点末位，probe 要求差值不超过 1e-15；没有放宽功能容差。

逐例另外核对：参考、context、parent 的完整记录精确不变；moving 三角拓扑相同，线性变换保持原 5e-7 门；每个顶点的实际平移匹配原预期和回包 requested/actual delta；无动作例整个 before/after 字典完全相同。回包状态、单位、目标、容差、观察/frame、witness 点间距与独立实际距离一致。它们不再只是“回包自身一致”。本次没有声称覆盖未列入五例的所有刚体/异常/视觉任务。

## 主线程、PID、IPC 与关闭

两进程均正常退出且 summary PASS，source/executable stable，无超时或 launch error；外层仍同时检查退出码、summary 和原案例清单。

- background 原生 PID **14824**，创建/dispatch/close 主线程 ID **14572**；GUI 原生 PID **10676**，主线程 ID **37328**。五个 native-transport 记录均实际保存且与各 job 嵌入的记录相同，dispatch/close 都等于 main_thread。
- 五例分别保存 launched/client/parent PID，全部为 Windows immediate-child：`4116→8008`、`35380→28680`、`28924→42792`、`36768→41344`、`40744→31132`。每个 client 的真实 parent 字段等于对应 launched PID，且实际 client 不等于 Blender PID；不再用上一轮单独 venv probe 代替逐例关系。
- handler 次数依次 **6、5、5、10、5**，与实际请求帧（含 initialized notification）及登记调用数完全对应。请求/响应 ID、原 bytes 长度、client.json 结果和原 responses.jsonl 逐项匹配；relay stdin/stdout EOF 与 exit 0 均保存。
- 每例单连接、一次 entry close，close 在显式 stop 前已由 EOF 发生；session 存在并 `_closed=true`。listener 在 stop 前打开、之后关闭；GUI timer 先注册后注销，background 没有注册 timer。额外 stop 没有重复 close。

这些是新原生记录中的实测字段，已不同于上一轮仅能由失败断点推断的前置断言证据。

## 按需图像与 GPU 生命周期

数值四例的 `operations.json` 中 VG 事件为空，dispatch/EOF 事件也为空：**0 init / 0 render / 0 close**。未因绑定或普通结果输出暗建 renderer。

occluded 的真实 VG wrapper 调用原 `VGRenderer.__init__/observe/close`，observe 返回后立即记录 PNG SHA 和 deep-copy metadata。保存事件严格为 **init → render → render → close**，同一 renderer ID，四事件均 completed：

- `run(SECTION)` 内一次 init、一次 render；`inspect(image,NATURAL)` 一次新 render。
- witness、result、camera、重复当前图均无 VG 事件，且没有额外控制执行。
- EOF 的 entry.close 内一次 VG close；既有 renderer 的真实 close 实现未改。这里证明实际资源生命周期调用成功，不扩大为新的 GPU 驱动分配字节审计。
- `inspect(result)` 与原 run 的 TextContent 完全相同；重复当前图的 content 与 NATURAL 响应完全相同，无重渲染。

两张实际接收图已离线完整解码（PNG CRC、扫描行、像素尺寸），并与各自本次 observe hook 的 SHA 精确相同：

| 图像 | image_id | PNG bytes | SHA-256 | 1024×512 图中背景场景屏障颜色像素 |
|---|---|---:|---|---:|
| SECTION | gap-1-image-1 | 30521 | `289588ac5334a2af8e2beeb479ed472c333cfb8b5489d3ad2b0f84aecbe0ed33` | 5621 |
| NATURAL | gap-1-image-2 | 29086 | `3038934c3b1776bfbd287be17f555da2b67ac90e14d165fd549c2da7c48e64f6` | 5621 |

每个 camera 响应的 image_id、frame、task/observation、mode、对象集、section、单位和完整 views 均与**对应那一次 observe** 的真实 metadata 完全相同；两种模式的 ID/hash 不混用，NATURAL section 为 null。SECTION 切面中点 y 根据实际 after RNA 最近两面重新计算并满足原误差门，法线为单位向量，kept side 保持 `<=0`。本次相机/图像同源检查不依赖另拍新图；原 VG `_view` 确实从相机 RNA 取矩阵/投影，并将同组 view/projection 供本次渲染，冻结源未改。

这足以验收本次“公开详细相机确实属于用户收到的当前图、按需常驻/缓存/关闭”的功能；不把它扩称四个正式 V 场景全部视觉评分完成，或外部 LLM 已看到/正确使用图像。

## 可承接范围

GUI 首次 Python 观察仍记录可见，随后初始化时隐藏；案例前后和末次均有 owned PID 隐藏记录，符合已冻结限定协议。按父任务要求，不重新扩大调查启动前可见区间，也不声称从未闪现。

可以接收本次 **2 进程、5/5 原生功能 PASS**，继续对应下一阶段；无需因本次结果重新开启原引擎优化或重复扩大 native 批次。仍须保留的限定是：真实 MCP 宿主协商、真实模型消费图像/事实、14 例正式双臂任务、任务完成质量、完整耗时和 provider token 收益未由本批证明。occluded 的附加 inspect 调用用于生命周期功能覆盖，不能作为正常任务模型回合基准，也不能据本次单轮原生运行宣布 E1 整体收益 PASS。
