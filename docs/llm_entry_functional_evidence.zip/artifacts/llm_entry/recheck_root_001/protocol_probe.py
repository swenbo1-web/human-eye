"""Offline revision-003 protocol/source and high precision interval review.

No Blender, rendering, performance benchmark, new task samples, or model call.
Reads archived/current sources, reconstructs only the 56 existing math states,
and writes protocol_probe.json beside this file.
"""
import ast
import copy
from decimal import Decimal, localcontext
import hashlib
import json
from pathlib import Path
import sys
import zipfile

import numpy as np

ROOT = Path('D:/human eye/human-eye')
REV = ROOT / 'artifacts/llm_entry/preflight_001/revision_003'
SMOKE = REV / 'protocol_smoke_001'
FIX = SMOKE / 'roundoff_recheck_001'
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT))

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def digest(data):
    return hashlib.sha256(data).hexdigest()

delivery = read(REV / 'delivery_001/manifest.json')
identity_errors = []
for kind in ('source_sha256', 'evidence_sha256'):
    for name, expected in delivery[kind].items():
        if digest((ROOT / name).read_bytes()) != expected:
            identity_errors.append((kind, name))
with zipfile.ZipFile(REV / 'delivery_001/sources.zip') as z:
    assert set(z.namelist()) == set(delivery['source_sha256'])
    for name, expected in delivery['source_sha256'].items():
        assert digest(z.read(name)) == expected, name
assert digest((REV / 'delivery_001/sources.zip').read_bytes()) == delivery['sources_zip_sha256']

archives = {}
stored = {}
for folder in (SMOKE, FIX):
    p, e = read(folder / 'preregistration.json'), read(folder / 'execution.json')
    assert digest((folder / 'preregistration.json').read_bytes()) == e['preregistration_sha256']
    assert digest((folder / 'sources.zip').read_bytes()) == e['sources_zip_sha256']
    with zipfile.ZipFile(folder / 'sources.zip') as z:
        archives[folder.name] = {n: z.read(n) for n in z.namelist()}
        for item in p['sources']:
            assert digest(z.read(Path(item['path']).name)) == item['sha256']
    for item in e['outputs']:
        blob = (folder / item['path']).read_bytes()
        assert (len(blob), digest(blob)) == (item['bytes'], item['sha256'])
    stored[folder.name] = read(folder / 'oracle_smoke.json')
assert read(FIX / 'preregistration.json')['source_parent_execution_sha256'] == digest((SMOKE / 'execution.json').read_bytes())
assert (SMOKE / 'case_manifest.json').read_bytes() == (FIX / 'case_manifest.json').read_bytes()
changed = [n for n in archives[SMOKE.name] if archives[SMOKE.name][n] != archives[FIX.name][n]]
assert changed == ['llm_task_reference.py', 'LLM_TASK_PROTOCOL_DRAFT.md'], changed
old_py, new_py = [archives[k]['llm_task_reference.py'].decode().replace('\r\n', '\n') for k in (SMOKE.name, FIX.name)]
added = '''    coordinate_scale = max(float(np.max(np.abs(moving))), float(np.max(np.abs(reference))))
    roundoff = 64 * np.finfo(float).eps * coordinate_scale
    lower, upper = max(0., lower - roundoff), upper + roundoff
    if lower > upper:
        raise AssertionError(("inconsistent numeric gap interval", lower, upper))
'''
assert new_py.replace(added, '') == old_py

from verification.llm_task_reference import build_episode, case_manifest, _gap_interval

# Reconstruct exactly the archived mathematical state builder, without main()
# or its native helper tests. It imports no Blender/engine code.
source = archives[FIX.name]['oracle_smoke.py'].decode()
tree = ast.parse(source)
nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef)
         and n.name in ('mathematical_snapshot', 'task_states')]
namespace = {'np': np, 'deepcopy': copy.deepcopy}
exec(compile(ast.Module(body=nodes, type_ignores=[]), '<archived mathematical state builder>', 'exec'), namespace)

def dec(x):
    return Decimal.from_float(float(x))

def vec(x):
    return [dec(v) for v in x]

def dot(a, b):
    return sum((x * y for x, y in zip(a, b)), Decimal(0))

def sub(a, b):
    return [x - y for x, y in zip(a, b)]

def hp_interval(episode, a, b):
    # Decimal arithmetic on exact binary64 input data. Direct 2x2 algebra
    # replaces numpy lstsq for the two new, well-conditioned support features.
    with localcontext() as context:
        context.prec = 90
        axis = vec(episode.axis)
        norm = dot(axis, axis).sqrt()
        axis = [v / norm for v in axis]
        lower = max(Decimal(0), min(dot(vec(p), axis) for p in b) - max(dot(vec(p), axis) for p in a))
        left, right = episode.witness_indices
        pa, pb = [vec(a[i]) for i in left], [vec(b[i]) for i in right]
        cols = [sub(p, pa[0]) for p in pa[1:]] + [sub(pb[0], p) for p in pb[1:]]
        if cols:
            assert len(cols) == 2
            rhs = sub(pb[0], pa[0])
            aa, ab, bb = dot(cols[0], cols[0]), dot(cols[0], cols[1]), dot(cols[1], cols[1])
            r0, r1 = dot(cols[0], rhs), dot(cols[1], rhs)
            determinant = aa * bb - ab * ab
            assert determinant > 0
            coefficients = [(r0 * bb - r1 * ab) / determinant,
                            (aa * r1 - ab * r0) / determinant]
        else:
            coefficients = []
        t, u = coefficients[:len(pa)-1], coefficients[len(pa)-1:]
        wa, wb = [1 - sum(t), *t], [1 - sum(u), *u]
        assert min(wa + wb) > Decimal('.05')
        qa = [sum(w * p[k] for w, p in zip(wa, pa)) for k in range(3)]
        qb = [sum(w * p[k] for w, p in zip(wb, pb)) for k in range(3)]
        upper = dot(sub(qa, qb), sub(qa, qb)).sqrt()
        return lower, upper, wa, wb

old_rows = {(row['id'], row['arm']): row for row in stored[SMOKE.name]['accepted']}
new_rows = {(row['id'], row['arm']): row for row in stored[FIX.name]['accepted']}
checks = []
inverted = []
for episode_case in case_manifest():
    episode = build_episode(episode_case)
    for arm, steps in (('I', 0 if episode_case.case_id == 'C02' else 1),
                       ('N', 0 if episode_case.case_id == 'C02' else 3)):
        before, after, _ = namespace['task_states'](episode, steps)
        key = episode_case.case_id, arm
        for phase, snapshot in (('before', before), ('after', after)):
            a, b = [snapshot[k]['world_vertices_m'] for k in episode.fixture.target_ids]
            interval, weights = _gap_interval(episode, a, b)
            recorded = new_rows[key][phase + '_gap_interval_m']
            assert list(interval) == recorded
            previous = old_rows[key][phase + '_gap_interval_m']
            if previous[0] > previous[1]:
                inverted.append({'case': key[0], 'arm': arm, 'phase': phase, 'interval': previous})
            lo, hi, wa, wb = hp_interval(episode, a, b)
            if not (dec(interval[0]) <= lo <= hi <= dec(interval[1])):
                raise AssertionError(('high precision bound mismatch', key, phase, interval, str(lo), str(hi)))
            coordinate = max(float(np.max(np.abs(a))), float(np.max(np.abs(b))))
            padding = 64 * np.finfo(float).eps * coordinate
            checks.append({'id': key[0], 'arm': arm, 'phase': phase, 'published': interval,
                           'decimal_support_lower': str(lo), 'decimal_feature_upper': str(hi),
                           'decimal_weights': [[str(w) for w in wa], [str(w) for w in wb]],
                           'padding_m': padding, 'padding_over_task_tolerance': padding / episode.tolerance_m})

result = {'scope': 'Existing 14 recipes, 28 synthetic pairs, 56 intervals only; no actual RNA/Blender/model/performance.',
          'identity_errors': identity_errors,
          'delivery_manifest_sha256': digest((REV / 'delivery_001/manifest.json').read_bytes()),
          'source_count': len(delivery['source_sha256']), 'evidence_count': len(delivery['evidence_sha256']),
          'roundoff_changed_files': changed, 'roundoff_code_change_only_5_added_lines': True,
          'old_inverted_intervals': inverted,
          'old_max_inversion_m': max(row['interval'][0] - row['interval'][1] for row in inverted),
          'current_ordered_count': len(checks),
          'max_padding_over_task_tolerance': max(c['padding_over_task_tolerance'] for c in checks),
          'high_precision_scope': '90-digit Decimal normalizes the exact stored axis and solves current 2-column supports by direct 2x2 algebra; checks current synthetic geometries, not a universal interval arithmetic proof.',
          'interval_checks': checks,
          'preserved_negative_labels': stored[FIX.name]['rejected'],
          'native_seed_records': stored[FIX.name]['native_seed'],
          'loaded_engine_modules': [k for k in sys.modules if k == 'human_eye_fast' or k.startswith('human_eye_fast.')],
          'pending': ['real evaluated RNA for formal recipes', 'native worker/setter/view wiring',
                      'V01-V04 actual camera/cut/PNG labels', 'actual MCP host', 'model and cost measurements']}
out = Path(__file__).with_suffix('.json')
out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'output': str(out), 'identity_errors': identity_errors,
                  'old_inverted': len(inverted), 'old_max_inversion_m': result['old_max_inversion_m'],
                  'current_intervals_hp_enclosed': len(checks),
                  'max_padding_over_task_tolerance': result['max_padding_over_task_tolerance'],
                  'engine_imports': result['loaded_engine_modules']}, ensure_ascii=False))
