"""Offline rev3 native acceptance: frozen numerical oracle and raw records only."""
from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
from itertools import combinations
import ast
import base64
import json
import math
import struct
import zlib
import numpy as np

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "artifacts/llm_entry/preflight_001"
NEW = BASE / "revision_003"
OLD = BASE / "revision_002"
OUT = Path(__file__).with_suffix(".json")
MANIFEST_HASH = "dc44bf3b9d5f024c7acce38bb71bd0b8bf0482e8801662d8e766025a1a092d8a"


def read(path):
    return json.loads(path.read_bytes())


def digest(raw):
    return sha256(raw).hexdigest()


def functions(source, names, globals_):
    nodes = [n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name in names]
    assert {n.name for n in nodes} == set(names)
    exec(compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])), "frozen-numeric", "exec"), globals_)
    return globals_


def main():
    dm = NEW / "delivery_001/manifest.json"
    assert digest(dm.read_bytes()) == MANIFEST_HASH
    delivery, manifest = read(dm), read(NEW / "native_001/manifest.json")
    old_manifest = read(OLD / "native_001/manifest.json")
    assert digest((NEW / "delivery_001/sources.zip").read_bytes()) == delivery["sources_zip_sha256"]
    assert len(list((NEW / "native_001").glob("*/launch.json"))) == 2
    assert len(list((OLD / "native_001").glob("*/launch.json"))) == 2
    assert read(OLD / "native_001/summary.json")["passed"] is False
    identities = {}
    for path, expected in delivery["evidence_sha256"].items():
        assert digest((ROOT / path).read_bytes()) == expected, path
    with ZipFile(NEW / "delivery_001/sources.zip") as archive, ZipFile(NEW / "native_001/sources.zip") as native, \
            ZipFile(OLD / "native_001/sources.zip") as old:
        for path, expected in delivery["source_sha256"].items():
            assert digest(archive.read(path)) == expected, path
        for path, expected in manifest["sources"].items():
            assert digest(native.read(path)) == expected, path
            assert native.read(path) == archive.read(path), path
        invariant = [p for p in old.namelist() if p.startswith("human_eye_fast/") and p not in
                     ("human_eye_fast/llm_entry.py", "human_eye_fast/local_tasks.py")]
        invariant.append("human_eye_llm_stdio.py")
        assert all(old.read(p) == native.read(p) for p in invariant)
        fixture_path = "verification/llm_entry_fixtures.py"
        f_old, f_new = ast.parse(old.read(fixture_path)), ast.parse(native.read(fixture_path))
        fixture_same = []
        for name in ("Fixture", "Episode", "case", "_notched_prism", "_mesh_object", "request_arguments", "_oracle", "_check_gap", "validate"):
            a = next(n for n in f_old.body if getattr(n, "name", None) == name)
            b = next(n for n in f_new.body if getattr(n, "name", None) == name)
            assert ast.dump(a, include_attributes=False) == ast.dump(b, include_attributes=False), name
            fixture_same.append(name)
        for label, path in (("oracle", "verification/test_bc_acceptance.py"),
                            ("png", "verification/test_raycast_saccade_gpu.py")):
            assert old.read(path) == native.read(path)
            identities[label] = digest(native.read(path))
        oracle = functions(native.read("verification/test_bc_acceptance.py"),
                           ("_supports", "convex_pair_oracle", "exhaustive_convex_oracle"),
                           {"np": np, "math": math, "combinations": combinations})["exhaustive_convex_oracle"]
        decoder = functions(native.read("verification/test_raycast_saccade_gpu.py"), ("_paeth", "decode_png"),
                            {"np": np, "struct": struct, "zlib": zlib, "SIZE": 512,
                             "PNG_MAGIC": b"\x89PNG\r\n\x1a\n"})["decode_png"]

    rows = []
    for mode in ("background", "gui"):
        folder = NEW / "native_001" / mode
        summary, process = read(folder / "result/summary.json"), read(folder / "process.json")
        assert process["exit_code"] == 0 and process["passed"] and process["sources_stable"] and process["executable_stable"]
        assert not process["timed_out"] and process["launch_error"] is None
        assert summary["status"] == "passed" and summary["blender_background"] == (mode == "background")
        assert [j["name"] for j in summary["jobs"]] == [c["fixture"]["name"] for c in old_manifest["cases"][mode]]
        for index, (specification, previous, job) in enumerate(zip(manifest["cases"][mode], old_manifest["cases"][mode], summary["jobs"], strict=True), 1):
            spec = specification["fixture"]
            assert spec == previous["fixture"]
            assert specification["calls"]["run"]["arguments"] == previous["arguments"]
            name, case = spec["name"], folder / "result" / job["folder"]
            previous_case = OLD / "native_001" / mode / "result" / job["folder"]
            assert (case / "before-rna.json").read_bytes() == (previous_case / "before-rna.json").read_bytes()
            before, after = read(case / "before-rna.json"), read(case / "after-rna.json")
            assert set(before) == set(after)
            assert all(before[k] == after[k] for k in before if k != "moving")
            for shape in (before, after):
                assert all(np.all(np.isfinite(v["world_vertices_m"])) for k, v in shape.items() if k != "parent_matrix_world_bu")
            initial, final = before["moving"], after["moving"]
            assert initial["triangles"] == final["triangles"]
            delta = np.array(final["world_vertices_m"]) - np.array(initial["world_vertices_m"])
            tolerance = specification["calls"]["run"]["arguments"]["tolerance_m"]
            assert tolerance == 8e-9
            np.testing.assert_allclose(delta, np.broadcast_to(spec["delta_m"], delta.shape), rtol=0, atol=tolerance)
            np.testing.assert_allclose(np.array(initial["matrix_world_bu"])[:3, :3], np.array(final["matrix_world_bu"])[:3, :3], rtol=0, atol=5e-7)
            if spec["expected_status"] == "no_action":
                assert before == after
            gaps = []
            for snapshot in (before, after):
                a, b = snapshot["moving"], snapshot["reference"]
                gaps.append(oracle(a["world_vertices_m"], a["triangles"], b["world_vertices_m"], b["triangles"])[0])
            assert abs(gaps[0] - spec["expected_before_m"]) <= tolerance
            assert abs(gaps[1] - spec["target_gap_m"]) <= tolerance

            req_bytes, resp_bytes = (case / "requests.jsonl").read_bytes(), (case / "responses.jsonl").read_bytes()
            requests, responses = [json.loads(line) for line in req_bytes.splitlines()], [json.loads(line) for line in resp_bytes.splitlines()]
            assert [r["id"] for r in responses] == [r["id"] for r in requests if "id" in r]
            client, nt, operations = read(case / "client.json"), read(case / "native-transport.json"), read(case / "operations.json")
            assert read(case / "client-config.json")["calls"] == list(specification["calls"].values())
            actual_calls = [r["params"] for r in requests if r["method"] == "tools/call"]
            expected_calls = []
            for call in specification["calls"].values():
                expected = {"name": call["name"], "arguments": dict(call["arguments"])}
                if expected["name"] == "eye_inspect" and expected["arguments"]["evidence"] != "directory":
                    expected["arguments"]["task_id"] = "gap-1"
                expected_calls.append(expected)
            assert actual_calls == expected_calls
            tools = [r["result"] for r in responses if "content" in r.get("result", {})]
            assert tools == client["results"] and len(tools) == len(specification["calls"])
            results = dict(zip(specification["calls"], tools, strict=True))
            assert all(t["isError"] is False and "structuredContent" not in t for t in tools)
            fields = {label: json.loads(result["content"][0]["text"]) for label, result in results.items()}
            run, witness = fields["run"], fields["witness"]
            assert (run["unit"], run["moving_id"], run["reference_id"], run["frame_id"]) == ("m", "moving", "reference", 7)
            assert witness["unit"] == "m"
            assert run["status"] == spec["expected_status"] and run["goal_reached"]
            assert run["target_gap_m"] == spec["target_gap_m"] and run["tolerance_m"] == tolerance
            assert abs(run["before_gap_m"] - gaps[0]) <= tolerance
            writes = int(spec["expected_after_m"] is not None)
            assert run["write_status"] == ("written" if writes else "not_written")
            assert operations["executions"] == job["executions"] == writes
            if writes:
                assert abs(run["after_gap_m"] - gaps[1]) <= tolerance
                for key in ("delta_world_m", "actual_delta_world_m"):
                    np.testing.assert_allclose(run[key], spec["delta_m"], rtol=0, atol=tolerance)
            else:
                assert run["after_gap_m"] is None and run["actual_delta_world_m"] is None and run["delta_world_m"] is None
            for key in ("task_id", "observation_id", "frame_id", "moving_id", "reference_id"):
                assert run[key] == witness[key]
            assert abs(witness["gap_m"] - gaps[1]) <= tolerance
            assert abs(np.linalg.norm(np.array(witness["moving_point_m"]) - witness["reference_point_m"]) - gaps[1]) <= tolerance
            for k, expected in (("independent_before_gap_m", gaps[0]), ("independent_after_gap_m", gaps[1])):
                assert abs(job["checks"][k] - expected) <= 1e-15
            assert nt == job["native_transport"]
            assert nt["pid"] == summary["pid"] and nt["background"] == (mode == "background")
            assert nt["main_thread_id"] == nt["dispatch_thread_id"] == nt["entry_close_thread_id"]
            assert nt["connections"] == nt["entry_close_calls"] == nt["entry_close_calls_before_stop"] == 1
            assert nt["handler_calls"] == len(requests) == 3 + len(tools)
            assert nt["listener_open_before_stop"] and nt["listener_closed"] and nt["timer_unregistered"]
            assert nt["timer_registered"] == (mode == "gui") and nt["session_present_at_eof"] and nt["session_closed"]
            proc = nt["client_process"]
            assert proc["exit_code"] == 0 and proc["client_pid"] == client["client_pid"] != nt["pid"]
            assert proc["client_parent_pid"] == client["client_parent_pid"]
            assert proc["relationship"] == "windows_immediate_child" and proc["client_parent_pid"] == proc["launched_pid"] != proc["client_pid"]
            relay = client["stdio_relay"]
            assert relay["exit_code"] == 0 and relay["stdin_eof"] and relay["stdout_eof"]
            assert relay["request_bytes"] == len(req_bytes) and relay["response_bytes"] == len(resp_bytes)
            events = operations["vg"]
            expected_ops = {"run": ["init", "render"], "natural_image": ["render"]} if name == "occluded" else {}
            assert nt["dispatch_vg_operations"] == [[], [], []] + [expected_ops.get(k, []) for k in results]
            assert nt["entry_close_vg_operations"] == (["close"] if name == "occluded" else [])
            images = []
            if name != "occluded":
                assert events == [] and "image" not in run
                assert all([b["type"] for b in v["content"]] == ["text"] for v in results.values())
            else:
                assert [e["operation"] for e in events] == ["init", "render", "render", "close"]
                assert len({e["renderer_id"] for e in events}) == 1 and all(e["completed"] for e in events)
                assert results["result"]["content"] == [results["run"]["content"][0]]
                assert results["repeat_image"]["content"] == results["natural_image"]["content"]
                for label, camera_label, imode, event in (("run", "section_camera", "SECTION", events[1]),
                                                          ("natural_image", "natural_camera", "NATURAL", events[2])):
                    compact = fields[label].get("image", fields[label]); camera = fields[camera_label]; metadata = event["metadata"]
                    assert [b["type"] for b in results[label]["content"]] == ["text", "image"]
                    for key in ("task_id", "observation_id", "frame_id", "moving_id", "reference_id"):
                        assert camera[key] == run[key]
                    for key in ("status", "mode", "image_id", "scene_object_ids", "section", "panels"):
                        assert camera[key] == compact[key]
                    assert camera["evidence"] == "camera" and camera["unit"] == "m"
                    assert camera["views"] == metadata["views"]
                    assert camera["meters_per_blender_unit"] == metadata["meters_per_blender_unit"]
                    assert math.isclose(metadata["meters_per_blender_unit"], spec["scale"], rel_tol=1e-6)
                    assert metadata["frame_id"] == run["frame_id"] == 7 and metadata["mode"] == compact["mode"] == imode
                    assert metadata["target_ids"] == ["moving", "reference"]
                    assert metadata["mesh_ids"] == compact["scene_object_ids"] == ["moving", "reference", "screen", "overhang"]
                    assert metadata["section"] == compact["section"]
                    assert "views" not in compact and "meters_per_blender_unit" not in compact
                    if imode == "SECTION":
                        section = compact["section"]
                        assert section["kept_side"] == "<=0" and abs(np.linalg.norm(section["normal"]) - 1) <= 1e-6
                        midpoint_y = (np.array(after["moving"]["world_vertices_m"])[:, 1].min() + np.array(after["reference"]["world_vertices_m"])[:, 1].max()) / 2
                        assert abs(section["point_m"][1] - midpoint_y) <= tolerance
                    else:
                        assert compact["section"] is None
                    png = base64.b64decode(results[label]["content"][1]["data"], validate=True)
                    assert digest(png) == event["png_sha256"]
                    pixels = decoder(png)
                    interior = pixels[45:465, :512, :3].astype(np.int16)
                    color = np.rint(255 * np.array([.22, .78, .32])).astype(np.int16)
                    green = int(np.count_nonzero(np.max(np.abs(interior - color), axis=2) <= 3))
                    assert green > 25
                    saved = job["checks"]["images"][imode]
                    assert (saved["png_sha256"], saved["png_bytes"], saved["visible_context_pixels"], saved["image_id"]) == (digest(png), len(png), green, compact["image_id"])
                    images.append({"mode": imode, "bytes": len(png), "sha256": digest(png), "image_id": compact["image_id"],
                                   "decoded_shape": list(pixels.shape), "visible_context_pixels": green, "camera_exactly_matches_render": True})
                assert images[0]["sha256"] != images[1]["sha256"] and images[0]["image_id"] != images[1]["image_id"]
            counts = {op: sum(e["operation"] == op for e in events) for op in ("init", "render", "close")}
            assert counts == job["vg_counts"]
            if mode == "gui":
                for k in ("windows_before", "windows_after"):
                    assert job[k] and all(w["pid"] == summary["pid"] and not w["visible"] for w in job[k])
            row = {"mode": mode, "case": name, "before_identical_to_rev2": True, "gaps_m": gaps,
                   "maximum_vertex_component_error_m": float(np.abs(delta - spec["delta_m"]).max()),
                   "other_objects_parent_exact": True, "executions": writes, "vg_counts": counts,
                   "native_pid": nt["pid"], "main_thread_id": nt["main_thread_id"], "handler_calls": nt["handler_calls"],
                   "client_process": proc, "request_bytes": len(req_bytes), "response_bytes": len(resp_bytes), "images": images,
                   "before_sha256": digest((case / "before-rna.json").read_bytes()), "after_sha256": digest((case / "after-rna.json").read_bytes()),
                   "checks_passed": True}
            rows.append(row)
            print(name, "offline geometry/transport/image audit passed", flush=True)
    report = {"scope": "offline CPU only; no native process, GPU, model or performance run",
              "delivery_manifest_sha256": MANIFEST_HASH, "native_sources_verified": len(manifest["sources"]),
              "delivery_sources_verified": len(delivery["source_sha256"]), "delivery_evidence_verified": len(delivery["evidence_sha256"]),
              "invariant_engine_transport_sources": invariant, "unchanged_fixture_ast": fixture_same, "numeric_source_hashes": identities,
              "cases": rows, "old_revision_native_status": "0/5 FAIL preserved", "native_functional_result": "5/5 PASS",
              "model_host_task_efficiency_result": "NOT QUALIFIED", "checks_passed": True}
    OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(str(OUT), flush=True)


if __name__ == "__main__":
    main()
