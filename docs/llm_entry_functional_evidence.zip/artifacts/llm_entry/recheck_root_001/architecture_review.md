# revision_003 架构/算法返工闭环

**结论：ACCEPT_R1_R4_ARCHITECTURE。** R1–R4 已落实；在本次限定的冻结源比较和针对性 CPU 检查中，未发现新增重大算法或架构退化。无需继续优化，也无需为本审再跑 Blender、GPU或局部性能实验。此结论关闭上轮实现返工，不替代原生执行独立验收、真实 MCP 宿主消费或端到端任务收益。

## 身份与方法

读取 delivery 的冻结 ZIP，独立核对全部 **40 个 source 项**；指定三个现源与 ZIP 相同。17 个已验收内核文件，以及 relay/pump，均与 revision_002 **逐字节相同**。旧失败与作者产物未改。

| 项 | SHA256 |
| --- | --- |
| revision_003 delivery manifest | `dc44bf3b9d5f024c7acce38bb71bd0b8bf0482e8801662d8e766025a1a092d8a` |
| sources.zip | `097b33d5ac975c613a7a353b0fd7802ef01eef69d068571ff75bd054078fa4b3` |
| local_tasks.py | `ff29164bad100269fae33e59192ee8c3cab8c63f3c5be5cbcf77faf019cde367` |
| llm_entry.py | `a6170f080a4d776eea463a7736827bc402f4c59a7a2fb88e2003f6684856dac3` |
| examples/blender_llm_entry.py | `58e97890549786e1231217fb2af6865bf9d0a2ba56e81e5fd4ad8a868d0c64e9` |

`architecture_probe.py/json` 是本审独立离线探针：从 ZIP 加载三个实际修订模块及必要 dataclass 定义，给控制器与渲染器装 CPU 双件，检验真实编排/回包；未 import 真实 bpy/GPU、创建 socket 或执行 native。旧 witness roundoff 仅重放上轮已保存的 SurfaceDistance，不新增 BC 查询。探针第一次运行修正了自有 fake renderer 误读参数类型的问题，再运行全部断言 PASS；没有为此改作者代码。

## R1：跨请求写锁已删除

`CloseGapSession` 不再有 `_blocked`，Binding 不再有 `_write_blocked`；未知/已写异常仅产生该次错误结果。`local_tasks.run` 入口清空旧 evidence，下一条显式任务正常 fresh observe。`llm_entry` 对 error 清除可继续使用的 `_readback`，但已知 Outcome 的距离、位移、阶段与 witness 仍留在该次 receipt。

独立 probe 首次抛带已知 Outcome 的 written error，公开 after=3m、实际位移=(1.2,1.6,0)；inspect result 原样恢复，witness 不冒用失效当前几何。第二次明确 run 从 3m 重新观察并到 2m；同 Binding 关闭/重连后新任务从 2m 到 1m。累计事件按明确请求各一次 observe/execute，没有隐藏重试。修复符合主干要求，并未把错误包装成成功。

## R2：热依赖扫描与重复 witness 门已删除

`_local_static/_static_transform/_plain_mesh/_fixed_parents/_eligible` 已移除，构造也不再收集 `_data` 作为防御比对。支持域现在明确记在 CloseGapSession docstring、binding_for 和 API 草案：固定拓扑独立刚体、moving 统一世界平移、reference 固定、任务/取证期间帧/单位/场景稳定。移除检查不是新增任意 modifier、动画或并发编辑支持。

原 `hypot/isclose(rel_tol=1e-9)` 额外算法门已删除，公式改成 `fraction=(d-g)/d; delta=fraction*(b-a)`，仍是同一解析解；保留的是实际平移向量有限性、输入单位、空表面和目标方向等直接合同检查。上轮被额外相对门拒绝的原始 surface 在本次编排双件中进入一次 execute，未被同类新阈值再次拒绝。该检查不声称远坐标 Blender float32 控制已达标。

probe 的绑定对象主动拒绝访问 parent/modifier/animation 等属性，正常任务仍完成。原公式证明与真实全局 before/after 路径不变，数值任务依然没有 TD、AO、CF、图片、候选搜索或第二次捕获来“证明” witness。

## R3：渲染器连接常驻与释放已落实

`Binding.open_renderer` 创建连接自有 renderer owner；`LLMEntry._renderer` 仅首次需要图时获得它。example 的 `ConnectionRenderer` 再惰性创建一次实际 VGRenderer，此后复用；更改目标导致 Control 替换，不销毁连接 renderer。每张真实新图仍 prepare 当前 target/context mesh，没有把旧 PreparedScene 当最新场景。

独立联合探针通过冻结 example 和 LLMEntry，依次请求 NATURAL、SECTION、更改目标后的 NATURAL，得到 **init=1、prepare=3、render=3、close=1**；重复 close 没有二次释放。前三个数值任务均 init=0。`LLMEntry.close` 在 finally 里关闭 Control；未变的 Bridge 在 EOF/drop_client/stop 调用 entry.close，资源释放链闭合。

这只确认生命周期和创建次数，**不是实测 GPU 时延、内存峰值或提速收益**。不为此追加计量。

## R4：当前 result/camera 可取回且同源

`_publish` 保存当前 compact receipt；`inspect result` 重新编码这一份已完成结果，不再 run、不再 observe、不再写入，也不重复传 PNG。成功及带已知 Outcome 的错误正文均在独立 probe 中逐值一致。

example 返回本次实际 `rendered.metadata`；LLMEntry 将实际 views、meters_per_blender_unit 与当前 image info/PNG 一起留存。`inspect camera` 只返回当前图的 image_id、模式、切面、单位和 views；不渲染来补元数据。probe 使用每次 render 独有矩阵标记：NATURAL camera/image_id/PNG 同源；显式换 SECTION 后 image_id 改变，camera 对应第二次实际渲染和切面。result、camera、同模式 image inspect 的事件计数完全不变。

默认数值回包仍只有一个 TextContent，无 AO、图片、views/camera 或多余 witness；默认有图回包仍只含紧凑 image info 和一个 ImageContent，没有把矩阵、base64 再塞入正文。图片字节的 base64 往返仅用双件哨兵验证编排，**不冒称真实 PNG/GPU 质量检查**。

## 保留的限定与放行边界

- 仅保留最后 task 的 result 和最近 image/camera。显式换图模式会替换当前 image；result 是原任务回包的原样记录，可能仍引用先前 image_id，消费者应按 image_id 区分，不能拿新的 camera 套旧图。当前合同明确最近图，不增设历史仓库。
- 零间隙会用实际 NATURAL。先请求 SECTION 再显式 NATURAL 时，按请求模式缓存可能多渲染一次；这是根侧已知限定，本轮不扩测、不新增返工。
- 支持域、主线程/scene/view_layer 绑定、context 实际捕获及单位语义没有被上述修订扩大。控制器与 renderer 未通过新共享 Session 私有状态耦合；已验收内核未改。
- 作者 manifest 登记本次 native 5/5，但本审未重跑或独立重算全部 native 原始结果；该部分由原生证据审查签核。先前 0/5 仍作为旧批结果保留，不被本结论覆盖。

**本责任范围无具体阻塞，允许关闭 R1–R4。** 后续按已冻结工作的原生/宿主/任务收益边界继续，不再因本审重开优化。四个 V 正式场景的同源相机/切面/像素标签、合理 native 对照、真实模型图片使用和实际时间/token 门仍是独立未完项；本结论不提前放行 E2。
