revision_003解决了上轮最关键的数学覆盖和判定定义缺项。下一步应优先完成真实宿主1个数值＋1个图像pilot，N/V先完成可执行准备；现在不要求模型胜负或收益成绩，也不先扩展原生运行矩阵。主模型协议仍不是完整可执行的正式比较：N worker及四个V的实际标签尚待落地。无需扩样本、扩大动作域或重优引擎。

本次CPU只读检查delivery、两次数学登记/ZIP/输出及当前源码，全部声明SHA一致。独立 [protocol_probe.py](<D:/human eye/human-eye/artifacts/llm_entry/recheck_root_001/protocol_probe.py>) exit 0，明细在 [protocol_probe.json](<D:/human eye/human-eye/artifacts/llm_entry/recheck_root_001/protocol_probe.json>)；未导入引擎、未运行Blender、GPU、模型或性能测试。计算只重建既有14个recipe、28对合成before/after共56状态，没有增加试验样本。

**两D替换：数学覆盖已成立。** D02在两目标前侧添加封闭四面体，最近支撑为两条切向正交边；D03的moving顶点落在reference支撑三角面内部。背后凹形部件才细分，前侧特征保持原拓扑。目标面数分别是D02的4612/4612、D03的4608/4612，不是将大量无关场景物体充数。[recipe](<D:/human eye/human-eye/verification/llm_task_reference.py:98>)

oracle在实际三角拓扑内确认支撑点/边/面，检查支撑平面附近顶点集合恰为登记特征，再求仿射最近点及正重心权重。D02两侧权重约(0.57333,0.42667)、(0.58889,0.41111)；D03面内权重约(0.41253,0.28346,0.30401)，最小值都远大于原0.05门。新增两个“最近点移出内部”的反例确实保留在13项负例中。因此，当前数学样本不再全是0号顶点对。[oracle](<D:/human eye/human-eye/verification/llm_task_reference.py:159>) [内部负例](<D:/human eye/human-eye/artifacts/llm_entry/preflight_001/revision_003/protocol_smoke_001/oracle_smoke.py:144>)

这种替换提高最近特征覆盖，但任务仍是已指定对象的最短平移缩隙，不能扩称自主选目标、多步规划或通用三维编辑。实际float32 RNA几何能否保留这些边/面内部条件，要在下一阶段按同一oracle检查，不用合成数组通过替代。

**浮点外扩：可接受为当前固定数值域的修正。**

最初protocol_smoke进程exit 0，但保存的56个区间有18个下界略大于上界，最大倒置4.336808689942018e-19 m。旧原件完整保留。roundoff_recheck只在评分器增加5行：按`64 ε_float64 max|coordinate|`向两端外扩，并拒绝仍倒置的区间；另外只改协议对应说明。清单字节完全相同，输入参数、任务容差、28个正例和13个反例没有改变。不能把初次exit 0称作区间有序检查已通过。

我以90位Decimal读取精确binary64坐标、重新归一化轴，并用独立2×2代数求解当前非退化支撑，复算56组高精度下界/上界，均被新发布区间包含。最大单侧外扩仅为任务容差的8.6577e-10倍。外扩后的两端仍须分别落在原容差内，因此没有用增大任务容差放行几何误差。[外扩代码](<D:/human eye/human-eye/verification/llm_task_reference.py:183>)

这是当前固定、良态几何的独立数值证据，不是对任意病态支撑/任意坐标范围的严格区间算术证明。下一阶段真实RNA也必须产生有序且合格的区间；若不成立，保留本例失败，不在见到结果后继续加padding。支撑下界遍历实际全体顶点，表面内见证构造上界，均不读候选BC/AO/Outcome，避免候选自己给出“真值”。

**N helper：已从空泛允许工具推进到通用数学起点，尚非运行对照。** `native_surface_pair`只接受两网格数组，以三角AABB下界筛选，再用独立凸包支持枚举/最小二乘求最近点；没有读取case ID、隐藏轴、target fraction或登记支撑索引。两个已有种子覆盖edge-edge和vertex-face，并含一个远离面检查筛选。它们只是两个小数学检查，不是D02/D03完整稠密网格运行，也不是N单次/多次真实写入成绩。[helper](<D:/human eye/human-eye/verification/llm_task_reference.py:204>) [两个种子](<D:/human eye/human-eye/artifacts/llm_entry/preflight_001/revision_003/protocol_smoke_001/oracle_smoke.py:73>)

N若沿用此起点，应只封装通用函数及必要数学源码，不能把含recipe和评分器的整个模块装入N。原生侧保留驻留、批处理、缓存、自己编排一次测量/求解/执行/核验的权利；一次完成就计一次工具往返，不能沿用smoke里人为N三步作为基线。[N接线合同](<D:/human eye/human-eye/docs/LLM_TASK_PROTOCOL_DRAFT.md:52>)

**该seed不能直接冻结为合理性能基线。** 它对每个A面扫描全部B面AABB，广相仍是O(Fa×Fb)；每个保留三角对最多枚举7×7组支持并多次最小二乘。这是质量优先的验收原语包装，2个小seed正确不能证明成本具有代表性。冻结实际N之前核对通用算法及复杂度，避免故意选慢oracle制造I的2倍收益；允许Blender原生mathutils几何、向量化通用三角距离、持久BVH等合理实现，不读取HE内核或recipe隐藏答案。采用双方同等开发预算即可，不要求现在将N优化到极限，也不为此开新性能循环。

**V设计：上轮定义歧义已消除，实际视觉资格仍待采集。** 新草案明确同一PNG与case/arm/task/observation/frame/mode/hash绑定；两个面板保存实际相机、投影、裁切矩形及像素约定；SECTION保存有符号切面、保留侧和切后几何，射线作用于真实保留几何。`camera`读取缓存证据，不重渲染补旧图。五点中至少三票同标签才给visible/occluded/cut_away/unknown，否则mixed；unknown不从分母删除。每个V案至少一个确定标签、整组至少有可见和遮挡各一项，阻止全unknown空通过。这些定义可冻结。[证据绑定](<D:/human eye/human-eye/docs/LLM_TASK_PROTOCOL_DRAFT.md:40>) [投票规则](<D:/human eye/human-eye/docs/LLM_TASK_PROTOCOL_DRAFT.md:42>)

仍未生成V01–V04各臂真实相机、样点和标签，草案也明确承认。delivery中普通occluded资格的两张PNG及背景像素数，不是这四个正式V的可见性真值，不能移用。下一阶段只需在这四案落实单点hit/色标或轮廓判据、画布边界约定与相同观察条件，保存5点分类及原PNG；模型标签要对实际收到的图判，不允许候选自己给visible充当独立评分。[未冻结范围](<D:/human eye/human-eye/docs/LLM_TASK_PROTOCOL_DRAFT.md:44>)

**进入下一阶段的最小合同。** 先接上真实宿主，只登记有限功能pilot，不生成正式模型成本/胜负样本。N/V本轮完成准备，执行范围由父端之后一次冻结；完整14例仍留给后续正式比较。

| 下一阶段项目 | 最小固定范围与证据 | 退出条件 |
| --- | --- | --- |
| 首先：实际MCP宿主 | 优先复用已通过原生资格的1个数值案＋1个图像案；实际注册/发现/调用，保存宿主收到的文本、标准image块及缓存camera读取记录 | 当前宿主确实消费新入口与同一图；PNG解码、hash/观察绑定成立，取camera不产生额外render。不能用脚本stdio客户端或文件路径替代；该单图不覆盖V01–V04正式标签 |
| 准备：N及数值真实资格 | 固定不人为过慢的纯通用N worker、RNA采集、世界米setter与写入审计；提供现有D02/D03、父级/单位和C02的可执行选择入口。此时不启动新矩阵 | 接线文件、命令和预期记录可审查；后续资格才核对实际非顶点见证、真实位移/间隙及C02零写入。N能一次批处理，不借用私有oracle |
| 准备：V评分 | 只针对既有V01–V04，完成同源相机/切面/几何保存和5点射线＋PNG评分程序，固定色标/轮廓和边界规则 | 程序与配置可执行；真实正负标签必须待后续固定资格批次生成，当前不预填PASS，不因宿主pilot成功而跳过 |
| 计量可用性 | 固定可观察模型版本、设置、实际schema/目录、冷/热边界；确认能否取得所要求文字token，记录审计开关与作用范围 | 只报告可测/未测。局部trace审计开销不隐去；没有真实模型比较前不判2倍收益 |

宿主pilot先完成，避免一直只有离线脚本而没有真实接入。N/V准备审过后，父端再固定一次最小资格批次并复用同次生成的证据，不为接线、图像、宿主分别重复跑整套实验。原5例原生复验由父端其他审查覆盖，本报告不要求重跑那5例或追溯PID问题。

可冻结：两D替换后的14例清单、原目标/容差、数值oracle当前修订、N允许能力与纯函数边界、V绑定/分类规则、180秒失败截断和全配对计时原则。待实际资格后才能冻结：N真实worker及渲染配置、四V相机/样点/正负标签、真实宿主资料及最终运行命令。

token缺测的总出口已写清：未提供则E1整体仍未通过；不妨碍先完成本轮功能资格。N多轮子集仍只能是条件诊断，报告全12例真实轮数，空集不能宣传轮数减半。当前交付没有正式模型或费用成绩，此时不需要补造这些成绩，也不推进E2。[成本出口](<D:/human eye/human-eye/docs/LLM_TASK_PROTOCOL_DRAFT.md:69>)
