validate_code("import mathutils\nprint('ok')")
_consumer_scope_state['running'] = True
try:
    exec(compile("import mathutils\nprint('ok')", '<ordinary-blender-task>', 'exec'), _ordinary_blender_namespace)
finally:
    _consumer_scope_state['running'] = False
