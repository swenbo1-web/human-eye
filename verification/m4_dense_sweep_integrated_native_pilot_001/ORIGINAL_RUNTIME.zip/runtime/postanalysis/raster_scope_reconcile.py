"""Replay frozen QP evidence offline with a derived per-owner raster counter."""
from copy import deepcopy
import json
from pathlib import Path
from runpy import run_path
import sys

root, ns = map(lambda value: Path(value).resolve(), sys.argv[1:])
l = run_path(str(ns/'analysis/ledger.py'))
f = l['F']
pin, read, require = (f[key] for key in ('pin', 'read', 'require'))
freeze = pin(ns/'FROZEN.json')
journal = [json.loads(line) for line in (root/'preflight/SEQUENCE.jsonl').read_bytes().splitlines()]
require([(row['event'], row['label']) for row in journal] ==
        [('start','QN'), ('publication','QN'), ('qualification_passed','QN'),
         ('start','QP'), ('publication','QP'), ('blocked','QP')]
        and journal[-1]['reason'] == 'actual_owned_raster_accounting_changed'
        and journal[-1]['remaining'] == ['N1','P1']
        and not any((root/'slots'/label).exists() for label in ('N1','P1')),
        'frozen_rejection_and_unrun_denominator_required')
pubs = {}
charges = {}
for label, proposal in (('QN',2), ('QP',3)):
    slot = root/'slots'/label
    result_path = slot/'SLOT_RESULT.json'
    publication_path = slot/'SLOT_PUBLICATION.json'
    actual, published = read(result_path), read(publication_path)
    result = pin(result_path,slot)
    require(result['sha256'] == published['result_sha256'] and actual['freeze_sha256'] == freeze['sha256']
            and actual['status'] == published['status'] == 'completed' and actual['model_consumers'] == 0
            and actual['closure_verification']['passed'] is True, 'original_closed_publication_changed')
    charge = l['raster_charges'](slot)
    require(charge['actual'] == proposal == charge['registered'], 'owner_charge_count_changed')
    records = [row for row in actual['budget']['records'] if row['claim']['kind']=='raster_attempt']
    bound = [row for row in records if row['claim']['label']==label]
    require(sum(row['settlement']['actual_attempts'] for row in bound) == charge['actual']
            and actual['budget']['counts']['all_raster_actual'] ==
                sum(row['settlement']['actual_attempts'] for row in records)
            and actual['budget']['counts']['pending_raster_reservations'] == 0,
            'owner_budget_snapshot_and_raw_settlements_disagree')
    pubs[label] = {'result':result,'publication':pin(publication_path,slot),
                   'original_cumulative_raster_actual':actual['budget']['counts']['all_raster_actual']}
    charges[label] = charge

installed = read(f['BINDING'])
v = ns.parent
for dep in (installed['dependency_root'],read(v/'m5_harness_recovery_001/SHARED_DEPENDENCY.json')['dependency_root']):
    if dep not in sys.path:
        sys.path.insert(0,dep)
p_slot = root/'slots/QP'
original = read(p_slot/'SLOT_RESULT.json')
copy = deepcopy(original)
copy['budget']['counts']['all_raster_actual'] = charges['QP']['actual']
frozen_closed = ns/'qualification/closed.py'
source_hash = pin(frozen_closed)
registered, = [row for row in read(ns/'FROZEN.json')['direct_inputs']
               if Path(row['path']).resolve()==frozen_closed.resolve()]
require(all(source_hash[key]==registered[key] for key in ('sha256','bytes')),
        'frozen_source_must_be_retained_byte_exact')
proof = run_path(str(frozen_closed))['verify'](p_slot,copy)
require(proof['passed'] is True and proof['rasters']==3
        and len(proof['proof']['discovery']['witness_paths'])==2
        and all(row['exact'] for call in proof['proof']['CLI'].values() for row in call['stages']),
        'offline_frozen_visual_path_or_CLI_reproof_changed')
meter_path = p_slot/'mcp_io/MCP_IO.jsonl'
meters = [json.loads(line) for line in meter_path.read_bytes().splitlines()]
tool_meters = [{'id':row['id'],'raster_actual':row.get('raster_actual'),
                'TX_bytes':row.get('TX_bytes'),'RX_bytes':row.get('RX_bytes')}
               for row in meters if row.get('method')=='tools/call']
require(sum(row['raster_actual'] for row in tool_meters if isinstance(row['raster_actual'],int))==3,
        'product_actual_tool_meter_rasters_not_reconciled')
verify = run_path(str(v/'perf050_dense_micro_surface_holdout_recovery_001/qualification/verify.py'))
worker = verify['closed_wire'](p_slot)
data = {'schema':'m4-dense-integrated-offline-raster-scope-reconciliation-v1',
        'status':'closed_evidence_only_not_an_admission', 'actual_gate_rejected': True,
        'new_starts': {'Blender':0,'model':0}, 'formal_slots_unrun':['N1','P1'],
        'frozen_plan':freeze, 'original_sequence':pin(root/'preflight/SEQUENCE.jsonl'),
        'result_identity':pubs, 'result_argument_only_change':{
            'field':'budget.counts.all_raster_actual',
            'original_cumulative':5,'derived_slot_owned':3,'original_files_changed':0},
        'verified_owner_raster_charges':charges, 'original_product_tool_raster_meter':tool_meters,
        'raw_product_tool_meter':pin(meter_path,p_slot),
        'native_wire_rows':[row for row in worker],
        'frozen_visual_checker':source_hash,
        'replayed_QP_closed_geometry_png_and_CLI_proof':proof}
with (root/'postanalysis/RASTER_SCOPE_RECONCILIATION.json').open('x',encoding='utf8',newline='\n') as out:
    json.dump(data,out,ensure_ascii=False,allow_nan=False,indent=2)
    out.write('\n')
print('QN',charges['QN']['actual'],'QP',charges['QP']['actual'],'cumulative 5',
      'witness paths',len(proof['proof']['discovery']['witness_paths']),
      'CLI stages',sum(len(c['stages']) for c in proof['proof']['CLI'].values()),
      'no gate or live rerun')
