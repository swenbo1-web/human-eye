import bpy, json
s=bpy.context.scene
out={'unit_system':s.unit_settings.system,'scale_length':s.unit_settings.scale_length,'objects':[]}
for o in s.objects:
 if o.type=='MESH':
  me=o.data
  out['objects'].append({'name':o.name,'vertices':[list(o.matrix_world @ v.co) for v in me.vertices],'polygons':[list(p.vertices) for p in me.polygons],'matrix_world':[list(r) for r in o.matrix_world],'modifiers':[{'name':m.name,'type':m.type,'show_viewport':m.show_viewport} for m in o.modifiers],'hidden':o.hide_get()})
print(json.dumps(out,ensure_ascii=False))