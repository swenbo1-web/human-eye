import bpy,json,math
s=bpy.context.scene
dg=bpy.context.evaluated_depsgraph_get()
results=[]
for o in s.objects:
    if o.type!='MESH':continue
    eo=o.evaluated_get(dg)
    vs=[world_xyz(eo,v) for v in eo.data.vertices]
    fs=[tuple(p.vertices) for p in eo.data.polygons]
    assert vs==T02_geoms[o.name][0] and fs==T02_geoms[o.name][1], 'Evaluated geometry differs: '+o.name
    assert all(math.isfinite(x) for p in vs for x in p)
    assert all(len(f)==3 for f in fs)
    if o.name=='M4_Focal':
        assert vs==[(0.0,0.0,0.0),(0.0,1.0,0.0),(0.0,0.0,1.0)] and fs==[(0,1,2)]
        continue
    xs={p[0] for p in vs}
    assert len(xs)==1, 'Nonconstant x: '+o.name
    dx=abs(next(iter(xs)))
    witness=None
    for fi,f in enumerate(fs):
        for vi in f:
            p=vs[vi]
            if p[1]>=0 and p[2]>=0 and p[1]+p[2]<=1:
                witness={'object_face':fi,'object_vertex':vi,'object_point':p,'focal_point':(0,p[1],p[2])};break
        if witness:break
    assert witness is not None, 'No attaining witness: '+o.name
    results.append({'name':o.name,'triangle_count':len(fs),'x_separation_lower_bound_m':dx*s.unit_settings.scale_length,'attained_distance_m':dx*s.unit_settings.scale_length,'witness':witness})
instances=[{'name':i.object.name,'source':i.object.original.name,'is_instance':i.is_instance,'type':i.object.type,'matrix_world':[list(row) for row in i.matrix_world]} for i in dg.object_instances]
mind=min(r['attained_distance_m'] for r in results)
print(json.dumps({'mesh_count':sum(o.type=='MESH' for o in s.objects),'comparison_meshes':len(results),'comparison_triangles':sum(r['triangle_count'] for r in results),'evaluated_matches_source':True,'instance_count':len(instances),'nonbase_instances':[i for i in instances if i['is_instance']],'nonmesh_objects':[o.name for o in s.objects if o.type!='MESH'],'results':results,'nearest_names':[r['name'] for r in results if r['attained_distance_m']==mind],'minimum_distance_m':mind,'clearance_3mm':mind>=0.003,'scale_length':s.unit_settings.scale_length},ensure_ascii=False))