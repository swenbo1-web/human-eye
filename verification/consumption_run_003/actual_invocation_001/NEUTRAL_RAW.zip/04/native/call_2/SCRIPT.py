import bpy,json,math
s=bpy.context.scene
def world_xyz(o,v):
    m=o.matrix_world
    return tuple(sum(float(m[i][j])*float(v.co[j]) for j in range(3))+float(m[i][3]) for i in range(3))
T02_geoms={}
T02_summary=[]
for o in s.objects:
    if o.type!='MESH': continue
    vs=[world_xyz(o,v) for v in o.data.vertices]
    fs=[tuple(p.vertices) for p in o.data.polygons]
    T02_geoms[o.name]=(vs,fs)
    deg=[]
    nontri=[]
    for k,f in enumerate(fs):
        if len(f)!=3:
            nontri.append(k);continue
        a,b,c=[vs[i] for i in f]
        u=[b[i]-a[i] for i in range(3)];v=[c[i]-a[i] for i in range(3)]
        cr=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
        if not any(cr):deg.append(k)
    T02_summary.append({'name':o.name,'bounds':[[min(p[i] for p in vs),max(p[i] for p in vs)] for i in range(3)],'vertices':len(vs),'triangles':len(fs),'nontriangles':nontri,'degenerate_faces':deg,'matrix_world':[list(row) for row in o.matrix_world],'small_mesh_geometry':{'vertices':vs,'faces':fs} if len(fs)<4 else None})
print(json.dumps(T02_summary,ensure_ascii=False))