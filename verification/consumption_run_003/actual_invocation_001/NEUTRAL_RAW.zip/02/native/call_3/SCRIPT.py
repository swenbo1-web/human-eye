import bpy, json
s = bpy.context.scene
out = {'scene':s.name,'units':{'system':s.unit_settings.system,'scale_length':s.unit_settings.scale_length},'objects':[]}
for o in s.objects:
    row={'name':o.name,'type':o.type,'matrix_world':[list(r) for r in o.matrix_world],'hide_viewport':o.hide_viewport,'hide_render':o.hide_render}
    if o.type=='MESH':
        m=o.data
        m.calc_loop_triangles()
        row.update({'vertices':[list(o.matrix_world @ v.co) for v in m.vertices],'triangles':[list(t.vertices) for t in m.loop_triangles],'polygons':[list(p.vertices) for p in m.polygons],'modifiers':[{'name':q.name,'type':q.type,'show_viewport':q.show_viewport} for q in o.modifiers]})
    out['objects'].append(row)
print(json.dumps(out,ensure_ascii=False))