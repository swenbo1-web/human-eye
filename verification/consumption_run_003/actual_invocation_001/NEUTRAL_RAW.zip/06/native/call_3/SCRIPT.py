import bpy, json
scene = bpy.context.scene
dg = bpy.context.evaluated_depsgraph_get()
result = {'scene': scene.name, 'unit_system': scene.unit_settings.system, 'scale_length': scene.unit_settings.scale_length, 'objects': []}
for obj in scene.objects:
    item = {'name': obj.name, 'type': obj.type, 'hide_viewport': obj.hide_viewport, 'hide_render': obj.hide_render}
    if obj.type == 'MESH':
        ev = obj.evaluated_get(dg)
        me = ev.to_mesh()
        try:
            me.calc_loop_triangles()
            item.update({'vertices_count': len(me.vertices), 'polygons_count': len(me.polygons), 'triangle_count': len(me.loop_triangles), 'matrix_world': [list(row) for row in ev.matrix_world], 'modifiers': [{'type': m.type, 'show_viewport': m.show_viewport} for m in obj.modifiers]})
            if len(me.vertices) <= 1000 and len(me.loop_triangles) <= 1000:
                item['vertices_world'] = [list(ev.matrix_world @ v.co) for v in me.vertices]
                item['triangles'] = [list(t.vertices) for t in me.loop_triangles]
        finally:
            ev.to_mesh_clear()
    result['objects'].append(item)
print(json.dumps(result, allow_nan=False))