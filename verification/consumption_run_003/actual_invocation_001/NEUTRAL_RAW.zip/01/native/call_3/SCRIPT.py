import bpy, json
s=bpy.context.scene
dg=bpy.context.evaluated_depsgraph_get()
checks=[]
for o in s.objects:
    if o.type != 'MESH':
        continue
    e=o.evaluated_get(dg)
    verts=[tuple(float(x) for x in e.matrix_world@v.co) for v in e.data.vertices]
    checks.append({'name':o.name,'evaluated_world_vertices':verts,'evaluated_faces':[list(p.vertices) for p in e.data.polygons],'shape_keys':o.data.shape_keys.name if o.data.shape_keys else None})
print(json.dumps({'mesh_count':sum(o.type=='MESH' for o in s.objects),'scale_length':s.unit_settings.scale_length,'checks':checks},ensure_ascii=False))