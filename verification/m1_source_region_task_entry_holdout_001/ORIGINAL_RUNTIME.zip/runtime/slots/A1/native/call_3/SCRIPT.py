import json as _json, contextlib as _cl, io as _io
_request = _json.loads('{"id":"afb82660f96e472896f82d85ae7dee09","command":"capture","params":{}}')
try:
    import sys as _sys
    _module = _sys.modules.get('_human_eye_mcp_resident_f7e0e626c38e70ef27df')
    if _module is None or getattr(_module, '_resident_tag', None) != '588f12a5001adb5df66b57ca8f8f2c3c20207192b6d141bd3ef8c7e01cb7d7f0': raise RuntimeError('Resident Blender host unavailable; reconnect with a new connector')
    _host = _module._mcp_resident_host
    with _cl.redirect_stdout(_io.StringIO()):
        _result = getattr(_host, 'capture_scene')(**_request['params'])
    _result = _host.capture_delta(_result, _json.loads('{"instance_id":"2e6da427254148cb9cfc90a7608f0daa","epoch":1,"resources":{"mesh:(\'uid\', 163)":1,"mesh:(\'uid\', 167)":2}}'))
    _envelope = {'protocol_version': '1.0', 'id': _request['id'], 'result': _result}
except Exception as _exc:
    _envelope = {'protocol_version': '1.0', 'id': _request['id'], 'error': {'type': type(_exc).__name__, 'message': str(_exc)[:2000], 'mutation_uncertain': _request['command'] == 'apply'}}
print('HUMAN_EYE_BLENDER_MCP:' + _json.dumps(_envelope, ensure_ascii=True, allow_nan=False, separators=(',', ':')))