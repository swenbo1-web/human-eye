from pathlib import Path
import sys
Path('D:\\he_m1_source_region_task_entry_holdout_001_consumer_preflight\\B1\\STDIN.bin').write_bytes(sys.stdin.buffer.read())
raise SystemExit(7)
