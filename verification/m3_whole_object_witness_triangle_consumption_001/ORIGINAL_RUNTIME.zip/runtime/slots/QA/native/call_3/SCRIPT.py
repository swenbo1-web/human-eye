import json as _json, contextlib as _cl, io as _io
_request = _json.loads('{"id":"73fc5307c380400aad1179274cf801fc","command":"capture_task","params":{"selectors":[{"name":"M16"},{"name":"M14"}]}}')
try:
    import sys as _sys
    _module = _sys.modules.get('_human_eye_mcp_resident_6bef073fee72074d89a6')
    if _module is None or getattr(_module, '_resident_tag', None) != '588f12a5001adb5df66b57ca8f8f2c3c20207192b6d141bd3ef8c7e01cb7d7f0': raise RuntimeError('Resident Blender host unavailable; reconnect with a new connector')
    _host = _module._mcp_resident_host
    with _cl.redirect_stdout(_io.StringIO()):
        _result = getattr(_host, 'capture_task_scene')(**_request['params'])
    _result = _host.capture_delta(_result, _json.loads('{"instance_id":"e5ceba333d6a47598a41a6fa604e9645","epoch":1,"resources":{"mesh:(\'uid\', 178)":1,"mesh:(\'uid\', 175)":2}}'))
    _envelope = {'protocol_version': '1.0', 'id': _request['id'], 'result': _result}
except Exception as _exc:
    _envelope = {'protocol_version': '1.0', 'id': _request['id'], 'error': {'type': type(_exc).__name__, 'message': str(_exc)[:2000], 'mutation_uncertain': _request['command'] == 'apply'}}
print('HUMAN_EYE_BLENDER_MCP:' + _json.dumps(_envelope, ensure_ascii=True, allow_nan=False, separators=(',', ':')))