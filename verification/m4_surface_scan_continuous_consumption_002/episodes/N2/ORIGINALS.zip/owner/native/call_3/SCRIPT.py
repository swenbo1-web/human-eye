geometry=[]
for obj in objs:
 evaluated=obj.evaluated_get(depsgraph)
 mesh=evaluated.to_mesh()
 try:
  mesh.calc_loop_triangles()
  transform=np.array(evaluated.matrix_world,dtype=np.float64)
  verts=np.array([v.co[:] for v in mesh.vertices],dtype=np.float64).reshape((-1,3))
  world=verts@transform[:3,:3].T+transform[:3,3]
  indices=np.array([t.vertices[:] for t in mesh.loop_triangles],dtype=np.int64).reshape((-1,3))
  triangles=world[indices]
  geometry.append({'name':obj.name,'tri':triangles,'lo':world.min(axis=0) if len(world) else None,'hi':world.max(axis=0) if len(world) else None})
 finally:
  evaluated.to_mesh_clear()
mm_per_unit=scene.unit_settings.scale_length*1000.0
threshold=2.0/mm_per_unit
candidates=[]
excluded=[]
for first in range(len(geometry)):
 for second in range(first+1,len(geometry)):
  ga,gb=geometry[first],geometry[second]
  if not len(ga['tri']) or not len(gb['tri']):
   print('EMPTY',ga['name'],gb['name']);continue
  separation=np.maximum(np.maximum(ga['lo']-gb['hi'],gb['lo']-ga['hi']),0)
  lower=float(np.linalg.norm(separation))
  if lower<=threshold+1e-12:
   candidates.append((first,second,lower))
  else:excluded.append((first,second,lower))
print('total triangles',sum(len(g['tri']) for g in geometry),'all pairs',len(objs)*(len(objs)-1)//2,'candidates',len(candidates),'AABB excluded',len(excluded))
for first,second,lower in candidates:print(geometry[first]['name'],geometry[second]['name'],'lower_mm',lower*mm_per_unit)
print('degenerate triangles',[(g['name'],int(np.sum(np.linalg.norm(np.cross(g['tri'][:,1]-g['tri'][:,0],g['tri'][:,2]-g['tri'][:,0]),axis=1)==0))) for g in geometry])