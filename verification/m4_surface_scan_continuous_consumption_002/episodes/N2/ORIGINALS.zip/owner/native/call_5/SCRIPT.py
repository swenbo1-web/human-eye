excluded_exact=[]
for first,second,lower in excluded:
 distance,hit=surface_distance(geometry[first]['tri'],geometry[second]['tri'])
 excluded_exact.append((first,second,distance,hit))
all_results=results+excluded_exact
max_asymmetry=0.0
for first,second,distance,hit in all_results:
 reverse,reverse_hit=surface_distance(geometry[second]['tri'],geometry[first]['tri'])
 max_asymmetry=max(max_asymmetry,abs(reverse-distance))
print('all_pairs_exactly_checked',len(all_results))
print('additional_qualifying',sum(record[2]<=threshold for record in excluded_exact))
print('max_reverse_difference_mm',max_asymmetry*mm_per_unit)
print('nonzero_count',sum(record[2]>0 for record in qualifying),'zero_count',sum(record[2]==0 for record in qualifying))
print('nearest_nonqualifying_mm',min(record[2] for record in all_results if record[2]>threshold)*mm_per_unit)
print('DATA_SCENE_MESH_COUNT',len([obj for obj in bpy.data.objects if obj.type=='MESH']),'SCENE_MESH_COUNT',len(objs))
print('GROUPED_ZERO')
for first in range(len(geometry)):
 names=[geometry[second]['name'] for aa,second,distance,hit in qualifying if aa==first and distance==0]
 if names:print(geometry[first]['name'],','.join(names))
print('NONZERO')
for first,second,distance,hit in qualifying:
 if distance>0:print(geometry[first]['name'],geometry[second]['name'],format(distance*mm_per_unit,'.6f'))