def dot_rows(left,right):
 return np.sum(left*right,axis=-1)
def point_segment_sq(points,start,end):
 direction=end-start
 parameter=np.clip(dot_rows(points-start,direction)/dot_rows(direction,direction),0,1)
 residual=points-start-parameter[...,None]*direction
 return dot_rows(residual,residual)
def point_triangle_sq(points,triangles):
 origin=triangles[:,0]; edge_u=triangles[:,1]-origin; edge_v=triangles[:,2]-origin
 normal=np.cross(edge_u,edge_v); normal_sq=dot_rows(normal,normal)
 offset=points-origin
 height=dot_rows(offset,normal)
 projected=offset-height[:,None]/normal_sq[:,None]*normal
 uu=dot_rows(edge_u,edge_u); uv=dot_rows(edge_u,edge_v); vv=dot_rows(edge_v,edge_v)
 pu=dot_rows(projected,edge_u); pv=dot_rows(projected,edge_v)
 determinant=dot_rows(normal,normal)
 bary_u=(pu*vv-pv*uv)/determinant
 bary_v=(pv*uu-pu*uv)/determinant
 inside=(bary_u>=0)&(bary_v>=0)&(bary_u+bary_v<=1)
 distance=np.minimum.reduce([point_segment_sq(points,triangles[:,idx],triangles[:,(idx+1)%3]) for idx in range(3)])
 return np.where(inside,np.minimum(distance,height*height/normal_sq),distance)
def segments_sq(start_a,end_a,start_b,end_b):
 direction_a=end_a-start_a;direction_b=end_b-start_b;offset=start_a-start_b
 aa=dot_rows(direction_a,direction_a);bb=dot_rows(direction_a,direction_b);cc=dot_rows(direction_b,direction_b)
 dd=dot_rows(direction_a,offset);ee=dot_rows(direction_b,offset)
 determinant=aa*cc-bb*bb
 stable=determinant>1e-14*aa*cc
 safe=np.where(stable,determinant,1)
 param_a=(bb*ee-cc*dd)/safe;param_b=(aa*ee-bb*dd)/safe
 interior=stable&(param_a>=0)&(param_a<=1)&(param_b>=0)&(param_b<=1)
 residual=offset+param_a[:,None]*direction_a-param_b[:,None]*direction_b
 endpoint=np.minimum.reduce([point_segment_sq(start_a,start_b,end_b),point_segment_sq(end_a,start_b,end_b),point_segment_sq(start_b,start_a,end_a),point_segment_sq(end_b,start_a,end_a)])
 return np.where(interior,np.minimum(endpoint,dot_rows(residual,residual)),endpoint)
def segment_triangle_hit(start,end,triangles):
 origin=triangles[:,0];edge_u=triangles[:,1]-origin;edge_v=triangles[:,2]-origin
 normal=np.cross(edge_u,edge_v);direction=end-start
 denominator=dot_rows(direction,normal)
 valid=np.abs(denominator)>1e-14*np.sqrt(dot_rows(direction,direction)*dot_rows(normal,normal))
 parameter=dot_rows(origin-start,normal)/np.where(valid,denominator,1)
 point=start+parameter[:,None]*direction
 offset=point-origin
 determinant=dot_rows(normal,normal)
 uu=dot_rows(edge_u,edge_u);uv=dot_rows(edge_u,edge_v);vv=dot_rows(edge_v,edge_v)
 pu=dot_rows(offset,edge_u);pv=dot_rows(offset,edge_v)
 bary_u=(pu*vv-pv*uv)/determinant;bary_v=(pv*uu-pu*uv)/determinant
 return valid&(parameter>=0)&(parameter<=1)&(bary_u>=0)&(bary_v>=0)&(bary_u+bary_v<=1)
def surface_distance(tris_a,tris_b):
 count_a,count_b=len(tris_a),len(tris_b)
 repeated_a=np.repeat(tris_a,count_b,axis=0);repeated_b=np.tile(tris_b,(count_a,1,1))
 hits=np.zeros(len(repeated_a),dtype=bool)
 for edge_idx in range(3):
  hits|=segment_triangle_hit(repeated_a[:,edge_idx],repeated_a[:,(edge_idx+1)%3],repeated_b)
  hits|=segment_triangle_hit(repeated_b[:,edge_idx],repeated_b[:,(edge_idx+1)%3],repeated_a)
 if hits.any():return 0.0,True
 best=np.full(len(repeated_a),np.inf)
 for vertex_idx in range(3):
  best=np.minimum(best,point_triangle_sq(repeated_a[:,vertex_idx],repeated_b))
  best=np.minimum(best,point_triangle_sq(repeated_b[:,vertex_idx],repeated_a))
 for edge_a in range(3):
  for edge_b in range(3):
   best=np.minimum(best,segments_sq(repeated_a[:,edge_a],repeated_a[:,(edge_a+1)%3],repeated_b[:,edge_b],repeated_b[:,(edge_b+1)%3]))
 return float(np.sqrt(best.min())),False
results=[]
for first,second,lower in candidates:
 distance,hit=surface_distance(geometry[first]['tri'],geometry[second]['tri'])
 results.append((first,second,distance,hit))
qualifying=[record for record in results if record[2]<=threshold]
print('QUALIFYING',len(qualifying))
for first,second,distance,hit in qualifying:
 print(geometry[first]['name'],geometry[second]['name'],format(distance*mm_per_unit,'.9f'),'intersection',hit)
print('remaining_candidates',len(results)-len(qualifying))
print('closest_excluded',sorted([(distance*mm_per_unit,geometry[first]['name'],geometry[second]['name']) for first,second,distance,hit in results if distance>threshold])[:8])
print('minimum_AABB_excluded_mm',min(record[2] for record in excluded)*mm_per_unit)