import bpy, numpy as np
scene=bpy.context.scene
depsgraph=bpy.context.evaluated_depsgraph_get()
objs=[obj for obj in scene.objects if obj.type=='MESH']
geometry=[]
for obj in objs:
 evaluated=obj.evaluated_get(depsgraph)
 mesh=evaluated.to_mesh()
 try:
  mesh.calc_loop_triangles()
  transform=np.array(evaluated.matrix_world,dtype=np.float64)
  vertices=np.array([vertex.co[:] for vertex in mesh.vertices],dtype=np.float64).reshape((-1,3))
  world=vertices@transform[:3,:3].T+transform[:3,3]
  indices=np.array([triangle.vertices[:] for triangle in mesh.loop_triangles],dtype=np.int64).reshape((-1,3))
  geometry.append({'name':obj.name,'tri':world[indices]})
 finally:evaluated.to_mesh_clear()
mm_per_unit=scene.unit_settings.scale_length*1000
threshold=2/mm_per_unit
print('units',scene.unit_settings.system,'scale',scene.unit_settings.scale_length,'mesh_count',len(objs),'triangles',sum(len(item['tri']) for item in geometry))
print('empty',[item['name'] for item in geometry if not len(item['tri'])])
print('distance_function_available','surface_distance' in globals())
print('degenerates',[(item['name'],int(np.sum(np.linalg.norm(np.cross(item['tri'][:,1]-item['tri'][:,0],item['tri'][:,2]-item['tri'][:,0]),axis=1)==0))) for item in geometry if len(item['tri']) and np.any(np.linalg.norm(np.cross(item['tri'][:,1]-item['tri'][:,0],item['tri'][:,2]-item['tri'][:,0]),axis=1)==0)])
all_results=[]
for first in range(len(geometry)):
 for second in range(first+1,len(geometry)):
  if not len(geometry[first]['tri']) or not len(geometry[second]['tri']):continue
  distance,hit=surface_distance(geometry[first]['tri'],geometry[second]['tri'])
  all_results.append((first,second,distance,hit))
qualifying=[record for record in all_results if record[2]<=threshold]
print('checked',len(all_results),'qualifying',len(qualifying))
for first,second,distance,hit in qualifying:print(geometry[first]['name'],geometry[second]['name'],format(distance*mm_per_unit,'.9f'),'hit',hit)
print('nearest_excluded_mm',min((record[2]*mm_per_unit for record in all_results if record[2]>threshold),default=None))