def dot_last(left,right):
 return np.sum(left*right,axis=-1)

def point_segment_sq(point,start,end):
 direction=end-start
 denom=dot_last(direction,direction)
 parameter=np.divide(dot_last(point-start,direction),denom,out=np.zeros(np.broadcast_shapes(point.shape[:-1],denom.shape)),where=denom>0)
 parameter=np.clip(parameter,0,1)
 residual=point-start-parameter[...,None]*direction
 return dot_last(residual,residual)

def point_triangle_sq(point,triangle):
 start=triangle[...,0,:]; side_a=triangle[...,1,:]-start; side_b=triangle[...,2,:]-start
 normal=np.cross(side_a,side_b); normal_sq=dot_last(normal,normal)
 offset=point-start
 signed=dot_last(offset,normal)
 aa=dot_last(side_a,side_a); ab=dot_last(side_a,side_b); bb=dot_last(side_b,side_b)
 pa=dot_last(offset,side_a); pb=dot_last(offset,side_b)
 denom=aa*bb-ab*ab
 coord_a=np.divide(bb*pa-ab*pb,denom,out=np.zeros_like(pa),where=denom>0)
 coord_b=np.divide(aa*pb-ab*pa,denom,out=np.zeros_like(pb),where=denom>0)
 inside=(denom>0)&(coord_a>=0)&(coord_b>=0)&(coord_a+coord_b<=1)
 plane_sq=np.divide(signed*signed,normal_sq,out=np.full_like(signed,np.inf),where=normal_sq>0)
 result=np.where(inside,plane_sq,np.inf)
 for edge in range(3):
  result=np.minimum(result,point_segment_sq(point,triangle[...,edge,:],triangle[...,(edge+1)%3,:]))
 return result

def segment_triangle_hit(start,end,triangle):
 base=triangle[...,0,:]; side_a=triangle[...,1,:]-base; side_b=triangle[...,2,:]-base
 normal=np.cross(side_a,side_b)
 initial=dot_last(start-base,normal); change=dot_last(end-start,normal)
 parameter=np.divide(-initial,change,out=np.full_like(initial,np.inf),where=change!=0)
 valid=(parameter>=0)&(parameter<=1)&(change!=0)
 point=start+np.where(valid,parameter,0)[...,None]*(end-start)
 offset=point-base
 aa=dot_last(side_a,side_a); ab=dot_last(side_a,side_b); bb=dot_last(side_b,side_b)
 pa=dot_last(offset,side_a); pb=dot_last(offset,side_b); denom=aa*bb-ab*ab
 coord_a=np.divide(bb*pa-ab*pb,denom,out=np.zeros_like(pa),where=denom>0)
 coord_b=np.divide(aa*pb-ab*pa,denom,out=np.zeros_like(pb),where=denom>0)
 return valid&(denom>0)&(coord_a>=0)&(coord_b>=0)&(coord_a+coord_b<=1)

def triangle_surface_distance(triangles_a,triangles_b):
 origin=triangles_a[0,0].copy()
 first=(triangles_a-origin)[:,None,:,:]
 second=(triangles_b-origin)[None,:,:,:]
 distance_sq=np.full((len(triangles_a),len(triangles_b)),np.inf)
 hits=np.zeros(distance_sq.shape,dtype=bool)
 for vertex in range(3):
  distance_sq=np.minimum(distance_sq,point_triangle_sq(first[...,vertex,:],second))
  distance_sq=np.minimum(distance_sq,point_triangle_sq(second[...,vertex,:],first))
  hits|=segment_triangle_hit(first[...,vertex,:],first[...,(vertex+1)%3,:],second)
  hits|=segment_triangle_hit(second[...,vertex,:],second[...,(vertex+1)%3,:],first)
 for edge_a in range(3):
  start_a=first[...,edge_a,:]; direction_a=first[...,(edge_a+1)%3,:]-start_a
  for edge_b in range(3):
   start_b=second[...,edge_b,:]; direction_b=second[...,(edge_b+1)%3,:]-start_b
   offset=start_a-start_b
   aa=dot_last(direction_a,direction_a); bb=dot_last(direction_b,direction_b); ab=dot_last(direction_a,direction_b)
   ao=dot_last(direction_a,offset); bo=dot_last(direction_b,offset)
   denom=aa*bb-ab*ab
   param_a=np.divide(ab*bo-bb*ao,denom,out=np.zeros_like(ao),where=denom>1e-14*aa*bb)
   param_b=np.divide(aa*bo-ab*ao,denom,out=np.zeros_like(bo),where=denom>1e-14*aa*bb)
   valid=(denom>1e-14*aa*bb)&(param_a>=0)&(param_a<=1)&(param_b>=0)&(param_b<=1)
   residual=offset+param_a[...,None]*direction_a-param_b[...,None]*direction_b
   distance_sq=np.minimum(distance_sq,np.where(valid,dot_last(residual,residual),np.inf))
 distance_sq=np.where(hits,0,distance_sq)
 best=np.unravel_index(np.argmin(distance_sq),distance_sq.shape)
 return float(np.sqrt(distance_sq[best])),bool(np.any(hits)),tuple(int(value) for value in best)

start_time=time.time()
results=[]
for first,second,lower in candidates:
 distance,hit,triangle_indices=triangle_surface_distance(geom[first]['triangles'],geom[second]['triangles'])
 results.append((first,second,distance,hit,triangle_indices))
qualifying=[result for result in results if result[2]<=2.0]
print('ELAPSED',time.time()-start_time,'QUALIFYING',len(qualifying),'CANDIDATES_REJECTED',len(results)-len(qualifying))
for first,second,distance,hit,triangle_indices in qualifying:
 print(geom[first]['name'],geom[second]['name'],format(distance,'.12f'),'intersection',hit,'triangles',triangle_indices)
print('NEAREST_REJECTED',sorted([(geom[first]['name'],geom[second]['name'],distance) for first,second,distance,hit,triangle_indices in results if distance>2],key=lambda row:row[2])[:12])
print('DEGENERATE_TRIANGLES',[(item['name'],int(np.sum(np.linalg.norm(np.cross(item['triangles'][:,1]-item['triangles'][:,0],item['triangles'][:,2]-item['triangles'][:,0]),axis=1)==0))) for item in geom])