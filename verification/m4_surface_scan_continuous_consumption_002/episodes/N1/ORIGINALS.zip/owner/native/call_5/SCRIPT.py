for obj,item in zip(objs,geom):
 evaluated=obj.evaluated_get(depsgraph)
 mesh=evaluated.data
 local=np.array([tuple(vertex.co) for vertex in mesh.vertices],dtype=np.float64)
 matrix=np.array(evaluated.matrix_world,dtype=np.float64)
 world=(local@matrix[:3,:3].T+matrix[:3,3])*unit_mm
 indices=np.array([tuple(triangle.vertices) for triangle in mesh.loop_triangles],dtype=np.int64)
 item['triangles']=world[indices]
full_results=[]
for first in range(len(geom)):
 for second in range(first+1,len(geom)):
  distance,hit,triangle_indices=triangle_surface_distance(geom[first]['triangles'],geom[second]['triangles'])
  full_results.append((first,second,distance,hit,triangle_indices))
qualifying=[result for result in full_results if result[2]<=2.0]
print('TOTAL_OBJECTS',len(geom),'TOTAL_TRIANGLES',sum(len(item['triangles']) for item in geom),'EXHAUSTIVE_PAIRS',len(full_results),'WITHIN_2MM',len(qualifying),'ZERO',sum(result[2]==0 for result in qualifying))
for first,second,distance,hit,triangle_indices in qualifying:
 print(geom[first]['name'],geom[second]['name'],f'{distance:.9f}')
print('MIN_EXCLUDED',min(result[2] for result in full_results if result[2]>2))
print('FINITE',all(np.isfinite(result[2]) for result in full_results))
print('CHANGED_MEMBERSHIP',set((row[0],row[1]) for row in qualifying)^set((row[0],row[1]) for row in results if row[2]<=2))
print('INSTANCES',[(instance.object.name,instance.is_instance) for instance in depsgraph.object_instances if instance.is_instance])