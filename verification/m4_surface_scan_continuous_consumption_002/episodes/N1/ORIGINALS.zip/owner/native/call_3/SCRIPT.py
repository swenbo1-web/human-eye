depsgraph=bpy.context.evaluated_depsgraph_get()
geom=[]
unit_mm=float(scene.unit_settings.scale_length)*1000.0
for obj in objs:
 evaluated=obj.evaluated_get(depsgraph)
 mesh=evaluated.data
 mesh.calc_loop_triangles()
 vertices=np.array([tuple(evaluated.matrix_world @ vertex.co) for vertex in mesh.vertices],dtype=np.float64)*unit_mm
 indices=np.array([tuple(triangle.vertices) for triangle in mesh.loop_triangles],dtype=np.int64).reshape(-1,3)
 triangles=vertices[indices]
 geom.append({'name':obj.name,'triangles':triangles,'min':triangles.min(axis=(0,1)) if len(triangles) else None,'max':triangles.max(axis=(0,1)) if len(triangles) else None})
print('TRIANGLES',[(item['name'],len(item['triangles'])) for item in geom])
candidates=[]; excluded=[]
for first in range(len(geom)):
 for second in range(first+1,len(geom)):
  aa,bb=geom[first],geom[second]
  if aa['min'] is None or bb['min'] is None: continue
  separation=np.maximum(0,np.maximum(aa['min']-bb['max'],bb['min']-aa['max']))
  lower=float(np.linalg.norm(separation))
  (candidates if lower<=2.0+1e-10 else excluded).append((first,second,lower))
print('CANDIDATE_COUNT',len(candidates),'EXCLUDED_AABB',len(excluded))
print('CANDIDATES',[(geom[first]['name'],geom[second]['name'],lower) for first,second,lower in candidates])
print('BOUNDS_MM',[(item['name'],item['min'].tolist(),item['max'].tolist()) for item in geom])