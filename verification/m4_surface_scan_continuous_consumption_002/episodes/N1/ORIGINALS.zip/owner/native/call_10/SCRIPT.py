import bpy, numpy as np
scene=bpy.context.scene
depsgraph=bpy.context.evaluated_depsgraph_get()
objs=[obj for obj in scene.objects if obj.type=='MESH']
unit_mm=float(scene.unit_settings.scale_length)*1000.0
geom=[]
for obj in objs:
 evaluated=obj.evaluated_get(depsgraph)
 mesh=evaluated.data
 mesh.calc_loop_triangles()
 local=np.array([tuple(vertex.co) for vertex in mesh.vertices],dtype=np.float64).reshape(-1,3)
 matrix=np.array(evaluated.matrix_world,dtype=np.float64)
 world=(local@matrix[:3,:3].T+matrix[:3,3])*unit_mm
 indices=np.array([tuple(triangle.vertices) for triangle in mesh.loop_triangles],dtype=np.int64).reshape(-1,3)
 geom.append({'name':obj.name,'triangles':world[indices]})
full_results=[]; incomplete=[]
for first in range(len(geom)):
 for second in range(first+1,len(geom)):
  if not len(geom[first]['triangles']) or not len(geom[second]['triangles']):
   incomplete.append((geom[first]['name'],geom[second]['name'],'empty triangle surface'))
   continue
  distance,hit,triangle_indices=triangle_surface_distance(geom[first]['triangles'],geom[second]['triangles'])
  full_results.append((first,second,distance,hit,triangle_indices))
qualifying=[result for result in full_results if result[2]<=2.0]
print('UNITS',scene.unit_settings.system,scene.unit_settings.scale_length)
print('TOTAL_OBJECTS',len(geom),'TOTAL_TRIANGLES',sum(len(item['triangles']) for item in geom),'EXHAUSTIVE_PAIRS',len(full_results),'WITHIN_2MM',len(qualifying),'ZERO',sum(result[2]==0 for result in qualifying))
print('OBJECTS',[(item['name'],len(item['triangles'])) for item in geom])
for first,second,distance,hit,triangle_indices in qualifying:
 print(geom[first]['name'],geom[second]['name'],f'{distance:.9f}','hit',hit)
print('INCOMPLETE',incomplete)
print('MIN_EXCLUDED',min((result[2] for result in full_results if result[2]>2),default=None))
print('FINITE',all(np.isfinite(result[2]) for result in full_results))
print('DEGENERATE',[(item['name'],int(np.sum(np.linalg.norm(np.cross(item['triangles'][:,1]-item['triangles'][:,0],item['triangles'][:,2]-item['triangles'][:,0]),axis=1)==0))) for item in geom if len(item['triangles'])])
print('INSTANCES',[(instance.object.name,instance.is_instance) for instance in depsgraph.object_instances if instance.is_instance])