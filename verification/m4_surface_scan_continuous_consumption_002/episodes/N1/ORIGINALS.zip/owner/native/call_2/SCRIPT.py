import bpy, numpy as np, math, time
from mathutils import Vector
from mathutils.bvhtree import BVHTree
scene=bpy.context.scene
print('UNITS',scene.unit_settings.system,scene.unit_settings.scale_length)
objs=[o for o in scene.objects if o.type=='MESH']
print('MESH_COUNT',len(objs))
for o in objs:
 print(repr(o.name),len(o.data.vertices),len(o.data.polygons),'modifiers',[(m.type,m.show_viewport) for m in o.modifiers])