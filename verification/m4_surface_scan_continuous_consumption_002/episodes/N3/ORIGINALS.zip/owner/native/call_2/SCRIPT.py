import bpy, math, time
import numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree
sc=bpy.context.scene
print('UNITS',sc.unit_settings.system,sc.unit_settings.scale_length)
print('OBJECTS',[(o.name,o.type,o.hide_viewport,o.hide_render) for o in sc.objects])
print('INSTANCES',len(list(bpy.context.evaluated_depsgraph_get().object_instances)))