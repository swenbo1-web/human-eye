deps=bpy.context.evaluated_depsgraph_get()
meshes=[]
for obj in sc.objects:
    if obj.type!='MESH': continue
    ev=obj.evaluated_get(deps)
    mesh=ev.to_mesh()
    mesh.calc_loop_triangles()
    coords=np.array([tuple(v.co) for v in mesh.vertices],dtype=np.float64)
    matrix=np.array(ev.matrix_world,dtype=np.float64)
    coords=coords@matrix[:3,:3].T+matrix[:3,3]
    indices=np.array([tuple(t.vertices) for t in mesh.loop_triangles],dtype=np.int64).reshape(-1,3)
    triangles=coords[indices]
    meshes.append(dict(name=obj.name,tri=triangles,lo=triangles.min(axis=(0,1)) if len(triangles) else None,hi=triangles.max(axis=(0,1)) if len(triangles) else None))
    ev.to_mesh_clear()
print('MESHES',[(m['name'],len(m['tri']),m['lo'].tolist() if m['lo'] is not None else None,m['hi'].tolist() if m['hi'] is not None else None) for m in meshes])
threshold=.002/sc.unit_settings.scale_length
candidates=[]
for i,a in enumerate(meshes):
    for j in range(i+1,len(meshes)):
        b=meshes[j]
        if a['lo'] is None or b['lo'] is None: continue
        delta=np.maximum(0,np.maximum(a['lo']-b['hi'],b['lo']-a['hi']))
        bound=np.linalg.norm(delta)
        if bound<=threshold: candidates.append((i,j,float(bound)))
print('CANDIDATES',len(candidates),[(meshes[i]['name'],meshes[j]['name'],d*1000) for i,j,d in candidates])