import bpy, numpy as np
sc=bpy.context.scene
deps=bpy.context.evaluated_depsgraph_get()
meshes=[]
for obj in sc.objects:
    if obj.type!='MESH': continue
    ev=obj.evaluated_get(deps)
    mesh=ev.to_mesh()
    mesh.calc_loop_triangles()
    coords=np.array([tuple(v.co) for v in mesh.vertices],dtype=np.float64).reshape(-1,3)
    matrix=np.array(ev.matrix_world,dtype=np.float64)
    coords=coords@matrix[:3,:3].T+matrix[:3,3]
    indices=np.array([tuple(t.vertices) for t in mesh.loop_triangles],dtype=np.int64).reshape(-1,3)
    meshes.append(dict(name=obj.name,tri=coords[indices]))
    ev.to_mesh_clear()
print('UNITS',sc.unit_settings.system,sc.unit_settings.scale_length)
print('MESHES',[(m['name'],len(m['tri'])) for m in meshes])
print('EXTRA_INSTANCES',[(inst.object.name,inst.is_instance) for inst in deps.object_instances if inst.is_instance])
print('FUNCTION_AVAILABLE','tri_pair_distances' in globals())
print('FINITE',all(np.isfinite(m['tri']).all() for m in meshes))
print('EMPTY',[m['name'] for m in meshes if not len(m['tri'])])
print('DEGENERATE',[(m['name'],int(np.sum(np.linalg.norm(np.cross(m['tri'][:,1]-m['tri'][:,0],m['tri'][:,2]-m['tri'][:,0]),axis=1)==0))) for m in meshes if len(m['tri'])])
results=[]
for i,first in enumerate(meshes):
    for j in range(i+1,len(meshes)):
        second=meshes[j]
        if not len(first['tri']) or not len(second['tri']): continue
        distance=float(tri_pair_distances(first['tri'],second['tri']).min())
        results.append((i,j,distance*1000*sc.unit_settings.scale_length))
qualifying=[(i,j,d) for i,j,d in results if d<=2]
zero=[(i,j,d) for i,j,d in qualifying if d==0]
positive=[(i,j,d) for i,j,d in qualifying if d>0]
print('COUNTS',len(meshes),sum(len(m['tri']) for m in meshes),len(results),len(qualifying),len(zero),len(positive))
print('ZERO_GROUPS')
for i in range(len(meshes)):
    partners=[meshes[j]['name'] for a,j,d in zero if a==i]
    if partners: print(meshes[i]['name'],', '.join(partners))
print('POSITIVE')
for i,j,d in positive: print(meshes[i]['name'],meshes[j]['name'],f'{d:.9f}')
print('NEAREST_THRESHOLD',sorted([(abs(d-2),meshes[i]['name'],meshes[j]['name'],d) for i,j,d in results])[:4])