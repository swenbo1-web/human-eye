qualifying=[(i,j,d*1000*sc.unit_settings.scale_length) for i,j,d in results if d<=threshold]
zero=[(i,j,d) for i,j,d in qualifying if d==0]
positive=[(i,j,d) for i,j,d in qualifying if d>0]
print('COUNTS objects triangles allpairs candidates excluded_aabb excluded_exact included zero positive',len(meshes),sum(len(m['tri']) for m in meshes),len(meshes)*(len(meshes)-1)//2,len(candidates),276-len(candidates),len(results)-len(qualifying),len(qualifying),len(zero),len(positive))
print('ZERO_GROUPS')
for i in range(len(meshes)):
    partners=[meshes[j]['name'] for a,j,d in zero if a==i]
    if partners: print(meshes[i]['name'],', '.join(partners))
print('POSITIVE')
for i,j,d in positive: print(meshes[i]['name'],meshes[j]['name'],f'{d:.6f}')
print('THRESHOLD_NEAREST',sorted([(abs(d*1000-2),meshes[i]['name'],meshes[j]['name'],d*1000) for i,j,d in results])[:3])
# Independently check triangle intersection with Blender BVH for positive-distance pairs.
for m in meshes:
    vertices=m['tri'].reshape(-1,3)
    m['bvh']=BVHTree.FromPolygons([Vector(v) for v in vertices],[(k,k+1,k+2) for k in range(0,len(vertices),3)],all_triangles=True,epsilon=0)
print('BVH_INTERSECTION_MISMATCH',[(meshes[i]['name'],meshes[j]['name'],d*1000) for i,j,d in results if bool(meshes[i]['bvh'].overlap(meshes[j]['bvh'])) and d>1e-10])
print('FINITE',all(np.isfinite(m['tri']).all() for m in meshes))