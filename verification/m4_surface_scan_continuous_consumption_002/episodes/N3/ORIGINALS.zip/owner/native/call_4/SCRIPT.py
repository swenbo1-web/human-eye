def dotvec(a,b): return np.einsum('...i,...i->...',a,b)
def tri_pair_distances(first,second):
    count=len(first)*len(second)
    aa=np.repeat(first,len(second),axis=0)
    bb=np.tile(second,(len(first),1,1))
    best=np.full(count,np.inf)
    def point_faces(points,faces):
        origin=faces[:,0]; edge_u=faces[:,1]-origin; edge_v=faces[:,2]-origin
        normal=np.cross(edge_u,edge_v); norm2=dotvec(normal,normal)
        offset=points-origin
        signed=dotvec(offset,normal)
        projection=points-normal*np.divide(signed,norm2,out=np.zeros_like(signed),where=norm2>0)[:,None]
        return projection,signed,norm2
    def inside(points,faces):
        edge_u=faces[:,1]-faces[:,0]; edge_v=faces[:,2]-faces[:,0]; offset=points-faces[:,0]
        normal=np.cross(edge_u,edge_v); denom=dotvec(normal,normal)
        bary_u=np.divide(dotvec(np.cross(offset,edge_v),normal),denom,out=np.full(count,np.nan),where=denom>0)
        bary_v=np.divide(dotvec(np.cross(edge_u,offset),normal),denom,out=np.full(count,np.nan),where=denom>0)
        return (bary_u>=-1e-13)&(bary_v>=-1e-13)&(bary_u+bary_v<=1+1e-13)
    for source,target in ((aa,bb),(bb,aa)):
        for vertex in range(3):
            projected,signed,norm2=point_faces(source[:,vertex],target)
            dist2=np.divide(signed*signed,norm2,out=np.full(count,np.inf),where=norm2>0)
            best=np.minimum(best,np.where(inside(projected,target),dist2,np.inf))
        normal=np.cross(target[:,1]-target[:,0],target[:,2]-target[:,0])
        for edge in range(3):
            start=source[:,edge]; end=source[:,(edge+1)%3]; direction=end-start
            denom=dotvec(direction,normal)
            param=np.divide(dotvec(target[:,0]-start,normal),denom,out=np.full(count,np.nan),where=denom!=0)
            hit=start+np.nan_to_num(param)[:,None]*direction
            intersects=(param>=0)&(param<=1)&inside(hit,target)
            best=np.where(intersects,0,best)
    for edge_a in range(3):
        start_a=aa[:,edge_a]; direction_a=aa[:,(edge_a+1)%3]-start_a
        for edge_b in range(3):
            start_b=bb[:,edge_b]; direction_b=bb[:,(edge_b+1)%3]-start_b
            offset=start_a-start_b
            length_a=dotvec(direction_a,direction_a); length_b=dotvec(direction_b,direction_b)
            mixed=dotvec(direction_a,direction_b); offset_a=dotvec(direction_a,offset); offset_b=dotvec(direction_b,offset)
            denom=dotvec(np.cross(direction_a,direction_b),np.cross(direction_a,direction_b))
            param_a=np.divide(mixed*offset_b-length_b*offset_a,denom,out=np.full(count,np.nan),where=denom>0)
            param_b=np.divide(length_a*offset_b-mixed*offset_a,denom,out=np.full(count,np.nan),where=denom>0)
            delta=offset+np.nan_to_num(param_a)[:,None]*direction_a-np.nan_to_num(param_b)[:,None]*direction_b
            best=np.minimum(best,np.where((param_a>=0)&(param_a<=1)&(param_b>=0)&(param_b<=1),dotvec(delta,delta),np.inf))
            for endpoint in (0,1):
                point=start_a+endpoint*direction_a
                param=np.clip(np.divide(dotvec(point-start_b,direction_b),length_b,out=np.zeros(count),where=length_b>0),0,1)
                delta=point-start_b-param[:,None]*direction_b
                best=np.minimum(best,dotvec(delta,delta))
                point=start_b+endpoint*direction_b
                param=np.clip(np.divide(dotvec(point-start_a,direction_a),length_a,out=np.zeros(count),where=length_a>0),0,1)
                delta=point-start_a-param[:,None]*direction_a
                best=np.minimum(best,dotvec(delta,delta))
    return np.sqrt(best).reshape(len(first),len(second))
start_time=time.time()
results=[]
for i,j,bound in candidates:
    distances=tri_pair_distances(meshes[i]['tri'],meshes[j]['tri'])
    distance=float(distances.min())
    results.append((i,j,distance))
print('SECONDS',time.time()-start_time)
print('RESULTS_MM',[(meshes[i]['name'],meshes[j]['name'],d*1000*sc.unit_settings.scale_length) for i,j,d in results])
print('DEGENERATE',[(m['name'],int(np.sum(np.linalg.norm(np.cross(m['tri'][:,1]-m['tri'][:,0],m['tri'][:,2]-m['tri'][:,0]),axis=1)==0))) for m in meshes])