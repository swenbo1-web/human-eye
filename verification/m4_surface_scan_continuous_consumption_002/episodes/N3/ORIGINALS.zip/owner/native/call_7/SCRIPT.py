threshold=.002/sc.unit_settings.scale_length
results=[]
for i,first in enumerate(meshes):
    for j in range(i+1,len(meshes)):
        second=meshes[j]
        if first['lo'] is None or second['lo'] is None: continue
        distance=float(tri_pair_distances(first['tri'],second['tri']).min())
        results.append((i,j,distance*1000*sc.unit_settings.scale_length))
qualifying=[(i,j,d) for i,j,d in results if d<=2]
zero=[(i,j,d) for i,j,d in qualifying if d==0]
positive=[(i,j,d) for i,j,d in qualifying if d>0]
print('COUNTS',len(meshes),sum(len(m['tri']) for m in meshes),len(results),len(qualifying),len(zero),len(positive))
print('ZERO_GROUPS')
for i in range(len(meshes)):
    partners=[meshes[j]['name'] for a,j,d in zero if a==i]
    if partners: print(meshes[i]['name'],', '.join(partners))
print('POSITIVE')
for i,j,d in positive: print(meshes[i]['name'],meshes[j]['name'],f'{d:.9f}')
print('NEAREST_THRESHOLD',sorted([(abs(d-2),meshes[i]['name'],meshes[j]['name'],d) for i,j,d in results])[:4])