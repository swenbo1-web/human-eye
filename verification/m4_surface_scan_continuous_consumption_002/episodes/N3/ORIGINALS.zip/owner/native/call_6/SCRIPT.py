import bpy, numpy as np, time
sc=bpy.context.scene
deps=bpy.context.evaluated_depsgraph_get()
meshes=[]
for obj in sc.objects:
    if obj.type!='MESH': continue
    ev=obj.evaluated_get(deps)
    mesh=ev.to_mesh()
    mesh.calc_loop_triangles()
    coords=np.array([tuple(v.co) for v in mesh.vertices],dtype=np.float64).reshape(-1,3)
    matrix=np.array(ev.matrix_world,dtype=np.float64)
    coords=coords@matrix[:3,:3].T+matrix[:3,3]
    indices=np.array([tuple(t.vertices) for t in mesh.loop_triangles],dtype=np.int64).reshape(-1,3)
    triangles=coords[indices]
    meshes.append(dict(name=obj.name,tri=triangles,lo=triangles.min(axis=(0,1)) if len(triangles) else None,hi=triangles.max(axis=(0,1)) if len(triangles) else None))
    ev.to_mesh_clear()
print('UNITS',sc.unit_settings.system,sc.unit_settings.scale_length)
print('CURRENT_MESHES',[(m['name'],len(m['tri'])) for m in meshes])
print('INSTANCES',[(inst.object.name,inst.is_instance) for inst in deps.object_instances])
print('FUNCTION_AVAILABLE', 'tri_pair_distances' in globals())
print('FINITE',all(np.isfinite(m['tri']).all() for m in meshes))
print('DEGENERATE',[(m['name'],int(np.sum(np.linalg.norm(np.cross(m['tri'][:,1]-m['tri'][:,0],m['tri'][:,2]-m['tri'][:,0]),axis=1)==0))) for m in meshes])