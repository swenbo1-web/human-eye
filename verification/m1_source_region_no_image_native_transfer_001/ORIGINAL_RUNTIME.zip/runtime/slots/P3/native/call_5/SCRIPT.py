validate_code("import bpy\nobj = bpy.data.objects['M08']\nevaluated = obj.evaluated_get(bpy.context.evaluated_depsgraph_get())\nmesh = evaluated.to_mesh()\nmesh.calc_loop_triangles()\nprint({'object': obj.name, 'current_evaluated_triangle_count': len(mesh.loop_triangles)})\nevaluated.to_mesh_clear()")
_consumer_scope_state['running'] = True
try:
    exec(compile("import bpy\nobj = bpy.data.objects['M08']\nevaluated = obj.evaluated_get(bpy.context.evaluated_depsgraph_get())\nmesh = evaluated.to_mesh()\nmesh.calc_loop_triangles()\nprint({'object': obj.name, 'current_evaluated_triangle_count': len(mesh.loop_triangles)})\nevaluated.to_mesh_clear()", '<ordinary-blender-task>', 'exec'), _ordinary_blender_namespace)
finally:
    _consumer_scope_state['running'] = False
