import json as _json, contextlib as _cl, io as _io
_request = _json.loads('{"id":"9b30120ecf764064a23e7e8d2ef161e6","command":"capture_task","params":{"selectors":[{"name":"M08"},{"name":"M02"}]}}')
try:
    import sys as _sys
    _module = _sys.modules.get('_human_eye_mcp_resident_6bef073fee72074d89a6')
    if _module is None or getattr(_module, '_resident_tag', None) != '588f12a5001adb5df66b57ca8f8f2c3c20207192b6d141bd3ef8c7e01cb7d7f0': raise RuntimeError('Resident Blender host unavailable; reconnect with a new connector')
    _host = _module._mcp_resident_host
    with _cl.redirect_stdout(_io.StringIO()):
        _result = getattr(_host, 'capture_task_scene')(**_request['params'])
    _result = _host.capture_delta(_result, _json.loads('{"instance_id":"6f2e53db79364acfa21e738aedd9dd9a","epoch":1,"resources":{"mesh:(\'uid\', 165)":1,"mesh:(\'uid\', 178)":2,"mesh:(\'uid\', 175)":3,"mesh:(\'uid\', 161)":4,"mesh:(\'uid\', 168)":5,"mesh:(\'uid\', 179)":6,"mesh:(\'uid\', 170)":7,"mesh:(\'uid\', 177)":8,"mesh:(\'uid\', 171)":9,"mesh:(\'uid\', 176)":10,"mesh:(\'uid\', 169)":11,"mesh:(\'uid\', 173)":12,"mesh:(\'uid\', 167)":13,"mesh:(\'uid\', 174)":14,"mesh:(\'uid\', 163)":15,"mesh:(\'uid\', 164)":16,"mesh:(\'uid\', 162)":17,"mesh:(\'uid\', 172)":18,"mesh:(\'uid\', 160)":19,"mesh:(\'uid\', 166)":20,"mesh:(\'uid\', 180)":21}}'))
    _envelope = {'protocol_version': '1.0', 'id': _request['id'], 'result': _result}
except Exception as _exc:
    _envelope = {'protocol_version': '1.0', 'id': _request['id'], 'error': {'type': type(_exc).__name__, 'message': str(_exc)[:2000], 'mutation_uncertain': _request['command'] == 'apply'}}
print('HUMAN_EYE_BLENDER_MCP:' + _json.dumps(_envelope, ensure_ascii=True, allow_nan=False, separators=(',', ':')))