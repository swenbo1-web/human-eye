validate_code("import bpy\nobj = bpy.data.objects['M19'].evaluated_get(bpy.context.evaluated_depsgraph_get())\nmesh = obj.to_mesh()\nmesh.calc_loop_triangles()\nprint({'M19_current_evaluated_triangle_count': len(mesh.loop_triangles)})\nobj.to_mesh_clear()")
_consumer_scope_state['running'] = True
try:
    exec(compile("import bpy\nobj = bpy.data.objects['M19'].evaluated_get(bpy.context.evaluated_depsgraph_get())\nmesh = obj.to_mesh()\nmesh.calc_loop_triangles()\nprint({'M19_current_evaluated_triangle_count': len(mesh.loop_triangles)})\nobj.to_mesh_clear()", '<ordinary-blender-task>', 'exec'), _ordinary_blender_namespace)
finally:
    _consumer_scope_state['running'] = False
