from pathlib import Path
import sys
Path('D:\\he_m1_source_region_no_image_native_transfer_001\\offline_runtime_03\\P2_exit_probe\\STDIN.bin').write_bytes(sys.stdin.buffer.read())
print("transfer offline early exit", file=sys.stderr)
raise SystemExit(7)
