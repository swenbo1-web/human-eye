from pathlib import Path
import sys
Path('D:\\he_m1_source_region_first_packet_consumption_001_consumer_preflight_02\\A1\\STDIN.bin').write_bytes(sys.stdin.buffer.read())
raise SystemExit(7)
