import bpy,json,math
s=bpy.context.scene
meshes=[o for o in s.objects if o.type=='MESH']
f=bpy.data.objects['M4_Focal']
fv=[tuple(f.matrix_world@v.co) for v in f.data.vertices]
rows=[]
for o in meshes:
    if o==f: continue
    vs=[tuple(o.matrix_world@v.co) for v in o.data.vertices]
    verified=(len(o.data.polygons)==1 and len(o.data.polygons[0].vertices)==3 and len(vs)==3 and len(set(v[0] for v in fv))==1 and len(set(v[0] for v in vs))==1 and sorted((v[1],v[2]) for v in vs)==sorted((v[1],v[2]) for v in fv))
    rows.append({'name':o.name,'parallel_planes_and_identical_yz_hulls_verified':verified,'distance_m':abs(vs[0][0]-fv[0][0])*s.unit_settings.scale_length if verified else None})
assert all(r['parallel_planes_and_identical_yz_hulls_verified'] for r in rows)
m=min(r['distance_m'] for r in rows)
print(json.dumps({'mesh_count':len(meshes),'distances':rows,'nearest_names':[r['name'] for r in rows if r['distance_m']==m],'minimum_distance_m':m,'clearance_3mm':'met' if m>=0.003 else 'not_met','unresolved':[]},ensure_ascii=False))