import bpy,json
s=bpy.context.scene
print(json.dumps({'objects':[{'name':o.name,'matrix_world':[list(r) for r in o.matrix_world],'vertices_local':[list(v.co) for v in o.data.vertices],'vertices_world':[list(o.matrix_world@v.co) for v in o.data.vertices],'faces':[list(p.vertices) for p in o.data.polygons]} for o in s.objects if o.type=='MESH']},ensure_ascii=False))