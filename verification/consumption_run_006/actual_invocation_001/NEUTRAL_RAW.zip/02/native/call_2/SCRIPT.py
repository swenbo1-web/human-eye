import bpy, json, math
s=bpy.context.scene
data={'scene':s.name,'units':{'system':s.unit_settings.system,'scale_length':s.unit_settings.scale_length},'meshes':[]}
for o in s.objects:
    if o.type != 'MESH': continue
    o.data.calc_loop_triangles()
    data['meshes'].append({'name':o.name,'hide_viewport':o.hide_viewport,'hide_render':o.hide_render,'vertices':len(o.data.vertices),'polygons':len(o.data.polygons),'triangles':len(o.data.loop_triangles),'modifiers':[(m.name,m.type,m.show_viewport) for m in o.modifiers], 'matrix_world':[list(r) for r in o.matrix_world], 'world_vertices':[list(o.matrix_world@v.co) for v in o.data.vertices], 'triangle_indices':[list(t.vertices) for t in o.data.loop_triangles]})
print(json.dumps(data,allow_nan=False))