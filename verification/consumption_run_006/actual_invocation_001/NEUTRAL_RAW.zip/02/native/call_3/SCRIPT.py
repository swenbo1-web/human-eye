import bpy, json
s=bpy.context.scene
dg=bpy.context.evaluated_depsgraph_get()
rows=[]
for o in s.objects:
    if o.type!='MESH': continue
    e=o.evaluated_get(dg)
    me=e.to_mesh()
    try:
        me.calc_loop_triangles()
        rows.append({'name':o.name,'evaluated_world_triangles':[[list(e.matrix_world@me.vertices[i].co) for i in t.vertices] for t in me.loop_triangles]})
    finally:
        e.to_mesh_clear()
print(json.dumps({'scale_length':s.unit_settings.scale_length,'mesh_count':len(rows),'meshes':rows},allow_nan=False))