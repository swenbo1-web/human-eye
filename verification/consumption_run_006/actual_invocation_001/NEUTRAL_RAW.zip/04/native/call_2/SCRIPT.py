import bpy, json, math
_t02_meshes={}
_t02_summaries=[]
for o in bpy.context.scene.objects:
    if o.type!='MESH': continue
    m=o.matrix_world
    vs=[tuple(sum(float(m[i][j])*float(v.co[j]) for j in range(3))+float(m[i][3]) for i in range(3)) for v in o.data.vertices]
    fs=[tuple(p.vertices) for p in o.data.polygons]
    _t02_meshes[o.name]={'vertices':vs,'faces':fs}
    row={'name':o.name,'matrix_world':[list(r) for r in m],'vertices':len(vs),'faces':len(fs),'face_sizes':sorted(set(map(len,fs))),'bbox_min':[min(v[i] for v in vs) for i in range(3)],'bbox_max':[max(v[i] for v in vs) for i in range(3)],'nonfinite':sum(not all(math.isfinite(c) for c in v) for v in vs)}
    if len(vs)<=3: row['world_vertices']=vs; row['faces_indices']=fs
    _t02_summaries.append(row)
print(json.dumps(_t02_summaries,ensure_ascii=False))