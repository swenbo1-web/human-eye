import bpy, json, math
dg=bpy.context.evaluated_depsgraph_get()
rows=[]
for o in bpy.context.scene.objects:
    if o.type!='MESH': continue
    e=o.evaluated_get(dg)
    m=e.matrix_world
    vs=[tuple(sum(float(m[i][j])*float(v.co[j]) for j in range(3))+float(m[i][3]) for i in range(3)) for v in e.data.vertices]
    fs=[tuple(p.vertices) for p in e.data.polygons]
    original=_t02_meshes[o.name]
    rows.append({'name':o.name,'evaluated_matches_read':vs==original['vertices'] and fs==original['faces'],'shape_keys':o.data.shape_keys is not None,'faces':len(fs),'nonfinite':any(not all(math.isfinite(c) for c in v) for v in vs)})
f=_t02_meshes['M4_Focal']; n=_t02_meshes['M4_Near']
matching_yz=[a[1:]==b[1:] for a,b in zip(f['vertices'],n['vertices'])]
d=n['vertices'][0][0]-f['vertices'][0][0]
far_lbs={name:min(v[0] for v in mesh['vertices'])-max(v[0] for v in f['vertices']) for name,mesh in _t02_meshes.items() if name not in ['M4_Focal','M4_Near']}
print(json.dumps({'evaluated_checks':rows,'other_mesh_count':len(rows)-1,'focal_and_near_equal_yz':matching_yz,'focal_near_distance_m':d*bpy.context.scene.unit_settings.scale_length,'other_mesh_x_separation_lower_bounds_m':far_lbs,'unresolved':[]},ensure_ascii=False))