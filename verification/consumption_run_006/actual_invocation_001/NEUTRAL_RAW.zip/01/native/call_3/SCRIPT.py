import bpy,json,math
sc=bpy.context.scene
dg=bpy.context.evaluated_depsgraph_get()
out=[]
for ob in sc.objects:
    if ob.type!='MESH': continue
    eo=ob.evaluated_get(dg)
    me=eo.to_mesh()
    try:
        vv=[[float(x) for x in eo.matrix_world@v.co] for v in me.vertices]
        pp=[list(p.vertices) for p in me.polygons]
        out.append({'name':ob.name,'evaluated_world_vertices':vv,'evaluated_faces':pp,'shape_keys':ob.data.shape_keys is not None,'constraints':len(ob.constraints),'all_coordinates_finite':all(math.isfinite(x) for v in vv for x in v)})
    finally:
        eo.to_mesh_clear()
print(json.dumps({'mesh_count':len(out),'evaluated_geometry':out},ensure_ascii=False))