import bpy, json
scene=bpy.context.scene
info={'scene':scene.name,'units':{'system':scene.unit_settings.system,'scale_length':scene.unit_settings.scale_length,'length_unit':scene.unit_settings.length_unit},'objects':[{'name':o.name,'type':o.type,'hide_viewport':o.hide_viewport,'hide_render':o.hide_render,'vertices':len(o.data.vertices) if o.type=='MESH' else None,'polygons':len(o.data.polygons) if o.type=='MESH' else None,'modifiers':[{'type':m.type,'name':m.name,'show_viewport':m.show_viewport} for m in o.modifiers]} for o in scene.objects]}
print(json.dumps(info,ensure_ascii=False))