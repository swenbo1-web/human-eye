import bpy,json,math
sc=bpy.context.scene
data=[]
for o in sc.objects:
    if o.type!='MESH': continue
    me=o.data
    verts=[list(o.matrix_world@v.co) for v in me.vertices]
    faces=[list(p.vertices) for p in me.polygons]
    data.append({'name':o.name,'matrix_world':[list(row) for row in o.matrix_world],'world_vertices':verts,'faces':faces,'finite':all(math.isfinite(x) for v in verts for x in v)})
print(json.dumps({'meshes':data,'instances':[{'name':i.object.name,'is_instance':i.is_instance} for i in bpy.context.evaluated_depsgraph_get().object_instances]},ensure_ascii=False))