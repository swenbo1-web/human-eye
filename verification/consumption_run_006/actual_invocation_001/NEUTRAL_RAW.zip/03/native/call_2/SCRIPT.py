import bpy, json
scene=bpy.context.scene
out={'scene':scene.name,'unit_system':scene.unit_settings.system,'scale_length':scene.unit_settings.scale_length,'objects':[]}
for o in scene.objects:
    if o.type=='MESH':
        out['objects'].append({'name':o.name,'vertices':len(o.data.vertices),'polygons':len(o.data.polygons),'modifiers':[{'name':m.name,'type':m.type,'show_viewport':m.show_viewport} for m in o.modifiers],'matrix_world':[list(row) for row in o.matrix_world],'vertices_local':[list(v.co) for v in o.data.vertices],'faces':[list(p.vertices) for p in o.data.polygons]})
print(json.dumps(out,allow_nan=False))