import bpy, json, math
scene=bpy.context.scene
depsgraph=bpy.context.evaluated_depsgraph_get()
result={'unit_system':scene.unit_settings.system,'scale_length':scene.unit_settings.scale_length,'objects':[]}
for obj in scene.objects:
    if obj.type!='MESH':
        continue
    ev=obj.evaluated_get(depsgraph)
    me=ev.to_mesh()
    try:
        me.calc_loop_triangles()
        mat=ev.matrix_world
        coords=[list(mat @ v.co) for v in me.vertices]
        tris=[list(t.vertices) for t in me.loop_triangles]
        finite=all(math.isfinite(x) for p in coords for x in p)
        result['objects'].append({'name':obj.name,'vertices':coords,'triangles':tris,'finite':finite,'modifiers':[m.type for m in obj.modifiers]})
    finally:
        ev.to_mesh_clear()
print(json.dumps(result,allow_nan=False))