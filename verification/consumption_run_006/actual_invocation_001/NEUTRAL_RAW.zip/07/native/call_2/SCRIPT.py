import bpy, json
s=bpy.context.scene
out={'scene':s.name,'unit_system':s.unit_settings.system,'scale_length':s.unit_settings.scale_length,'objects':[]}
for o in s.objects:
    item={'name':o.name,'type':o.type}
    if o.type=='MESH':
        mesh=o.data
        mesh.calc_loop_triangles()
        item.update({'vertices_world':[list(o.matrix_world @ v.co) for v in mesh.vertices], 'triangles':[list(t.vertices) for t in mesh.loop_triangles], 'polygons':[list(p.vertices) for p in mesh.polygons], 'modifiers':[{'name':m.name,'type':m.type,'show_viewport':m.show_viewport} for m in o.modifiers], 'hidden':o.hide_get()})
    out['objects'].append(item)
print(json.dumps(out,ensure_ascii=False))