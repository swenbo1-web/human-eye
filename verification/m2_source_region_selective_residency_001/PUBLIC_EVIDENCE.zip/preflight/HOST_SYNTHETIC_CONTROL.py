from pathlib import Path
from time import perf_counter_ns
from types import SimpleNamespace as NS
import sys
import unittest
sys.path.insert(0,str(Path.cwd()))
from verification.test_m4_capture_001 import fixture,m

m._READONLY_LOADED_HOST_SHA256='a'*64
host,objects=fixture((0., 2., 100.))
host.bpy.app.handlers=NS(depsgraph_update_post=[],undo_post=[],redo_post=[],load_post=[])
for obj in objects:
    obj.hidden=obj is objects[1]
    obj.visible_get=lambda view_layer, o=obj:not o.hidden
    obj.hide_get=lambda view_layer, o=obj:o.hidden
first={'min':[0.,0.,0.],'max':[0.,1.,1.]}
other={'min':[-0.,0.,0.],'max':[0.,1.,1.]}
def call(box=first,known=None,maxbytes=10**6):
    return host.capture_source_region_pair({'name':'O0'},{'name':'O1'},box,
        perf_counter_ns()+5*10**9,maxbytes,known)
def assert_mode(value,mode,exp,scan,sends):
    item=value['work']
    assert (item['mode'],item['to_mesh'],item['box_triangles_scanned'],item['transmitted_triangles'])==(mode,exp,scan,sends),item
    assert value['host_source_sha256']=='a'*64
    if value['capture'] is not None:
        assert value['capture']['work']==item and value['capture']['stages']==value['stages']
    else:
        assert 'mesh_expansion' not in value['stages'] and 'selection_and_compaction' not in value['stages']
    assert not host._residency.captures and not host._residency.wire

base=call()
assert_mode(base,'resident_capture',2,1,2)
assert base['capture']['binding']['reference']['name']=='O1'
assert base['work']['retained_resources']==2 and base['work']['retained_compact_leases']==1
hit=call(known=base['lease'])
assert hit['capture'] is None and hit['lease']==base['lease']
assert_mode(hit,'lease_hit',0,0,0)
next_box=call(other,hit['lease'])
assert_mode(next_box,'resident_capture',0,1,2)
assert next_box['lease']['selection_sha256']!=hit['lease']['selection_sha256']
stale=call(known=hit['lease'])
assert_mode(stale,'resident_capture',0,1,2)
objects[1].hidden=False
after_display=call(known=stale['lease'])
assert_mode(after_display,'resident_capture',0,1,2)
assert after_display['lease']['selection_sha256']!=stale['lease']['selection_sha256']
objects[0].matrix_world[0][3]=-0.
after_zero=call(known=after_display['lease'])
assert_mode(after_zero,'uncached_capture',2,1,2)
assert after_zero['work']['fallback_reason']=='signed_pose_mismatch' and after_zero['lease'] is None
objects[0].matrix_world[0][3]=0.
recovered=call()
assert_mode(recovered,'resident_capture',0,1,2)
key=host._residency_module.identity(objects[1])
host._residency.resources.pop(key)
lost=call(known=recovered['lease'])
assert_mode(lost,'uncached_capture',2,1,2)
assert lost['work']['fallback_reason']=='retained_resource_unavailable' and lost['lease'] is None
rebuilt=call()
assert_mode(rebuilt,'resident_capture',1,1,2)
objects[0].data.vertices[0].co=(0., .25, .25)
for changed in host.bpy.app.handlers.depsgraph_update_post:
    changed(host.scene,NS(updates=[NS(id=objects[0].data,is_updated_geometry=True)]))
dirty=call(known=rebuilt['lease'])
assert_mode(dirty,'uncached_capture',2,1,2)
assert dirty['capture']['region']['vertices'][0]==[0.,.25,.25]
uncertified=call()
assert_mode(uncertified,'resident_capture',1,1,2)
host.bpy.app.handlers.undo_post.clear()
unsafe=call(known=uncertified['lease'])
assert_mode(unsafe,'uncached_capture',2,1,2)
assert unsafe['work']['fallback_reason']=='residency_invalidation_unavailable'
assert objects[2].mesh_calls==0
print('host-only real code through synthetic Blender API: cold, lease, box sign, stale, display, pose sign, eviction, geometry invalidation and missing handler passed')
suite=unittest.TestLoader().loadTestsFromName('verification.test_blender_host_contracts')
assert unittest.TextTestRunner(verbosity=1).run(suite).wasSuccessful()
import json
fields=('mode','to_mesh','triangulations','world_transforms','world_vertices_transformed','box_vertices_scanned',
        'box_triangles_scanned','transmitted_vertices','transmitted_triangles','retained_resources',
        'retained_compact_leases','private_cache_retained_objects','fallback_reason')
controls={'cold':base,'same_box_confirm':hit,'negative_zero_box':next_box,'stale':stale,'display_change':after_display,
          'negative_zero_pose':after_zero,'resource_eviction':lost,'rebuild_after_eviction':rebuilt,
          'dirty_data':dirty,'handler_missing':unsafe}
print(json.dumps({name:{key:result['work'][key] for key in fields} for name,result in controls.items()},sort_keys=True))
