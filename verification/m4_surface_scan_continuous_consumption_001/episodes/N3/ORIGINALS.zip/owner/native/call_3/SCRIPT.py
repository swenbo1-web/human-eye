depsgraph=bpy.context.evaluated_depsgraph_get()
mm_scale=1000.0*scene.unit_settings.scale_length
meshes=[]
for obj in scene.objects:
    if obj.type!='MESH': continue
    evaluated=obj.evaluated_get(depsgraph)
    mesh=evaluated.to_mesh()
    try:
        mesh.calc_loop_triangles()
        coords=np.array([tuple(evaluated.matrix_world @ vertex.co) for vertex in mesh.vertices],dtype=np.float64).reshape(-1,3)*mm_scale
        indices=np.array([tuple(triangle.vertices) for triangle in mesh.loop_triangles],dtype=np.int64).reshape(-1,3)
        triangles=coords[indices]
        meshes.append({'name':obj.name,'tri':triangles,'lo':triangles.min(axis=(0,1)) if len(triangles) else None,'hi':triangles.max(axis=(0,1)) if len(triangles) else None})
    finally:
        evaluated.to_mesh_clear()
print('evaluated_meshes',[(entry['name'],len(entry['tri'])) for entry in meshes])
print('bounds_mm',[(entry['name'],entry['lo'].tolist() if entry['lo'] is not None else None,entry['hi'].tolist() if entry['hi'] is not None else None) for entry in meshes])
print('finite',all(np.isfinite(entry['tri']).all() for entry in meshes))