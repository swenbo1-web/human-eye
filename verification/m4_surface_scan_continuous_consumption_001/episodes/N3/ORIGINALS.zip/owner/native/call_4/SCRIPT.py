def dot_rows(first, second):
    return np.einsum('ij,ij->i',first,second)

def point_segment_squared(points, starts, ends):
    direction=ends-starts
    denominator=dot_rows(direction,direction)
    parameter=np.divide(dot_rows(points-starts,direction),denominator,out=np.zeros(len(points)),where=denominator>0)
    delta=points-(starts+np.clip(parameter,0,1)[:,None]*direction)
    return dot_rows(delta,delta)

def projection_inside(points, triangles):
    first=triangles[:,1]-triangles[:,0]
    second=triangles[:,2]-triangles[:,0]
    relative=points-triangles[:,0]
    normal=np.cross(first,second)
    normal_squared=dot_rows(normal,normal)
    numerator_first=dot_rows(np.cross(relative,second),normal)
    numerator_second=dot_rows(np.cross(first,relative),normal)
    valid=normal_squared>0
    return valid & (numerator_first>=0) & (numerator_second>=0) & (numerator_first+numerator_second<=normal_squared),normal,normal_squared

def point_triangle_squared(points,triangles):
    inside,normal,normal_squared=projection_inside(points,triangles)
    plane_numerator=dot_rows(points-triangles[:,0],normal)
    plane_squared=np.divide(plane_numerator**2,normal_squared,out=np.full(len(points),np.inf),where=normal_squared>0)
    result=np.where(inside,plane_squared,np.inf)
    for edge in range(3):
        result=np.minimum(result,point_segment_squared(points,triangles[:,edge],triangles[:,(edge+1)%3]))
    return result

def segment_segment_squared(start_first,end_first,start_second,end_second):
    direction_first=end_first-start_first
    direction_second=end_second-start_second
    offset=start_first-start_second
    aa=dot_rows(direction_first,direction_first)
    bb=dot_rows(direction_first,direction_second)
    cc=dot_rows(direction_second,direction_second)
    dd=dot_rows(direction_first,offset)
    ee=dot_rows(direction_second,offset)
    determinant=dot_rows(np.cross(direction_first,direction_second),np.cross(direction_first,direction_second))
    parameter_first=np.divide(bb*ee-cc*dd,determinant,out=np.zeros(len(aa)),where=determinant>0)
    parameter_second=np.divide(aa*ee-bb*dd,determinant,out=np.zeros(len(aa)),where=determinant>0)
    interior=(determinant>0)&(parameter_first>=0)&(parameter_first<=1)&(parameter_second>=0)&(parameter_second<=1)
    delta=offset+parameter_first[:,None]*direction_first-parameter_second[:,None]*direction_second
    result=np.where(interior,dot_rows(delta,delta),np.inf)
    for points,starts,ends in [(start_first,start_second,end_second),(end_first,start_second,end_second),(start_second,start_first,end_first),(end_second,start_first,end_first)]:
        result=np.minimum(result,point_segment_squared(points,starts,ends))
    return result

def segment_triangle_hit(starts,ends,triangles):
    normal=np.cross(triangles[:,1]-triangles[:,0],triangles[:,2]-triangles[:,0])
    distance_start=dot_rows(starts-triangles[:,0],normal)
    distance_end=dot_rows(ends-triangles[:,0],normal)
    denominator=distance_start-distance_end
    parameter=np.divide(distance_start,denominator,out=np.zeros(len(starts)),where=denominator!=0)
    points=starts+parameter[:,None]*(ends-starts)
    inside,_,_=projection_inside(points,triangles)
    return (denominator!=0)&(parameter>=0)&(parameter<=1)&inside

def triangle_distances_squared(first,second):
    result=np.full(len(first),np.inf)
    hits=np.zeros(len(first),dtype=bool)
    for vertex in range(3):
        result=np.minimum(result,point_triangle_squared(first[:,vertex],second))
        result=np.minimum(result,point_triangle_squared(second[:,vertex],first))
        hits |= segment_triangle_hit(first[:,vertex],first[:,(vertex+1)%3],second)
        hits |= segment_triangle_hit(second[:,vertex],second[:,(vertex+1)%3],first)
        for edge in range(3):
            result=np.minimum(result,segment_segment_squared(first[:,vertex],first[:,(vertex+1)%3],second[:,edge],second[:,(edge+1)%3]))
    result[hits]=0
    return result

threshold=2.0
results=[]
counts={'object_pairs':0,'object_aabb_excluded':0,'triangle_aabb_candidates':0,'triangle_aabb_excluded_pairs':0}
for index, first in enumerate(meshes):
    for second in meshes[index+1:]:
        counts['object_pairs']+=1
        if not len(first['tri']) or not len(second['tri']):
            continue
        gap=np.maximum(0,np.maximum(first['lo']-second['hi'],second['lo']-first['hi']))
        if np.dot(gap,gap)>threshold**2:
            counts['object_aabb_excluded']+=1
            continue
        first_tri=first['tri']; second_tri=second['tri']
        gaps=np.maximum(0,np.maximum(first_tri.min(axis=1)[:,None,:]-second_tri.max(axis=1)[None,:,:],second_tri.min(axis=1)[None,:,:]-first_tri.max(axis=1)[:,None,:]))
        row_indices,column_indices=np.where(np.sum(gaps*gaps,axis=2)<=threshold**2)
        counts['triangle_aabb_candidates']+=len(row_indices)
        if not len(row_indices):
            counts['triangle_aabb_excluded_pairs']+=1
            continue
        distances=triangle_distances_squared(first_tri[row_indices],second_tri[column_indices])
        minimum=float(np.sqrt(np.min(distances)))
        if minimum<=threshold:
            results.append((first['name'],second['name'],minimum))
print('counts',counts)
print('qualifying_pairs',len(results))
for first_name,second_name,distance in results:
    print(f'{first_name} | {second_name} | {distance:.9f} mm')
print('degenerate_triangles',[(entry['name'],int(np.count_nonzero(np.linalg.norm(np.cross(entry['tri'][:,1]-entry['tri'][:,0],entry['tri'][:,2]-entry['tri'][:,0]),axis=1)==0))) for entry in meshes])