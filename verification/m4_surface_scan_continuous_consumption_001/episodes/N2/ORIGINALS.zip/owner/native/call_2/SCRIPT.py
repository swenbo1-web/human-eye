import bpy, numpy as np, math, time
from mathutils import Vector
from mathutils.bvhtree import BVHTree
scene=bpy.context.scene
deps=bpy.context.evaluated_depsgraph_get()
objs=[o for o in scene.objects if o.type=='MESH']
print('units',scene.unit_settings.system,scene.unit_settings.scale_length)
print('meshes',len(objs))
for o in objs:
 e=o.evaluated_get(deps); m=e.to_mesh(); m.calc_loop_triangles()
 print(repr(o.name),len(m.vertices),len(m.loop_triangles),'hidden',o.hide_get(),o.hide_render)
 e.to_mesh_clear()
