full_results=[]; excluded=[]; total_tests=0
for i,g in enumerate(geom):
 for h in geom[i+1:]:
  a=g['tri']; b=h['tri']; aa=np.repeat(a,len(b),axis=0); bb=np.tile(b,(len(a),1,1))
  distance=math.sqrt(float(tri_dist2(aa,bb).min()))*scene.unit_settings.scale_length*1000
  total_tests+=len(aa)
  (full_results if distance<=2 else excluded).append((g['name'],h['name'],distance))
print('full_triangle_pair_tests',total_tests,'same_results',full_results==results,'qualifying',len(full_results),'excluded',len(excluded))
print('nearest_excluded',sorted(excluded,key=lambda r:r[2])[:5])
print('exact_zeros',sum(r[2]==0 for r in full_results),'positive',sum(r[2]>0 for r in full_results))
print('frame',scene.frame_current,'mode',bpy.context.mode)
print('mesh_instances',[(inst.object.name,inst.is_instance) for inst in deps.object_instances if inst.object.type=='MESH' and inst.is_instance])
print('modifiers',[(o.name,[(m.name,m.type,m.show_viewport,m.show_render) for m in o.modifiers]) for o in objs if len(o.modifiers)])
