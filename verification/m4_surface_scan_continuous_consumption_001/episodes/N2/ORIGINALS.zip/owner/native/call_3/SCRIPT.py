geom=[]
for o in objs:
 e=o.evaluated_get(deps); mesh=e.to_mesh(); mesh.calc_loop_triangles()
 verts=np.array([tuple(v.co) for v in mesh.vertices],dtype=np.float64)
 mat=np.array([list(r) for r in e.matrix_world],dtype=np.float64)
 world=verts@mat[:3,:3].T+mat[:3,3]
 inds=np.array([tuple(t.vertices) for t in mesh.loop_triangles],dtype=int)
 tris=world[inds]
 geom.append({'name':o.name,'tri':tris,'lo':tris.min(axis=(0,1)),'hi':tris.max(axis=(0,1))})
 e.to_mesh_clear()
print('total_triangles',sum(len(g['tri']) for g in geom))
print('bounds',[(g['name'],g['lo'].tolist(),g['hi'].tolist()) for g in geom])
