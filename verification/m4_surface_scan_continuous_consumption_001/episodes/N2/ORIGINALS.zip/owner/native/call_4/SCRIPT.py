def dot(a,b): return np.einsum('...i,...i->...',a,b)
def pseg(p,a,b):
 v=b-a; den=dot(v,v)
 t=np.divide(dot(p-a,v),den,out=np.zeros_like(den),where=den>0)
 d=p-(a+np.clip(t,0,1)[...,None]*v)
 return dot(d,d)
def ptri(p,tri):
 a,b,c=tri[:,0],tri[:,1],tri[:,2]
 u=b-a; v=c-a; w=p-a
 n=np.cross(u,v); nn=dot(n,n)
 wu=dot(w,u); wv=dot(w,v); uu=dot(u,u); uv=dot(u,v); vv=dot(v,v)
 det=uu*vv-uv*uv
 s=np.divide(wu*vv-wv*uv,det,out=np.zeros_like(det),where=det>0)
 t=np.divide(wv*uu-wu*uv,det,out=np.zeros_like(det),where=det>0)
 plane=np.divide(dot(w,n)**2,nn,out=np.full_like(nn,np.inf),where=nn>0)
 inside=(det>0)&(s>=0)&(t>=0)&(s+t<=1)
 return np.minimum(np.where(inside,plane,np.inf),np.minimum.reduce([pseg(p,a,b),pseg(p,b,c),pseg(p,c,a)]))
def segseg(a,b,c,d):
 u=b-a; v=d-c; w=a-c
 aa=dot(u,u); bb=dot(u,v); cc=dot(v,v); dd=dot(u,w); ee=dot(v,w)
 det=aa*cc-bb*bb
 s=np.divide(bb*ee-cc*dd,det,out=np.zeros_like(det),where=det>0)
 t=np.divide(aa*ee-bb*dd,det,out=np.zeros_like(det),where=det>0)
 delta=w+s[:,None]*u-t[:,None]*v
 interior=(det>0)&(s>=0)&(s<=1)&(t>=0)&(t<=1)
 return np.minimum(np.where(interior,dot(delta,delta),np.inf),np.minimum.reduce([pseg(a,c,d),pseg(b,c,d),pseg(c,a,b),pseg(d,a,b)]))
def seg_hit(a,b,tri):
 orig=tri[:,0]; u=tri[:,1]-orig; v=tri[:,2]-orig
 n=np.cross(u,v); denom=dot(b-a,n)
 fraction=np.divide(dot(orig-a,n),denom,out=np.full_like(denom,np.inf),where=denom!=0)
 valid=(denom!=0)&(fraction>=0)&(fraction<=1)
 fraction=np.where(valid,fraction,0)
 w=a+fraction[:,None]*(b-a)-orig
 uu=dot(u,u); uv=dot(u,v); vv=dot(v,v); wu=dot(w,u); wv=dot(w,v); det=uu*vv-uv*uv
 s=np.divide(wu*vv-wv*uv,det,out=np.zeros_like(det),where=det>0)
 t=np.divide(wv*uu-wu*uv,det,out=np.zeros_like(det),where=det>0)
 return valid&(det>0)&(s>=0)&(t>=0)&(s+t<=1)
def tri_dist2(a,b):
 dist=np.full(len(a),np.inf); hit=np.zeros(len(a),dtype=bool)
 for i in range(3):
  dist=np.minimum(dist,ptri(a[:,i],b)); dist=np.minimum(dist,ptri(b[:,i],a))
  hit |= seg_hit(a[:,i],a[:,(i+1)%3],b)|seg_hit(b[:,i],b[:,(i+1)%3],a)
  for j in range(3): dist=np.minimum(dist,segseg(a[:,i],a[:,(i+1)%3],b[:,j],b[:,(j+1)%3]))
 return np.where(hit,0,dist)
threshold=0.002/scene.unit_settings.scale_length
results=[]; counts={'object_pairs':0,'object_aabb_excluded':0,'triangle_aabb_excluded_pairs':0,'tested_triangle_pairs':0,'tested_object_pairs':0}
t0=time.time()
for i,g in enumerate(geom):
 for h in geom[i+1:]:
  counts['object_pairs']+=1
  gap=np.maximum(np.maximum(g['lo']-h['hi'],h['lo']-g['hi']),0)
  if dot(gap,gap)>threshold**2:
   counts['object_aabb_excluded']+=1; continue
  a=g['tri']; b=h['tri']
  gaps=np.maximum(np.maximum(a.min(axis=1)[:,None,:]-b.max(axis=1)[None,:,:],b.min(axis=1)[None,:,:]-a.max(axis=1)[:,None,:]),0)
  ai,bi=np.where(dot(gaps,gaps)<=threshold**2)
  if not len(ai): counts['triangle_aabb_excluded_pairs']+=1; continue
  counts['tested_object_pairs']+=1; counts['tested_triangle_pairs']+=len(ai)
  ds=tri_dist2(a[ai],b[bi]); best=float(np.min(ds))
  if best<=threshold**2: results.append((g['name'],h['name'],math.sqrt(best)*scene.unit_settings.scale_length*1000))
print('counts',counts,'seconds',time.time()-t0)
print('qualifying',len(results))
for row in results: print('%s %s %.9f mm'%row)
print('degenerate_triangles',[(g['name'],int(np.sum(np.linalg.norm(np.cross(g['tri'][:,1]-g['tri'][:,0],g['tri'][:,2]-g['tri'][:,0]),axis=1)==0))) for g in geom])
