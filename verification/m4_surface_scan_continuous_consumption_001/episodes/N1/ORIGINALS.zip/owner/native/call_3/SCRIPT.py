import itertools
mm_per_unit=float(scene.unit_settings.scale_length)*1000.0
for entry in meshes:
    entry['points_mm']=entry['vertices']*mm_per_unit
    entry['faces_mm']=entry['points_mm'][entry['triangles']]
    entry['low']=entry['faces_mm'].min(axis=(0,1)) if len(entry['triangles']) else None
    entry['high']=entry['faces_mm'].max(axis=(0,1)) if len(entry['triangles']) else None

def dot_vectors(first,second):
    return np.sum(first*second,axis=-1)

def point_segment_squared(point,start,end):
    direction=end-start
    denominator=dot_vectors(direction,direction)
    parameter=np.divide(dot_vectors(point-start,direction),denominator,out=np.zeros(np.broadcast_shapes(point.shape[:-1],start.shape[:-1],end.shape[:-1])),where=denominator>0)
    closest=start+np.clip(parameter,0,1)[...,None]*direction
    return dot_vectors(point-closest,point-closest)

def point_triangle_squared(point,triangle):
    start=triangle[...,0,:]; edge_first=triangle[...,1,:]-start; edge_second=triangle[...,2,:]-start
    normal=np.cross(edge_first,edge_second)
    normal_squared=dot_vectors(normal,normal)
    offset=point-start
    height_numerator=dot_vectors(offset,normal)
    first_numerator=dot_vectors(np.cross(offset,edge_second),normal)
    second_numerator=dot_vectors(np.cross(edge_first,offset),normal)
    inside=(first_numerator>=0)&(second_numerator>=0)&(first_numerator+second_numerator<=normal_squared)&(normal_squared>0)
    plane_squared=np.divide(height_numerator**2,normal_squared,out=np.full_like(height_numerator,np.inf),where=normal_squared>0)
    result=np.where(inside,plane_squared,np.inf)
    for edge_index in range(3):
        result=np.minimum(result,point_segment_squared(point,triangle[...,edge_index,:],triangle[...,(edge_index+1)%3,:]))
    return result

def segments_squared(first_start,first_end,second_start,second_end):
    first_direction=first_end-first_start; second_direction=second_end-second_start; offset=first_start-second_start
    first_squared=dot_vectors(first_direction,first_direction); second_squared=dot_vectors(second_direction,second_direction)
    cross_dot=dot_vectors(first_direction,second_direction)
    first_offset=dot_vectors(first_direction,offset); second_offset=dot_vectors(second_direction,offset)
    denominator=dot_vectors(np.cross(first_direction,second_direction),np.cross(first_direction,second_direction))
    first_parameter=np.divide(cross_dot*second_offset-second_squared*first_offset,denominator,out=np.zeros_like(denominator),where=denominator>0)
    second_parameter=np.divide(first_squared*second_offset-cross_dot*first_offset,denominator,out=np.zeros_like(denominator),where=denominator>0)
    valid=(denominator>0)&(first_parameter>=0)&(first_parameter<=1)&(second_parameter>=0)&(second_parameter<=1)
    delta=offset+first_parameter[...,None]*first_direction-second_parameter[...,None]*second_direction
    result=np.where(valid,dot_vectors(delta,delta),np.inf)
    for point,start,end in [(first_start,second_start,second_end),(first_end,second_start,second_end),(second_start,first_start,first_end),(second_end,first_start,first_end)]:
        result=np.minimum(result,point_segment_squared(point,start,end))
    return result

def segment_hits_triangle(start,end,triangle):
    origin=triangle[...,0,:]; edge_first=triangle[...,1,:]-origin; edge_second=triangle[...,2,:]-origin
    normal=np.cross(edge_first,edge_second); normal_squared=dot_vectors(normal,normal)
    initial_height=dot_vectors(start-origin,normal); final_height=dot_vectors(end-origin,normal)
    denominator=initial_height-final_height
    parameter=np.divide(initial_height,denominator,out=np.zeros_like(denominator),where=denominator!=0)
    relative=start+parameter[...,None]*(end-start)-origin
    first=dot_vectors(np.cross(relative,edge_second),normal)
    second=dot_vectors(np.cross(edge_first,relative),normal)
    return (denominator!=0)&(normal_squared>0)&(parameter>=0)&(parameter<=1)&(first>=0)&(second>=0)&(first+second<=normal_squared)

def triangle_surface_distance(first_faces,second_faces):
    first=first_faces[:,None,:,:]; second=second_faces[None,:,:,:]
    minimum=np.inf
    for vertex_index in range(3):
        if np.any(segment_hits_triangle(first[...,vertex_index,:],first[...,(vertex_index+1)%3,:],second)) or np.any(segment_hits_triangle(second[...,vertex_index,:],second[...,(vertex_index+1)%3,:],first)):
            return 0.0
        minimum=min(minimum,float(np.min(point_triangle_squared(first[...,vertex_index,:],second))),float(np.min(point_triangle_squared(second[...,vertex_index,:],first))))
    for first_edge in range(3):
        for second_edge in range(3):
            minimum=min(minimum,float(np.min(segments_squared(first[...,first_edge,:],first[...,(first_edge+1)%3,:],second[...,second_edge,:],second[...,(second_edge+1)%3,:]))))
    return math.sqrt(max(0,minimum))

results=[]; excluded=[]; candidates=[]; empty=[]
started=time.time()
for first,second in itertools.combinations(meshes,2):
    if first['low'] is None or second['low'] is None:
        empty.append((first['name'],second['name'])); continue
    gap=np.maximum(0,np.maximum(first['low']-second['high'],second['low']-first['high']))
    lower_bound=float(np.linalg.norm(gap))
    if lower_bound>2.0:
        excluded.append((first['name'],second['name'],lower_bound)); continue
    distance=triangle_surface_distance(first['faces_mm'],second['faces_mm'])
    candidates.append((first['name'],second['name'],distance))
    if distance<=2.0: results.append((first['name'],second['name'],distance))
print('COUNTS',{'meshes':len(meshes),'triangles':sum(len(entry['triangles']) for entry in meshes),'all_pairs':len(meshes)*(len(meshes)-1)//2,'aabb_excluded':len(excluded),'computed':len(candidates),'qualifying':len(results),'empty_pairs':len(empty),'seconds':time.time()-started})
print('RESULTS')
for first_name,second_name,distance in results: print(first_name,second_name,format(distance,'.12f'))
print('CANDIDATES_OVER_THRESHOLD',[(first,second,distance) for first,second,distance in candidates if distance>2])
print('DEGENERATE_TRIANGLES',[(entry['name'],int(np.count_nonzero(np.linalg.norm(np.cross(entry['faces_mm'][:,1]-entry['faces_mm'][:,0],entry['faces_mm'][:,2]-entry['faces_mm'][:,0]),axis=1)==0))) for entry in meshes])
