full_results=[]
for first,second in itertools.combinations(meshes,2):
    distance=triangle_surface_distance(first['faces_mm'],second['faces_mm'])
    if distance<=2.0: full_results.append((first['name'],second['name'],distance))
print('FULL_CHECK',len(full_results),'MATCH',full_results==results)
print('EXACT_ZERO',sum(distance==0 for _,_,distance in full_results))
print('SMALL_POSITIVES',[(first,second,distance) for first,second,distance in full_results if 0<distance<0.000001])
print('TOTAL_PAIRS',276,'OVER_THRESHOLD',276-len(full_results))
print('OBJECT_INSTANCES',[(instance.object.name,instance.is_instance) for instance in depsgraph.object_instances if instance.is_instance])
