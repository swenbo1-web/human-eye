import bpy, numpy as np, math, time
from mathutils import Vector
from mathutils.bvhtree import BVHTree
scene=bpy.context.scene
print('UNITS',scene.unit_settings.system,scene.unit_settings.scale_length)
print('OBJECTS',[(o.name,o.type,o.hide_viewport,o.hide_render) for o in scene.objects])
depsgraph=bpy.context.evaluated_depsgraph_get()
meshes=[]
for obj in scene.objects:
    if obj.type!='MESH': continue
    evaluated=obj.evaluated_get(depsgraph)
    mesh=evaluated.to_mesh()
    try:
        mesh.calc_loop_triangles()
        vertices=np.array([tuple(evaluated.matrix_world @ vertex.co) for vertex in mesh.vertices],dtype=float).reshape((-1,3))
        triangles=np.array([tuple(triangle.vertices) for triangle in mesh.loop_triangles],dtype=np.int64).reshape((-1,3))
        meshes.append({'name':obj.name,'vertices':vertices,'triangles':triangles})
    finally: evaluated.to_mesh_clear()
print('MESHES',[(m['name'],len(m['vertices']),len(m['triangles']), (m['vertices'].min(axis=0).tolist(),m['vertices'].max(axis=0).tolist()) if len(m['vertices']) else None) for m in meshes])
print('MM_PER_UNIT',scene.unit_settings.scale_length*1000)
