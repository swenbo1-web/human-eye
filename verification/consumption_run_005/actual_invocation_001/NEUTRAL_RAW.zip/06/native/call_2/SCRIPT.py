import bpy, json
from mathutils import Vector
s=bpy.context.scene
out={'unit_system':s.unit_settings.system,'scale_length':s.unit_settings.scale_length,'objects':[]}
for o in s.objects:
    if o.type != 'MESH':
        continue
    me=o.data
    me.calc_loop_triangles()
    verts=[list(o.matrix_world @ v.co) for v in me.vertices]
    out['objects'].append({'name':o.name,'vertices':verts,'triangles':[list(t.vertices) for t in me.loop_triangles],'modifiers':[{'name':m.name,'type':m.type,'show_viewport':m.show_viewport} for m in o.modifiers]})
print(json.dumps(out,ensure_ascii=False))