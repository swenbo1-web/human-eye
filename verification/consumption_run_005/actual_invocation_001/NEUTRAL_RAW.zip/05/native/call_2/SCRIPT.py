import bpy, json
s=bpy.context.scene
out=[]
for o in s.objects:
 if o.type=='MESH':
  out.append({'name':o.name,'matrix_world':[list(row) for row in o.matrix_world],'vertices_local':[list(v.co) for v in o.data.vertices],'vertices_world':[list(o.matrix_world @ v.co) for v in o.data.vertices],'polygons':[list(p.vertices) for p in o.data.polygons]})
print(json.dumps({'meshes':out},ensure_ascii=False,allow_nan=True))