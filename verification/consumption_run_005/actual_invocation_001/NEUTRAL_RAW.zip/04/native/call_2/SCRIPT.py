import bpy,json,math
T02_geometry={}
for o in bpy.context.scene.objects:
    if o.type!='MESH': continue
    verts=[tuple(o.matrix_world@v.co) for v in o.data.vertices]
    faces=[list(p.vertices) for p in o.data.polygons]
    T02_geometry[o.name]={'vertices':verts,'faces':faces}
print(json.dumps({'geometry':{n: {'vertices':d['vertices'],'faces':d['faces']} if n in ['M4_Focal','M4_Near'] else {'vertex_count':len(d['vertices']),'face_count':len(d['faces']),'face_sizes':sorted(set(map(len,d['faces']))),'bounds':[tuple(min(v[i] for v in d['vertices']) for i in range(3)),tuple(max(v[i] for v in d['vertices']) for i in range(3))]} for n,d in T02_geometry.items()},'finite':all(math.isfinite(x) for d in T02_geometry.values() for v in d['vertices'] for x in v)},ensure_ascii=False))