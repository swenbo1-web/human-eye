import bpy,json,math
scene=bpy.context.scene
dg=bpy.context.evaluated_depsgraph_get()
read={}
for obj in scene.objects:
    if obj.type!='MESH': continue
    eo=obj.evaluated_get(dg)
    verts=[tuple(eo.matrix_world@v.co) for v in eo.data.vertices]
    faces=[tuple(p.vertices) for p in eo.data.polygons]
    read[obj.name]={'vertices':verts,'faces':faces}
f=read['M4_Focal']; n=read['M4_Near']
assert f['faces']==[(0,1,2)] and n['faces']==[(0,1,2)]
assert f['vertices']==[(0.,0.,0.),(0.,1.,0.),(0.,0.,1.)]
distance=n['vertices'][0][0]
assert all(q==(p[0]+distance,p[1],p[2]) for p,q in zip(f['vertices'],n['vertices']))
assert all(math.isfinite(c) for d in read.values() for v in d['vertices'] for c in v)
assert all(len(face)==3 for d in read.values() for face in d['faces'])
bounds=[]
for name,data in read.items():
    if name in ('M4_Focal','M4_Near'): continue
    used=[data['vertices'][i] for face in data['faces'] for i in face]
    lower=min(v[0] for v in used)
    assert lower>distance
    bounds.append({'name':name,'proven_distance_lower_bound_m':lower*scene.unit_settings.scale_length,'triangles_covered':len(data['faces'])})
print(json.dumps({'mesh_count':len(read),'triangles_covered':sum(len(d['faces']) for d in read.values()),'all_evaluated_geometry_matches_initial_read':read==T02_geometry,'nearest_names':['M4_Near'],'minimum_distance_m':distance*scene.unit_settings.scale_length,'witness_points':[[0.0,0.0,0.0],list(n['vertices'][0])],'excluded_meshes':bounds,'clearance_3mm':distance*scene.unit_settings.scale_length>=0.003,'unresolved':[]},ensure_ascii=False))