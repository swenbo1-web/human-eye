import bpy, json
s = bpy.context.scene
dg = bpy.context.evaluated_depsgraph_get()
objects = []
for o in s.objects:
    if o.type != 'MESH':
        continue
    eo = o.evaluated_get(dg)
    mesh = eo.to_mesh()
    try:
        mesh.calc_loop_triangles()
        w = eo.matrix_world
        vs = [list(w @ v.co) for v in mesh.vertices]
        ts = [list(t.vertices) for t in mesh.loop_triangles]
        objects.append({'name':o.name, 'vertices_world':vs, 'triangles':ts, 'modifiers':[m.type for m in o.modifiers], 'visible':o.visible_get()})
    finally:
        eo.to_mesh_clear()
print(json.dumps({'scene':s.name,'unit_system':s.unit_settings.system,'scale_length':s.unit_settings.scale_length,'objects':objects},ensure_ascii=False))