import bpy, json
from mathutils import Vector
scene=bpy.context.scene
rows=[]
for o in scene.objects:
    if o.type=='MESH':
        rows.append({'name':o.name,'vertices':len(o.data.vertices),'polygons':len(o.data.polygons),'matrix_world':[list(r) for r in o.matrix_world],'modifiers':[{'name':m.name,'type':m.type,'show_viewport':m.show_viewport} for m in o.modifiers],'hide_viewport':o.hide_viewport,'hide_render':o.hide_render})
print(json.dumps({'scene':scene.name,'units':{'system':scene.unit_settings.system,'scale_length':scene.unit_settings.scale_length},'meshes':rows},ensure_ascii=False))