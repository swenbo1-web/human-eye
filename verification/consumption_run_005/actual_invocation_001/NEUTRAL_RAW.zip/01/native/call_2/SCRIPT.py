import bpy, json
rows=[]
for o in bpy.context.scene.objects:
    if o.type=='MESH':
        rows.append({'name':o.name,'world_vertices':[[float(c) for c in o.matrix_world @ v.co] for v in o.data.vertices],'faces':[list(p.vertices) for p in o.data.polygons],'edges':[list(e.vertices) for e in o.data.edges]})
print(json.dumps(rows,ensure_ascii=False))