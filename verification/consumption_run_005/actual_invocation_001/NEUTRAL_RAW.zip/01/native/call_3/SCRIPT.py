import bpy, json
sc=bpy.context.scene
dg=bpy.context.evaluated_depsgraph_get()
rows=[]
for o in sc.objects:
    if o.type=='MESH':
        eo=o.evaluated_get(dg)
        rows.append({'name':o.name,'mode':o.mode,'shape_keys':None if o.data.shape_keys is None else [{'name':k.name,'value':k.value} for k in o.data.shape_keys.key_blocks],'evaluated_world_vertices':[[float(c) for c in eo.matrix_world @ v.co] for v in eo.data.vertices],'evaluated_faces':[list(p.vertices) for p in eo.data.polygons]})
print(json.dumps({'objects':[{'name':o.name,'type':o.type} for o in sc.objects],'evaluated':rows,'instances':[{'name':i.object.name,'is_instance':i.is_instance,'matrix_world':[list(r) for r in i.matrix_world]} for i in dg.object_instances]},ensure_ascii=False))