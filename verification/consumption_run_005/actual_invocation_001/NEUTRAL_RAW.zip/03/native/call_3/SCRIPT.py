import bpy,json,math
records=[]
for o in bpy.context.scene.objects:
 if o.type!='MESH': continue
 vs=[tuple(o.matrix_world@v.co) for v in o.data.vertices]
 bounds=[[min(v[k] for v in vs),max(v[k] for v in vs)] for k in range(3)]
 deg=[]
 counts={}
 for p in o.data.polygons:
  ids=list(p.vertices);counts[len(ids)]=counts.get(len(ids),0)+1
  if len(ids)==3:
   a,b,c=[vs[i] for i in ids]
   u=[b[i]-a[i] for i in range(3)];v=[c[i]-a[i] for i in range(3)]
   cr=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
   if sum(x*x for x in cr)==0: deg.append({'face':p.index,'vertices':[a,b,c]})
 records.append({'name':o.name,'bounds':bounds,'polygon_sizes':counts,'degenerate_count':len(deg),'degenerate_faces':deg,'vertices':vs if len(vs)<4 else None})
print(json.dumps(records,ensure_ascii=False))