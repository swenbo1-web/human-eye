import bpy, json
scene=bpy.context.scene
deps=bpy.context.evaluated_depsgraph_get()
result={'unit_system':scene.unit_settings.system,'scale_length':scene.unit_settings.scale_length,'objects':[]}
for obj in scene.objects:
    if obj.type!='MESH':
        continue
    ev=obj.evaluated_get(deps)
    mesh=ev.to_mesh()
    try:
        mesh.calc_loop_triangles()
        result['objects'].append({'name':obj.name,'vertices':[list(ev.matrix_world @ v.co) for v in mesh.vertices],'triangles':[list(t.vertices) for t in mesh.loop_triangles],'polygons':[list(p.vertices) for p in mesh.polygons]})
    finally:
        ev.to_mesh_clear()
print(json.dumps(result,ensure_ascii=False))