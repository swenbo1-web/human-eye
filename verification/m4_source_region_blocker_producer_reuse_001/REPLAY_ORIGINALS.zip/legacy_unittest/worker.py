
import json,sys,unittest
from pathlib import Path
b=json.loads(Path(sys.argv[1]).read_bytes())
sys.path[:0]=[b['install_root'],b['dependency_root'],str(Path.cwd())]
suite=unittest.defaultTestLoader.loadTestsFromNames([
    'verification.test_live_spatial_mcp',
    'verification.test_source_region_display_host',
    'verification.m4_m5_source_region_001.core_tests.test_source_region_core',
])
res=unittest.TextTestRunner(verbosity=2).run(suite)
print(json.dumps({'tests':res.testsRun,'failures':[str(test) for test,_ in res.failures],
                  'errors':[str(test) for test,_ in res.errors]}))
sys.exit(0 if res.wasSuccessful() else 1)
