
from pathlib import Path
import copy,json,sys
sys.path[:0]=['D:/he_m4_source_region_blocker_brief_001/candidate_install/product','D:/he_anchor_001/venv/Lib/site-packages']
from human_eye_plugin import live_spatial_mcp as mcp
from human_eye_plugin.runtime_identity import runtime_identity
assert runtime_identity()['source_sha256']=='bfe3d10f86d2c48f822879e9c503aae4d64cd76b789256e385863b780860d59d'
data=json.loads(Path(sys.argv[1]).read_bytes())
class Replay:
    def __init__(self): self.i=0
    def observe(self,session_id,*,query,include_image,**kwargs):
        assert query==data['request']['params']['arguments']['query'] and include_image is True
        label,number=data['cases'][self.i];self.i+=1
        v=copy.deepcopy(data['producer'])
        if number is not None:
            blocker=v['view_attempts'][1]['first_blocker']
            blocker['source_triangle_index']=number
            if label=='bad-self-2':blocker['object_index']=2
        return v
    def _check_request_budget(self,phase,**kwargs):pass
    def close(self): pass
mcp._configure_utf8_stdio()
mcp.run_stdio_mcp_server(Replay())
