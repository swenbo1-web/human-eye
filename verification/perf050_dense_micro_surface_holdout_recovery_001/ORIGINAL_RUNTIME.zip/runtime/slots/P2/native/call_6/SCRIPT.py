validate_code("import bpy\nfor name in ['S034','S021','S055']:\n obj=bpy.data.objects[name]; ev=obj.evaluated_get(bpy.context.evaluated_depsgraph_get()); mesh=ev.to_mesh(); mesh.calc_loop_triangles()\n print(name, 'polygons',[(p.index,list(p.vertices)) for p in mesh.polygons], 'triangles',[(i,tr.polygon_index,list(tr.vertices)) for i,tr in enumerate(mesh.loop_triangles)])\n ev.to_mesh_clear()")
_consumer_scope_state['running'] = True
try:
    exec(compile("import bpy\nfor name in ['S034','S021','S055']:\n obj=bpy.data.objects[name]; ev=obj.evaluated_get(bpy.context.evaluated_depsgraph_get()); mesh=ev.to_mesh(); mesh.calc_loop_triangles()\n print(name, 'polygons',[(p.index,list(p.vertices)) for p in mesh.polygons], 'triangles',[(i,tr.polygon_index,list(tr.vertices)) for i,tr in enumerate(mesh.loop_triangles)])\n ev.to_mesh_clear()", '<ordinary-blender-task>', 'exec'), _ordinary_blender_namespace)
finally:
    _consumer_scope_state['running'] = False
