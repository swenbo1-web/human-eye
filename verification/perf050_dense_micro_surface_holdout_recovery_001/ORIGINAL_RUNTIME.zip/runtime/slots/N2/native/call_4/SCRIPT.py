validate_code("import bpy\nfor name in ['S034','S021','S055','M4_Far_00']:\n obj=bpy.data.objects[name].evaluated_get(bpy.context.evaluated_depsgraph_get()); mesh=obj.to_mesh(); mesh.calc_loop_triangles()\n print(name, 'polygons', [(poly.index,tuple(poly.vertices)) for poly in mesh.polygons if name!='M4_Far_00' or poly.index>=512])\n print('triangle-to-polygon',[(idx,tri.polygon_index,tuple(tri.vertices)) for idx,tri in enumerate(mesh.loop_triangles) if name!='M4_Far_00' or idx>=512]); obj.to_mesh_clear()")
_consumer_scope_state['running'] = True
try:
    exec(compile("import bpy\nfor name in ['S034','S021','S055','M4_Far_00']:\n obj=bpy.data.objects[name].evaluated_get(bpy.context.evaluated_depsgraph_get()); mesh=obj.to_mesh(); mesh.calc_loop_triangles()\n print(name, 'polygons', [(poly.index,tuple(poly.vertices)) for poly in mesh.polygons if name!='M4_Far_00' or poly.index>=512])\n print('triangle-to-polygon',[(idx,tri.polygon_index,tuple(tri.vertices)) for idx,tri in enumerate(mesh.loop_triangles) if name!='M4_Far_00' or idx>=512]); obj.to_mesh_clear()", '<ordinary-blender-task>', 'exec'), _ordinary_blender_namespace)
finally:
    _consumer_scope_state['running'] = False
