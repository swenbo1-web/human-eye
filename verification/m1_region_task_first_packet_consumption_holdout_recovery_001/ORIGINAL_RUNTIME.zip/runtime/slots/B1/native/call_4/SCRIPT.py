import json as _json, contextlib as _cl, io as _io
_request = _json.loads('{"id":"273aa947577e41b6baae8f0d36ed0f55","command":"capture","params":{}}')
try:
    import sys as _sys
    _module = _sys.modules.get('_human_eye_mcp_resident_efde2761a83326624fa4')
    if _module is None or getattr(_module, '_resident_tag', None) != '588f12a5001adb5df66b57ca8f8f2c3c20207192b6d141bd3ef8c7e01cb7d7f0': raise RuntimeError('Resident Blender host unavailable; reconnect with a new connector')
    _host = _module._mcp_resident_host
    with _cl.redirect_stdout(_io.StringIO()):
        _result = getattr(_host, 'capture_scene')(**_request['params'])
    _result = _host.capture_delta(_result, _json.loads('{"instance_id":"9b54568d024943fbb0ce92fef5bcf3e6","epoch":1,"resources":{"mesh:(\'uid\', 168)":1,"mesh:(\'uid\', 163)":2,"mesh:(\'uid\', 161)":3,"mesh:(\'uid\', 175)":4,"mesh:(\'uid\', 171)":5,"mesh:(\'uid\', 176)":6,"mesh:(\'uid\', 169)":7,"mesh:(\'uid\', 160)":8,"mesh:(\'uid\', 172)":9,"mesh:(\'uid\', 162)":10,"mesh:(\'uid\', 177)":11,"mesh:(\'uid\', 164)":12,"mesh:(\'uid\', 170)":13,"mesh:(\'uid\', 179)":14,"mesh:(\'uid\', 165)":15,"mesh:(\'uid\', 174)":16,"mesh:(\'uid\', 178)":17,"mesh:(\'uid\', 173)":18,"mesh:(\'uid\', 167)":19,"mesh:(\'uid\', 166)":20}}'))
    _envelope = {'protocol_version': '1.0', 'id': _request['id'], 'result': _result}
except Exception as _exc:
    _envelope = {'protocol_version': '1.0', 'id': _request['id'], 'error': {'type': type(_exc).__name__, 'message': str(_exc)[:2000], 'mutation_uncertain': _request['command'] == 'apply'}}
print('HUMAN_EYE_BLENDER_MCP:' + _json.dumps(_envelope, ensure_ascii=True, allow_nan=False, separators=(',', ':')))