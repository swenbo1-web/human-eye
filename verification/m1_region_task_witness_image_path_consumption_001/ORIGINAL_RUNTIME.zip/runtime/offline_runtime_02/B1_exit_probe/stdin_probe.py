from pathlib import Path
import sys
Path('D:\\he_m1_region_task_witness_image_path_consumption_001\\offline_runtime_02\\B1_exit_probe\\STDIN.bin').write_bytes(sys.stdin.buffer.read())
print("transfer offline early exit", file=sys.stderr)
raise SystemExit(7)
