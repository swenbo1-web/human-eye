"""MCP transport for the live, guarded Blender service.

This entry point deliberately exposes a separate set of tools from the legacy
demo server. It requires a trusted local configuration and never loads a demo
scene or executes arbitrary host code supplied by a model.
"""
from __future__ import annotations

import argparse
import base64
import copy
import hashlib
from fractions import Fraction
from contextlib import contextmanager, nullcontext
from functools import partial
import json
import math
from pathlib import Path
import sys
import time
import uuid
from typing import Any, TextIO

from .runtime_identity import BASE_VERSION, MCP_PROTOCOL_VERSION, runtime_identity
from .auto_router import _trace_span, _trace_annotate as annotate
from .query_policy import MAX_VISUAL_LABEL_IDS, NATIVE_VISUAL_SCHEMA, validate_query
from .task_query import FACTS as TASK_FACTS, SELECTOR_SCHEMA
from .native_observation import _public_native_png
from .support_plane_discovery import SUPPORT_PLANE_DISCOVERY_REQUEST_SCHEMA
from .telemetry import set_image_request, record_image_artifact
from .goal_segment import CLEARANCE_SEGMENT_REQUEST_SCHEMA, validate_clearance_segment_request
from .request_context import (TASK_CONTEXT_SCHEMA, SCENE_DELTA_REQUEST_SCHEMA,
                              validate_task_context, validate_scene_delta_request, bind_task_context)
from .telemetry import current_trace
from . import mcp_transport as wire
from .hook_context import (_observation as _parse_observation,
                           _deduplicate, _contains_reference_key)
from .task_brief import project_task_brief, project_segment_brief, project_structure_brief

span = partial(_trace_span, source_name='mcp_transport')
_NO_RPC_ID = object()


_ID_SCHEMA = {"type": "string", "minLength": 1}
_VECTOR_SCHEMA = {
    "type": "array", "items": {"type": "number"}, "minItems": 3, "maxItems": 3,
}
_TASK_GEOMETRY_SCHEMA = {
    'type': 'object',
    'description': 'Opt-in geometry from the original relation bindings. Vertices use world metres; captured triangles are optional.',
    'properties': {
        'objects': {'type': 'array', 'items': copy.deepcopy(SELECTOR_SCHEMA), 'minItems': 1, 'maxItems': 4},
        'include_triangles': {'type': 'boolean', 'default': False},
    },
    'required': ['objects'], 'additionalProperties': False,
}
_ACTION_SCHEMA = {
    "type": "object",
    "properties": {
        "focal_id": copy.deepcopy(_ID_SCHEMA),
        "reference_id": copy.deepcopy(_ID_SCHEMA),
        "translation": copy.deepcopy(_VECTOR_SCHEMA),
        "rotation_euler_deg": copy.deepcopy(_VECTOR_SCHEMA),
    },
    "required": ["focal_id", "reference_id"],
    "anyOf": [{"required": ["translation"]}, {"required": ["rotation_euler_deg"]}],
    "additionalProperties": False,
}
_QUERY_SCHEMA = {
    "type": "object",
    "description": "Selectors use name OR id. Legacy exact_pairs/nearest/top1 use object_ids/max_exact_pairs. nearest needs complete exact nonpenetrating order; top1 may prune by strict outward bounds and reports ties. Unknown/budget-limited proofs do not certify nearest.",
    "properties": {
        "mode": {"type": "string", "enum": ["directory", "task", "surface_nearest", "surface_scan", "overview", "exact_pairs", "nearest", "top1", "mesh_structure", "mesh_surface", "active_observation"]},
        "objects": {"type": "array", "items": SELECTOR_SCHEMA, "minItems": 1, "maxItems": 4,
            "description": "Legacy task: aabb 1..4 selectors; pair facts two ordered A to B."},
        "target": copy.deepcopy(SELECTOR_SCHEMA),
        "candidates": {"type": "array", "items": copy.deepcopy(SELECTOR_SCHEMA), "minItems": 1, "maxItems": 3,
            "description": "1..3 explicit candidates in request order; one capture with target. Requires surface_proximity with spatial_relation or closed_solid_relation. Optional aabb supplies bounds."},
        "requested_facts": {"type": "array", "items": {"type": "string", "enum": list(TASK_FACTS)},
            "minItems": 1, "uniqueItems": True,
            "description": "task: spatial_relation proves strict full-referenced-vertex support separation or uses closed-shell classification, with geometry_scope identifying the performed proof. closed_solid_relation is zero-tolerance separated/touching/penetrating (positive-volume overlap, including containment) for represented connected closed triangle shells; invalid/ambiguous is unknown. surface_proximity independently gives nonnegative triangle-surface distance, original world witness points and positive-distance A-to-B direction; zero-distance direction is inapplicable. Boundary/nonmanifold counts do not certify solids. Penetrating/contained distances are not separated gaps. pair_relation's escape of A is not surface distance, nearest direction or minimum depth."},
        'geometry': copy.deepcopy(_TASK_GEOMETRY_SCHEMA),
        "operation": {"type":"string","enum":["diagnose","patch","reference","restore_preview","reference_patch"],
            "description":"Registered target reads. mesh_structure: diagnose text or patch images. mesh_surface (local opt-in): diagnose/reference/restore_preview require include_image=false; reference_patch uses a returned opaque patch_ref and optional native images. References are locally trusted; previews do not execute; the original task budget applies."},
        "request_id": {"type":"string","minLength":1,"maxLength":128},
        "near_m": {"type":"number","minimum":0,"maximum":0.001},
        "threshold_m": {"type":"number","minimum":0},
        "reference_ref": {"type":"string","pattern":"^[a-f0-9]{32}$"},
        "indices": {"type":"array","items":{"type":"integer","minimum":0,"maximum":4095},"minItems":1,"maxItems":64,"uniqueItems":True},
        "patch_ref": {"type":"string","pattern":"^[a-f0-9]{32}$"},
        "task_ref": {"type":"string","pattern":"^[a-f0-9]{32}$",
            "description":"Trusted begin handoff, required in local lifecycle mode; selects the active generation without creating or renewing a task."},
        "object_ids": {"type": "array", "items": copy.deepcopy(_ID_SCHEMA), "minItems": 1, "maxItems": 255, "uniqueItems": True},
        "label_object_ids": {"type": "array", "items": copy.deepcopy(_ID_SCHEMA), "minItems": 1, "maxItems": MAX_VISUAL_LABEL_IDS, "uniqueItems": True,
            "description": "Current full IDs for image annotation, separate from measurement object_ids: up to six related labels plus A/B. Missing pair/image, occlusion or undersampling is explicit; display only."},
        "max_exact_pairs": {"type": "integer", "minimum": 1, "maximum": 255},
        "alignment_evidence": {"type": "boolean", "default": True,
            "description": "False omits optional face angles and requires include_image=false; strict distance, host rigid-frame and action checks remain."},
        "support_plane_discovery": copy.deepcopy(SUPPORT_PLANE_DISCOVERY_REQUEST_SCHEMA),
        "native_visual": copy.deepcopy(NATIVE_VISUAL_SCHEMA),
        "visual_diagnostic": {"type": "string", "enum": ["contact_section"],
            "description": "Analytical full-mesh contact section beside natural views; not visibility evidence or action permission."},
    },
    "allOf": [{"if": {"properties": {"mode": {"const": "active_observation"}}, "required": ["mode"]},
               "then": {"properties": {"mode": {}}, "additionalProperties": False}},
              {"if": {"properties": {"mode": {"const": "directory"}}, "required": ["mode"]},
               "then": {"properties": {"mode": {}}, "additionalProperties": False}},
              {"if": {"properties": {"mode": {"const": "surface_nearest"}}, "required": ["mode"]},
               "then": {"properties": {"mode": {}, "objects": {"maxItems": 1}}, "additionalProperties": False}},
              {"if": {"properties": {"mode": {"const": "surface_scan"}}, "required": ["mode"]},
               "then": {"required": ["threshold_m"], "properties": {"mode": {}, "threshold_m": {}},
                        "additionalProperties": False},
               "else": {"properties": {"threshold_m": {"exclusiveMinimum": 0, "maximum": 0.01}}}},
              {"if": {"anyOf": [{"properties": {"mode": {"const": "task"}}, "required": ["mode"]},
                                  {"required": ["target"]}, {"required": ["candidates"]}]},
               "then": {"required": ["mode", "requested_facts"], "properties": {"mode": {"const": "task"}}, "oneOf": [
                   {"required": ["objects"], "properties": {"target": False, "candidates": False}},
                   {"required": ["target", "candidates"],
                    "additionalProperties": False,
                    "properties": {"mode": {}, "target": {}, "candidates": {}, "geometry": {}, "requested_facts": {"items": {"enum": ["closed_solid_relation", "spatial_relation", "surface_proximity", "aabb"]},
                        "allOf": [{"contains": {"const": "surface_proximity"}},
                            {"anyOf": [{"contains": {"const": "closed_solid_relation"}},
                                       {"contains": {"const": "spatial_relation"}}]}]}}}
               ]}},
              {"if": {"required": ["geometry"]},
               "then": {"required": ["mode", "target", "candidates"],
                        "properties": {"mode": {"const": "task"}}}}],
    "additionalProperties": False,
}
_GOAL_SCHEMA = {
    "type": "object",
    "description": (
        "Optional caller-supplied task criteria, evaluated separately from execution. "
        "Omitted object IDs bind to the selected observation/action pair. "
        "These criteria are not independently verified as the human user's intent."
    ),
    "properties": {
        "focal_id": copy.deepcopy(_ID_SCHEMA),
        "reference_id": copy.deepcopy(_ID_SCHEMA),
        "target_clearance_m": {"type": "number", "minimum": 0},
        "clearance_tolerance_m": {"type": "number", "minimum": 0},
        "target_focal_pivot_world_m": copy.deepcopy(_VECTOR_SCHEMA),
        "position_tolerance_m": {"type": "number", "minimum": 0},
        "max_contact_normal_angle_deg": {"type": "number", "minimum": 0, "maximum": 180},
        "max_tangent_yaw_mismatch_deg": {"type": "number", "minimum": 0, "maximum": 180},
        "yaw_symmetry_order": {"type": "integer", "enum": [1, 2, 4]},
    },
    "anyOf": [
        {"required": [field]} for field in (
            "target_clearance_m", "target_focal_pivot_world_m",
            "max_contact_normal_angle_deg", "max_tangent_yaw_mismatch_deg")
    ],
    "dependentRequired": {
        "target_clearance_m": ["clearance_tolerance_m"],
        "clearance_tolerance_m": ["target_clearance_m"],
        "target_focal_pivot_world_m": ["position_tolerance_m"],
        "position_tolerance_m": ["target_focal_pivot_world_m"],
    },
    "additionalProperties": False,
}

LIVE_MCP_TOOLS_SCHEMA = [
    {
        "name": "human_eye_scene_observe",
        "description": (
            "Current Blender facts. Directory query={mode:directory} with include_image=false returns tight evaluated world bounds, AABB centers and an independent directory binding. Task set example: "
            "{\"include_image\":false,\"query\":{\"mode\":\"task\",\"target\":{\"name\":\"A\"},\"candidates\":[{\"name\":\"B\"}],\"requested_facts\":[\"closed_solid_relation\",\"surface_proximity\"]}}. "
            "Opt in to spatial_relation and surface_proximity for support-certified separation with closed-classification fallback. "
            "Unknown/duplicate rows remain. Complete penetration/nearest-separated sets require all relevant evidence; otherwise only known subsets are reported. "
            "Legacy objects pair/aabb supported. Global surface_nearest instead uses one query.objects selector without focal_id, "
            "or focal_id with query={\"mode\":\"surface_nearest\"}; session_id and include_image=false required. "
            "Complete means global nearest; partial means best-known. scene_revision/fingerprint bind this capture/source/revision; "
            "runtime_source_sha256 identifies code. Scene edits expire observations. Goals are caller criteria."
            " For all current scene mesh pairs use query={\"mode\":\"surface_scan\",\"threshold_m\":0.002}. "
            "This text-only scan includes hidden meshes, needs no selectors, includes threshold equality and reports coverage. "
            "Its unsigned triangle-surface distance describes surface proximity. Solid relations require separate facts. "
            "For surface_scan, omitted response_detail or brief returns a versioned compact table with readable names, "
            "object-table references, original distance_m and derived distance_mm. Explicit full returns detailed current "
            "evidence with witnesses. Combine observations using their scene/source binding."
            " For finite active observation of the complete scene use {\"query\":{\"mode\":\"active_observation\"},\"include_image\":true}; returns brief source-bound region locations, owned-pixel anchors and remaining unknowns with up to six 512px native PNGs. Explicit response_detail=full includes diagnostics."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_instruction": {"type": "string"},
                "focal_id": copy.deepcopy(_ID_SCHEMA),
                "reference_id": copy.deepcopy(_ID_SCHEMA),
                "session_id": copy.deepcopy(_ID_SCHEMA),
                "goal": copy.deepcopy(_GOAL_SCHEMA),
                "query": copy.deepcopy(_QUERY_SCHEMA),
                "include_image": {"type": "boolean", "default": True,
                    "description": "False returns text evidence without rendering. surface_scan defaults to false and accepts only false. mesh_structure diagnose requires false and reads only the registered target raw mesh; patch may explicitly request images. Other observation modes retain default true."},
            },
            "allOf": [{"if": {"required": ["query"], "properties": {"query": {
                    "required": ["mode"], "properties": {"mode": {"const": "active_observation"}}}}},
                "then": {"properties": {"task_instruction": {"const": ""}},
                         "not": {"anyOf": [{"required": [field]} for field in
                             ("focal_id", "reference_id", "goal", "scene_delta")]}}},
              {"if": {"required": ["query"], "properties": {"query": {
                    "required": ["mode"], "properties": {"mode": {"const": "directory"}}}}},
                "then": {"required": ["include_image"],
                         "properties": {"include_image": {"const": False}, "task_instruction": {"const": ""}},
                         "not": {"anyOf": [{"required": [field]} for field in
                             ("focal_id", "reference_id", "goal", "scene_delta")]}}}, {
                "if": {"required": ["query"], "properties": {"query": {
                    "required": ["mode"], "properties": {"mode": {"const": "surface_nearest"}}}}},
                "then": {"required": ["session_id", "include_image"],
                         "properties": {"include_image": {"const": False}},
                         "oneOf": [
                             {"required": ["focal_id"], "properties": {"query": {"not": {"required": ["objects"]}}}},
                             {"not": {"required": ["focal_id"]}, "properties": {"query": {"required": ["objects"]}}},
                         ]},
            }, {"if": {"required": ["query"], "properties": {"query": {
                    "required": ["mode"], "properties": {"mode": {"const": "surface_scan"}}}}},
                "then": {"properties": {"include_image": {"const": False},
                                         "response_detail": {"default": "brief"}},
                         "not": {"anyOf": [{"required": [field]} for field in
                             ("focal_id", "reference_id", "goal", "scene_delta")]}}},
            {"if": {"required": ["query"], "properties": {"query": {
                    "required": ["mode"], "properties": {"mode": {"enum": ["surface_scan", "active_observation"]}}}}},
                "then": {"properties": {"response_detail": {"default": "brief"}}},
                "else": {"properties": {"response_detail": {"default": "full"}}}},
            {"if": {"required": ["query"], "properties": {"query": {
                    "required": ["mode"], "properties": {"mode": {"const": "task"}}}}},
                "then": {"required": ["include_image"], "properties": {"include_image": {"const": False}},
                         "not": {"anyOf": [{"required": [field]} for field in
                             ("focal_id", "reference_id", "goal", "scene_delta")]}}}],
            "additionalProperties": False,
        },
    },
    {
        "name": "human_eye_transform",
        "description": (
            "Apply a guarded world-space rigid transform to the focal Blender object "
            "automatically preparing a fresh engine observation before its mandatory check. "
            "Translation is in metres; rotation is XYZ Euler degrees about the object pivot. "
            "The service checks the current revision and endpoint geometry, executes only "
            "accepted actions, and reads the actual scene back. An optional caller-supplied "
            "goal checks the actual result separately from execution verification. "
            "This does not certify a swept path or independently verify the caller's intent."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": copy.deepcopy(_ACTION_SCHEMA),
                "session_id": copy.deepcopy(_ID_SCHEMA),
                "goal": copy.deepcopy(_GOAL_SCHEMA),
            },
            "required": ["action"],
            "additionalProperties": False,
        },
    },
    {
        "name": "human_eye_connection_status",
        "description": "Read the live service configuration and connection status without changing the scene.",
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
    },
]

LIVE_MCP_TOOLS_SCHEMA.append({
    'name': 'human_eye_clearance_segment',
    'description': ('Preview or execute a finite target-clearance segment. Legacy requests use exact '
        'world-axis boxes with an explicit signed world axis. Explicit solver=support_plane requests '
        'select an original reference triangle and a world translation direction; exact finite-plane '
        'certificates restrict their supported convex-mesh domain. Supply object IDs, target and '
        'tolerance; the engine computes translations and may correct confirmed residuals within '
        'the declared budget. execute defaults '
        'to false. Reuse the same request_id to retrieve a historical receipt, never to repeat motion. '
        'Every real step retains fresh geometry/precision checks and actual readback. Endpoint only; '
        'no swept path or in-flight cancellation is certified.'),
    'inputSchema': {'type': 'object', 'additionalProperties': False,
        'properties': {'session_id': copy.deepcopy(_ID_SCHEMA), 'request_id': copy.deepcopy(_ID_SCHEMA),
            'request': copy.deepcopy(CLEARANCE_SEGMENT_REQUEST_SCHEMA),
            'execute': {'type': 'boolean', 'default': False},
            'include_image': {'type': 'boolean', 'default': False}},
        'required': ['request_id', 'request']},
})

LIVE_MCP_TOOLS_SCHEMA.append({
    'name': 'human_eye_arm_twist_observe',
    'description': ('Read an explicitly selected Blender arm patch. Returns synthetic-trained '
        'twist-collapse severity by original vertex section and current source. Diagnostic only: '
        'no repair or execution authority. Supply mesh, a 2..4 bone chain and existing ordered sections.'),
    'annotations': {'readOnlyHint': True, 'destructiveHint': False, 'idempotentHint': True, 'openWorldHint': False},
    'inputSchema': {'type': 'object', 'additionalProperties': False,
        'properties': {'session_id': copy.deepcopy(_ID_SCHEMA),
            'selection': {'type': 'object', 'additionalProperties': False,
                'properties': {
                    'mesh_name': {'type': 'string', 'minLength': 1, 'maxLength': 256},
                    'armature_name': {'type': 'string', 'minLength': 1, 'maxLength': 256},
                    'bone_names': {'type': 'array', 'minItems': 2, 'maxItems': 4, 'uniqueItems': True,
                        'items': {'type': 'string', 'minLength': 1, 'maxLength': 256}},
                    'vertex_indices': {'type': 'array', 'minItems': 6, 'maxItems': 8192, 'uniqueItems': True,
                        'items': {'type': 'integer', 'minimum': 0}},
                    'sections': {'type': 'array', 'minItems': 2, 'maxItems': 128,
                        'items': {'type': 'array', 'minItems': 3, 'maxItems': 256, 'uniqueItems': True,
                            'items': {'type': 'integer', 'minimum': 0}}}},
                'required': ['mesh_name', 'bone_names', 'sections']}},
        'required': ['selection']}})

for _tool in LIVE_MCP_TOOLS_SCHEMA:
    if _tool['name'] != 'human_eye_connection_status':
        _tool['inputSchema']['properties']['task_context'] = copy.deepcopy(TASK_CONTEXT_SCHEMA)
    if _tool['name'] == 'human_eye_scene_observe':
        _tool['inputSchema']['properties']['scene_delta'] = copy.deepcopy(SCENE_DELTA_REQUEST_SCHEMA)
        _tool['inputSchema']['properties']['response_detail'] = {
            'type': 'string', 'enum': ['full', 'brief'],
            'description': ('Optional display projection. surface_scan defaults to brief: a versioned table preserves '
                'all delivered matches, raw metre distances, derived millimetres, identities, scopes and unknowns. '
                'distance_mm uses a number, or an exact decimal string when binary64 millimetres overflow. '
                'Its object table covers matched endpoints. Full requests a new current observation with detailed '
                'witnesses; combine observations by scene/source binding. active_observation also defaults to brief, '
                'with all objects, region unknowns, actual pixel facts and native image references; full retains diagnostics. '
                'Other modes default to full; their brief '
                'omits named camera/raster diagnostics while preserving measurements and native images. '
                'Errors and unsupported projections retain the detailed response.'),
        }
    if _tool['name'] == 'human_eye_clearance_segment':
        _tool['inputSchema']['properties']['response_detail'] = {
            'type': 'string', 'enum': ['full', 'brief'], 'default': 'full',
            'description': ('Optional endpoint display encoding. Brief preserves all receipt facts, '
                'diagnostics and native PNG bytes using exact references within this same result. '
                'The embedded JSON context is represented by its decoded values, not original string '
                'formatting. Historical, unsupported, conflicting or insufficiently smaller results '
                'retain full. This display option grants no execution authority.'),
        }


SPATIAL_TASK_TOOLS_SCHEMA = [{
    'name': 'human_eye_spatial_relations',
    'description': ('Read current solid relations and surface distances from a target to 1..3 explicit '
        'candidates in one capture. Returns each pair, penetrating candidates and nearest separated ties; '
        'unknowns and incomplete sets stay explicit. Surface distance is not penetration depth. '
        'A supported transverse crossing includes its captured triangles and an approximate boundary location when publishable. '
        'Read-only: no images or actions.'),
    'inputSchema': {'type': 'object', 'properties': {
        'target': copy.deepcopy(SELECTOR_SCHEMA),
        'candidates': {'type': 'array', 'items': copy.deepcopy(SELECTOR_SCHEMA), 'minItems': 1, 'maxItems': 3},
        'geometry': copy.deepcopy(_TASK_GEOMETRY_SCHEMA),
        'include_aabb': {'type': 'boolean', 'default': False}},
        'required': ['target', 'candidates'], 'additionalProperties': False}}, {
    'name': 'human_eye_surface_nearest',
    'description': ('Find the nearest triangle surfaces, in metres, from one current Blender mesh '
        'to all other meshes in the scene. Complete results give global nearest ties; partial '
        'results give best-known candidates and unresolved coverage. Surface distance is unsigned, '
        'not penetration depth. Includes available closest points in world metres and independent '
        'witness/direction status for each best-known candidate. Read-only: no images or actions. '
        'Example: {"target":{"name":"Bracket"}}.'),
    'annotations': {'readOnlyHint': True, 'destructiveHint': False,
                    'idempotentHint': True, 'openWorldHint': False},
    'inputSchema': {'type': 'object', 'properties': {
        'target': copy.deepcopy(SELECTOR_SCHEMA)},
        'required': ['target'], 'additionalProperties': False}}]


def _spatial_task_query(arguments):
    query = {'mode': 'task', 'target': arguments.get('target'), 'candidates': arguments.get('candidates'),
        'requested_facts': ['closed_solid_relation', 'surface_proximity']
            + (['aabb'] if arguments.get('include_aabb', False) else [])}
    if 'geometry' in arguments:
        query['geometry'] = arguments['geometry']
    return query


def _surface_nearest_task_query(arguments):
    return {'mode': 'surface_nearest', 'objects': [arguments.get('target')]}


def _rpc_error(request_id: Any, code: int, message: str) -> dict:
    return {"jsonrpc": "2.0", "id": request_id, "error": {"code": code, "message": message}}


def _validate_goal_arguments(goal, pair):
    """Validate goal structure now; the service binds it to real host identities.

    Temporary distinct IDs permit optional pair fields at this transport layer.
    They are never passed to the service or used as scene/authority defaults.
    """
    from .task_verification import _goal
    if not isinstance(goal, dict):
        raise ValueError("goal must be an object")
    candidate = copy.deepcopy(goal)
    used = {value for value in (*goal.values(), *pair.values()) if isinstance(value, str)}
    for field in ("focal_id", "reference_id"):
        if field in candidate and field in pair and candidate[field] != pair[field]:
            raise ValueError("goal." + field + " differs from the selected object pair")
        if field not in candidate:
            if field in pair:
                candidate[field] = pair[field]
            else:
                placeholder = "__unbound_goal_" + field + "__"
                while placeholder in used:
                    placeholder += "_"
                candidate[field] = placeholder
                used.add(placeholder)
    if ("target_focal_pivot_world_m" in candidate
            and not isinstance(candidate["target_focal_pivot_world_m"], list)):
        raise ValueError("goal.target_focal_pivot_world_m must be an array")
    _goal(candidate)


def _validate_arguments(name: str, arguments: Any) -> None:
    if not isinstance(arguments, dict):
        raise ValueError("arguments must be an object")
    allowed = {
        'human_eye_spatial_relations': {'target', 'candidates', 'include_aabb', 'geometry'},
        'human_eye_surface_nearest': {'target'},
        'human_eye_arm_twist_observe': {'selection', 'session_id', 'task_context'},
        "human_eye_scene_observe": {"task_instruction", "focal_id", "reference_id", "session_id", "goal", "query", 'task_context', 'scene_delta', 'response_detail', 'include_image'},
        "human_eye_transform": {"action", "session_id", "goal", 'task_context'},
        "human_eye_connection_status": set(),
        'human_eye_clearance_segment': {'session_id', 'request_id', 'request', 'execute', 'include_image', 'task_context', 'response_detail'},
    }
    if name not in allowed:
        raise ValueError(f"Unknown tool: {name}")
    if set(arguments) - allowed[name]:
        raise ValueError("Unexpected tool arguments")
    if name == 'human_eye_spatial_relations':
        if type(arguments.get('include_aabb', False)) is not bool:
            raise ValueError('include_aabb must be boolean')
        validate_query(_spatial_task_query(arguments))
        return
    if name == 'human_eye_surface_nearest':
        validate_query(_surface_nearest_task_query(arguments))
        return
    for field in ("session_id", "focal_id", "reference_id"):
        if field in arguments and (not isinstance(arguments[field], str) or not arguments[field].strip()):
            raise ValueError(f"{field} must be a nonempty string")
    if "task_instruction" in arguments and not isinstance(arguments["task_instruction"], str):
        raise ValueError("task_instruction must be a string")
    if name == 'human_eye_arm_twist_observe' and type(arguments.get('selection')) is not dict:
        raise ValueError('selection must be an object')
    if 'response_detail' in arguments and (not isinstance(arguments['response_detail'], str)
            or arguments['response_detail'] not in ('full', 'brief')):
        raise ValueError('response_detail must be full or brief')
    if "query" in arguments:
        selected_query = validate_query(arguments["query"])
    if name == 'human_eye_scene_observe':
        if 'include_image' in arguments and type(arguments['include_image']) is not bool:
            raise ValueError('include_image must be boolean')
        if 'query' not in arguments:
            selected_query = validate_query(None)
        if selected_query['mode'] == 'directory':
            if (arguments.get('include_image', True) or arguments.get('task_instruction', '')
                    or any(field in arguments for field in ('focal_id', 'reference_id', 'goal', 'scene_delta'))):
                raise ValueError('directory requires include_image=false and no instruction, pair, goal or scene_delta')
        if selected_query['mode'] == 'active_observation':
            if (arguments.get('task_instruction', '')
                    or any(field in arguments for field in ('focal_id', 'reference_id', 'goal', 'scene_delta'))):
                raise ValueError('active_observation accepts complete-scene observation without instruction, pair, goal or scene_delta')
        if selected_query['mode'] == 'surface_nearest':
            if 'objects' in selected_query and 'focal_id' in arguments:
                raise ValueError('surface_nearest accepts query.objects or focal_id, not both')
            if (not arguments.get('session_id') or ('objects' not in selected_query and not arguments.get('focal_id'))
                    or arguments.get('include_image', True)
                    or any(arguments.get(key) is not None for key in ('goal', 'reference_id', 'scene_delta'))):
                raise ValueError('surface_nearest requires session_id, one target, include_image=false and no reference, goal or scene_delta')
        if selected_query['mode'] == 'surface_scan':
            if (arguments.get('include_image', False)
                    or any(field in arguments for field in ('focal_id', 'reference_id', 'goal', 'scene_delta'))):
                raise ValueError('surface_scan accepts only text observation without pair selectors, goal or scene_delta')
        if (selected_query.get('alignment_evidence') is False
                and arguments.get('include_image', True)):
            raise ValueError('alignment_evidence=false requires include_image=false')
    if 'task_context' in arguments:
        if not isinstance(arguments['task_context'], dict):
            raise ValueError('task_context must be an object')
        validate_task_context(arguments['task_context'])
    if 'scene_delta' in arguments:
        if not isinstance(arguments['scene_delta'], dict):
            raise ValueError('scene_delta must be an object')
        validate_scene_delta_request(arguments['scene_delta'])
    if name == 'human_eye_clearance_segment':
        identity = arguments.get('request_id')
        if not isinstance(identity, str) or not identity.strip():
            raise ValueError('request_id is required')
        validate_clearance_segment_request(arguments.get('request'))
        for flag in ('execute', 'include_image'):
            if flag in arguments and type(arguments[flag]) is not bool:
                raise ValueError(flag + ' must be boolean')
        return
    if name != "human_eye_transform":
        if "goal" in arguments:
            _validate_goal_arguments(arguments["goal"],
                {field: arguments[field] for field in ("focal_id", "reference_id") if field in arguments})
        if (name == 'human_eye_scene_observe' and selected_query['mode'] == 'task'
                and (arguments.get('include_image', True)
                     or any(field in arguments for field in ('focal_id', 'reference_id', 'goal', 'scene_delta')))):
            raise ValueError('task queries require include_image=false and selectors only in query.objects or query.target/query.candidates')
        return
    action = arguments.get("action")
    if not isinstance(action, dict):
        raise ValueError("action must be an object")
    if (set(action) - set(_ACTION_SCHEMA["properties"])
            or not {"translation", "rotation_euler_deg"}.intersection(action)):
        raise ValueError("action requires an exact rigid transform")
    for field in ("focal_id", "reference_id"):
        if not isinstance(action.get(field), str) or not action[field].strip():
            raise ValueError(f"action.{field} must be a nonempty string")
    if action["focal_id"] == action["reference_id"]:
        raise ValueError("focal_id and reference_id must be distinct")
    for field in ("translation", "rotation_euler_deg"):
        if field not in action:
            continue
        vector = action[field]
        if (not isinstance(vector, list) or len(vector) != 3
                or any(type(value) not in (int, float) or not math.isfinite(value) for value in vector)):
            raise ValueError(f"action.{field} requires three finite numbers")
    if "goal" in arguments:
        _validate_goal_arguments(arguments["goal"],
            {field: action[field] for field in ("focal_id", "reference_id")})


def _project_capability_aliases(metadata):
    """Replace exact new-field wire duplicates; keep SDK results untouched."""
    target = '#/scene_capabilities'
    capability = metadata.get('scene_capabilities')
    routing = metadata.get('routing')
    marker = 'same_tool_result_metadata_json_pointer'
    if (not isinstance(capability, dict) or not isinstance(routing, dict)
            or metadata.get('capability_reference_encoding', marker) != marker):
        return
    def equal(value):
        try:
            return json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False) == json.dumps(
                capability, sort_keys=True, ensure_ascii=True, allow_nan=False)
        except (TypeError, ValueError, OverflowError, RecursionError):
            return False
    replaced = False
    if ('scene_capabilities' in routing and routing.get('scene_capabilities_ref', target) == target
            and equal(routing['scene_capabilities'])):
        routing.pop('scene_capabilities')
        routing['scene_capabilities_ref'] = target
        replaced = True
    facts, status = _parse_observation(routing.get('context_text'))
    if (status == 'structured' and 'scene_capabilities' in facts
            and facts.get('scene_capabilities_ref', target) == target
            and equal(facts['scene_capabilities'])):
        facts.pop('scene_capabilities')
        facts['scene_capabilities_ref'] = target
        routing['context_text'] = json.dumps(facts, ensure_ascii=False, allow_nan=False)
        replaced = True
    if replaced:
        metadata['capability_reference_encoding'] = marker


def _project_support_plane_discovery_aliases(metadata):
    """Keep compact selectors once, with exact same-result references.

    SDK evidence stays detached and complete. Only byte-equivalent new-field
    dictionaries are replaced; disagreement remains visible in full.
    """
    field = 'support_plane_discovery'
    target = '#/' + field
    discovery = metadata.get(field)
    routing = metadata.get('routing')
    marker = 'same_tool_result_metadata_json_pointer'
    if (not isinstance(discovery, dict) or not isinstance(routing, dict)
            or metadata.get('support_plane_reference_encoding', marker) != marker):
        return
    def equal(value):
        try:
            return json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False) == json.dumps(
                discovery, sort_keys=True, ensure_ascii=True, allow_nan=False)
        except (TypeError, ValueError, OverflowError, RecursionError):
            return False
    facts, status = _parse_observation(routing.get('context_text'))
    # Retain all conflicting original copies. Partial aliasing would hide the
    # route copy needed by the brief's contradiction check.
    if ((field in routing and not equal(routing[field]))
            or (status == 'structured' and field in facts and not equal(facts[field]))):
        return
    replaced = False
    if (field in routing and routing.get(field + '_ref', target) == target
            and equal(routing[field])):
        routing.pop(field)
        routing[field + '_ref'] = target
        replaced = True
    if (status == 'structured' and field in facts
            and facts.get(field + '_ref', target) == target and equal(facts[field])):
        facts.pop(field)
        facts[field + '_ref'] = target
        routing['context_text'] = json.dumps(facts, ensure_ascii=False, allow_nan=False)
        replaced = True
    if replaced:
        metadata['support_plane_reference_encoding'] = marker


def _compact_discovery_metadata(metadata):
    """Reversibly reference repeated major facts only for opted-in discovery.

    Reuses the Hook dictionary codec. References inside context_text target
    preceding structured metadata only, never a path through that JSON string.
    The compact selector itself remains a complete directly readable object.
    """
    marker = 'same_tool_result_metadata_json_pointer'
    if (metadata.get('support_plane_reference_encoding') != marker
            or not isinstance(metadata.get('support_plane_discovery'), dict)
            or 'support_plane_value_encoding' in metadata or _contains_reference_key(metadata)):
        return None
    route = metadata.get('routing')
    if not isinstance(route, dict):
        return None
    raw = route.get('context_text')
    facts = None
    if raw is not None:
        facts, status = _parse_observation(raw)
        if (status != 'structured' or _contains_reference_key(facts)
                or json.dumps(facts, ensure_ascii=False, allow_nan=False) != raw):
            return None
    known = {'query_result', 'rigid_frame', 'measurement', 'scene_contacts',
             'scene_assessment', 'scene_capabilities'}
    seen = {}
    def path_for(path, key):
        return path + '/' + key.replace('~', '~0').replace('/', '~1')
    def replace_known(value, path, catalog):
        return {key: (_deduplicate(item, path_for(path, key), catalog)
                      if key in known else copy.deepcopy(item))
                for key, item in value.items()}
    # Canonical top fields precede routing, whose own structured facts precede
    # context_text; a parsed brief observation comes last. No forward scope.
    ordered = {key: value for key, value in metadata.items() if key not in ('routing', 'observation')}
    result = replace_known(ordered, '#', seen)
    route_fields = {key: value for key, value in route.items() if key != 'context_text'}
    result['routing'] = replace_known(route_fields, '#/routing', seen)
    if facts is not None:
        class ExistingMetadataOnly(dict):
            # New dictionaries seen in the decoded string cannot become
            # physical JSON Pointer targets. Existing metadata is read-only.
            def __setitem__(self, key, value):
                pass
        catalog = ExistingMetadataOnly(seen)
        replaced = replace_known(facts, '#/decoded_context_text', catalog)
        result['routing']['context_text'] = json.dumps(replaced, ensure_ascii=False, allow_nan=False)
    if 'observation' in metadata:
        observation = metadata['observation']
        if not isinstance(observation, dict):
            return None
        result['observation'] = replace_known(observation, '#/observation', seen)
    header = {'revision': 'discovery-major-fact-references-v1-20261028',
        'reference_encoding': 'local_pointer_with_object_id',
        'reference_base': 'this_same_tool_result_metadata',
        'context_text_reference_base': 'enclosing_metadata_not_the_decoded_string',
        'context_text_serialization': 'json.dumps_ensure_ascii_false_default_separators' if facts is not None else None,
        'scope': 'exact_value_transport_only_no_geometry_or_authority_change',
        'execution_authority': False}
    return {'support_plane_value_encoding': header, **result}


def _project_spatial_relations(value):
    """Same facts, with request rows and shared metadata written only once."""
    if value.get('schema_version') != 'task-query-set-v1':
        return value
    binding = value['binding']
    rows = [dict(row) for row in binding['objects']]
    context = {key: item for key, item in binding.items() if key not in ('objects', 'host_identity')}
    context.update(scope=value['scope'], unit=value['unit'], coordinate_frame=value['coordinate_frame'],
                   pair_order=value['pair_order'])
    host = binding.get('host_identity')
    if host is not None:
        instances = host.get('object_instances', {})
        for row in rows:
            if row.get('object_id') in instances:
                row['instance_id'] = instances[row['object_id']]
        remaining = {oid: instance for oid, instance in instances.items()
                     if not any(row.get('object_id') == oid for row in rows)}
        context['host_identity'] = {key: item for key, item in host.items()
            if key != 'object_instances' and not (key == 'capture_scope' and item == context.get(key))}
        if remaining:
            context['host_identity']['object_instances'] = remaining
        context['identity_scope'] = 'Object and instance IDs belong to this captured document/snapshot.'
    boxes = value['facts'].get('aabb')
    if boxes is not None:
        for row, box in zip(rows, boxes):
            row['aabb'] = box
    pairs = value['pairs']
    contracts = {}
    for name in ('closed_solid_relation', 'surface_proximity', 'separation_gap'):
        facts = [pair['separation_gap'] if name == 'separation_gap' else pair['facts'][name]
                 for pair in pairs]
        common = {key: facts[0][key] for key in
                  ('method', 'semantics', 'geometry_scope', 'relation_tolerance_m')
                  if key in facts[0] and all(key in fact and fact[key] == facts[0][key] for fact in facts)}
        if common:
            contracts[name] = common
        for pair, fact in zip(pairs, facts):
            row = rows[pair['candidate_index'] + 1]
            row['candidate_index'] = pair['candidate_index']
            row[name] = {key: item for key, item in fact.items() if key not in common}
    if any('certificate' in row['closed_solid_relation'] for row in rows[1:]):
        context['certificate_scope'] = ('Certificate category with local evidence when available. '
            'Transverse evidence identifies current captured triangles and approximates their boundary crossing; '
            'the exact midpoint is on both boundaries, not in their shared volume interior. '
            'Neither a boundary location nor surface distance is penetration depth.')
    indices = {row['object_id']: row['candidate_index'] for row in rows[1:] if 'object_id' in row}
    def candidate_indices(ids):
        return None if ids is None else [indices[oid] for oid in ids]
    summary = value['summary']
    penetrating = {'complete': summary['penetration_set_complete'],
                   'candidate_indices': candidate_indices(summary['penetrating_ids'])}
    if summary['known_penetrating_ids'] != summary['penetrating_ids']:
        penetrating['known_candidate_indices'] = candidate_indices(summary['known_penetrating_ids'])
    if summary['unresolved_relations']:
        penetrating['unresolved'] = summary['unresolved_relations']
    nearest = {'complete': summary['nearest_separated_complete'],
               'candidate_indices': candidate_indices(summary['nearest_separated_ids']),
               'distance_m': summary['distance_m']}
    if (summary['best_known_separated_ids'] != summary['nearest_separated_ids']
            or summary['best_known_distance_m'] != summary['distance_m']):
        nearest.update(best_known_candidate_indices=candidate_indices(summary['best_known_separated_ids']),
                       best_known_distance_m=summary['best_known_distance_m'])
    if summary['unresolved_distances']:
        nearest['unresolved_distances'] = [dict(candidate_index=indices[oid], reason=reason)
            for oid, reason in summary['unresolved_distances'].items()]
    result = {'result_kind': value['result_kind'], 'schema_version': 'spatial-relations-v1',
        'status': value['status'], 'target': rows[0], 'candidates': rows[1:],
        'sets': {'penetrating': penetrating, 'nearest_separated': nearest},
        'coverage': value['coverage'], 'context': context, 'measurement_contracts': contracts,
        'execution_authority': value['execution_authority']}
    if 'trace_id' in value:
        result['trace_id'] = value['trace_id']
    if 'geometry' in value:
        result['geometry'] = value['geometry']
    return result


def project_surface_scan_brief(value):
    """Project delivered scan facts into a detached, source-bound display table."""
    display_fields = ('display_encoding', 'objects', 'object_table_scope', 'object_reference',
                      'match_columns', 'match_metadata', 'match_exceptions',
                      'match_metadata_semantics', 'distance_mm_semantics', 'detail')
    if (type(value) is not dict or value.get('result_kind') != 'surface_scan'
            or value.get('status') not in ('complete', 'partial', 'unknown')
            or value.get('unit') != 'm' or value.get('coordinate_frame') != 'world'
            or type(value.get('matches')) is not list
            or any(field in value for field in display_fields)):
        return None
    objects = []
    object_refs = {}
    matches = []
    annotations = []
    for match in value['matches']:
        if (type(match) is not dict or type(match.get('objects')) is not list
                or len(match['objects']) != 2
                or type(match.get('distance_m')) not in (int, float)):
            return None
        distance = match['distance_m']
        if distance < 0 or type(distance) is float and not math.isfinite(distance):
            return None
        refs = []
        for obj in match['objects']:
            if (type(obj) is not dict or type(obj.get('id')) is not str or not obj['id']
                    or type(obj.get('name')) is not str):
                return None
            object_id = obj['id']
            if object_id not in object_refs:
                object_refs[object_id] = len(objects)
                objects.append(copy.deepcopy(obj))
            reference = object_refs[object_id]
            if json.dumps(objects[reference], ensure_ascii=False, allow_nan=False) != json.dumps(
                    obj, ensure_ascii=False, allow_nan=False):
                return None
            refs.append(reference)
        for key in ('point_a_world', 'point_b_world'):
            if key in match:
                point = match[key]
                if (type(point) is not list or len(point) != 3
                        or any(type(number) not in (int, float)
                               or type(number) is float and not math.isfinite(number)
                               for number in point)):
                    return None
        distance_mm = distance * 1000
        if type(distance_mm) is float and not math.isfinite(distance_mm):
            # A finite binary64 this large already has integral metre value.
            distance_mm = str(int(distance) * 1000)
        matches.append([match['objects'][0]['name'], match['objects'][1]['name'],
                        refs[0], refs[1], distance, distance_mm])
        annotations.append({key: copy.deepcopy(item) for key, item in match.items()
                            if key not in ('objects', 'distance_m', 'point_a_world', 'point_b_world')})
    encoded_annotations = [
        {key: json.dumps(item, ensure_ascii=False, allow_nan=False, separators=(',', ':'))
         for key, item in annotation.items()} for annotation in annotations]
    common = {}
    if annotations:
        common = {key: item for key, item in annotations[0].items()
                  if all(annotation.get(key) == encoded_annotations[0][key]
                         for annotation in encoded_annotations)}
    exceptions = []
    for index, annotation in enumerate(annotations):
        varying = {key: item for key, item in annotation.items() if key not in common}
        if varying:
            exceptions.append({'match_index': index, 'metadata': varying})
    result = {key: copy.deepcopy(item) for key, item in value.items() if key != 'matches'}
    result.update(display_encoding='surface-scan-task-table-v1', objects=objects,
        object_table_scope='matched_endpoints_only',
        object_reference='zero_based_index_in_objects; scoped_to_this_result_binding',
        match_columns=['object_a', 'object_b', 'object_a_ref', 'object_b_ref', 'distance_m', 'distance_mm'],
        matches=matches, match_metadata=common, match_exceptions=exceptions,
        match_metadata_semantics='common_fields_apply_to_every_match; merge_exceptions_by_zero_based_match_index',
        distance_mm_semantics='derived_display_only; number_or_exact_decimal_string_on_binary64_overflow; '
                              'threshold_membership_uses_original_distance_m',
        detail='response_detail=full requests a new current observation with witnesses; compare binding before combining')
    return result


def _project_active_patch_support(patch_support, objects, regions):
    """Keep complete source-face denominators while displaying component ranges."""
    if set(patch_support) != {'schema', 'triangle_index_scope', 'all_triangles_participate_in_occlusion',
                              'objects', 'regions'} or patch_support['schema'] != 'active-patch-support-v1':
        raise ValueError('unsupported_active_patch_support')
    mapping = patch_support['regions']
    if len(mapping) != len(regions):
        raise ValueError('active_patch_region_mapping_mismatch')
    region_counts, region_faces = [], [set() for _ in objects]
    for source, region in zip(mapping, regions):
        if (set(source) != {'roi_id', 'object_index', 'triangle_indices'}
                or source['roi_id'] != region['roi_id'] or type(source['object_index']) is not int
                or source['object_index'] != region['object_index']):
            raise ValueError('active_patch_region_mapping_mismatch')
        faces = source['triangle_indices']
        indices = set(faces)
        owned = region_faces[region['object_index']]
        if (not indices or len(indices) != len(faces) or owned & indices
                or any(type(index) is not int for index in faces)):
            raise ValueError('active_patch_region_triangle_overlap')
        owned.update(indices)
        region_counts.append(len(indices))
    support_rows, component_rows = [], []
    sources = patch_support['objects']
    object_fields = {'object_index', 'host_id', 'instance_id', 'object_name'}
    partition_fields = {'source_triangle_count', 'supported_triangle_count', 'supported_triangle_indices',
                        'unsupported_triangle_count', 'unsupported_components', 'support_status'}
    if len(sources) != len(objects):
        raise ValueError('active_patch_object_mapping_mismatch')
    for index, source in enumerate(sources):
        if (set(source) != object_fields | partition_fields or type(source['object_index']) is not int
                or any(source[key] != objects[index][key] for key in object_fields)
                or any(type(source[key]) is not int or source[key] < 0 for key in
                       ('source_triangle_count', 'supported_triangle_count', 'unsupported_triangle_count'))):
            raise ValueError('active_patch_object_mapping_mismatch')
        total = source['source_triangle_count']
        supported = set(source['supported_triangle_indices'])
        rejected = set()
        for component_index, component in enumerate(source['unsupported_components']):
            if (set(component) != {'triangle_indices', 'reason', 'status'}
                    or component['status'] != 'unknown' or type(component['reason']) is not str
                    or not component['reason']):
                raise ValueError('active_patch_component_mismatch')
            faces = component['triangle_indices']
            indices = set(faces)
            if (not indices or len(indices) != len(faces) or rejected & indices
                    or any(type(face) is not int for face in faces)):
                raise ValueError('active_patch_component_mismatch')
            rejected.update(indices)
            ranges = []
            for triangle_index in sorted(indices):
                if ranges and triangle_index == ranges[-1][1] + 1:
                    ranges[-1][1] = triangle_index
                else:
                    ranges.append([triangle_index, triangle_index])
            component_rows.append([index, component_index, len(indices), component['reason'],
                                   component['status'], ranges])
        expected_status = ('unsupported' if not supported else
                           'partially_supported' if rejected else 'fully_supported')
        if (len(supported) != len(source['supported_triangle_indices'])
                or any(type(face) is not int for face in source['supported_triangle_indices'])
                or supported != region_faces[index] or supported & rejected
                or supported | rejected != set(range(total))
                or source['supported_triangle_count'] != len(supported)
                or source['unsupported_triangle_count'] != len(rejected)
                or source['support_status'] != expected_status):
            raise ValueError('active_patch_triangle_denominator_mismatch')
        support_rows.append([index, total, len(supported), len(rejected), expected_status])
    result = {key: patch_support[key] for key in
              ('schema', 'triangle_index_scope', 'all_triangles_participate_in_occlusion')}
    result['object_support'] = {
        'columns': ['object_index', 'source_triangle_count', 'supported_triangle_count',
                    'unsupported_triangle_count', 'support_status'],
        'rows': support_rows,
    }
    if component_rows:
        result['unsupported_components'] = {
            'columns': ['object_index', 'component_index', 'triangle_count', 'reason', 'status',
                        'triangle_index_ranges'],
            'rows': component_rows,
        }
    return result, region_counts


def _valid_region_location_vector(values):
    if type(values) is not list or len(values) != 3:
        return False
    for value in values:
        if type(value) not in (int, float, str) or type(value) is float and not math.isfinite(value):
            return False
        if type(value) is str:
            try:
                Fraction(value)
            except (ValueError, ZeroDivisionError):
                return False
    return True


def _valid_visible_pixel_location(pixel, size):
    bounds, anchor = pixel['visible_pixel_bounds'], pixel['visible_pixel_anchor']
    if pixel['visible_surface_pixels'] == 0:
        return bounds is None and anchor is None
    if (type(bounds) is not list or len(bounds) != 4 or type(anchor) is not list or len(anchor) != 2
            or any(type(value) is not int for value in bounds + anchor)):
        return False
    xmin, ymin, xmax, ymax = bounds
    return (0 <= xmin <= anchor[0] <= xmax < size[0]
            and 0 <= ymin <= anchor[1] <= ymax < size[1])


def project_active_observation_brief(value):
    """Deduplicate one complete active result using versioned, local table indices.

    Empty tables and coverage collections are omitted. Indices are zero-based;
    native_content_block_index addresses the actual MCP content list, whose
    first image follows its text at index one. Unsupported or conflicting
    references retain the full response through the caller's existing path.
    """
    object_columns = ['object_index', 'host_id', 'instance_id', 'object_name']
    region_columns = ['roi_id', 'object_index', 'status', 'reason']
    pixel_columns = ['image_index', 'region_index', 'front_facing',
                     'visible_surface_pixels', 'contrasting_boundary_pixels', 'readable']
    rule_fields = ('minimum_surface_pixels', 'minimum_boundary_pixels', 'minimum_rgb_boundary_contrast')
    identity_fields = ('host_id', 'instance_id', 'object_name')
    world_fields = ('center_world_m', 'half_edge_u_world_m', 'half_edge_v_world_m', 'front_direction_world')
    location_fields = ('visible_pixel_bounds', 'visible_pixel_anchor')
    try:
        if (value['result_kind'] != 'active_observation'
                or value['status'] not in ('complete', 'partial', 'unknown', 'predicted')):
            return None
        binding, facts = value['binding'], value['facts']
        required_binding = {
            'scene_revision', 'document_epoch', 'capture_scope', 'unit', 'coordinate_frame',
            'source', 'capture_state', 'source_binding_sha256', 'geometry_identity',
            'camera_identity', 'binding_sha256', 'runtime_source_sha256',
            'source_status', 'disk_status', 'source_check_scope', 'objects',
        }
        if (type(binding) is not dict or not required_binding <= set(binding)
                or set(binding) - required_binding - {'schema', 'camera_policy'}):
            return None
        capture_state = binding['capture_state']
        if capture_state is not None and (
                type(capture_state) is not dict
                or not {'instance_id', 'epoch', 'revision'} <= set(capture_state)
                or set(capture_state) - {'instance_id', 'epoch', 'revision', 'selection_key'}):
            return None
        located = 'location_conventions' in facts
        fact_fields = {'scene_identity', 'candidate_identity', 'regions', 'observations',
                       'coverage', 'scope', 'image_delivery_scope'}
        if (set(facts) != fact_fields | ({'location_conventions'} if located else set())
                or facts['scene_identity'] != binding['geometry_identity']
                or facts['candidate_identity'] != binding['camera_identity']):
            return None
        objects = binding['objects']
        if (not objects or any(set(obj) != set(object_columns) or type(obj['object_index']) is not int
                              or obj['object_index'] != index
                              for index, obj in enumerate(objects))
                or len({obj['host_id'] for obj in objects}) != len(objects)
                or len({obj['instance_id'] for obj in objects}) != len(objects)):
            return None
        regions = facts['regions']
        if located:
            conventions = facts['location_conventions']
            if (set(conventions) != {'coordinate_frame', 'unit', 'corner_order', 'front_direction_normalization',
                    'pixel_origin', 'pixel_index_base', 'pixel_axis_order', 'image_size_px',
                    'visible_pixel_bounds', 'visible_pixel_anchor'}
                    or conventions['coordinate_frame'] != binding['coordinate_frame']
                    or conventions['unit'] != binding['unit']
                    or conventions['corner_order'] != ['center-u-v', 'center+u-v', 'center+u+v', 'center-u+v']
                    or conventions['front_direction_normalization'] != 'maximum absolute component is 1'
                    or conventions['pixel_origin'] != 'top-left' or type(conventions['pixel_index_base']) is not int
                    or conventions['pixel_index_base'] != 0 or conventions['pixel_axis_order'] != ['x', 'y']
                    or conventions['visible_pixel_bounds'] != 'inclusive bounds of actual ROI-owned pixels'
                    or conventions['visible_pixel_anchor'] != 'ROI-owned pixel nearest bounds center; row-major ties'):
                return None
            image_size = conventions['image_size_px']
            if (type(image_size) is not list or len(image_size) != 2
                    or any(type(size) is not int or not 64 <= size <= 512 for size in image_size)):
                return None
        region_indices = {region['roi_id']: index for index, region in enumerate(regions)}
        if len(region_indices) != len(regions):
            return None
        for region in regions:
            if (set(region) != set(region_columns) | set(identity_fields) | (set(world_fields) if located else set())
                    or type(region['object_index']) is not int
                    or not 0 <= region['object_index'] < len(objects)
                    or any(region[key] != objects[region['object_index']][key] for key in identity_fields)):
                return None
            if located and not all(_valid_region_location_vector(region[key]) for key in world_fields):
                return None

        def region_references(ids):
            if type(ids) is not list or len(set(ids)) != len(ids):
                raise ValueError('nonunique_region_reference')
            return [region_indices[roi_id] for roi_id in ids]

        coverage = facts['coverage']
        coverage_lists = {
            'covered_roi_ids': 'covered_region_indices',
            'unresolved_roi_ids': 'unresolved_region_indices',
            'candidate_pool_uncovered_roi_ids': 'candidate_pool_uncovered_region_indices',
        }
        if set(coverage) != set(coverage_lists) | {'scope', 'state_updates', 'observed_views'}:
            return None
        compact_coverage = {key: coverage[key] for key in ('scope', 'state_updates')}
        for key, projected_key in coverage_lists.items():
            references = region_references(coverage[key])
            if references:
                compact_coverage[projected_key] = references
        if coverage['observed_views']:
            compact_coverage['observed_views'] = coverage['observed_views']
        if set(coverage['covered_roi_ids']) & set(coverage['unresolved_roi_ids']):
            return None

        scope = facts['scope']
        patch_support = scope.get('patch_support')
        scope_fields = {'capture_object_count', 'supported_roi_object_count', 'domain',
                        'all_objects_participate_in_occlusion', 'objects_without_supported_roi'}
        if (set(scope) != scope_fields | ({'patch_support'} if patch_support is not None else set())
                or scope['capture_object_count'] != len(objects)):
            return None
        unsupported = scope['objects_without_supported_roi']
        unsupported_indices = []
        for obj in unsupported:
            index = obj['object_index']
            if (set(obj) != set(object_columns) | {'status'} or type(index) is not int
                    or not 0 <= index < len(objects)
                    or any(obj[key] != objects[index][key] for key in identity_fields)):
                return None
            unsupported_indices.append(index)
        supported_indices = {region['object_index'] for region in regions}
        if (len(set(unsupported_indices)) != len(unsupported_indices)
                or set(unsupported_indices) != set(range(len(objects))) - supported_indices
                or scope['supported_roi_object_count'] != len(supported_indices)):
            return None
        compact_scope = {key: item for key, item in scope.items() if key != 'objects_without_supported_roi'}
        if unsupported:
            compact_scope['objects_without_supported_roi'] = {
                'columns': ['object_index', 'status'],
                'rows': [[obj['object_index'], obj['status']] for obj in unsupported],
            }
        region_counts = None
        if patch_support is not None:
            compact_scope['patch_support'], region_counts = _project_active_patch_support(patch_support, objects, regions)

        frames = value['frames']
        image_indices = {frame['image_ref']: index for index, frame in enumerate(frames)}
        if (len(image_indices) != len(frames)
                or len({frame['view_name'] for frame in frames}) != len(frames)):
            return None
        for frame in frames:
            if (frame['scene_identity'] != binding['geometry_identity']
                    or frame['candidate_identity'] != binding['camera_identity']
                    or frame['host_binding_sha256'] != binding['binding_sha256']
                    or frame['source_revision'] != binding['scene_revision']):
                return None
        if patch_support is not None:
            for frame in frames:
                if (frame['patch_mapping_version'] != 'active-patch-owner-v1'
                        or frame['patch_roi_ids'] != [region['roi_id'] for region in regions]
                        or type(frame['patch_mapping_identity']) is not str or not frame['patch_mapping_identity']
                        or frame['patch_mapping_identity'] != frames[0]['patch_mapping_identity']):
                    return None
        observation_rows, pixels, pixel_rules, observed_indices = [], [], None, []
        for observation in facts['observations']:
            if set(observation) != {'view_name', 'image_path', 'image_ref', 'image_sha256',
                                    'readable_roi_ids', 'pixel_rows'}:
                return None
            image_index = image_indices[observation['image_ref']]
            frame = frames[image_index]
            if any(observation[key] != frame[key] for key in ('view_name', 'image_path', 'image_sha256')):
                return None
            observed_indices.append(image_index)
            observation_rows.append([image_index, region_references(observation['readable_roi_ids'])])
            seen_regions, readable_ids = set(), set()
            for pixel in observation['pixel_rows']:
                expected_pixel_fields = set(rule_fields) | {
                        'roi_id', 'object_index', 'host_id', 'object_name', 'view',
                        'front_facing', 'visible_surface_pixels', 'contrasting_boundary_pixels', 'readable'}
                if set(pixel) != expected_pixel_fields | (set(location_fields) if located else set()):
                    return None
                if located and not _valid_visible_pixel_location(pixel, image_size):
                    return None
                region_index = region_indices[pixel['roi_id']]
                region = regions[region_index]
                if (region_index in seen_regions or pixel['view'] != observation['view_name']
                        or any(pixel[key] != region[key] for key in ('object_index', 'host_id', 'object_name'))):
                    return None
                seen_regions.add(region_index)
                rules = {key: pixel[key] for key in rule_fields}
                if pixel_rules is None:
                    pixel_rules = rules
                elif rules != pixel_rules:
                    return None
                if pixel['readable']:
                    readable_ids.add(pixel['roi_id'])
                pixels.append([image_index, region_index, *[pixel[key] for key in pixel_columns[2:]],
                               *[pixel[key] for key in location_fields if located]])
            if (seen_regions != set(range(len(regions)))
                    or readable_ids != set(observation['readable_roi_ids'])):
                return None
        if (len(set(observed_indices)) != len(frames) or sorted(observed_indices) != list(range(len(frames)))
                or coverage['observed_views'] != [row['view_name'] for row in facts['observations']]):
            return None
        compact_binding = {key: item for key, item in binding.items()
                           if key not in ('schema', 'objects', 'camera_policy')}
        if type(compact_binding.get('capture_state')) is dict:
            compact_binding['capture_state'] = {key: item for key, item in binding['capture_state'].items()
                                                if key != 'selection_key'}
        result = {key: value[key] for key in ('status', 'result_kind', 'observation_status',
                                             'session_id', 'read_only', 'execution_authority')}
        result.update(schema='active-observation-brief-v2' if patch_support is not None else 'active-observation-brief-v1', index_base=0,
            binding=compact_binding,
            objects={'columns': object_columns, 'rows': [[obj[key] for key in object_columns] for obj in objects]},
            coverage=compact_coverage, scope=compact_scope,
            image_delivery_scope=facts['image_delivery_scope'], image_delivery=value['image_delivery'])
        if regions:
            result['regions'] = {'columns': region_columns,
                                 'rows': [[region[key] for key in region_columns] for region in regions]}
            if region_counts is not None:
                result['regions']['columns'].append('triangle_count')
                for row, count in zip(result['regions']['rows'], region_counts):
                    row.append(count)
            if located:
                result['regions']['columns'].extend(world_fields)
                for row, region in zip(result['regions']['rows'], regions):
                    row.extend(region[key] for key in world_fields)
        if frames:
            result['images'] = {
                'columns': ['view_name', 'image_ref', 'image_sha256', 'native_content_block_index'],
                'rows': [[frame['view_name'], frame['image_ref'], frame['image_sha256'], index + 1]
                         for index, frame in enumerate(frames)],
            }
            result['observations'] = {'columns': ['image_index', 'readable_region_indices'], 'rows': observation_rows}
            if patch_support is not None:
                result['patch_mapping_version'] = frames[0]['patch_mapping_version']
                result['images']['columns'].append('patch_mapping_identity')
                for row, frame in zip(result['images']['rows'], frames):
                    row.append(frame['patch_mapping_identity'])
        if pixels:
            result['pixels'] = {'columns': pixel_columns + (list(location_fields) if located else []), 'rows': pixels}
            result['pixel_rules'] = pixel_rules
        if located:
            result['schema'] = 'active-observation-brief-v3'
            result['location_conventions'] = conventions
        return copy.deepcopy(result)
    except (KeyError, TypeError, IndexError, AttributeError, ValueError):
        return None


def _active_observation_content(value, *, is_error, audit, response_detail=None):
    started = time.perf_counter_ns()
    audit.update(status='encoding', started_ns=started, frames=[],
        native_blocks_constructed=0, mcp_content_ready=False,
        consumer_read_status='unconfirmed')
    metadata = {key: copy.deepcopy(value[key]) for key in (
        'status', 'result_kind', 'observation_status', 'session_id', 'facts',
        'work', 'generation_work', 'stages', 'generation_stages',
        'read_only', 'execution_authority',
    ) if key in value}
    if 'binding' in value:
        metadata['binding'] = {key: copy.deepcopy(item) for key, item in value['binding'].items()
            if key != 'camera_specification'}
    frames = value.get('frames')
    content = []
    try:
        if type(frames) is not list or len(frames) > 6:
            raise ValueError('Active observation requires at most six frame references')
        metadata['frames'] = [{key: copy.deepcopy(frame[key]) for key in (
            'scene_identity', 'candidate_identity', 'view_name', 'image_ref',
            'image_path', 'image_sha256', 'PNG_bytes', 'arrays_path', 'arrays_sha256',
            'compressed_array_file_bytes', 'array_payload_bytes',
            'host_binding_sha256', 'source_revision', 'stages', 'feedback_stages',
            'patch_mapping_version', 'patch_roi_ids', 'patch_mapping_identity',
            'patch_owner_array_bytes', 'patch_mapping_array_bytes',
        ) if key in frame} for frame in frames]
        for frame in frames:
            row = {'image_ref': frame.get('image_ref'), 'view_name': frame.get('view_name'),
                   'PNG_bytes_read': 0, 'base64_chars': 0, 'status': 'reading'}
            audit['frames'].append(row)
            mark = time.perf_counter_ns()
            raw = Path(frame['image_path']).read_bytes()
            row.update(read_ns=time.perf_counter_ns()-mark, PNG_bytes_read=len(raw))
            mark = time.perf_counter_ns()
            if hashlib.sha256(raw).hexdigest() != frame['image_sha256']:
                raise ValueError('Active observation PNG source binding changed')
            public = _public_native_png(raw)
            if public != raw or public[16:24] != b'\x00\x00\x02\x00\x00\x00\x02\x00':
                raise ValueError('Active observation requires the registered 512px PNG bytes')
            row.update(validate_ns=time.perf_counter_ns()-mark, status='encoding')
            mark = time.perf_counter_ns()
            data = base64.b64encode(public).decode('ascii')
            row.update(base64_ns=time.perf_counter_ns()-mark, base64_chars=len(data), status='constructed')
            content.append({'type': 'image', 'mimeType': 'image/png', 'data': data})
            audit['native_blocks_constructed'] = len(content)
        metadata['image_delivery'] = {
            'local_verified_image_count': len(frames),
            'mcp_content_constructed_image_count': len(content),
            'consumer_read_status': 'unconfirmed',
            'frame_reuses': value.get('work', {}).get('frame_reuses', 0),
            'new_raster_attempts': value.get('work', {}).get('raster_attempts', 0),
        }
        audit['projection_status'] = 'full_requested' if response_detail == 'full' else 'unsupported_full'
        if response_detail != 'full' and not is_error:
            brief = project_active_observation_brief(metadata)
            if brief is not None:
                metadata = brief
                audit['projection_status'] = 'brief'
        text = json.dumps(metadata, ensure_ascii=False, allow_nan=False, separators=(',', ':'))
        audit.update(status='constructed', mcp_content_ready=True,
            public_text_bytes=len(text.encode('utf8')),
            PNG_bytes=sum(row['PNG_bytes_read'] for row in audit['frames']),
            base64_chars=sum(row['base64_chars'] for row in audit['frames']))
        record_image_artifact('mcp_content', native_block_count=len(content))
        return {'content': [{'type': 'text', 'text': text}, *content], 'isError': bool(is_error)}
    except Exception as error:
        audit.update(status='failed', error={'type': type(error).__name__, 'message': str(error)[:1000]})
        record_image_artifact('mcp_content', native_block_count=0)
        raise
    finally:
        audit['closed_ns'] = time.perf_counter_ns()
        audit['elapsed_ns'] = audit['closed_ns'] - started


def _tool_result(value: Any, *, is_error: bool, response_detail: str | None = None,
                 compact_support_planes: bool = False, segment_brief: bool = False,
                 active_delivery_audit=None) -> dict:
    if not isinstance(value, dict):
        raise ValueError("Live service returned an invalid result")
    if value.get('result_kind') == 'active_observation':
        return _active_observation_content(value, is_error=is_error,
            audit={} if active_delivery_audit is None else active_delivery_audit,
            response_detail=response_detail)
    if response_detail is None:
        response_detail = 'brief' if value.get('result_kind') == 'surface_scan' else 'full'
    if (value.get('result_kind') in ('task_query', 'surface_nearest', 'surface_scan', 'scene_directory')
            or value.get('schema') == 'arm-twist-expert-report-v1'):
        # Validate the complete response before optional display-only omission.
        text = json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(',', ':'))
        if value.get('result_kind') == 'surface_scan' and response_detail == 'brief' and not is_error:
            try:
                with span('mcp.surface_scan_compact_projection'):
                    compact = project_surface_scan_brief(value)
                if compact is not None:
                    text = json.dumps(compact, ensure_ascii=False, allow_nan=False, separators=(',', ':'))
                    annotate(surface_scan_display='compact')
                else:
                    annotate(surface_scan_display='full_unsupported_projection')
            except Exception as error:
                annotate(surface_scan_display='full_projection_fallback',
                         surface_scan_display_error=type(error).__name__)
        record_image_artifact('mcp_content', native_block_count=0)
        return {'content': [{'type': 'text', 'text': text}], 'isError': bool(is_error)}
    metadata = copy.deepcopy(value)
    _project_capability_aliases(metadata)
    _project_support_plane_discovery_aliases(metadata)
    routing = metadata.get("routing")
    picture = routing.pop("image", None) if isinstance(routing, dict) else None
    pictures = routing.pop("images", None) if isinstance(routing, dict) else None
    content = []
    if pictures is not None:
        if picture is not None or type(pictures) is not list or not 1<=len(pictures)<=2:
            raise ValueError('Live service returned an invalid native image bundle')
        staged=[]
        for image in pictures:
            if (type(image) is not dict or set(image)!={'type','mimeType','data'}
                    or image['type']!='image' or image['mimeType']!='image/png'
                    or type(image['data']) is not str or len(image['data'])>4*((8*1024*1024+2)//3)):
                raise ValueError('Live service returned an invalid native PNG content block')
            decoded=_public_native_png(base64.b64decode(image['data'],validate=True))
            if decoded[16:24]!=b'\x00\x00\x01\x80\x00\x00\x01\x80':
                raise ValueError('Live service returned an invalid native PNG shape')
            staged.append({'type':'image','mimeType':'image/png','data':base64.b64encode(decoded).decode('ascii')})
        content.extend(staged)
    if picture is not None:
        if (not isinstance(picture, dict) or picture.get("type") != "image"
                or picture.get("mimeType") != "image/png" or not isinstance(picture.get("data"), str)):
            raise ValueError("Live service returned an invalid PNG content block")
        try:
            decoded = base64.b64decode(picture["data"], validate=True)
        except (ValueError, TypeError) as exc:
            raise ValueError("Live service returned invalid image data") from exc
        if not decoded.startswith(b"\x89PNG\r\n\x1a\n"):
            raise ValueError("Live service returned invalid PNG data")
        content.append({"type": "image", "mimeType": "image/png", "data": picture["data"]})
    # Keep image bytes in a native MCP image block only, rather than repeating
    # base64 in the JSON text the model needs to read.
    full_text = json.dumps(metadata, ensure_ascii=False, allow_nan=False)
    if metadata.get('result_kind') in ('structure_task','surface_task') and 'accounted_public_text_bytes' in metadata:
        charge=metadata['accounted_public_text_bytes']
        if type(charge) is not int or not len(full_text.encode('utf8'))<=charge<=96*1024:
            raise ValueError('Structure task text exceeds its committed charge')
    text = full_text
    selected_metadata = metadata
    if response_detail == 'brief' and not is_error:
        try:
            brief = (project_structure_brief(metadata) if metadata.get('result_kind')=='structure_task' else
                None if metadata.get('result_kind')=='surface_task' else project_segment_brief(metadata) if segment_brief else project_task_brief(metadata))
            if brief is not None:
                candidate = json.dumps(brief, ensure_ascii=False, allow_nan=False, separators=(',', ':'))
                full_bytes = len(full_text.encode('utf-8'))
                brief_bytes = len(candidate.encode('utf-8'))
                # A request for less detail must actually save transport bytes.
                # This threshold is representation policy, never a geometry gate.
                if full_bytes - brief_bytes >= 256 and brief_bytes <= full_bytes * .9:
                    text = candidate
                    selected_metadata = brief
        except Exception:
            # Only the optional display projection is recoverable. Original
            # full JSON and native PNG validation above must still succeed.
            text = full_text
    if compact_support_planes and not is_error:
        try:
            compact = _compact_discovery_metadata(selected_metadata)
            if compact is not None:
                encoded = json.dumps(compact, ensure_ascii=False, allow_nan=False, separators=(',', ':'))
                if len(encoded.encode('utf-8')) < len(text.encode('utf-8')):
                    text = encoded
        except Exception:
            # Encoding can only fall back to the unchanged complete payload.
            pass
    content.insert(0, {"type": "text", "text": text})
    if metadata.get('result_kind') in ('structure_task','surface_task') and 'task_budget' in metadata:
        budget=metadata['task_budget']
        if (type(budget) is not dict or type(budget.get('deadline_ns')) is not int
                or type(budget.get('deadline_wall_ns')) is not int
                or time.perf_counter_ns()>=budget['deadline_ns'] or time.time_ns()>=budget['deadline_wall_ns']):
            raise ValueError('Structure task delivery deadline expired before MCP content publication')
    record_image_artifact('mcp_content', native_block_count=sum(c['type']=='image' for c in content))
    return {"content": content, "isError": bool(is_error)}


class LiveSpatialMCPServer:
    """One persistent MCP process, with a stable default spatial session."""

    def __init__(self, service: Any, default_session_id: str | None = None, *, spatial_task_only=False):
        if type(spatial_task_only) is not bool:
            raise ValueError('spatial_task_only must be boolean')
        self.service = service
        self.spatial_task_only = spatial_task_only
        self.default_session_id = f"mcp-{uuid.uuid4()}" if default_session_id is None else default_session_id
        if not isinstance(self.default_session_id, str) or not self.default_session_id.strip():
            raise ValueError("default_session_id must be a nonempty string")

    @contextmanager
    def request_trace(self, name, arguments, *, mcp_request_id=_NO_RPC_ID):
        factory = getattr(self.service, 'request_trace', None)
        if not callable(factory):
            yield None
            return
        operations = {'human_eye_scene_observe': 'mcp.observe',
                      'human_eye_spatial_relations': 'mcp.observe',
                      'human_eye_surface_nearest': 'mcp.observe',
                      'human_eye_arm_twist_observe': 'mcp.arm_twist_observe',
                      'human_eye_transform': 'mcp.transform',
                      'human_eye_clearance_segment': 'mcp.clearance_segment',
                      'human_eye_connection_status': 'mcp.status'}
        args = arguments if isinstance(arguments, dict) else {}
        query = args.get('query')
        scan = isinstance(query, dict) and query.get('mode') == 'surface_scan'
        operation = operations.get(name, 'mcp.invalid') if isinstance(name, str) else 'mcp.invalid'
        with factory(operation,
                     session_id=args.get('session_id', self.default_session_id)) as trace:
            set_image_request(False if name in {'human_eye_spatial_relations', 'human_eye_surface_nearest', 'human_eye_arm_twist_observe'} else
                              args.get('include_image', False) if name == 'human_eye_clearance_segment' else
                              args.get('include_image', not scan) if name == 'human_eye_scene_observe' else
                              True if name == 'human_eye_transform' else None,
                              source_name='mcp_transport')
            if mcp_request_id is not _NO_RPC_ID:
                id_type = ('null' if mcp_request_id is None else
                           'string' if type(mcp_request_id) is str else
                           'integer' if type(mcp_request_id) is int else None)
                # Only the actual envelope ID is recorded. params._meta and
                # model-selected tool arguments confer no host identity.
                annotate(mcp_request_id=mcp_request_id, mcp_request_id_type=id_type)
            yield trace

    def _call_tool(self, name: str, arguments: dict, *, mcp_request_id=_NO_RPC_ID) -> dict:
        budget = getattr(self.service, '_request_budget', nullcontext)
        with self.request_trace(name, arguments, mcp_request_id=mcp_request_id), budget():
            annotate(request_origin='mcp')
            value = self._dispatch_tool(name, arguments)
            # Constructing native content proves transport preparation only.
            annotate(delivery='mcp_content_constructed')
            return value

    def request_error_fields(self, error=None):
        describe = getattr(self.service, 'request_error_fields', None)
        return describe(error) if callable(describe) else {}

    def _error_result(self, exc):
        metadata = {'status': 'error', 'error': str(exc),
            'tool_outcome': 'unknown', 'automatic_retry': False,
            **self.request_error_fields(exc)}
        from .live_service import StateBindingError, RequestBudgetError
        if isinstance(exc, (StateBindingError, RequestBudgetError)):
            metadata.update(exc.to_error_fields())
            metadata['allow_action'] = False
        return _tool_result(metadata, is_error=True)

    def _dispatch_tool(self, name: str, arguments: dict) -> dict:
        spatial_task = name in {tool['name'] for tool in SPATIAL_TASK_TOOLS_SCHEMA}
        if spatial_task != self.spatial_task_only:
            raise ValueError('Tool not exposed by this server mode: ' + name)
        _validate_arguments(name, arguments)
        spatial_relations = name == 'human_eye_spatial_relations'
        if spatial_relations:
            arguments = {'query': _spatial_task_query(arguments), 'include_image': False}
            name = 'human_eye_scene_observe'
        elif name == 'human_eye_surface_nearest':
            arguments = {'query': _surface_nearest_task_query(arguments), 'include_image': False}
            name = 'human_eye_scene_observe'
        bind_task_context(current_trace(), arguments.get('task_context'))
        # A service must not retain or mutate the incoming protocol message.
        args = copy.deepcopy(arguments)
        session_id = args.get("session_id", self.default_session_id)
        goal_kwargs = {"goal": args["goal"]} if "goal" in args else {}
        query_kwargs = {"query": args["query"]} if "query" in args else {}
        context_kwargs = {'task_context': args['task_context']} if 'task_context' in args else {}
        delta_kwargs = {'scene_delta': args['scene_delta']} if 'scene_delta' in args else {}
        if name == "human_eye_scene_observe":
            if isinstance(args.get('query'), dict) and args['query'].get('mode') == 'surface_scan':
                args.setdefault('include_image', False)
            value = self.service.observe(
                session_id,
                task_instruction=args.get("task_instruction", ""),
                focal_id=args.get("focal_id"), reference_id=args.get("reference_id"),
                **({'include_image': args['include_image']} if 'include_image' in args else {}),
                **goal_kwargs,
                **query_kwargs,
                **context_kwargs,
                **delta_kwargs,
            )
            is_error = value.get("status") not in {"observed", "overview", "partial"}
            if value.get('result_kind') in ('surface_nearest', 'scene_directory'):
                is_error = value.get('status') not in {'complete', 'partial'}
            if value.get('result_kind') == 'surface_scan':
                is_error = value.get('status') not in {'complete', 'partial', 'unknown'}
            if value.get('result_kind') == 'active_observation':
                is_error = value.get('status') not in {'complete', 'partial', 'unknown', 'predicted'}
            if value.get('result_kind') in ('structure_task','surface_task') and value.get('status')=='receipt':is_error=False
        elif name == 'human_eye_arm_twist_observe':
            value = self.service.observe_arm_twist(session_id, args['selection'], **context_kwargs)
            is_error = value.get('status') not in {'estimated', 'unknown'}
        elif name == "human_eye_transform":
            value = self.service.transform(session_id, args["action"], **goal_kwargs, **context_kwargs)
            is_error = value.get("status") not in {"verified", "no_op"}
        elif name == 'human_eye_clearance_segment':
            value = self.service.run_clearance_segment(session_id, args['request_id'], args['request'],
                execute=args.get('execute', False), include_image=args.get('include_image', False), **context_kwargs)
            is_error = value.get('status') not in {'preview', 'satisfied', 'review_required', 'segment_interrupted'}
        else:
            value = self.service.status()
            is_error = value.get("status") in {"blocked", "error", "unavailable", "disconnected"}
        with span('mcp.content_encode', kind='encoding'):
            if spatial_relations:
                value = _project_spatial_relations(value)
            delivery_audit = {} if value.get('result_kind') == 'active_observation' else None
            try:
                result = _tool_result(value, is_error=is_error,
                    response_detail=args.get('response_detail'),
                    segment_brief=(name == 'human_eye_clearance_segment'),
                    compact_support_planes=(name == 'human_eye_scene_observe'
                        and 'support_plane_discovery' in args.get('query', {})),
                    active_delivery_audit=delivery_audit)
            finally:
                recorder = getattr(self.service, 'record_event', None)
                if delivery_audit is not None and callable(recorder):
                    recorder('active_observation_mcp_content', session_id=session_id,
                        image_delivery=delivery_audit)
        if value.get('result_kind') in ('task_query', 'surface_nearest', 'surface_scan', 'scene_directory', 'active_observation'):
            self.service._check_request_budget('before_task_publication')
        return result

    def handle_jsonrpc_message(self, req: Any) -> dict | None:
        try:wire.validate_request(req,allow_nonfinite=True)
        except wire.RPCInputError as exc:return _rpc_error(None,exc.code,exc.message)
        method, request_id = req["method"], req.get("id")
        # JSON-RPC notifications never receive responses. They also never run
        # mutating tools, even if a malformed client sends tools/call this way.
        if "id" not in req:
            return None
        params = req.get("params", {})
        if not isinstance(params, dict):
            return _rpc_error(request_id, -32602, "params must be an object")
        if method == "initialize":
            describe = getattr(self.service, 'describe_runtime', None)
            identity = describe() if callable(describe) else runtime_identity(mode='live')
            identity = copy.deepcopy(identity)
            identity['source_file_count'] = identity.get('source_file_count', len(identity.pop('source_files', [])))
            result = {
                "protocolVersion": MCP_PROTOCOL_VERSION,
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": {"name": "human-eye-live-spatial", "version": BASE_VERSION},
                '_meta': {'human_eye': identity},
            }
        elif method == "ping":
            result = {}
        elif method == "tools/list":
            result = {"tools": copy.deepcopy(SPATIAL_TASK_TOOLS_SCHEMA if self.spatial_task_only else LIVE_MCP_TOOLS_SCHEMA)}
        elif method == "tools/call":
            if not isinstance(params.get("name"), str):
                return _rpc_error(request_id, -32602, "Tool name must be a string")
            try:
                result = self._call_tool(params["name"], params.get("arguments", {}),
                                         mcp_request_id=request_id)
            except Exception as exc:
                result = self._error_result(exc)
        else:
            return _rpc_error(request_id, -32601, f"Method not found: {method}")
        return {"jsonrpc": "2.0", "id": request_id, "result": result}


def handle_jsonrpc_message(req: Any, service: Any = None, *, server: LiveSpatialMCPServer | None = None) -> dict | None:
    """Convenience handler; reuse ``server`` for a persistent default session."""
    if server is None:
        if service is None:
            raise ValueError("A live service or server is required")
        server = LiveSpatialMCPServer(service)
    return server.handle_jsonrpc_message(req)


def run_stdio_mcp_server(service: Any, input_stream: TextIO | None = None,
                         output_stream: TextIO | None = None, *, spatial_task_only=False) -> None:
    """Serve newline-delimited MCP JSON-RPC without writing logs to stdout."""
    incoming = sys.stdin if input_stream is None else input_stream
    outgoing = sys.stdout if output_stream is None else output_stream
    server = LiveSpatialMCPServer(service, spatial_task_only=spatial_task_only)
    try:
        for req,error in wire.requests(incoming):
            if error is not None:
                if not wire.write_encoded(outgoing,wire.encode_response(error)):break
                continue
            params=req.get('params')
            traced=(req.get('method')=='tools/call' and 'id' in req and isinstance(params,dict))
            scope=server.request_trace(params.get('name'),params.get('arguments',{}),mcp_request_id=req['id']) if traced else nullcontext()
            budget=getattr(service,'_request_budget',nullcontext) if traced else nullcontext
            published=False;pipe_closed=False;write_started=False
            try:
                with budget(),scope:
                    response=server.handle_jsonrpc_message(req)
                    if response is not None:
                        terminal_error=('error' in response or response.get('result',{}).get('isError') is True)
                        try:
                            with span('mcp.wire_encode',kind='encoding'):
                                encoded=wire.encode_response(response,req,error_fields=server.request_error_fields)
                        except Exception as exc:
                            response={'jsonrpc':'2.0','id':req['id'],'result':server._error_result(exc)}
                            encoded=wire.encode_response(response,req,error_fields=server.request_error_fields)
                            terminal_error=True
                        with span('mcp.stdio_write',kind='io'):
                            check=getattr(service,'_check_request_budget',None)
                            if traced and not terminal_error and callable(check):
                                try:
                                    check('before_stdio_write',publication=True)
                                except Exception as exc:
                                    response={'jsonrpc':'2.0','id':req['id'],'result':server._error_result(exc)}
                                    # Encode the one terminal error without
                                    # renewing or rechecking its expired budget.
                                    encoded=wire.encode_response(response,req,error_fields=server.request_error_fields)
                            write_started=True
                            pipe_closed=not wire.write_encoded(outgoing,encoded)
                        if pipe_closed:break
                        published=True
                        annotate(output_bytes=len(encoded.encode('utf8')),delivery='stdio_write_completed')
            except Exception as exc:
                # Handler/encoder/trace failures belong to this request. A
                # completed write must never get a second response or dispatch.
                if pipe_closed or write_started and not published:break
                if not published and 'id' in req:
                    failure=wire.internal_error(req)
                    failure['error']['data'].update(server.request_error_fields(exc))
                    if not wire.write_encoded(outgoing,wire.encode_response(failure,req)):break
    finally:
        # EOF and actual output/input failure end the connection. No tool call
        # or write is retried; close a live host socket before returning.
        owner=service if callable(getattr(service,'close',None)) else getattr(service,'host',None)
        close=getattr(owner,'close',None)
        if callable(close):close()


def _configure_utf8_stdio() -> None:
    # MCP stdio is UTF-8, including when Windows starts Python with an ANSI
    # default encoding. Injected streams used by callers need no reconfigure.
    for stream in (sys.stdin, sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


def main(argv: list[str] | None = None, *, spatial_task_only=False) -> int:
    if type(spatial_task_only) is not bool:
        raise ValueError('spatial_task_only must be boolean')
    _configure_utf8_stdio()
    parser = argparse.ArgumentParser(description="Serve the live Human Eye Blender connection over MCP stdio")
    parser.add_argument("--config", required=True, help="Trusted local live-service configuration JSON")
    parser.add_argument('--spatial-task-only', action='store_true', default=spatial_task_only,
                        help='Expose only read-only spatial relations and global surface-nearest tasks')
    args = parser.parse_args(argv)
    from .live_service import LiveSpatialService
    try:
        service = LiveSpatialService(args.config, production_mode=True)
    except Exception as exc:
        print(f"Unable to configure live spatial service: {exc}", file=sys.stderr)
        return 2
    run_stdio_mcp_server(service, **({'spatial_task_only': True} if args.spatial_task_only else {}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
