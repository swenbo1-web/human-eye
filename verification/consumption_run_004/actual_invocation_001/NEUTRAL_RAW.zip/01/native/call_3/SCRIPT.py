import bpy,json
s=bpy.context.scene
dg=bpy.context.evaluated_depsgraph_get()
rows=[]
for o in s.objects:
 if o.type=='MESH':
  e=o.evaluated_get(dg)
  v=[tuple(float(c) for c in e.matrix_world@p.co) for p in e.data.vertices]
  faces=[tuple(p.vertices) for p in e.data.polygons]
  rows.append({'name':o.name,'evaluated_vertices_world':v,'evaluated_faces':faces,'shape_keys':o.data.shape_keys.name if o.data.shape_keys else None,'mode':o.mode})
print(json.dumps({'mesh_count':len(rows),'scale_length':s.unit_settings.scale_length,'meshes':rows},ensure_ascii=False))