import bpy,json
s=bpy.context.scene
out=[]
for o in s.objects:
 if o.type=='MESH':
  out.append({'name':o.name,'matrix_world':[list(r) for r in o.matrix_world],'vertices_world':[list(o.matrix_world@v.co) for v in o.data.vertices],'polygons':[list(p.vertices) for p in o.data.polygons],'edges':[list(e.vertices) for e in o.data.edges]})
print(json.dumps({'scale_length':s.unit_settings.scale_length,'meshes':out},ensure_ascii=False))