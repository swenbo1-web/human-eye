import bpy,json,math
dg=bpy.context.evaluated_depsgraph_get()
geoms={}
for o in bpy.context.scene.objects:
    if o.type=='MESH':
        ev=o.evaluated_get(dg)
        me=ev.data
        geoms[o.name]={'verts':[tuple(ev.matrix_world @ v.co) for v in me.vertices],'faces':[tuple(p.vertices) for p in me.polygons]}
f=geoms['M4_Focal']; fv=f['verts']
assert len(fv)==3 and f['faces']==[(0,1,2)]
assert all(v[0]==fv[0][0] for v in fv)
rows=[]
for name,g in geoms.items():
    if name=='M4_Focal':continue
    vv=g['verts']
    assert len(vv)==3 and g['faces']==[(0,1,2)]
    assert all(v[0]==vv[0][0] for v in vv)
    assert all(vv[i][1:]==fv[i][1:] for i in range(3))
    rows.append({'name':name,'distance_m':abs(vv[0][0]-fv[0][0])*bpy.context.scene.unit_settings.scale_length})
print(json.dumps({'mode':bpy.context.mode,'evaluated_mesh_count':len(geoms),'mesh_instances':[{'name':i.object.name,'is_instance':i.is_instance} for i in dg.object_instances if i.object.type=='MESH'],'distances':rows,'basis':'All evaluated triangles have identical yz projections and constant x; x separation is a lower bound attained by corresponding points.'},ensure_ascii=False))