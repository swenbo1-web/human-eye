import bpy, json
from mathutils import Vector
scene=bpy.context.scene
print(json.dumps({'scene':scene.name,'unit_system':scene.unit_settings.system,'scale_length':scene.unit_settings.scale_length,'objects':[{'name':o.name,'type':o.type,'vertices':len(o.data.vertices) if o.type=='MESH' else None,'polygons':len(o.data.polygons) if o.type=='MESH' else None,'modifiers':[m.type for m in o.modifiers] if o.type=='MESH' else [],'hide_viewport':o.hide_viewport,'hide_render':o.hide_render} for o in scene.objects]},ensure_ascii=False))