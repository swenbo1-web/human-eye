import bpy,json
rows=[]
for obj in bpy.context.scene.objects:
    if obj.type!='MESH': continue
    mesh=obj.data
    rows.append({'name':obj.name,'matrix_world':[list(r) for r in obj.matrix_world],'world_vertices':[list(obj.matrix_world @ v.co) for v in mesh.vertices],'polygons':[list(p.vertices) for p in mesh.polygons]})
print(json.dumps(rows,ensure_ascii=False))