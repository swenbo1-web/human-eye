import bpy, json
from mathutils import Vector
scene = bpy.context.scene
dg = bpy.context.evaluated_depsgraph_get()
records = []
for obj in sorted(scene.objects, key=lambda o: o.name):
    if obj.type != 'MESH':
        continue
    ev = obj.evaluated_get(dg)
    mesh = ev.to_mesh()
    try:
        mesh.calc_loop_triangles()
        records.append({'name': obj.name, 'vertices_world': [list(ev.matrix_world @ v.co) for v in mesh.vertices], 'triangles': [list(t.vertices) for t in mesh.loop_triangles], 'polygons': [list(p.vertices) for p in mesh.polygons], 'modifiers': [{'name': m.name, 'type': m.type} for m in obj.modifiers]})
    finally:
        ev.to_mesh_clear()
print(json.dumps({'scene': scene.name, 'unit_system': scene.unit_settings.system, 'scale_length': scene.unit_settings.scale_length, 'meshes': records, 'instance_count': sum(1 for x in dg.object_instances if x.is_instance)}, ensure_ascii=False))