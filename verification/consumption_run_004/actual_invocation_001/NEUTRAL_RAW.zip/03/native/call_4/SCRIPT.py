import bpy, json, math
from mathutils import Vector
scene = bpy.context.scene
dg = bpy.context.evaluated_depsgraph_get()
summary = []
for obj in sorted(scene.objects, key=lambda o: o.name):
    if obj.type != 'MESH':
        continue
    ev = obj.evaluated_get(dg)
    mesh = ev.to_mesh()
    try:
        mesh.calc_loop_triangles()
        vv = [tuple(ev.matrix_world @ v.co) for v in mesh.vertices]
        tt = [tuple(t.vertices) for t in mesh.loop_triangles]
        deg = []
        for i,t in enumerate(tt):
            a,b,c = (Vector(vv[j]) for j in t)
            if (b-a).cross(c-a).length_squared == 0:
                deg.append({'triangle_index': i, 'vertices': [vv[j] for j in t]})
        summary.append({'name':obj.name,'vertex_count':len(vv),'triangle_count':len(tt),'polygon_sizes':sorted(set(len(p.vertices) for p in mesh.polygons)), 'aabb_min':[min(v[k] for v in vv) for k in range(3)] if vv else None,'aabb_max':[max(v[k] for v in vv) for k in range(3)] if vv else None, 'degenerate_triangles':deg,'small_geometry':{'vertices':vv,'triangles':tt} if len(tt)<5 else None,'modifiers':len(obj.modifiers)})
    finally:
        ev.to_mesh_clear()
print(json.dumps({'unit_system':scene.unit_settings.system,'scale_length':scene.unit_settings.scale_length,'meshes':summary,'instance_count':sum(1 for x in dg.object_instances if x.is_instance)},ensure_ascii=False))