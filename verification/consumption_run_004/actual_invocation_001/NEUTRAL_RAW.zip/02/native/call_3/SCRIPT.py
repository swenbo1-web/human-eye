import bpy, json
scene=bpy.context.scene
out={'scene':scene.name,'unit_system':scene.unit_settings.system,'scale_length':scene.unit_settings.scale_length,'objects':[]}
for obj in scene.objects:
    if obj.type != 'MESH':
        continue
    mesh=obj.data
    mesh.calc_loop_triangles()
    out['objects'].append({'name':obj.name,'vertices_world':[list(obj.matrix_world @ v.co) for v in mesh.vertices], 'triangles':[list(t.vertices) for t in mesh.loop_triangles], 'modifiers':[{'name':m.name,'type':m.type,'show_viewport':m.show_viewport} for m in obj.modifiers], 'hide_viewport':obj.hide_viewport})
print(json.dumps(out,ensure_ascii=False))