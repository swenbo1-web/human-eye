import bpy, json
scene = bpy.context.scene
depsgraph = bpy.context.evaluated_depsgraph_get()
readout = {'scene_name': scene.name, 'unit_system':scene.unit_settings.system, 'scale_length':scene.unit_settings.scale_length, 'meshes':[]}
for obj in scene.objects:
    if obj.type != 'MESH':
        continue
    eobj = obj.evaluated_get(depsgraph)
    mesh = eobj.to_mesh()
    try:
        mesh.calc_loop_triangles()
        readout['meshes'].append({'name':obj.name, 'vertices_world':[list(eobj.matrix_world @ v.co) for v in mesh.vertices], 'triangles':[list(t.vertices) for t in mesh.loop_triangles], 'raw_vertices':len(obj.data.vertices), 'raw_polygons':len(obj.data.polygons), 'modifiers':[m.type for m in obj.modifiers]})
    finally:
        eobj.to_mesh_clear()
print(json.dumps(readout,ensure_ascii=False))