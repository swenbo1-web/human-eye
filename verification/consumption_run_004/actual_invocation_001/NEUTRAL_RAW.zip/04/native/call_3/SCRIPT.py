import bpy, json, math
scene=bpy.context.scene
dg=bpy.context.evaluated_depsgraph_get()
records=[]
for o in scene.objects:
    if o.type!='MESH': continue
    e=o.evaluated_get(dg)
    vs=[tuple(sum(float(e.matrix_world[i][j])*float(v.co[j]) for j in range(3))+float(e.matrix_world[i][3]) for i in range(3)) for v in e.data.vertices]
    faces=[tuple(p.vertices) for p in e.data.polygons]
    records.append({'name':o.name,'evaluated_vertex_count':len(vs),'evaluated_face_count':len(faces),'all_faces_triangles':all(len(f)==3 for f in faces),'world_bounds_m':[[min(v[i] for v in vs)*scene.unit_settings.scale_length,max(v[i] for v in vs)*scene.unit_settings.scale_length] for i in range(3)],'nonfinite':any(not math.isfinite(c) for v in vs for c in v),'shape_keys':o.data.shape_keys is not None,'world_vertices_m':[[c*scene.unit_settings.scale_length for c in v] for v in vs] if len(vs)==3 else None,'faces':faces if len(vs)==3 else None})
print(json.dumps({'mesh_object_count':len(records),'mode':bpy.context.mode,'evaluated_geometry':records},ensure_ascii=False))