import bpy, json, math
scene=bpy.context.scene
readout=[]
for o in scene.objects:
    if o.type!='MESH': continue
    m=o.data
    vs=[tuple(sum(float(o.matrix_world[i][j])*float(v.co[j]) for j in range(3))+float(o.matrix_world[i][3]) for i in range(3)) for v in m.vertices]
    tris=[tuple(p.vertices) for p in m.polygons if len(p.vertices)==3]
    deg=[]
    for ti,t in enumerate(tris):
        a,b,c=[vs[i] for i in t]
        u=[b[i]-a[i] for i in range(3)]; v=[c[i]-a[i] for i in range(3)]
        n=(u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])
        if all(x==0 for x in n): deg.append(ti)
    d={'name':o.name,'vertices':len(vs),'polygons':len(m.polygons),'triangle_count':len(tris),'nontriangles':[p.index for p in m.polygons if len(p.vertices)!=3],'bounds':[[min(v[i] for v in vs),max(v[i] for v in vs)] for i in range(3)],'degenerate_triangles':deg,'nonfinite':any(not math.isfinite(x) for v in vs for x in v)}
    if len(vs)<=3: d['world_vertices']=vs; d['triangles']=tris
    readout.append(d)
print(json.dumps(readout,ensure_ascii=False))