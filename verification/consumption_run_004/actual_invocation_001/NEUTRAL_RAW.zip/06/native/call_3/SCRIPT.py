import bpy, json
s=bpy.context.scene
out={'unit_system':s.unit_settings.system,'scale_length':s.unit_settings.scale_length,'objects':[]}
for o in s.objects:
    if o.type=='MESH':
        m=o.data
        out['objects'].append({'name':o.name,'matrix_world':[list(row) for row in o.matrix_world],'vertices':[list(o.matrix_world @ v.co) for v in m.vertices],'polygons':[list(p.vertices) for p in m.polygons],'modifiers':[{'name':q.name,'type':q.type,'show_viewport':q.show_viewport} for q in o.modifiers]})
print(json.dumps(out,ensure_ascii=False))