from pathlib import Path
import sys
Path('D:\\he_m1_source_region_no_image_measurement_consumption_001\\offline_runtime_01\\B1_exit_probe\\STDIN.bin').write_bytes(sys.stdin.buffer.read())
print("transfer offline early exit", file=sys.stderr)
raise SystemExit(7)
