"""Reconstruct post-close accounting using the frozen 28-object capture verifier."""

from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import sys


RUNTIME = Path(__file__).resolve().parents[1]
OUT = RUNTIME / 'postanalysis'
NS = Path(sys.argv[1]).resolve(strict=True)
FROZEN = NS / 'FROZEN.json'
TRACE = NS / 'analysis/consumption.py'
EVIDENCE = NS / 'checks/evidence.py'


def read(path):
    return json.loads(path.read_bytes())


def write(name, data):
    with (OUT / name).open('x', encoding='utf8', newline='\n') as stream:
        json.dump(data, stream, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write('\n')


def main():
    paths = (TRACE, EVIDENCE)
    original = read(FROZEN)
    pins = {Path(row['path']): row for row in original['direct_inputs']}
    for path in paths:
        pin = pins[path]
        assert pin['sha256'] == sha256(path.read_bytes()).hexdigest() and pin['bytes'] == path.stat().st_size

    account = run_path(str(TRACE))
    verify = run_path(str(EVIDENCE))
    quality = {label: read(OUT / f'{label}_QUALITY.json') for label in account['LABELS']}
    judgments = read(OUT / 'TRACE_JUDGMENTS.json')
    unchanged = account['analyze'](RUNTIME, FROZEN, quality, judgments)
    for label, outcome in unchanged['slots'].items():
        rejected = [error for error in outcome['verification_errors']
                    if error.endswith('full_owned_current_object_roster_required')]
        assert len(rejected) == 2, (label, outcome['verification_errors'])
    assert not unchanged['same_closed_quality']
    write('ORIGINAL_ACCOUNTING_BLOCKED.json', unchanged)
    write('QUALITY.json', quality)

    def current_capture(capture, source, names, *, revision, scope, generation=None, epoch=None):
        assert scope == 'selected_objects' and capture['capture_state'] == generation
        assert capture['host_identity']['document_epoch'] == epoch
        return verify['prove_capture'](capture, source, names, revision=revision)

    account['D']['E']['prove_capture'] = current_capture
    reconstructed = account['analyze'](RUNTIME, FROZEN, quality, judgments)
    pair_proofs = {}
    for label, data in reconstructed['slots'].items():
        assert not data['verification_errors'], (label, data['verification_errors'])
        slot = RUNTIME / 'slots' / label
        record = account['C']['read'](slot / 'SLOT_RESULT.json')
        terminal, _ = account['source_state'](slot, record)
        binding = account['C']['read'](account['BINDINGS'][label])
        calls = {row['attempt']: row for row in data['actual_requests']}
        assert all(data['pairs'][ref]['first_whole_attempt'] is not None for ref in account['REFERENCES'])
        pair_proofs[label] = {}
        for ref in account['REFERENCES']:
            call = calls[data['pairs'][ref]['first_whole_attempt']]
            product = call['product']
            req = read(Path(product['request_file']['path']))
            envelope, = [e for e in account['OLD']['lines'](slot/'PUBLIC_REQUESTS.jsonl')
                         if e['request']['id'] == req['id']]
            producer = read(Path(product['producer_archive']['path']))
            _, capture = account['D']['H']['slot_capture'](slot, binding, {**envelope, 'producer': producer},
                                                          lambda path: account['P']['inside'](slot, path).read_bytes())
            reply = read(Path(call['stdio_RX']['path']))
            pair_proofs[label][ref] = verify['verify_pair'](ref, reply, producer, capture, terminal, binding,
                                                          require_source=label == 'B1')

    reconstructed['original_accounting_retained'] = 'ORIGINAL_ACCOUNTING_BLOCKED.json'
    reconstructed['post_close_adapter'] = {
        'issue': 'Inherited prior task capture verifier read through a 21-object truth parser.',
        'correction': 'Use the frozen current 28-object selected-capture verifier for the same held wires. '
                      'Keep exact scene revision, current capture generation, epoch and source array reconciliation.',
        'frozen_inputs_unchanged': True,
        'actual_trials_repeated': 0,
        'source_pins': [pins[path] for path in paths],
    }
    reconstructed['first_natural_whole_packet_proofs'] = pair_proofs
    reconstructed['fixed_CLI_natural_whole_stages'] = 6 * sum(len(rows) for rows in pair_proofs.values())
    write('CONSUMPTION_TRACE.json', reconstructed)


if __name__ == '__main__':
    main()
