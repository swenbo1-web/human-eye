import json as _json, contextlib as _cl, io as _io
_request = _json.loads('{"id":"957342bca07d4760b831f756730b0f12","command":"capture","params":{}}')
try:
    import sys as _sys
    _module = _sys.modules.get('_human_eye_mcp_resident_f7e0e626c38e70ef27df')
    if _module is None or getattr(_module, '_resident_tag', None) != '588f12a5001adb5df66b57ca8f8f2c3c20207192b6d141bd3ef8c7e01cb7d7f0': raise RuntimeError('Resident Blender host unavailable; reconnect with a new connector')
    _host = _module._mcp_resident_host
    with _cl.redirect_stdout(_io.StringIO()):
        _result = getattr(_host, 'capture_scene')(**_request['params'])
    _result = _host.capture_delta(_result, _json.loads('{"instance_id":"38e861843eb24f8f87d6e4fd16b05268","epoch":1,"resources":{"mesh:(\'uid\', 174)":1,"mesh:(\'uid\', 178)":2,"mesh:(\'uid\', 160)":3,"mesh:(\'uid\', 185)":4,"mesh:(\'uid\', 161)":5,"mesh:(\'uid\', 184)":6,"mesh:(\'uid\', 180)":7,"mesh:(\'uid\', 164)":8,"mesh:(\'uid\', 166)":9,"mesh:(\'uid\', 176)":10,"mesh:(\'uid\', 173)":11,"mesh:(\'uid\', 171)":12,"mesh:(\'uid\', 187)":13,"mesh:(\'uid\', 170)":14,"mesh:(\'uid\', 163)":15,"mesh:(\'uid\', 165)":16,"mesh:(\'uid\', 179)":17,"mesh:(\'uid\', 162)":18,"mesh:(\'uid\', 182)":19,"mesh:(\'uid\', 183)":20,"mesh:(\'uid\', 168)":21,"mesh:(\'uid\', 181)":22,"mesh:(\'uid\', 172)":23,"mesh:(\'uid\', 186)":24,"mesh:(\'uid\', 175)":25,"mesh:(\'uid\', 169)":26,"mesh:(\'uid\', 177)":27,"mesh:(\'uid\', 167)":28}}'))
    _envelope = {'protocol_version': '1.0', 'id': _request['id'], 'result': _result}
except Exception as _exc:
    _envelope = {'protocol_version': '1.0', 'id': _request['id'], 'error': {'type': type(_exc).__name__, 'message': str(_exc)[:2000], 'mutation_uncertain': _request['command'] == 'apply'}}
print('HUMAN_EYE_BLENDER_MCP:' + _json.dumps(_envelope, ensure_ascii=True, allow_nan=False, separators=(',', ':')))